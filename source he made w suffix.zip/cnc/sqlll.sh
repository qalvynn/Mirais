#!/bin/bash

while true; do
    service mariadb restart
    sleep 200
done
