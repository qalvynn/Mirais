package telegram

import "strconv"

func isAdmin(userID int, admins []string) bool { /* trash system, don't care */
	uidStr := strconv.Itoa(userID)

	for _, admin := range admins {
		if admin == uidStr {
			return true
		}
	}

	return false
}
