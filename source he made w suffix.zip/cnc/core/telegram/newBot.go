package telegram

import (
	"cnc/core/config"
	"fmt"
	"github.com/go-telegram-bot-api/telegram-bot-api"
	"log"
)

func Init() {
	bot, err := tgbotapi.NewBotAPI(config.Config.Telegram.BotToken)
	if err != nil {
		fmt.Println(err)
	}

	bot.Debug = false

	log.Printf("Authorized on account %s", bot.Self.UserName)

	err = HandleCommand(bot)
	if err != nil {
		fmt.Println(err)
	}
}
