package database

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"log"
)

type Database struct {
	db *sql.DB
}

var DatabaseConnection *Database

func NewDatabase(dbURL string) *Database {
	db, err := sql.Open("mysql", dbURL)
	if err != nil {
		log.Fatal(err)
	}

	createTables(db)
	createEvent(db)

	fmt.Println("Database connection initiated.")
	DatabaseConnection = &Database{db}
	return nil
}
