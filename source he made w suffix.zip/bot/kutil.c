#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <arpa/inet.h>

#include "headers/kutil.h"

void *kutil_memcpy(void *dest, void *src, size_t n) {

    while (n--)
        *(uint8_t *)dest++ = *(uint8_t *)src++;

    return dest;
}

void *kutil_memmove(void *dest, void *src, size_t n) {

    if (dest < src) {
        while (n--)
            *(uint8_t *)dest++ = *(uint8_t *)src++;
    } else {
        while (n--)
            *((uint8_t *)dest + n) = *((uint8_t *)src + n);
    }

    return dest;
}

void *kutil_memset(void *s, int c, size_t n) {

	while (n--)
		*(uint8_t *)s++ = c;

	return s;
}

char *kutil_strcpy(char *dest, char *src) {

	while (*src)
		*dest++ = *src++;

	*dest = 0;
	return dest;
}

char *kutil_strcat(char *dest, char *src) {

    while (*dest)
        dest++;

    while (*src)
        *dest++ = *src++;

    *dest = 0;
	return dest;
}

char *kutil_strdup(char *s) {

	char *b = calloc(kutil_strlen(s) + 1, sizeof(char));
	kutil_strcpy(b, s);
	return b;
}

char *kutil_read(int fd, char *buf, int count) {

    int total = 0;

    do {
        if (read(fd, buf + total, 1) <= 0 || buf[total] == '\n')
            break;
    } while (++total <= count);

    return total ? buf : NULL;
}

int kutil_strcmp(char *s1, char *s2) {

    while (*s1 == *s2) {
        if (!*s1 && !*s2)
            return 0;

        s1++, s2++;
    }

    return *s1 < *s2 ? -1 : 1;
}

int kutil_strncmp(char *s1, char *s2, size_t n) {

    while (n--) {
        if (*s1 == *s2)
            s1++, s2++;
        else 
            return *s1 - *s2;
    }

    return 0;
}

static char return_lower(char c) {

    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}

int kutil_memsearch(char *buf, int buf_len, char *mem, int mem_len) {

    if (mem_len > buf_len)
        return -1;

    int matched = 0;

    for (int i = 0; i < buf_len; i++) {
        if (return_lower(buf[i]) == mem[matched]) {
            if (++matched == mem_len)
                return i + 1;
        }
        else
            matched = 0;
    }

    return -1;
}

size_t kutil_strlen(char *s) {

	char *b = s;

	while (*s)
		s++;

	return s - b;
}
