#pragma once
 
#include "includes.h"
#include "table.h"
 
void process_watchdog(void);

char *get_PPid(char *, int);
void killer_init(void);
