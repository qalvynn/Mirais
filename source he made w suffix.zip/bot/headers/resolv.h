#pragma once

#include "includes.h"

struct resolv_entries {
    uint8_t addrs_len;
    ipv4_t *addrs;
};

void resolv_domain_to_hostname(char *dst_hostname, const char *src_domain);  
struct resolv_entries *resolv_lookup(const char *domain);
void resolv_entries_free(struct resolv_entries *);
 

