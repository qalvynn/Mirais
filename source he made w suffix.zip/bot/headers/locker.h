#pragma once

typedef struct locker {
    int pro_id;
    struct locker* left, *right;
} locker;

void locker_init(int pipe[2]);
