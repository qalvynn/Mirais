#pragma once

#include <stdint.h>
#include <unistd.h>

#define INET_ADDR(o1, o2, o3, o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

extern uint32_t local_addr;

void *kutil_memcpy(void *, void *, size_t);
void *kutil_memmove(void *, void *, size_t);
void *kutil_memset(void *, int, size_t);

char *kutil_strcpy(char *, char *);
char *kutil_strcat(char *, char *);
char *kutil_strdup(char *);
char *kutil_read(int, char *, int);

int kutil_strcmp(char *, char *);
int kutil_strncmp(char *, char *, size_t);
int kutil_memsearch(char *, int, char *, int);

size_t kutil_strlen(char *);
