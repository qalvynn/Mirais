void locksh_init(void);
