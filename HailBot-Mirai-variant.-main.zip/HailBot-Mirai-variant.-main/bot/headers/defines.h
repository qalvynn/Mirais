#ifndef DEFINES_H
#define DEFINES_H
#include <stdint.h>
typedef uint32_t ipv4_t;
typedef uint16_t port_t;
typedef char BOOL;
extern ipv4_t LOCAL_ADDR;

#define FALSE   0
#define TRUE    1
#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))
#define STDIN   0
#define STDOUT  1
#define STDERR  2
#endif // DEFINES_H
