#pragma once

void user_acception(void);
