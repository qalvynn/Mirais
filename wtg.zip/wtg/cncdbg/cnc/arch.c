#include <stdio.h>
#include <string.h>

#include "bool.h"
#include "arch.h"

struct arch_t arch_info[MAX_ARCHS];

static int find_arch(char *arch) {

	for (int i = 0; i < MAX_ARCHS; i++) {
		if (!strcmp(arch, arch_info[i].arch))
			return i;
	}

	return -1;
}

static int add_arch(char *arch) {

	for (int i = 0; i < MAX_ARCHS; i++) {
		if (!arch_info[i].count) {
			strcpy(arch_info[i].arch, arch);
			return i;
		}
	}

	return -1;
}

void update_arch(char *arch, BOOL opt) {

	int loc = find_arch(arch);

	if (opt) {
		if (loc == -1) {
			if ((loc = add_arch(arch)) == -1) {
				printf("[update_arch] add_arch() failed\n");
				return;
			}
		}
		
		arch_info[loc].count++;
	}
	else {
		if (loc != -1 && --arch_info[loc].count <= 0)
			memset(&arch_info[loc], 0, sizeof(struct arch_t));
	}
}
