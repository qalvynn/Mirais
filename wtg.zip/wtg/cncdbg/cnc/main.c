#include <signal.h>
#include <sys/stat.h>

#include "epoll.h"
#include "user.h"

int main(void) {

    signal(SIGPIPE, SIG_IGN);

    if (!epoll_init())
        return 1;

    mkdir("logs/", 0700);
    mkdir("logs/attacks/", 0700);

    user_acception();

    return 0;
}
