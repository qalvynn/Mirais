#pragma once

void rc4(char *, int);
