#pragma once

#include "bool.h"

#define MAX_ARCHS 128

extern struct arch_t {
	int count;
	char arch[32];
} arch_info[MAX_ARCHS];

void update_arch(char *, BOOL);
