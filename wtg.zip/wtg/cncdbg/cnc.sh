#!/bin/bash

while true; do
    ulimit -n 999999
    ./a.out
done
