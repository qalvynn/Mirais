#pragma once

#include <stdint.h>

void rand_init(void);
void rand_str(char *, int);
void rand_hex(char *, int);

uint32_t rand_next(void);
uint32_t rand_next_range(uint32_t, uint32_t);
