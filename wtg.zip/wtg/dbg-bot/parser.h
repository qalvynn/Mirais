#pragma once

void command_parser(char *);
void dyn_parse(char *);
