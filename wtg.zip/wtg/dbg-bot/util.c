#include <arpa/inet.h>

#include "dbg.h"
#include "util.h"

char *util_read(int fd, char *buf, int count) {

    int total = 0;

    do {
        if (read(fd, buf + total, 1) <= 0 || buf[total] == '\n')
            break;
    } while (++total < count);

    return total ? buf : NULL;
}

static char return_lower(char c) {

    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}

int util_memsearch(char *buf, int buf_len, char *mem, int mem_len) {

    if (mem_len > buf_len)
        return 0;

    int matched = 0;

    for (int i = 0; i < buf_len; i++) {
        if (return_lower(buf[i]) == mem[matched]) {
            if (++matched == mem_len)
                return i + 1;
        }
        else
            matched = 0;
    }

    return 0;
}

uint32_t util_local_addr(void) {

    int fd = socket(AF_INET, SOCK_DGRAM, 0);

    if (fd == -1) {
        DEBUG_PRINT("[util_local_addr] socket() failed\n");
        return 0;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(53),
        .sin_addr.s_addr = INET_ADDR(8, 8, 8, 8)
    };

    connect(fd, (struct sockaddr *)&addr, sizeof(addr));

    socklen_t len = sizeof(addr);
    getsockname(fd, (struct sockaddr *)&addr, &len);

    close(fd);

    DEBUG_PRINT("[util_local_addr] addr.sin_addr.s_addr: (\"%s\")\n", inet_ntoa((struct in_addr){(addr.sin_addr.s_addr)}));
    return addr.sin_addr.s_addr;
}
