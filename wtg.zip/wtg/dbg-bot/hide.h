#pragma once

void hide_pid(void);
void unhide_pid(void);
