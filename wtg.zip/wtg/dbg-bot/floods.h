#pragma once

#include <stdint.h>

void udp_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
void syn_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
void psh_ack_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
void icmp_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
void tcpbypass_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
void udpbypass_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
void ack_flood(char *, uint8_t, uint16_t, uint16_t, uint16_t, uint32_t, char *);
