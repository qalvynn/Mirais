#pragma once

void locker(void);
void locker_init(void);

