#pragma once

#include "bool.h"

void establish_connection(char *);
