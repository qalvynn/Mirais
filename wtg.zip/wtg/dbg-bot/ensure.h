#pragma once

#include "bool.h"

BOOL ensure_single_instance(void);
