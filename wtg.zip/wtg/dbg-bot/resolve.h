#pragma once

#include <stdint.h>

struct dns_result {
    uint32_t *ips;
    int count;
};

struct dns_result resolve_domain(char *, BOOL);
struct dns_result rand_addr(void);

void free_dns_result(struct dns_result *);
