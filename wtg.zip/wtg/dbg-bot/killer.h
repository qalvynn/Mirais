#pragma once

void killer_init(void);
