#pragma once

#include <stdint.h>
#include "bool.h"

#define TSHARK 0
#define WIRESHARK 1
#define TCPDUMP 2
#define QEMU 3
#define ANYRUN 4
#define DUMPCAP 5

#define LIBPCAP 6
#define LIBWIRESHARK 7
#define LIBWAYLANDCLIENT 8

#define CMDLINE 9
#define PROC 10
#define MAPS 11

typedef struct {
    char *str;
    int len;
} atable_t;

extern atable_t *atable;

void adbg_init(void);
int adbg(void);
