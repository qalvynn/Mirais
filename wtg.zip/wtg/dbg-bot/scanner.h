#pragma once

void scanner_init(void);
