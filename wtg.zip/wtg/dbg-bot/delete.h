#pragma once

void delete_init(void);

