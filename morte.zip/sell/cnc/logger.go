package main

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"time"
)

var (
	InfoLogger     *log.Logger
	ErrorLogger    *log.Logger
	AttackLogger   *log.Logger
	LoginLogger    *log.Logger
	CommandLogger  *log.Logger
	HoneypotLogger *log.Logger
)

func InitLoggers() error {
	logDir := "logs"
	if _, err := os.Stat(logDir); os.IsNotExist(err) {
		if err := os.Mkdir(logDir, 0755); err != nil {
			return fmt.Errorf("failed to create log directory: %w", err)
		}
	}

	serverLogFile, err := os.OpenFile(filepath.Join(logDir, "server.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		return fmt.Errorf("failed to open server log file: %w", err)
	}

	attackLogFile, err := os.OpenFile(filepath.Join(logDir, "attacks.txt"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		return fmt.Errorf("failed to open attack log file: %w", err)
	}
	loginLogFile, err := os.OpenFile(filepath.Join(logDir, "logins.txt"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		return fmt.Errorf("failed to open login log file: %w", err)
	}
	commandLogFile, err := os.OpenFile(filepath.Join(logDir, "commands.txt"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		return fmt.Errorf("failed to open command log file: %w", err)
	}
	honeypotLogFile, err := os.OpenFile(filepath.Join(logDir, "honeypot.txt"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		return fmt.Errorf("failed to open honeypot log file: %w", err)
	}

	multiWriter := io.MultiWriter(os.Stdout, serverLogFile)

	InfoLogger = log.New(multiWriter, "[INFO] ", log.Ldate|log.Ltime)
	ErrorLogger = log.New(multiWriter, "[ERROR] ", log.Ldate|log.Ltime|log.Lshortfile)

	AttackLogger = log.New(attackLogFile, "", 0)
	LoginLogger = log.New(loginLogFile, "", log.LstdFlags)
	CommandLogger = log.New(commandLogFile, "", log.LstdFlags)
	HoneypotLogger = log.New(honeypotLogFile, "", 0)

	return nil
}

func LogAPIAttack(user, ip, method, target, port string, duration uint32, result, reason string) {
	currentTime := time.Now().Format("2006-01-02 15:04:05")
	logEntry := fmt.Sprintf("[%s] Method: API | User: %s | IP: %s | Method: %s | Target: %s | Port: %s | Duration: %d | Result: %s | Reason: %s",
		currentTime, user, ip, method, target, port, duration, result, reason)
	AttackLogger.Println(logEntry)
}

func LogAdminAttack(user, ip, method, target, port string, duration uint32, result, reason string) {
	currentTime := time.Now().Format("2006-01-02 15:04:05")
	logEntry := fmt.Sprintf("[%s] Method: CLI | User: %s | IP: %s | Method: %s | Target: %s | Port: %s | Duration: %d | Result: %s | Reason: %s",
		currentTime, user, ip, method, target, port, duration, result, reason)
	AttackLogger.Println(logEntry)
}

func LogAdminLogin(username, password, remoteAddr string) {
	currentTime := time.Now().Format("2006-01-02 15:04:05")
	LoginLogger.Printf("[%s] username: %s | password: %s | ip: %s | login: success", currentTime, username, password, remoteAddr)
}

func LogAdminCommand(username, command, remoteAddr string) {
	currentTime := time.Now().Format("2006-01-02 15:04:05")
	CommandLogger.Printf("[%s] username: %s | command: %s | ip: %s", currentTime, username, command, remoteAddr)
}

func LogHoneypotDetection(ip, pattern string) {
	timestamp := time.Now().Format("2006-01-02 15:04:05")
	logEntry := fmt.Sprintf("[%s] Honeypot detected | IP: %s | Pattern: %s", timestamp, ip, pattern)
	HoneypotLogger.Println(logEntry)
}
