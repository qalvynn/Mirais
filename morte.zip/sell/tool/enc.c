#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <arpa/inet.h>

static uint32_t table_key = 0x5FF176B1;

void *xor_encrypt(void *data, int len);

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <string | ip | uint32 | uint16 | uint8 | bool> <data>\n", argv[0]);
        return 1;
    }

    void *data = NULL;
    int len = 0;
    void *allocated = NULL;

    if (strcmp(argv[1], "string") == 0) {
        data = argv[2];
        len = strlen(argv[2]) + 1;
    } else if (strcmp(argv[1], "ip") == 0) {
        allocated = data = calloc(1, sizeof(uint32_t));
        if (!data) {
            fprintf(stderr, "Memory allocation failed\n");
            return 1;
        }
        if (inet_pton(AF_INET, argv[2], data) != 1) {
            fprintf(stderr, "Invalid IP address: %s\n", argv[2]);
            free(data);
            return 1;
        }
        len = sizeof(uint32_t);
    } else if (strcmp(argv[1], "uint32") == 0) {
        allocated = data = calloc(1, sizeof(uint32_t));
        if (!data) {
            fprintf(stderr, "Memory allocation failed\n");
            return 1;
        }
        char *endptr;
        uint32_t num = strtoul(argv[2], &endptr, 10);
        if (*endptr != '\0') {
            fprintf(stderr, "Invalid uint32: %s\n", argv[2]);
            free(data);
            return 1;
        }
        *(uint32_t *)data = htonl(num);
        len = sizeof(uint32_t);
    } else if (strcmp(argv[1], "uint16") == 0) {
        allocated = data = calloc(1, sizeof(uint16_t));
        if (!data) {
            fprintf(stderr, "Memory allocation failed\n");
            return 1;
        }
        char *endptr;
        uint32_t num = strtoul(argv[2], &endptr, 10);
        if (*endptr != '\0' || num > UINT16_MAX) {
            fprintf(stderr, "Invalid uint16: %s\n", argv[2]);
            free(data);
            return 1;
        }
        *(uint16_t *)data = htons((uint16_t)num);
        len = sizeof(uint16_t);
    } else if (strcmp(argv[1], "uint8") == 0) {
        allocated = data = calloc(1, sizeof(uint8_t));
        if (!data) {
            fprintf(stderr, "Memory allocation failed\n");
            return 1;
        }
        char *endptr;
        uint32_t num = strtoul(argv[2], &endptr, 10);
        if (*endptr != '\0' || num > UINT8_MAX) {
            fprintf(stderr, "Invalid uint8: %s\n", argv[2]);
            free(data);
            return 1;
        }
        *(uint8_t *)data = (uint8_t)num;
        len = sizeof(uint8_t);
    } else if (strcmp(argv[1], "bool") == 0) {
        allocated = data = calloc(1, sizeof(char));
        if (!data) {
            fprintf(stderr, "Memory allocation failed\n");
            return 1;
        }
        if (strcmp(argv[2], "false") == 0) {
            ((char *)data)[0] = 0;
        } else if (strcmp(argv[2], "true") == 0) {
            ((char *)data)[0] = 1;
        } else {
            fprintf(stderr, "Unknown value `%s` for datatype bool!\n", argv[2]);
            free(data);
            return 1;
        }
        len = sizeof(char);
    } else {
        fprintf(stderr, "Unknown data type `%s`!\n", argv[1]);
        return 1;
    }

    printf("XOR'ing %d bytes of data...\n", len);
    void *encrypted = xor_encrypt(data, len);
    if (!encrypted) {
        fprintf(stderr, "Encryption failed\n");
        if (allocated) free(allocated);
        return 1;
    }

    for (int i = 0; i < len; i++) {
        printf("\\x%02X", ((unsigned char *)encrypted)[i]);
    }
    printf("\n");

    free(encrypted);
    if (allocated) free(allocated);
    return 0;
}

void *xor_encrypt(void *_buf, int len) {
    unsigned char *buf = (unsigned char *)_buf;
    unsigned char *out = malloc(len);
    if (!out) return NULL;

    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for (int i = 0; i < len; i++) {
        char tmp = buf[i] ^ k1;
        tmp ^= k2;
        tmp ^= k3;
        tmp ^= k4;
        out[i] = tmp;
    }

    return out;
}