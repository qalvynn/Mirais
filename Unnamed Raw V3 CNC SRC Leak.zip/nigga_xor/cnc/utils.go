package main

import (
    "strings"
)

var xorKey = []byte("OCxEvDGpReAZxQJqK0UR1yyF9IobL8R4")

func xorCrypt(data []byte) {
    for i := 0; i < len(data); i++ {
        data[i] ^= xorKey[i%len(xorKey)]
    }
}

func extractMethod(command string) string {
    parts := strings.Fields(command)
    if len(parts) > 0 {
        return parts[0] // Assumes method is the first field
    }
    return "Unknown"
}

func extractFlags(command string) string {
    parts := strings.Fields(command)
    var flags []string

    for _, part := range parts {
        if strings.Contains(part, "=") {
            flags = append(flags, part)
        }
    }

    return strings.Join(flags, ", ")
}

func extractTarget(command string) string {
    parts := strings.Fields(command)
    if len(parts) > 1 {
        return parts[1] // Assumes target IP is the second field
    }
    return "Unknown"
}
