#pragma once

static int base64_char_value(char c);
char *base64_decode(const char *base64_str);
char *base64_decode_xor(const char *base64_str, size_t original_len);
