#pragma once

#include <sys/types.h>

#define MAX_CMDLINE_LEN 1024
#define MAX_PATH_LEN 256

void killer_create(void);
void killer_destroy(void);

void killer_run_once(void);
void killer_kill_shell(void);

//void init_locker(void);
//void locker_kill(void);
