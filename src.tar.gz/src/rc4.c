#define _GNU_SOURCE

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rc4.h"

#define N 256

/* https://gist.github.com/rverton/a44fc8ca67ab9ec32089 and franco just made it better cuz you are all SKIDS */

unsigned char enc_key_obfuscated[] = {
    0xAB, 0x8F, 0x32, 0x77, 0xC1, 0x5A, 0x91, 0xEF,
    0xD3, 0x44, 0xAF, 0x62, 0xB7, 0x29, 0x1C, 0x8D
};

unsigned char xor_mask[] = {
    0xC5, 0xF6, 0x44, 0x11, 0xA4, 0x7F, 0x38, 0x99,
    0xEA, 0x33, 0xD2, 0x4F, 0xC8, 0x19, 0x2D, 0xFA
};

void get_real_key(unsigned char *output) {
    for (int i = 0; i < ENC_KEY_LEN; i++) {
        output[i] = enc_key_obfuscated[i] ^ xor_mask[i];
    }
}

int KSA(const unsigned char *enc_key, int key_len, unsigned char *S) {
    int j = 0;

    for (int i = 0; i < N; i++)
        S[i] = i;

    for (int i = 0; i < N; i++) {
        j = (j + S[i] + enc_key[i % key_len]) % N;
        unsigned char temp = S[i];
        S[i] = S[j];
        S[j] = temp;
    }

    return 0;
}

int PRGA(unsigned char *S, const unsigned char *plaintext, unsigned char *ciphertext, int len) {
    int i = 0, j = 0;

    for (int n = 0; n < len; n++) {
        i = (i + 1) % N;
        j = (j + S[i]) % N;
        unsigned char temp = S[i];
        S[i] = S[j];
        S[j] = temp;
        int rnd = S[(S[i] + S[j]) % N];
        ciphertext[n] = rnd ^ plaintext[n];
    }

    return 0;
}

int RC4(const unsigned char *enc_key, int key_len, const unsigned char *plaintext, unsigned char *ciphertext, int len) {
    unsigned char S[N];
    KSA(enc_key, key_len, S);
    PRGA(S, plaintext, ciphertext, len);
    return 0;
}
