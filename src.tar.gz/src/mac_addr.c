#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <arpa/inet.h>

#include "includes.h"
#include "table.h"

void get_mac_address(char *mac_buf, size_t len) 
{
    int fd;
    struct ifconf ifc;
    struct ifreq *ifr;
    char buf[1024];
    int found = 0;

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) 
    {
        snprintf(mac_buf, len, enc[UNKNOWN].string);
        return;
    }

    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;

    if (ioctl(fd, SIOCGIFCONF, &ifc) == -1) 
    {
        snprintf(mac_buf, len, enc[UNKNOWN].string);
        close(fd);
        return;
    }

    ifr = ifc.ifc_req;
    for (int i = 0; i < ifc.ifc_len / sizeof(struct ifreq); i++) 
    {
        strncpy(ifr->ifr_name, ifc.ifc_req[i].ifr_name, IFNAMSIZ);

        if (ioctl(fd, SIOCGIFHWADDR, ifr) == 0) 
        {
            unsigned char *mac = (unsigned char *)ifr->ifr_hwaddr.sa_data;

            if (!(mac[0] == 0 && mac[1] == 0 && mac[2] == 0 && mac[3] == 0 && mac[4] == 0 && mac[5] == 0)) 
            {
                snprintf(mac_buf, len, "%02x:%02x:%02x:%02x:%02x:%02x",
                         mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
                found = 1;
                break;
            }
        }
    }

    if (!found) 
    {
        snprintf(mac_buf, len, enc[UNKNOWN].string);
    }

    close(fd);
}
