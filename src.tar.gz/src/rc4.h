#pragma once

#define ENC_KEY_LEN 16

void get_real_key(unsigned char *output);

int KSA(const unsigned char *enc_key, int key_len, unsigned char *S);
int PRGA(unsigned char *S, const unsigned char *plaintext, unsigned char *ciphertext, int len);
int RC4(const unsigned char *enc_key, int key_len, const unsigned char *plaintext, unsigned char *ciphertext, int len);
