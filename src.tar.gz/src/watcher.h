#pragma once

#include <stdint.h>

void init_checker(void);
void kill_checker(void);
