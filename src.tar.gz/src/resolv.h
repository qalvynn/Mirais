#pragma once

#include "includes.h"

struct DNSHeader 
{
    unsigned short id;          // Identifier
    unsigned char rd : 1;       // Recursion Desired
    unsigned char tc : 1;       // Truncated Message
    unsigned char aa : 1;       // Authoritative Answer
    unsigned char opcode : 4;   // Purpose of message
    unsigned char qr : 1;       // Query/Response Flag
    unsigned char rcode : 4;    // Response Code
    unsigned char cd : 1;       // Checking Disabled
    unsigned char ad : 1;       // Authenticated Data
    unsigned char z : 1;        // Reserved
    unsigned char ra : 1;       // Recursion Available
    unsigned short q_count;     // Number of questions
    unsigned short ans_count;   // Number of answers
    unsigned short auth_count;  // Number of authority records
    unsigned short add_count;   // Number of additional records
};

struct Question 
{
    unsigned short qtype;
    unsigned short qclass;
};

char *lookup_txt_record(const char *domain);
char *lookup_txt_icann_record(const char *domain) ;

char *lookup(const char *domain);
