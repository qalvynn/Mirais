#pragma once
#include <stdint.h>

enum 
{
	PHI = 0x9e3779b9
};

uint32_t rand_next(void);
uint32_t rand_real(void);
uint32_t rand_cmwc(void);
uint32_t rand_new(void);

void rand_init(void);
void rand_str(char *, int);

uint32_t rand_next_range(uint32_t, uint32_t);
void rand_smart_str(uint8_t *, int);
void rand_packet(char *, int);
