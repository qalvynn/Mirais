#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "table.h"

static int base64_char_value(char c) 
{
    if ('A' <= c && c <= 'Z') return c - 'A';
    if ('a' <= c && c <= 'z') return c - 'a' + 26;
    if ('0' <= c && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

char *base64_decode(const char *base64_str) 
{
    size_t len = strlen(base64_str);
    if (len % 4 != 0) return NULL;

    size_t out_len = len / 4 * 3;
    if (base64_str[len - 1] == '=') out_len--;
    if (base64_str[len - 2] == '=') out_len--;

    char *decoded_data = malloc(out_len + 1);
    if (!decoded_data) return NULL;

    size_t i, j;
    int val;
    for (i = 0, j = 0; i < len; i += 4) 
    {
        val = (base64_char_value(base64_str[i]) << 18) |
              (base64_char_value(base64_str[i + 1]) << 12) |
              (base64_char_value(base64_str[i + 2]) << 6) |
              base64_char_value(base64_str[i + 3]);

        decoded_data[j++] = (val >> 16) & 0xFF;
        if (base64_str[i + 2] != '=') decoded_data[j++] = (val >> 8) & 0xFF;
        if (base64_str[i + 3] != '=') decoded_data[j++] = val & 0xFF;
    }

    decoded_data[j] = '\0';
    return decoded_data;
}

char *base64_decode_xor(const char *base64_str, size_t original_len) 
{
    size_t len = strlen(base64_str);
    if (len % 4 != 0) return NULL;

    size_t out_len = (len / 4) * 3;
    if (base64_str[len - 1] == '=') out_len--;
    if (base64_str[len - 2] == '=') out_len--;

    if (out_len > original_len) out_len = original_len;

    char *decoded_data = malloc(out_len + 1);
    if (!decoded_data) return NULL;

    size_t i, j = 0;
    int val;
    for (i = 0; i < len; i += 4) {
        val = (base64_char_value(base64_str[i]) << 18) |
              (base64_char_value(base64_str[i + 1]) << 12) |
              ((base64_str[i + 2] == '=') ? 0 : (base64_char_value(base64_str[i + 2]) << 6)) |
              ((base64_str[i + 3] == '=') ? 0 : base64_char_value(base64_str[i + 3]));

        if (j < out_len) decoded_data[j] = ((val >> 16) & 0xFF) ^ enc[XOR_KEY].string[j % 32];
        if (j + 1 < out_len) decoded_data[j + 1] = ((val >> 8) & 0xFF) ^ enc[XOR_KEY].string[(j + 1) % 32];
        if (j + 2 < out_len) decoded_data[j + 2] = (val & 0xFF) ^ enc[XOR_KEY].string[(j + 2) % 32];
        j += 3;
    }

    decoded_data[out_len] = '\0';
    return decoded_data;
}
