//#pragma once
//
//#include "includes.h"
//#define TIMEOUT_MS 100000
//
//char *dns_over_tls_query(const char *domain);
//char *parse_dot_record(unsigned char *response, int response_size);
