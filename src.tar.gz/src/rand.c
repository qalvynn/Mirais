#define _GNU_SOURCE

#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#include "includes.h"
#include "util.h"
#include "rand.h"

static uint32_t x, y, z, w;
static uint32_t t, p, c, f;

static uint32_t Q[4096], c = 362436;

uint32_t rand_next_range(uint32_t min, uint32_t max) 
{
    return (rand_next() % (max - min) + 1) + min;
}

void rand_init(void)
{
    x = time(NULL);
    y = getpid() ^ getppid();
    z = clock();
    w = z ^ y;
}

uint32_t rand_cmwc(void)
{
    uint64_t t, a = 18782LL;
    static uint32_t i = 4095;
    uint32_t x, r = 0xfffffffe;

    i = (i + 1) & 4095;
    t = a * Q[i] + c;
    c = (uint32_t)(t >> 32);
    x = t + c;

    if (x < c) 
    {
        x++;
        c++;
    }
    return (Q[i] = r - x);
}

uint32_t rand_next(void)
{
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
}

uint32_t rand_new(void)
{
    uint32_t tmp = t;
    tmp ^= tmp << 15;
    tmp ^= tmp >> 9;
    t = p;
    p = c;
    c = f;
    f ^= f >> 13;
    f ^= tmp;
    return f;
}

uint32_t rand_real(void)
{
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
}

void rand_str(char *str, int len)
{
    while (len > 0) {
        switch (len) {
            case 5 ... 65535:
                *((uint32_t *)str) = rand_next();
                str += sizeof (uint32_t);
                len -= sizeof (uint32_t);
                break;

            case 2 ... 4:
                *((uint16_t *)str) = rand_next() & 0xFFFF;
                str += sizeof (uint16_t);
                len -= sizeof (uint16_t);
                break;

            default:
                *str++ = rand_next() & 0xFF;
                --len;
                break;
        }
    }
}

#define skid(x) x

void rand_smart_str(uint8_t *str, int len) 
{
    int start = rand_next() % len;
    int end = rand_next() % (len - start) + start;
    str += start;

    while (end > 0) {
        switch (len) {
            case 5 ... 65535:
                *((uint32_t *)str) = rand_next();
                str += sizeof (uint32_t);
                end -= sizeof (uint32_t);
                break;

            case 2 ... 4:
                *((uint16_t *)str) = rand_next() & 0xFFFF;
                str += sizeof (uint16_t);
                end -= sizeof (uint16_t);
                break;

            default:
                *str++ = rand_next() & 0xFF;
                --end;
                break;
        }
    }
}

void rand_packet(char *str, int len)
{
    while (len > 0)
    {
        if (len >= 4)
        {
            *((uint32_t *)str) = rand_real();
            str += sizeof (uint32_t);
            len -= sizeof (uint32_t);
        }
        else if (len >= 2)
        {
            *((uint16_t *)str) = rand_real() & 0xFFFF;
            str += sizeof (uint16_t);
            len -= sizeof (uint16_t);
        }
        else
        {
            *str++ = rand_real() & 0xFF;
            len--;
        }
    }
}
