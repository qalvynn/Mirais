//#include <arpa/inet.h>
//#include <stdint.h>
//#include <netinet/in.h>
//#include <stdint.h>
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <time.h>
//#include <poll.h>
//
//#include "mbedtls/ctr_drbg.h"
//#include "mbedtls/entropy.h"
//#include "mbedtls/error.h"
//#include "mbedtls/net_sockets.h"
//#include "mbedtls/ssl.h"
//
//#include "dot.h"
//#include "base64.h"
//#include "util.h"
//
//#define BUFFER_SIZE 512
//
//struct dns_hdr {
//  uint16_t id;
//  uint8_t rd : 1;
//  uint8_t tc : 1;
//  uint8_t aa : 1;
//  uint8_t opcode : 4;
//  uint8_t qr : 1;
//  uint8_t rcode : 4;
//  uint8_t z : 3;
//  uint8_t ra : 1;
//  uint16_t q_count;
//  uint16_t ans_count;
//  uint16_t auth_count;
//  uint16_t add_count;
//};
//
//struct dns_question {
//  uint16_t qtype;
//  uint16_t qclass;
//};
//
//int construct_dot_query(const char *domain, unsigned char *query, size_t query_size) {
//  struct dns_hdr *dns = (struct dns_hdr *)query;
//  memset(query, 0, query_size);
//
//  srand(time(NULL));
//  dns->id = htons(rand() % 0xFFFF);
//  dns->qr = 0;
//  dns->opcode = 0;
//  dns->aa = 0;
//  dns->tc = 0;
//  dns->rd = 1;
//  dns->ra = 0;
//  dns->z = 0;
//  dns->rcode = 0;
//  dns->q_count = htons(1);
//
//  unsigned char *qname = query + sizeof(struct dns_hdr);
//  const char *start = domain;
//  while (*start) {
//    const char *dot = strchr(start, '.');
//    if (!dot) dot = start + strlen(start);
//    *qname++ = dot - start;
//    memcpy(qname, start, dot - start);
//    qname += dot - start;
//    start = (*dot) ? dot + 1 : dot;
//  }
//  *qname++ = 0;
//
//  struct dns_question *qinfo = (struct dns_question *)qname;
//  qinfo->qtype = htons(16);
//  qinfo->qclass = htons(1);
//
//  return qname - query + sizeof(struct dns_question);
//}
//char *parse_dot_record(unsigned char *response, int response_size) {
//    int pos = 12;
//    uint16_t answer_count = ntohs(*(uint16_t *)(response + 6));
//
//    if (answer_count == 0) {
//        return NULL;
//    }
//
//    // Skip the question section
//    while (response[pos] != 0)
//        pos++;
//    pos += 5;
//
//    char *txt_records = malloc(1024); // Buffer for storing TXT records
//    if (!txt_records) return NULL;
//    txt_records[0] = '\0';
//
//    for (int i = 0; i < answer_count; i++) {
//        if ((response[pos] & 0xC0) == 0xC0) {
//            pos += 2;
//        } else {
//            while (response[pos] != 0)
//                pos++;
//            pos++;
//        }
//
//        uint16_t type = ntohs(*(uint16_t *)(response + pos));
//        uint16_t rd_length = ntohs(*(uint16_t *)(response + pos + 8));
//        pos += 10;
//
//        if (type != 16) {
//            pos += rd_length;
//            continue;
//        }
//
//        if (rd_length < 1 || pos + rd_length > response_size) {
//            free(txt_records);
//            return NULL;
//        }
//
//        int offset = 0;
//        while (offset < rd_length) {
//            uint8_t txt_len = response[pos + offset];
//
//            if (txt_len == 0 || (offset + txt_len + 1) > rd_length) {
//                free(txt_records);
//                return NULL;
//            }
//
//            strncat(txt_records, (char *)&response[pos + offset + 1], txt_len);
//            strcat(txt_records, "|");  // Use '|' as a separator
//
//            offset += txt_len + 1;
//        }
//
//        pos += rd_length;
//    }
//
//    return txt_records;
//}
//
//char *dns_over_tls_query(const char *domain) {
//    mbedtls_net_context server_fd;
//    mbedtls_ssl_context ssl;
//    mbedtls_ssl_config conf;
//    mbedtls_entropy_context entropy;
//    mbedtls_ctr_drbg_context ctr_drbg;
//    struct pollfd pfd;
//
//    unsigned char query[BUFFER_SIZE];
//    unsigned char response[BUFFER_SIZE];
//    int query_len = construct_dot_query(domain, query, sizeof(query));
//
//    char *pers = "dns_tls";
//    mbedtls_net_init(&server_fd);
//    mbedtls_ssl_init(&ssl);
//    mbedtls_ssl_config_init(&conf);
//    mbedtls_ctr_drbg_init(&ctr_drbg);
//    mbedtls_entropy_init(&entropy);
//
//    mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, (const unsigned char *)pers, strlen(pers));
//
//    const char* resolver_ip = _select_dot_resolver();
//    if (!resolver_ip) {
//        return NULL;
//    }
//
//    if (mbedtls_net_connect(&server_fd, resolver_ip, base64_decode_xor("YlgF", 3), MBEDTLS_NET_PROTO_TCP) != 0) {
//        return NULL;
//    }
//
//    if (mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT) != 0) {
//        return NULL;
//    }
//
//    mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_NONE);
//    mbedtls_ssl_conf_rng(&conf, mbedtls_ctr_drbg_random, &ctr_drbg);
//    mbedtls_ssl_setup(&ssl, &conf);
//    mbedtls_ssl_set_bio(&ssl, &server_fd, mbedtls_net_send, mbedtls_net_recv, NULL);
//
//    if (mbedtls_ssl_handshake(&ssl) != 0) {
//        return NULL;
//    }
//
//    uint16_t len = htons(query_len);
//
//    // Configure poll for writing
//    pfd.fd = server_fd.fd;
//    pfd.events = POLLOUT;
//
//    // Wait until socket is ready to send
//    if (poll(&pfd, 1, TIMEOUT_MS) <= 0) {
//        return NULL; // Timeout or error
//    }
//
//    if (mbedtls_ssl_write(&ssl, (uint8_t *)&len, sizeof(len)) <= 0) {
//        return NULL;
//    }
//
//    if (mbedtls_ssl_write(&ssl, query, query_len) < 0) {
//        return NULL;
//    }
//
//    // Configure poll for reading
//    pfd.events = POLLIN;
//
//    // Wait until socket is ready to read
//    if (poll(&pfd, 1, TIMEOUT_MS) <= 0) {
//        return NULL; // Timeout or error
//    }
//
//    int ret;
//    if ((ret = mbedtls_ssl_read(&ssl, (uint8_t *)&len, sizeof(uint16_t))) <= 0) {
//        return NULL;
//    }
//
//    if (poll(&pfd, 1, TIMEOUT_MS) <= 0) {
//        return NULL; // Timeout or error
//    }
//
//    if ((ret = mbedtls_ssl_read(&ssl, response, ntohs(len))) <= 0) {
//        return NULL;
//    }
//
//    char *txt_record = parse_dot_record(response, ret);
//
//    mbedtls_ssl_close_notify(&ssl);
//    mbedtls_ssl_free(&ssl);
//    mbedtls_net_free(&server_fd);
//    mbedtls_ssl_config_free(&conf);
//    mbedtls_ctr_drbg_free(&ctr_drbg);
//    mbedtls_entropy_free(&entropy);
//
//    return txt_record;
//}
